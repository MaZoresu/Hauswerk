/* Hauswerk – Panel für Home Assistant (Module: Heizwerk, Rollwerk, Kraftwerk; Licht, Garten geplant). Eigenständige Web-Komponente, kein Build nötig. */

const VERSION = "0.68.0";
const DAYS = ["Mo", "Di", "Mi", "Do", "Fr", "Sa", "So"];
const TYPES = {
  heizkoerper: {
    label: "Heizkörper",
    icon: "mdi:radiator",
    text: "Reagiert schnell. Kurze Fensterverzögerung, kurzes Vorheizen, Absenken lohnt sich.",
  },
  flaeche: {
    label: "Flächenheizung",
    icon: "mdi:heating-coil",
    text: "Fußboden- oder Wandheizung, sehr träge. Lange Fensterverzögerung, frühes Vorheizen, nur geringe Absenkung.",
  },
};
/** Farbsprache – überall gleich: Kacheln, Kopfkacheln, Hinweise, Widgets. */
const C = {
  ok: "#22c55e",     // läuft wie gewollt, fertig
  warm: "#f97316",   // Wärme: heizt, Beschattung, Kamin
  sun: "#f59e0b",    // Sonne und Hinweis: Tür offen, lange offen, Ende wird geprüft
  air: "#22d3ee",    // Fenster und Lüften
  cool: "#38bdf8",   // kühl, Frost, sparen, Gerät läuft
  hand: "#8b5cf6",   // von Hand
  alert: "#ef4444",  // Achtung: Sturm, Fenster schließen, Schimmel, Batterie
  rest: "#94a3b8",   // Ruhe, aus, ohne Automatik
};
const COLOR_LEGEND = [
  [C.ok, "Grün", "läuft wie gewollt, fertig"],
  [C.warm, "Orange", "Wärme – heizt, Beschattung, Kamin"],
  [C.sun, "Gelb", "Sonne und Hinweise – Tür offen, lange offen"],
  [C.air, "Türkis", "Fenster und Lüften"],
  [C.cool, "Hellblau", "kühl, Frost, sparen, Gerät läuft"],
  [C.hand, "Violett", "von Hand verstellt"],
  [C.alert, "Rot", "Achtung – bitte handeln"],
  [C.rest, "Grau", "Ruhe, aus, Automatik aus"],
];
const MODE = {
  komfort: { c: "#fbbf24", i: "mdi:sofa-outline" },
  vorheizen: { c: "#fb923c", i: "mdi:clock-fast" },
  eco: { c: "#60a5fa", i: "mdi:leaf" },
  fenster: { c: "#22d3ee", i: "mdi:window-open-variant" },
  manuell: { c: "#8b5cf6", i: "mdi:hand-back-right-outline" },
  urlaub: { c: "#34d399", i: "mdi:palm-tree" },
  abwesend: { c: "#94a3b8", i: "mdi:home-export-outline" },
  aus: { c: "#6b7280", i: "mdi:power" },
  entkalken: { c: "#38bdf8", i: "mdi:water-sync" },
  sommer: { c: "#facc15", i: "mdi:weather-sunny" },
  boost: { c: "#f43f5e", i: "mdi:rocket-launch-outline" },
  party: { c: "#e879f9", i: "mdi:party-popper" },
  leer: { c: "#64748b", i: "mdi:account-off-outline" },
  belegt: { c: "#fbbf24", i: "mdi:account-check-outline" },
  warm: { c: "#f97316", i: "mdi:thermometer-check" },
  eco_fix: { c: "#22c55e", i: "mdi:leaf-circle-outline" },
  frost: { c: "#38bdf8", i: "mdi:snowflake-thermometer" },
};
/** Symbol-Legende: [Gruppe, Symbol, Farbe, Kurzname, Erklärung, Text am Symbol (optional)] – Quelle für das „?“-Fenster. */
const LEGEND = [
  ["Heizwerk", "mdi:fire", C.warm, "Heizt", "Das Thermostat fordert gerade Wärme an."],
  ["Heizwerk", "mdi:sofa-outline", "#fbbf24", "Komfort", "Heizplan: Wohlfühltemperatur."],
  ["Heizwerk", "mdi:leaf", "#60a5fa", "Eco", "Heizplan: abgesenkt, spart Energie."],
  ["Heizwerk", "mdi:clock-fast", "#fb923c", "Vorheizen", "Heizt schon vor, damit es zur Komfortzeit warm ist."],
  ["Heizwerk", "mdi:hand-back-right-outline", C.hand, "Von Hand", "Temperatur von Hand gesetzt – gilt bis zur angezeigten Zeit, dann wieder der Plan."],
  ["Heizwerk", "mdi:rocket-launch-outline", "#f43f5e", "Boost", "Kurz volle Leistung."],
  ["Heizwerk", "mdi:home-export-outline", C.rest, "Abwesend", "Niemand zu Hause – höchstens die Abwesend-Temperatur."],
  ["Heizwerk", "mdi:palm-tree", "#34d399", "Urlaub", "Urlaubstemperatur."],
  ["Heizwerk", "mdi:weather-sunny", "#facc15", "Sommerpause", "Heizperiode vorbei – Thermostate ruhen."],
  ["Heizwerk", "mdi:snowflake-thermometer", C.cool, "Frostschutz", "Nur Schutz vor Frost."],
  ["Heizwerk", "mdi:power", "#6b7280", "Automatik aus", "Heizwerk stellt in diesem Raum nichts ein."],
  ["Heizwerk", "mdi:account-check-outline", "#fbbf24", "Jemand im Raum", "Präsenzmelder meldet: belegt."],
  ["Heizwerk", "mdi:account-off-outline", C.rest, "Niemand im Raum", "Präsenzmelder meldet: leer."],
  ["Heizwerk", "mdi:valve", C.warm, "Ventil", "Öffnung des Heizkörperventils in % (grau = zu).", "42 %"],
  ["Heizwerk", "mdi:heating-coil", C.warm, "Fußbodenheizung heizt", "Nur sichtbar, solange sie heizt."],
  ["Heizwerk", "mdi:radiator", C.warm, "Heizkörper hilft nach", "Mischbetrieb: der Heizkörper unterstützt die Fußbodenheizung."],
  ["Heizwerk", "mdi:fireplace", C.warm, "Kamin an", "Von Hand oder laut Signal – zählt nicht für die Bewertung der Heizleistung."],
  ["Heizwerk", "mdi:fireplace", C.rest, "Wärmer ohne Heizung", "Vielleicht der Kamin, die Sonne oder Kochen – sicher ist das nicht.", "?"],
  ["Heizwerk", "mdi:fireplace", "#fdba74", "Nachwärme", "Nach dem Kamin noch wärmer als gewollt."],
  ["Heizwerk", "mdi:radiator-off", C.alert, "Heizkörper bleibt kalt", "Ventil offen, Raum wird nicht wärmer – Luft, Ventilstift oder Heizung prüfen."],
  ["Heizwerk", "mdi:battery-alert-variant-outline", C.alert, "Batterie schwach", "Batterie eines Thermostats oder Sensors bald leer."],
  ["Lüften", "mdi:window-open-variant", C.air, "Fenster offen", "Fensterpause – Thermostate auf Frostschutz bzw. aus."],
  ["Lüften", "mdi:weather-windy", C.air, "Jetzt lüften", "Empfohlen, mit Dauer (Feuchte, CO₂, morgens).", "10 Min."],
  ["Lüften", "mdi:timer-sand", C.ok, "Lüften läuft", "Countdown bis genug gelüftet ist.", "4/10 Min."],
  ["Lüften", "mdi:window-closed-variant", C.alert, "Fenster schließen", "Genug gelüftet."],
  ["Lüften", "mdi:window-open-variant", C.sun, "Lange offen", "Kippen kostet Wärme – lieber kurz stoßlüften.", "45 Min."],
  ["Lüften", "mdi:snowflake", C.cool, "Kühlt", "Sommer: Fenster offen zum Kühlen."],
  ["Lüften", "mdi:alert-octagon-outline", C.alert, "Schimmelgefahr", "An der Außenwand sehr feucht."],
  ["Rollwerk", "mdi:white-balance-sunny", C.sun, "Sonne aufs Fenster", "Die Sonne scheint gerade wirklich aufs Fenster."],
  ["Rollwerk", "mdi:sun-thermometer-outline", C.warm, "Beschattung", "Sonnenschutz aktiv bzw. ab der angezeigten Zeit."],
  ["Rollwerk", "mdi:weather-windy-variant", C.alert, "Sturm", "Sturmschutz – alle Rollläden oben."],
  ["Rollwerk", "mdi:door-open", C.sun, "Tür offen", "Aussperrschutz – fährt nicht herunter."],
  ["Rollwerk", "mdi:window-open-variant", C.air, "Fenster gekippt", "Lüftungsstellung."],
  ["Rollwerk", "mdi:hand-back-right-outline", C.hand, "Von Hand", "Von Hand verstellt – die Automatik wartet bis zum nächsten Wechsel."],
  ["Rollwerk", "mdi:robot-off-outline", C.rest, "Automatik aus", "Rollwerk fährt diesen Rollladen nicht."],
  ["Rollwerk", "mdi:battery-alert-variant-outline", C.alert, "Batterie schwach", "Batterie am Rollladen bald leer."],
  ["Lichtwerk", "mdi:lightbulb-on", "#facc15", "Licht an", "In der echten Lichtfarbe; Prozent = Helligkeit."],
  ["Lichtwerk", "mdi:lightbulb-outline", C.rest, "Licht aus", ""],
  ["Lichtwerk", "mdi:hand-back-right-outline", C.hand, "Von Hand", "Von Hand geschaltet – die Automatik wartet bis zum nächsten Wechsel (oder die im Profil eingestellte Zeit)."],
  ["Lichtwerk", "mdi:motion-sensor", C.ok, "Bewegung", "Licht an durch Bewegung – aus nach der Wartezeit ohne Bewegung."],
  ["Lichtwerk", "mdi:weather-night", "#6366f1", "Nachtlicht", "Gedimmt im Nachtlicht-Zeitraum des Profils."],
  ["Lichtwerk", "mdi:lightbulb-alert-outline", C.alert, "Nicht erreichbar", "Leuchte meldet sich nicht (Funk, Strom, ausgeschaltet am Schalter)."],
  ["Kraftwerk", "mdi:power-sleep", "#64748b", "Bereit", "Gerät wartet auf den nächsten Durchlauf."],
  ["Kraftwerk", "mdi:play-circle-outline", C.cool, "Läuft", "Mit Restzeit aus den gelernten Durchläufen."],
  ["Kraftwerk", "mdi:timer-sand", C.sun, "Ende wird geprüft", "Ruhe erkannt – ist es eine Pause oder fertig?"],
  ["Kraftwerk", "mdi:check-circle", C.ok, "Fertig", "Bitte ausräumen – „Gesehen“ quittiert."],
  ["Kraftwerk", "mdi:solar-power-variant", C.sun, "Solar", "Erzeugung der Solaranlage."],
  ["Allgemein", "mdi:bell-badge-outline", C.sun, "Hinweise", "Oben rechts: Hinweise aller Module, rot = Achtung."],
  ["Allgemein", "mdi:account-group-outline", "#e879f9", "Gäste / Party", "Gilt fürs ganze Haus."],
];
/** Anlässe für Benachrichtigungen: k = Einstellung notify_<k>, g = Modul, def = Standard, ex = Beispielmeldung. */
const NK_KINDS = [
  { k: "window", g: "Heizwerk", icon: "mdi:window-open-variant", c: C.air, title: "Fenster lange offen", def: "normal", ex: ["Fenster lange offen", "Wohnzimmer: seit 30 Min. offen"], text: "Steht ein Fenster so lange offen, kommt eine Nachricht – einmal je Öffnen." },
  { k: "offline", g: "Heizwerk", icon: "mdi:thermostat", c: C.alert, title: "Thermostat nicht erreichbar", def: "normal", ex: ["Thermostat nicht erreichbar", "Heizkörper Bad (Bad) seit 15 Min."], text: "Meldet sich ein Thermostat so lange nicht (Funk, Batterie). Kommt es zurück, ist die Sache erledigt." },
  { k: "frost", g: "Heizwerk", icon: "mdi:snowflake-thermometer", c: C.cool, title: "Frost erwartet", def: "normal", ex: ["Frost erwartet", "Tiefstwert −4 °C morgen (Grenze 0 °C)"], text: "Die Vorhersage der nächsten 3 Tage liegt unter der Grenze „Kälteeinbruch“ (Hauswerk › Wetter)." },
  { k: "battery", g: "Heizwerk", icon: "mdi:battery-alert-variant-outline", c: C.alert, title: "Batterie schwach", def: "normal", ex: ["Batterie schwach", "Fensterkontakt Bad (Bad): 12 %"], text: "Batterien an Thermostaten, Fensterkontakten und Raumsensoren. Die Grenze gilt auch für die Glocke." },
  { k: "cold", g: "Heizwerk", icon: "mdi:radiator-off", c: C.alert, title: "Heizkörper bleibt kalt", def: "normal", ex: ["Heizkörper bleibt kalt", "Küche: Ventil seit 1 Std. offen, Raum wird nicht wärmer"], text: "Ventil eine Stunde ≥ 90 % offen, Raum unter Soll und wird nicht wärmer – Luft, Ventilstift oder Heizung prüfen." },
  { k: "vent", g: "Lüften", icon: "mdi:weather-windy", c: C.air, title: "Lüften empfohlen", def: "off", ex: ["Lüften empfohlen", "Bad: Luftfeuchte 72 % – 10 Min. stoßlüften"], text: "Feucht, Schimmelgefahr, CO₂ oder morgens – mit empfohlener Dauer, einmal je Anlass." },
  { k: "vent_done", g: "Lüften", icon: "mdi:window-closed-variant", c: C.alert, title: "Fenster schließen", def: "normal", ex: ["Fenster schließen", "Bad: genug gelüftet (10 Min. um)"], text: "Zeit um, Feuchte gesunken oder Raum ausgekühlt." },
  { k: "storm", g: "Rollwerk", icon: "mdi:weather-windy-variant", c: C.alert, title: "Sturm", def: "normal", ex: ["Sturm – Rollläden fahren hoch", "Böen 82 km/h (Grenze 70 km/h)"], text: "Der Sturmschutz fährt alle Rollläden hoch. Erledigt, sobald er endet." },
  { k: "cover", g: "Rollwerk", icon: "mdi:window-shutter-alert", c: C.alert, title: "Rollladen nicht erreichbar", def: "normal", ex: ["Rollladen nicht erreichbar", "Küche links meldet sich seit 15 Min. nicht – Funk oder Strom prüfen"], text: "Ein Rollladen meldet sich so lange nicht (gleiche Zeit wie bei Thermostaten)." },
  { k: "light_away", g: "Lichtwerk", icon: "mdi:home-lightbulb-outline", c: "#6366f1", title: "Licht an, niemand zu Hause", def: "normal", ex: ["Licht an, niemand zu Hause", "Wohnzimmer, Küche – brennt seit 30 Min."], text: "Brennt Licht so lange (Lichtwerk › Einstellungen), obwohl niemand zu Hause ist – nicht im Urlaub mit Anwesenheits-Simulation." },
  { k: "light_offline", g: "Lichtwerk", icon: "mdi:lightbulb-alert-outline", c: C.alert, title: "Leuchte nicht erreichbar", def: "log", ex: ["Leuchte nicht erreichbar", "Flur OG meldet sich seit 15 Min. nicht"], text: "Eine Leuchte aus Lichtwerk meldet sich so lange nicht (gleiche Zeit wie bei Thermostaten)." },
  { k: "waste", g: "Hauswerk", icon: "mdi:trash-can-outline", c: "#64748b", title: "Müllabfuhr morgen", def: "off", ex: ["Morgen Müllabfuhr", "Restabfall, Papier – Tonne heute Abend rausstellen."], text: "Am Vorabend ab der Uhrzeit unter Hauswerk › Kalender › Müllabholung, einmal je Abholtag." },
];
const NK_GROUPS = { Heizwerk: ["#f97316", "logo:heizen"], "Lüften": ["#22d3ee", "mdi:weather-windy"], Rollwerk: ["#0ea5e9", "logo:rollwerk"], Kraftwerk: ["#eab308", "logo:kraftwerk"], Lichtwerk: ["#6366f1", "logo:lichtwerk"], Hauswerk: ["#14b8a6", "mdi:home-outline"] };
const NK_GICON = { App: "mdi:cellphone", Pushover: "mdi:message-badge-outline", Telegram: "mdi:send-circle-outline", "E-Mail": "mdi:email-outline", Sprachausgabe: "mdi:account-voice", Bildschirm: "mdi:tablet", Weitere: "mdi:bell-outline", "Home Assistant": "mdi:home-assistant" };
/** Kanäle eines Kraftwerk-Geräts (alte Einträge: nur Dienstname, notify_ha). */
const appChannels = (a) => [...new Set([...(a.notify || []).map((x) => (x.includes(":") || x === "ha" ? x : `svc:${x}`)), ...(a.notify_ha ? ["ha"] : [])])];
/** Raum-Icon aus dem Namen erraten (reihenfolgeabhängig: spezielle Begriffe zuerst). */
const ROOM_GUESS = [
  [/wc|toilette|klo/, "mdi:toilet"],
  [/bad|dusche/, "mdi:shower-head"],
  [/küche|kueche|kochen/, "mdi:stove"],
  [/wohn|lounge/, "mdi:sofa-outline"],
  [/schlaf|eltern/, "mdi:bed-king-outline"],
  [/kind|baby|jugend/, "mdi:teddy-bear"],
  [/arbeit|büro|buero|office|studio/, "mdi:desk"],
  [/ess/, "mdi:silverware-fork-knife"],
  [/flur|diele|gang|eingang|treppe/, "mdi:door"],
  [/gäste|gaeste|gast/, "mdi:bed-outline"],
  [/keller|hauswirtschaft|wasch/, "mdi:washing-machine"],
  [/dach|speicher|boden/, "mdi:home-roof"],
  [/wintergarten|garten/, "mdi:flower-outline"],
  [/hobby|werkstatt|werk/, "mdi:hammer-wrench"],
  [/ankleide|garderobe/, "mdi:hanger"],
  [/sport|fitness/, "mdi:dumbbell"],
  [/garage/, "mdi:garage"],
];
const ROOM_ICON_CHOICES = [...new Set(ROOM_GUESS.map(([, i]) => i)), "mdi:radiator", "mdi:heating-coil", "mdi:television", "mdi:music", "mdi:book-open-variant", "mdi:paw"];
const roomIcon = (room) => {
  if (room.icon) return room.icon;
  const n = (room.name || "").toLowerCase();
  const hit = ROOM_GUESS.find(([re]) => re.test(n));
  return hit ? hit[1] : (TYPES[room.type] || TYPES.heizkoerper).icon;
};
/** Wie weit ist der Raum vom Soll entfernt? Icon, Farbe und Kurztext. */
const trend = (temp, target) => {
  if (temp == null || target == null) return null;
  const d = temp - target;
  if (Math.abs(d) < 0.3) return { i: "mdi:thermometer-check", c: "#34d399", t: "am Soll" };
  if (d < 0) return { i: "mdi:thermometer-chevron-up", c: "#fb923c", t: `${fmt(-d)} °C unter Soll` };
  return { i: "mdi:thermometer-chevron-down", c: "#60a5fa", t: `${fmt(d)} °C über Soll` };
};
const humidityInfo = (h) =>
  h == null ? null : h >= 65 ? { i: "mdi:water-alert", c: "#f59e0b", t: "feucht – lüften" } : h <= 35 ? { i: "mdi:water-off-outline", c: "#f59e0b", t: "trocken" } : { i: "mdi:water-percent", c: "var(--muted)", t: "" };
/** Wetterlage aus Home Assistant: Symbol und deutscher Text. */
const WEATHER = {
  "clear-night": ["mdi:weather-night", "Klar"],
  cloudy: ["mdi:weather-cloudy", "Bewölkt"],
  exceptional: ["mdi:alert-circle-outline", "Unwetter"],
  fog: ["mdi:weather-fog", "Nebel"],
  hail: ["mdi:weather-hail", "Hagel"],
  lightning: ["mdi:weather-lightning", "Gewitter"],
  "lightning-rainy": ["mdi:weather-lightning-rainy", "Gewitter mit Regen"],
  partlycloudy: ["mdi:weather-partly-cloudy", "Teils bewölkt"],
  pouring: ["mdi:weather-pouring", "Starkregen"],
  rainy: ["mdi:weather-rainy", "Regen"],
  snowy: ["mdi:weather-snowy", "Schnee"],
  "snowy-rainy": ["mdi:weather-snowy-rainy", "Schneeregen"],
  sunny: ["mdi:weather-sunny", "Sonnig"],
  windy: ["mdi:weather-windy", "Windig"],
  "windy-variant": ["mdi:weather-windy-variant", "Windig, bewölkt"],
};
/** Widgets der Startseite: Name, Symbol, Farbe, Beschreibung; go = Ansicht öffnen, pop = Einstellung, config = Entitäten wählen. */
const WIDGETS = {
  heat: { name: "Heizwerk", icon: "mdi:radiator", c: "#fb923c", text: "Ø-Temperatur, Kurzurteil, heizende Räume, offene Fenster und Heizstunden heute", go: "overview" },
  presence: { name: "Anwesenheit", icon: "mdi:home-account", c: "#34d399", text: "Zu Hause, Abwesend, Urlaub sowie Gäste, Party und Eco mit einem Tipp umschalten", pop: "presence" },
  weather: { name: "Wetter", icon: "mdi:weather-partly-cloudy", c: "#60a5fa", text: "Wetterlage, Außentemperatur, Wind und Luftfeuchte", pop: "weather" },
  rooms: { name: "Räume", icon: "mdi:floor-plan", c: "#2dd4bf", text: "Alle Räume als kleine Kacheln mit Temperatur und Betriebsart", size: "l", go: "overview" },
  shortcuts: { name: "Shortcuts", icon: "mdi:gesture-tap-button", c: "#a78bfa", text: "Eigene Knöpfe für Szenen, Skripte, Schalter oder Lichter", config: true },
  windows: { name: "Fenster", icon: "mdi:window-open-variant", c: "#22d3ee", text: "Welche Fenster gerade offen sind und seit wann" },
  schedule: { name: "Komfortzeiten", icon: "mdi:calendar-clock", c: "#f59e0b", text: "Wann welcher Raum als Nächstes warm wird oder absenkt" },
  report: { name: "Heizdauer", icon: "mdi:chart-bar", c: "#a78bfa", text: "Geheizte Stunden der letzten 7 Tage als Balken", go: "report" },
  values: { name: "Werte", icon: "mdi:gauge", c: "#94a3b8", text: "Beliebige Sensoren, z. B. Gaszähler, Strompreis oder Vorlauftemperatur", config: true },
  hints: { name: "Hinweise", icon: "mdi:bell-outline", c: "#f59e0b", text: "Was zu beheben ist – Thermostate, Batterien, Fenster, Kalender – mit Sprung zur Stelle" },
  power: { name: "Heizleistung", icon: "mdi:radiator", c: "#ef4444", text: "Räume, in denen die Heizung nicht reicht, knapp ist oder die Messung nicht stimmt (aus dem Bericht)", go: "report" },
  shutters: { name: "Rollläden", icon: "mdi:window-shutter", c: "#0ea5e9", text: "Wie viele offen, zu oder beschattet sind, Alle hoch/runter und von Hand verstellte Rollläden", go: "shutters" },
  energy: { name: "Energie", icon: "mdi:solar-power-variant", c: "#f59e0b", text: "Solar, Netz, Hausverbrauch und Batterie jetzt; groß mit Energiefluss und Tageswerten", go: "kwflow" },
  rwnext: { name: "Nächste Fahrten", icon: "mdi:clock-outline", c: "#38bdf8", text: "Die nächsten Fahrten heute mit Uhrzeit und die Tagesleiste", go: "shutters" },
  forecast: { name: "Wetterprognose", icon: "mdi:weather-cloudy-clock", c: "#60a5fa", text: "Die nächsten Stunden oder Tage mit Tiefst- und Höchstwerten, Regen und Frost-Hinweis", size: "l", forecast: true },
};
Object.assign(WIDGETS, {
  lage: { name: "Lage", icon: "mdi:view-dashboard-outline", c: "#2dd4bf", text: "Der Stand aller Module in je einem Satz – Heizwerk, Rollwerk, Kraftwerk – mit Sprung zum Modul" },
  events: { name: "Nächste Ereignisse", icon: "mdi:timeline-clock-outline", c: "#38bdf8", text: "Zeitleiste: Heizwechsel, Rollladen-Fahrten und Termine (Kalender wählbar)", config: true, cal: true },
  calendar: { name: "Termine", icon: "mdi:calendar-month-outline", c: "#f472b6", text: "Termine heute und morgen, z. B. Müllabfuhr – mit Symbol je Müllart", config: true, cal: true },
  vent: { name: "Lüften", icon: "mdi:weather-windy", c: "#22d3ee", text: "Wo jetzt gelüftet werden sollte (mit Dauer), laufende Lüftungen mit Countdown, Schimmelgefahr", go: "vent" },
  light: { name: "Licht", icon: "mdi:lightbulb-outline", c: "#6366f1", text: "Wie viele Lichter an sind, nächste Schaltung, Alle aus; groß mit allen Lichtern zum Schalten", go: "lights" },
});
const DEFAULT_WIDGETS = [{ type: "heat", size: "m" }, { type: "weather", size: "s" }, { type: "windows", size: "s" }, { type: "presence", size: "l" }, { type: "rooms", size: "l" }];
const SC_ICONS = { light: "mdi:lightbulb-outline", switch: "mdi:toggle-switch-outline", input_boolean: "mdi:toggle-switch-outline", script: "mdi:script-text-play-outline", scene: "mdi:palette-outline", button: "mdi:gesture-tap-button", input_button: "mdi:gesture-tap-button", fan: "mdi:fan", cover: "mdi:window-shutter", lock: "mdi:lock-outline", media_player: "mdi:speaker" };
const ROOM_COLORS = ["#2dd4bf", "#f59e0b", "#a78bfa", "#f472b6", "#60a5fa", "#a3e635", "#f87171", "#22d3ee", "#facc15", "#c084fc"];
const PICKERS = {
  climates: { scope: "room", multi: true, domains: ["climate"] },
  windows: { scope: "room", multi: true, domains: ["binary_sensor", "cover"] },
  temp_sensor: { scope: "room", multi: false, domains: ["sensor"], deviceClass: "temperature" },
  humidity_sensor: { scope: "room", multi: false, domains: ["sensor"], deviceClass: "humidity" },
  co2_sensor: { scope: "room", multi: false, domains: ["sensor"], deviceClass: "carbon_dioxide" },
  kwa_power: { scope: "pop", multi: false, domains: ["sensor"], deviceClass: "power" },
  kwa_door: { scope: "pop", multi: false, domains: ["binary_sensor"] },
  kwa_status: { scope: "pop", multi: false, domains: ["sensor", "binary_sensor", "select", "input_select"] },
  persons: { scope: "settings", multi: true, domains: ["person", "device_tracker"] },
  presence_sensor: { scope: "room", multi: false, domains: ["binary_sensor"] },
  fireplace_entity: { scope: "room", multi: false, domains: ["binary_sensor", "switch", "input_boolean", "sensor"] },
  comfort_entity: { scope: "room", multi: false, domains: ["input_number", "number", "sensor"] },
  eco_entity: { scope: "room", multi: false, domains: ["input_number", "number", "sensor"] },
  proximity_sensors: { scope: "settings", multi: true, domains: ["sensor"] },
  radio_entities: { scope: "settings", multi: true, domains: ["sensor"] },
  demand_entity: { scope: "settings", multi: false, domains: ["climate"] },
  rw_covers: { scope: "settings", multi: true, domains: ["cover"] },
  rw_wind_entity: { scope: "settings", multi: false, domains: ["sensor"] },
  kw_solar: { scope: "settings", multi: true, domains: ["sensor"], deviceClass: "power" },
  kw_grid: { scope: "settings", multi: false, domains: ["sensor"], deviceClass: "power" },
  kw_grid_export: { scope: "settings", multi: false, domains: ["sensor"], deviceClass: "power" },
  kw_battery: { scope: "settings", multi: false, domains: ["sensor"], deviceClass: "power" },
  kw_battery_soc: { scope: "settings", multi: false, domains: ["sensor"], deviceClass: "battery" },
  kw_home: { scope: "settings", multi: false, domains: ["sensor"], deviceClass: "power" },
  kw_consumers: { scope: "settings", multi: true, domains: ["sensor"], deviceClass: "power" },
  outside_sensor: { scope: "settings", multi: false, domains: ["sensor"], deviceClass: "temperature" },
  season_entity: { scope: "settings", multi: false, domains: ["input_boolean", "switch", "binary_sensor", "schedule"] },
  schedule_entity: { scope: "room", multi: false, domains: ["schedule", "calendar", "input_boolean", "binary_sensor"] },
  vacation_calendar: { scope: "settings", multi: false, domains: ["calendar"] },
  weather_entity: { scope: "settings", multi: false, domains: ["weather"] },
  tablet_wake: { scope: "settings", multi: true, domains: ["binary_sensor", "input_boolean", "switch"] },
  calendars: { scope: "settings", multi: true, domains: ["calendar"] },
  main_calendar: { scope: "settings", multi: false, domains: ["calendar"] },
  waste_calendars: { scope: "settings", multi: true, domains: ["calendar"] },
  workday_calendar: { scope: "settings", multi: false, domains: ["calendar"] },
  import_calendar: { scope: "pop", multi: false, domains: ["calendar"] },
  w_weather: { scope: "pop", multi: false, domains: ["weather"] },
  w_calendars: { scope: "pop", multi: true, domains: ["calendar"] },
  w_entities: { scope: "pop", multi: true, domains: ["sensor", "binary_sensor", "input_number", "input_select", "counter", "switch", "light", "input_boolean", "script", "scene", "button", "input_button", "fan", "cover", "lock", "media_player"] },
  plan_calendar: { scope: "plan", multi: false, domains: ["calendar"] },
  presence_schedule: { scope: "room", multi: false, domains: ["schedule", "input_boolean", "binary_sensor"] },
  calibration_entities: { scope: "room", multi: true, domains: ["number"] },
  valve_entities: { scope: "room", multi: true, domains: ["number"] },
  workday_entity: { scope: "settings", multi: false, domains: ["binary_sensor"] },
  sun_entity: { scope: "settings", multi: false, domains: ["sun"] },
  wind_sensor: { scope: "settings", multi: false, domains: ["sensor"], deviceClass: "wind_speed" },
  // Personen hinzufügen: wählt aus Personen und Trackern, die gewählten stehen schon als Chips da
  person_add: { scope: "settings", multi: true, domains: ["person", "device_tracker"], noCards: true },
  // Weitere Geräte im Raum, nur zur Anzeige (z. B. Ventil eines Heizkörper-Thermostats, Stellantrieb der Fußbodenheizung)
  show_entities: { scope: "room", multi: true, domains: ["climate", "switch", "sensor", "number", "valve", "cover", "binary_sensor", "input_boolean"] },
};
// Entitätssuche: Wörter im Namen, die zum Feld passen, und passende Geräteklassen
const PICK_HINTS = {
  kw_solar: ["pv", "solar", "photovoltaik", "wechselrichter", "inverter"],
  kw_grid: ["netz", "grid", "bezug", "einspeis", "zähler", "meter"],
  kw_grid_export: ["einspeis", "export", "feed"],
  kw_battery: ["batterie", "battery", "akku", "speicher"],
  kw_battery_soc: ["batterie", "battery", "akku", "speicher", "soc", "ladestand"],
  kw_home: ["haus", "home", "verbrauch", "load", "last"],
  climates: ["thermostat", "heizung", "heizkörper", "heizkoerper", "trv", "climate"],
  windows: ["fenster", "tür", "tuer", "window", "door", "kontakt"],
  temp_sensor: ["temperatur", "temp"],
  humidity_sensor: ["feucht", "humid"],
  presence_sensor: ["präsenz", "praesenz", "bewegung", "motion", "presence", "occupancy"],
  outside_sensor: ["außen", "aussen", "outdoor", "garten", "wetter", "balkon", "terrasse"],
  proximity_sensors: ["entfernung", "distance", "nähe", "proximity", "abstand"],
  radio_entities: ["duty_cycle", "duty cycle", "duty", "funk", "carrier"],
  demand_entity: ["zone", "circuit", "vaillant", "kessel", "therme", "heizkreis", "wärmepumpe", "boiler"],
  rw_covers: ["rollladen", "rolladen", "rollo", "shutter", "jalousie", "raffstore", "blind", "markise", "ra_"],
  rw_wind_entity: ["böe", "boe", "gust", "wind"],
  wind_sensor: ["böe", "boe", "gust", "wind"],
  calibration_entities: ["calibration", "offset", "kalibrier"],
  valve_entities: ["valve", "ventil", "position", "opening"],
  comfort_entity: ["komfort", "comfort"],
  eco_entity: ["eco", "absenk"],
  season_entity: ["heizperiode", "heizsaison", "winter"],
  schedule_entity: ["heiz", "zeitplan", "schedule"],
  vacation_calendar: ["urlaub", "familie", "ferien"],
  workday_entity: ["arbeitstag", "workday", "werktag", "feiertag"],
  workday_calendar: ["arbeitstag", "workday", "werktag"],
  calendars: ["familie", "termine", "schule", "geburtstag"],
  main_calendar: ["familie", "family", "termine", "privat"],
  waste_calendars: ["müll", "abfall", "waste", "abfuhr", "tonne", "landkreis"],
  person_add: ["person", "handy", "phone", "iphone", "pixel", "galaxy"],
  show_entities: ["ventil", "valve", "stellantrieb", "stellung", "position", "demand", "heizkörper", "heizkoerper", "fußboden", "fussboden", "fbh", "heizkreis", "thermostat"],
};
const PICK_CLASSES = {
  windows: ["window", "door", "opening", "garage_door"],
  presence_sensor: ["occupancy", "motion", "presence"],
  proximity_sensors: ["distance"],
  temp_sensor: ["temperature"],
  humidity_sensor: ["humidity"],
  outside_sensor: ["temperature"],
};
// Gerätemodelle verschiedener Hersteller (wie logic.py TRV_MODELS / WALL_MODELS)
const TRV_MODELS = ["trv", "rt-dn", "bth-ra", "radiator", "va01", "va02", "va04", "nrv", "srts", "spzb", "hr91", "hr92", "ally",
  "dect 300", "dect 301", "dect 302", "comet", "eve thermo", "zk03840", "heizkörper", "heizkorper"];
const WALL_MODELS = ["wth", "bwth", "sth", "tc-it", "bth-rm", "rth", "room thermostat", "raumthermostat", "wall", "wand",
  "ru01", "ru02", "su02", "t87rf", "roomstat", "natherm", "w100", "bht-", "ct100", "ct200", "nest", "ecobee"];

const DC_LABEL = {
  temperature: "Temperatur", humidity: "Feuchte", window: "Fenster", door: "Tür", opening: "Öffnung", garage_door: "Garagentor",
  motion: "Bewegung", occupancy: "Belegung", presence: "Präsenz", distance: "Entfernung", battery: "Batterie", power: "Leistung",
};
const DOMAIN_LABEL = {
  climate: "Thermostat", binary_sensor: "Binärsensor", sensor: "Sensor", cover: "Abdeckung", number: "Zahl", input_number: "Zahl-Helfer",
  input_boolean: "Schalter-Helfer", switch: "Schalter", schedule: "Zeitplan", calendar: "Kalender", person: "Person", device_tracker: "Tracker",
  weather: "Wetter", light: "Licht", script: "Skript", scene: "Szene", button: "Knopf", input_button: "Knopf-Helfer", fan: "Lüfter",
  lock: "Schloss", media_player: "Medienplayer", input_select: "Auswahl", counter: "Zähler",
};
// ---------------------------------------------------------------- Heizplan-Regeln (wie logic.py, per Test abgeglichen)
// Zeitfenster {start, end, days, kind: "comfort"|"eco", temp}: Komfort = eigene Temperatur, sonst Komfortwert;
// Eco-Fenster = Eco-Wert; außerhalb aller Fenster immer Eco. end <= start = bis zum Folgetag; "24:00" = Mitternacht.
const WEEK = 7 * 1440;
const planWeek = (blocks) => {
  const out = [];
  (blocks || []).forEach((b, i) => {
    const s = hm(b.start);
    let e = hm(b.end);
    if (e <= s) e += 1440;
    const kind = b.kind === "eco" ? "eco" : "comfort";
    for (const d of [...new Set((b.days ?? [0, 1, 2, 3, 4, 5, 6]).map(Number))].sort())
      out.push([d * 1440 + s, d * 1440 + e, kind === "comfort" ? b.temp ?? null : null, i, kind]);
  });
  return out;
};
const planValue = (kind, temp, comfort, eco) => (kind === "eco" ? eco : temp ?? comfort);
const planState = (blocks, wm, comfort, eco) => {
  wm = ((wm % WEEK) + WEEK) % WEEK;
  const hits = planWeek(blocks).filter(([s, e]) => (s <= wm && wm < e) || (s <= wm + WEEK && wm + WEEK < e));
  if (!hits.length) return { target: eco, kind: "eco", custom: false, index: null, start: null, end: null };
  const key = (h) => [h[4] === "comfort" ? 1 : 0, planValue(h[4], h[2], comfort, eco), -h[3]];
  const best = hits.reduce((a, b) => { const ka = key(a), kb = key(b); for (let k = 0; k < 3; k++) if (ka[k] !== kb[k]) return kb[k] > ka[k] ? b : a; return a; });
  const [s, e, t, i, k] = best;
  return { target: planValue(k, t, comfort, eco), kind: k === "comfort" ? "komfort" : "eco_window", custom: k === "comfort" && t != null, index: i, start: s % WEEK, end: e % WEEK };
};
const DAY_SHORT = ["Mo", "Di", "Mi", "Do", "Fr", "Sa", "So"];
const t2 = (m) => { m = ((m % 1440) + 1440) % 1440; return `${String(Math.floor(m / 60)).padStart(2, "0")}:${String(m % 60).padStart(2, "0")}`; };
/** Ungültige bzw. sich überschneidende Zeitfenster: [{i, j, day, text}] (j null = Fenster i selbst). */
const planConflicts = (blocks) => {
  const out = [];
  (blocks || []).forEach((b, i) => {
    const s = hm(b.start), e = hm(b.end);
    if (s % 1440 === e % 1440 && !(s === 0 && (e === 0 || e === 1440))) out.push({ i, j: null, text: `Zeitfenster ${i + 1}: Beginn und Ende sind gleich (${b.start})` });
  });
  if (out.length) return out;
  const w = planWeek(blocks);
  const seen = new Set();
  for (let a = 0; a < w.length; a++)
    for (let b = a + 1; b < w.length; b++) {
      const [s1, e1, , i] = w[a], [s2, e2, , j] = w[b];
      if (i === j) continue;
      for (const sh of [0, WEEK, -WEEK]) {
        const lo = Math.max(s1, s2 + sh), hi = Math.min(e1, e2 + sh), key = `${Math.min(i, j)}-${Math.max(i, j)}`;
        if (lo < hi && !seen.has(key)) {
          seen.add(key);
          const day = Math.floor(lo / 1440) % 7;
          out.push({ i: Math.min(i, j), j: Math.max(i, j), day, text: `Zeitfenster ${Math.min(i, j) + 1} und ${Math.max(i, j) + 1} überschneiden sich am ${DAY_SHORT[day]} ${t2(lo)}–${hi % 1440 ? t2(hi) : "24:00"}` });
        }
      }
    }
  return out;
};
/** Überschneidungen auflösen: Fenster `win` behält seine Zeit, die anderen werden dort gekürzt bzw. geteilt. */
const planResolve = (blocks, win) => {
  const w = planWeek(blocks);
  const order = [win, ...[...new Set(w.map((x) => x[3]))].filter((i) => i !== win).sort((a, b) => a - b)];
  const taken = [];
  const pieces = {};
  const free = (s, e) => {
    let parts = [[s, e]];
    for (const [ts, te] of taken) for (const sh of [0, WEEK, -WEEK]) {
      const a = ts + sh, b = te + sh;
      parts = parts.flatMap(([ps, pe]) => (b <= ps || a >= pe ? [[ps, pe]] : [...(ps < a ? [[ps, a]] : []), ...(b < pe ? [[b, pe]] : [])]));
    }
    return parts;
  };
  for (const i of order) for (const [s, e, , j] of w) if (j === i) { const got = free(s, e); (pieces[i] = pieces[i] || []).push(...got); taken.push(...got); }
  const out = [];
  blocks.forEach((b, i) => {
    const groups = new Map();
    for (const [s, e] of pieces[i] || []) {
      const day = Math.floor(s / 1440) % 7, st = s % 1440, key = `${st}|${st + (e - s)}`;
      groups.set(key, [...(groups.get(key) || []), day]);
    }
    for (const [key, days] of groups) {
      const [st, en] = key.split("|").map(Number);
      out.push({ ...b, start: t2(st), end: en === 1440 ? "24:00" : t2(en), days: [...new Set(days)].sort() });
    }
  });
  return out;
};
const planLabel = (st) => {
  const span = st.start != null ? ` ${t2(st.start)}–${st.end % 1440 || st.end === st.start ? t2(st.end) : "24:00"}` : "";
  if (st.kind === "komfort") return `Komfort${span}${st.custom ? ` (eigene ${fmt(st.target)} °C)` : ""}`;
  if (st.kind === "eco_window") return `Eco-Zeitfenster${span}`;
  return "Eco (kein Zeitfenster)";
};
const PLAN_PRESETS = {
  berufstaetig: {
    label: "Werktags früh und abends",
    blocks: [
      { days: [0, 1, 2, 3, 4], start: "06:00", end: "08:00" },
      { days: [0, 1, 2, 3, 4], start: "16:30", end: "22:00" },
      { days: [5, 6], start: "08:00", end: "22:30" },
    ],
  },
  homeoffice: {
    label: "Homeoffice",
    blocks: [
      { days: [0, 1, 2, 3, 4], start: "07:00", end: "22:00" },
      { days: [5, 6], start: "08:00", end: "22:30" },
    ],
  },
  ganztags: { label: "Täglich 6–22 Uhr", blocks: [{ days: [0, 1, 2, 3, 4, 5, 6], start: "06:00", end: "22:00" }] },
  bad: {
    label: "Bad morgens und abends",
    blocks: [
      { days: [0, 1, 2, 3, 4, 5, 6], start: "05:30", end: "08:00" },
      { days: [0, 1, 2, 3, 4, 5, 6], start: "19:00", end: "21:30" },
    ],
  },
};
// Aufbau: Start = Hauswerk-Dashboard mit den Widgets aller Module, dann die Module als Reiter,
// zentrale Hauswerk-Einstellungen (gelten für alle Module) hinter dem Zahnrad oben rechts.
// Alles rund ums Heizen liegt im Modul „Heizwerk“ mit eigener Unterleiste und eigenen Einstellungen.
const HEAT_VIEWS = [
  { id: "overview", slug: "raeume", name: "Räume", icon: "mdi:radiator" },
  { id: "vent", slug: "lueften", name: "Lüften", icon: "mdi:weather-windy" },
  { id: "plans", slug: "heizplaene", name: "Heizpläne", icon: "mdi:calendar-clock", hidden: true }, // über Einstellungen › Heizpläne
  { id: "room", slug: "raum", name: "Raum", icon: "mdi:door", hidden: true }, // Raum-Detailseite
  { id: "report", slug: "bericht", name: "Bericht", icon: "mdi:chart-bar" },
  { id: "settings", slug: "einstellungen", name: "Einstellungen", icon: "mdi:tune-variant" },
];
const SHUT_VIEWS = [
  { id: "shutters", slug: "rolllaeden", name: "Rollläden", icon: "mdi:window-shutter" },
  { id: "shutset", slug: "einstellungen", name: "Einstellungen", icon: "mdi:tune-variant" },
];
const LW_VIEWS = [
  { id: "lights", slug: "licht", name: "Licht", icon: "mdi:lightbulb-group-outline" },
  { id: "lwrep", slug: "bericht", name: "Bericht", icon: "mdi:chart-bar" },
  { id: "lightset", slug: "einstellungen", name: "Einstellungen", icon: "mdi:tune-variant" },
];
// Abschnitte des Lichtwerk-Profils (wie die Bereiche des Blueprints „Smart Light“)
const LW_SECTIONS = [
  ["on", "Einschalten", "mdi:lightbulb-on-outline"], ["off", "Ausschalten", "mdi:lightbulb-off-outline"], ["motion", "Bewegung", "mdi:motion-sensor"],
  ["days", "Tage", "mdi:calendar-week"], ["light", "Licht", "mdi:brightness-6"], ["scenes", "Tageszeiten", "mdi:clock-time-four-outline"], ["dyn", "Dynamisch", "mdi:theme-light-dark"],
  ["night", "Nachtlicht", "mdi:weather-night"], ["more", "Ausnahmen", "mdi:hand-back-right-outline"],
];
// Szenen je Tageszeit: Vorlage
const LW_SCENES = [
  { from: "06:00", name: "Morgen", brightness: 60, kelvin: 4000 },
  { from: "09:00", name: "Tag", brightness: 100, kelvin: 4500 },
  { from: "18:00", name: "Abend", brightness: 50, kelvin: 2700 },
  { from: "22:00", name: "Nacht", brightness: 15, kelvin: 2200 },
];
const lwKelvinColor = (k) => (!k ? "#facc15" : k < 2600 ? "#f59e0b" : k < 3300 ? "#fbbf24" : k < 4200 ? "#fde68a" : "#bae6fd");
// Vorlagen für neue Lichtwerk-Profile
const LW_PRESETS = {
  abend: { name: "Abendlicht", icon: "mdi:sofa-outline", text: "an bei Sonnenuntergang, aus um 23:00", prof: { on_sun: true, sun_on: 2, off_sun: true, off_time: true, time_off: "23:00", on_time: false, motion: [], night: false } },
  aussen: { name: "Außenlicht", icon: "mdi:outdoor-lamp", text: "an in der Dämmerung, aus 23:30, danach bei Bewegung", prof: { on_sun: true, sun_on: -2, off_sun: true, off_time: true, time_off: "23:30", motion_off: 3, motion_dark: true } },
  flur: { name: "Flur mit Bewegung", icon: "mdi:motion-sensor", text: "nur bei Bewegung und Dunkelheit, nachts gedimmt", prof: { on_sun: true, sun_on: 5, off_sun: false, off_time: false, motion_off: 3, motion_dark: true, night: true, night_from: "22:30", night_to: "06:00", night_brightness: 10 } },
  tv: { name: "Fernsehlicht", icon: "mdi:television-ambient-light", text: "an mit dem Fernseher, aus mit dem Fernseher", prof: { on_sun: false, off_sun: false, on_entity: true, off_entity: true, off_time: false, brightness: 30, color: "temp", kelvin: 2400 } },
  deko: { name: "Deko / Weihnachten", icon: "mdi:pine-tree", text: "an 16:00 bzw. bei Dämmerung, aus 22:30", prof: { on_sun: true, sun_on: 4, on_time: false, off_sun: false, off_time: true, time_off: "22:30" } },
  morgen: { name: "Morgenlicht", icon: "mdi:weather-sunset-up", text: "werktags 06:00 an, aus bei Sonnenaufgang", prof: { on_sun: false, on_time: true, time_on: "06:00", off_sun: true, sun_off: 3, off_time: true, time_off: "09:00", day_mode: "workday" } },
};
const KW_VIEWS = [
  { id: "kwflow", slug: "energiefluss", name: "Energiefluss", icon: "mdi:transmission-tower" },
  { id: "kwdev", slug: "geraete", name: "Geräte", icon: "mdi:washing-machine" },
  { id: "kwrep", slug: "verlauf", name: "Verlauf", icon: "mdi:chart-bar" },
  { id: "kwset", slug: "einstellungen", name: "Einstellungen", icon: "mdi:tune-variant" },
];
const MODULES = [
  { id: "heizen", no: 1, name: "Heizwerk", icon: "mdi:radiator", logo: "heizen", views: HEAT_VIEWS.map((v) => v.id) },
  { id: "rollwerk", no: 2, name: "Rollwerk", icon: "mdi:window-shutter", logo: "rollwerk", views: SHUT_VIEWS.map((v) => v.id) },
  { id: "kraftwerk", no: 3, name: "Kraftwerk", icon: "mdi:solar-power-variant", logo: "kraftwerk", views: KW_VIEWS.map((v) => v.id) },
  { id: "lichtwerk", no: 4, name: "Lichtwerk", icon: "mdi:lightbulb-outline", logo: "lichtwerk", views: LW_VIEWS.map((v) => v.id) },
];
const SUB_VIEWS = [...HEAT_VIEWS, ...SHUT_VIEWS, ...KW_VIEWS, ...LW_VIEWS];
// Symbol eines Verbrauchers nach seinem Namen (erster Treffer zählt)
const KW_ICONS = [
  [/w(ä|ae)rmepumpe|heat ?pump|\bwp\b/, "mdi:heat-pump-outline"], [/wallbox|e-?auto|\bev\b|lades(ä|ae)ule|laden|charger|auto/, "mdi:ev-station"],
  [/wasch|washer/, "mdi:washing-machine"], [/trockner|dryer/, "mdi:tumble-dryer"], [/sp(ü|ue)l|dishwasher/, "mdi:dishwasher"],
  [/k(ü|ue)hl|gefrier|fridge|freezer/, "mdi:fridge-outline"], [/herd|kochfeld|induktion|stove|cooktop/, "mdi:stove"], [/backofen|ofen|oven/, "mdi:toaster-oven"],
  [/mikrowelle|microwave/, "mdi:microwave"], [/kaffee|espresso|coffee/, "mdi:coffee-maker-outline"], [/wasserkocher|kettle/, "mdi:kettle-outline"],
  [/heizstab|boiler|warmwasser|durchlauf|speicher ?wasser/, "mdi:water-boiler"], [/klima|air ?con|split/, "mdi:air-conditioner"],
  [/pool|teich|pumpe|pump/, "mdi:pump"], [/sauna|infrarot/, "mdi:fire"], [/heiz/, "mdi:radiator"], [/l(ü|ue)ft|ventilator|fan/, "mdi:fan"],
  [/fernseh|\btv\b|beamer|heimkino|soundbar/, "mdi:television"], [/server|\bnas\b|rack/, "mdi:server"], [/router|netzwerk|switch|wlan|fritz/, "mdi:router-wireless"],
  [/computer|\bpc\b|b(ü|ue)ro|desk|monitor|gaming/, "mdi:desktop-tower-monitor"], [/drucker|printer/, "mdi:printer"], [/licht|lampe|leuchte|light/, "mdi:lightbulb-outline"],
  [/aquarium|terrarium/, "mdi:fishbowl-outline"], [/rasen|m(ä|ae)her|garten|garage|werkstatt/, "mdi:hammer-wrench"], [/akku|batterie|speicher/, "mdi:battery-charging-outline"],
];
const APP_TYPES = {
  waschmaschine: { label: "Waschmaschine", icon: "mdi:washing-machine", match: /wasch|washer|washing/ },
  trockner: { label: "Trockner", icon: "mdi:tumble-dryer", match: /trockner|dryer/ },
  geschirrspueler: { label: "Geschirrspüler", icon: "mdi:dishwasher", match: /sp(ü|ue)l|dishwasher/ },
  sonstiges: { label: "Anderes Gerät", icon: "mdi:power-plug-outline", match: null },
};
const APP_STATE = { idle: ["Bereit", "#64748b", "mdi:power-sleep"], running: ["Läuft", "#38bdf8", "mdi:play-circle-outline"], ending: ["Ende wird geprüft", "#f59e0b", "mdi:timer-sand"], done: ["Fertig", "#22c55e", "mdi:check-circle"] };
const KW_POPS = ["kwdetect", "kwsolar", "kwgrid", "kwbatt", "kwhome", "kwcons"];
// Geplante Module: nur ausgegraut angezeigt, noch ohne Funktion.
const COMING = [
  { name: "Garten", icon: "mdi:flower-outline" },
];
const SLUGS = { start: "start", house: "einstellungen", log: "protokoll", ...Object.fromEntries(HEAT_VIEWS.map((v) => [v.id, `heizen/${v.slug}`])),
  ...Object.fromEntries(SHUT_VIEWS.map((v) => [v.id, `rollwerk/${v.slug}`])), ...Object.fromEntries(KW_VIEWS.map((v) => [v.id, `kraftwerk/${v.slug}`])),
  ...Object.fromEntries(LW_VIEWS.map((v) => [v.id, `lichtwerk/${v.slug}`])) };
// Pop-ups von Rollwerk (Einstellungen unter Rollwerk › Einstellungen)
const WIZ_USES = [
  { id: "wohnen", label: "Wohnzimmer", icon: "mdi:sofa-outline", comfort: 21, eco: 18, plan: "berufstaetig", match: /wohn|living|stube/ },
  { id: "schlafen", label: "Schlafzimmer", icon: "mdi:bed-outline", comfort: 19, eco: 16.5, plan: "berufstaetig", match: /schlaf|bed/ },
  { id: "kind", label: "Kinderzimmer", icon: "mdi:teddy-bear", comfort: 20, eco: 17.5, plan: "ganztags", match: /kind|kids|jugend/ },
  { id: "bad", label: "Bad", icon: "mdi:shower", comfort: 22, eco: 18, plan: "bad", match: /bad|dusch|wc|toilet|bath/ },
  { id: "kueche", label: "Küche / Essen", icon: "mdi:silverware-fork-knife", comfort: 20, eco: 17, plan: "berufstaetig", match: /k(ü|ue)che|kitchen|ess/ },
  { id: "buero", label: "Büro", icon: "mdi:desk", comfort: 21, eco: 17, plan: "homeoffice", match: /b(ü|ue)ro|arbeit|office/ },
  { id: "flur", label: "Flur / Sonstiges", icon: "mdi:door", comfort: 18, eco: 16, plan: "ganztags", match: /flur|diele|gang|treppe|keller|hall/ },
];
// Empfehlungen für den Sonnenschutz je Fensterrichtung (Faustwerte: Sonnenstand Mitteleuropa, Hitzeeintrag, Blendung)
const RW_SHADE_SUGGEST = {
  0: { span: 60, elevation_min: 5, elevation_max: 40, temp2_min: 26, pos_shading: 40, why: "Nordfenster bekommen kaum direkte Sonne – höchstens im Hochsommer früh morgens und spät abends. Sonnenschutz ist meist nicht nötig; wenn, dann nur bei großer Hitze." },
  45: { span: 70, elevation_min: 5, elevation_max: 45, temp2_min: 24, pos_shading: 40, why: "Nur früh morgens flache Sonne: blendet, heizt aber wenig, weil die Luft noch kühl ist. Erst bei richtig warmen Tagen beschatten." },
  90: { span: 75, elevation_min: 5, elevation_max: 60, temp2_min: 22, pos_shading: 30, why: "Morgensonne bis gegen 11 Uhr, flach und blendend. Wer ab 22 °C beschattet, hält den Raum vor der Mittagshitze kühl." },
  135: { span: 75, elevation_min: 15, elevation_max: 70, temp2_min: 22, pos_shading: 25, why: "Vormittags- und Mittagssonne. Ab etwa 15° Höhe scheint sie über Nachbarhäuser und Bäume ins Fenster." },
  180: { span: 75, elevation_min: 25, elevation_max: 65, temp2_min: 21, pos_shading: 25, why: "Die Mittagssonne steht hoch – ein Dachüberstand schützt dann oft schon (daher bis 65°). Flache Wintersonne unter 25° wärmt gratis und bleibt draußen nicht ausgesperrt." },
  225: { span: 75, elevation_min: 10, elevation_max: 60, temp2_min: 20, pos_shading: 20, why: "Nachmittagssonne trifft auf schon warme Luft – nach West die heißeste Seite. Früh und kräftig beschatten." },
  270: { span: 75, elevation_min: 3, elevation_max: 50, temp2_min: 20, pos_shading: 15, why: "Abendsonne ist flach, kommt zur heißesten Tageszeit und scheint tief ins Zimmer. Schon ab geringer Höhe stark beschatten." },
  315: { span: 70, elevation_min: 3, elevation_max: 35, temp2_min: 24, pos_shading: 40, why: "Nur im Sommer späte, flache Abendsonne. Beschatten lohnt vor allem an heißen Tagen und gegen Blendung." },
};
const RW_TIME_DEFAULTS = { up_early: "06:00", up_late: "08:00", up_early_we: "07:00", up_late_we: "08:00", down_early: "16:00", down_late: "22:00",
  down_early_we: "16:00", down_late_we: "22:00", stage1_time: "18:00", reset_time: "00:01" };
const RW_POPS = ["rwcovers", "rwstorm", "rwrecovery"];
const RW_FEATURES = [["up", "Morgens öffnen"], ["down", "Abends schließen"], ["time", "Zeitsteuerung"], ["brightness", "Helligkeit"], ["sun", "Sonnenhöhe"], ["ventilate", "Lüften"], ["shading", "Beschattung"]];
const RW_SECTIONS = [
  ["tag", "Tagesablauf", "mdi:weather-sunset", "#f59e0b"], ["shade", "Sonnenschutz", "mdi:sun-thermometer-outline", "#f97316", "shading"],
  ["vent", "Fenster & Lüften", "mdi:window-open-variant", "#22c55e"], ["exc", "Ausnahmen", "mdi:account-clock-outline", "#a78bfa"],
  ["fine", "Feinheiten", "mdi:tune-variant", "#64748b"],
];
const RW_WORDS = { fn: "funktionen automatik öffnen schließen", pos: "stellung position prozent fahrzeit toleranz", time: "uhrzeit früh spät werktag wochenende kalender",
  bright: "helligkeit lux sensor", sun: "sonnenhöhe elevation dämmerung", vent: "lüften fenster gekippt aussperrschutz",
  shade: "beschattung hitze sonne azimut temperatur vorhersage", res: "bewohner schlafen schlafzimmer", man: "manuell hand übersteuerung zurücksetzen",
  delay: "verzögerung zufall", force: "erzwingen pause schalter", beh: "verhalten einmal am tag" };
const RW_SHADE_CONDS = [["azimuth", "Richtung"], ["elevation", "Sonnenhöhe"], ["brightness", "Helligkeit"], ["temp1", "Temp. innen"], ["temp2", "Temp. außen"], ["forecast_temp", "Vorhersage"], ["forecast_weather", "Wetterlage"], ["custom", "Eigene"]];
const RW_WEATHER = [["sunny", "Sonnig"], ["partlycloudy", "Teils bewölkt"], ["cloudy", "Bewölkt"], ["fog", "Nebel"], ["rainy", "Regen"], ["windy", "Windig"], ["exceptional", "Extrem"]];
const RW_VENT = [["ventilation_start_no_delay", "Beim Kippen ohne Verzögerung fahren"], ["ventilation_if_lower_enabled", "Auch herunterfahren auf Lüftungsstellung, wenn der Rollladen höher steht"],
  ["ventilation_after_shading_end", "Nach der Beschattung auf Lüftungsstellung statt ganz auf"], ["shading_over_ventilation", "Beschattung geht vor Lüften (auch bei gekipptem Fenster)"]];
const RW_LOCK_TILTED = [["lockout_tilted_closing", "beim Schließen"], ["lockout_tilted_shading_start", "beim Beginn der Beschattung"], ["lockout_tilted_shading_end", "beim Ende der Beschattung"]];
const RW_RESIDENT = [["closing", "Schließen, wenn der Bewohner schlafen geht"], ["opening", "Öffnen, wenn der Bewohner aufwacht (wenn Zeit/Helligkeit passen)"],
  ["allow_shading", "Beschattung erlauben, während er schläft"], ["allow_opening", "Öffnen erlauben, während er schläft"]];
const RW_MANUAL = [["opening", "Öffnen"], ["closing", "Schließen"], ["ventilation", "Lüften"], ["shading", "Beschattung"]];
const RW_RESET = [["fixed", "zu einer festen Uhrzeit"], ["timeout", "nach einiger Zeit"], ["in_position", "in einer bestimmten Stellung"]];
const RW_FORCE = [["force_pause", "Pause – Rollwerk fährt nichts", "mdi:pause-circle-outline"], ["force_up", "Öffnen erzwingen", "mdi:arrow-up-bold"], ["force_down", "Schließen erzwingen", "mdi:arrow-down-bold"],
  ["force_ventilate", "Lüften erzwingen", "mdi:window-open-variant"], ["force_shading", "Beschattung erzwingen", "mdi:sun-thermometer-outline"]];
const RW_BEHAVIOR = [["prevent_higher_position_closing", "Abends nicht höher fahren, als der Rollladen schon steht"], ["prevent_lowering_when_closing_if_shaded", "Abends in der Beschattungsstellung bleiben (nicht weiter herunter)"],
  ["prevent_shading_end_if_closed", "Beschattung nicht beenden, wenn der Rollladen schon zu ist"], ["prevent_opening_after_shading_end", "Nach der Beschattung nicht öffnen"],
  ["prevent_opening_after_ventilation_end", "Nach dem Lüften nicht öffnen"], ["prevent_opening_multiple_times", "Nur einmal am Tag öffnen"],
  ["prevent_closing_multiple_times", "Nur einmal am Tag schließen"], ["prevent_shading_multiple_times", "Nur einmal am Tag beschatten"]];
const FACADE_NAMES = { N: "Nord", NO: "Nordost", O: "Ost", SO: "Südost", S: "Süd", SW: "Südwest", W: "West", NW: "Nordwest" };
// Pop-ups, die zu den zentralen Hauswerk-Einstellungen gehören (alle anderen gehören zu Heizwerk)
const HOUSE_POPS = ["presence", "vacation", "calendars", "weather", "notify", "radio", "access", "look"];
// Akzentfarben der Darstellung: [gespeicherter Wert (null = Standard), Name, Anzeigefarbe]
const ACCENTS = [
  [null, "Türkis", "#14b8a6"], ["#0ea5e9", "Himmelblau"], ["#3b82f6", "Blau"], ["#8b5cf6", "Violett"],
  ["#ec4899", "Pink"], ["#f43f5e", "Rot"], ["#f59e0b", "Orange"], ["#84cc16", "Grün"],
];
// Kategorien des Protokolls (Filter-Chips); off = standardmäßig ausgeblendet
const LOG_CATS = {
  presence: { name: "Anwesenheit", icon: "mdi:home-account", c: "#8b5cf6" },
  season: { name: "Saison", icon: "mdi:sun-snowflake-variant", c: "#f97316" },
  target: { name: "Ziel & Heizung", icon: "mdi:thermometer-auto", c: "#14b8a6" },
  window: { name: "Fenster", icon: "mdi:window-open-variant", c: "#3b82f6" },
  manual: { name: "Von Hand", icon: "mdi:hand-back-right-outline", c: "#8b5cf6" },
  light: { name: "Licht", icon: "mdi:lightbulb-outline", c: "#6366f1" },
  health: { name: "Geräte", icon: "mdi:heart-pulse", c: "#f43f5e" },
  shutter: { name: "Rollläden", icon: "mdi:window-shutter", c: "#0ea5e9" },
  command: { name: "Thermostat-Befehle", icon: "mdi:access-point", c: "#94a3b8", off: true },
  settings: { name: "Einstellungen", icon: "mdi:cog-outline", c: "#64748b" },
  notify: { name: "Nachrichten", icon: "mdi:message-badge-outline", c: "#0ea5e9" },
  appliance: { name: "Geräte", icon: "mdi:washing-machine", c: "#f59e0b" },
};
const SKIES = [["night", "Nacht"], ["dawn", "Sonnenaufgang"], ["day", "Tag"], ["dusk", "Sonnenuntergang"]];
const DEFAULT_VIEW = "start";

const esc = (v) =>
  String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
const fmt = (v, d = 1) => (v === null || v === undefined || isNaN(v) ? "–" : Number(v).toLocaleString("de-DE", { minimumFractionDigits: d, maximumFractionDigits: d }));
const int = (v) => Math.round(v || 0).toLocaleString("de-DE");
const clone = (o) => JSON.parse(JSON.stringify(o));
const hm = (s) => {
  const [h, m] = String(s || "0:0").split(":").map(Number);
  return h * 60 + m;
};
const clampT = (t) => Math.min(30, Math.max(5, Math.round(t * 2) / 2));
/** Farbskala für Temperaturen: kühl blau, mittel grün/gelb, warm orange. */
const tempColor = (t) => {
  if (t == null) return "var(--muted)";
  if (t < 16.5) return "#60a5fa";
  if (t < 18.5) return "#5eead4";
  if (t < 20) return "#a3e635";
  if (t < 21.5) return "#fde047";
  if (t < 23) return "#fbbf24";
  return "#fb923c";
};
/** Farbe für Text: im hellen Theme abgedunkelt, damit sie auf Weiß lesbar bleibt. */
const tint = (c) => `color-mix(in srgb, ${c}, var(--text) var(--shade))`;

class HauswerkPanel extends HTMLElement {
  constructor() {
    super();
    this.attachShadow({ mode: "open" });
    this._tab = this._viewFromPath() || DEFAULT_VIEW;
    this._onLocation = () => {
      const v = this._viewFromPath();
      if (v && v !== this._tab) this._setView(v, false);
    };
    this._data = null;
    this._status = null;
    this._dialog = null;
    this._plan = null;
    this._settings = null;
    this._pop = null;
    this._reports = {};
    this._reportDays = 7;
    this._error = null;
  }

  set hass(hass) {
    const first = !this._hass;
    this._hass = hass;
    // Design, Akzentfarbe, Hintergrund und Größe (Hauswerk › Einstellungen › Darstellung)
    this._applyLook(this._pop?.id === "look" ? this._settings : null);
    // Tablet: Bewegungsmelder weckt den Bildschirmschoner
    if (!first && this._tablet && this._data) this._wakeCheck(hass);
    if (first) this._init();
    // Kraftwerk: Energiefluss live (Zahlen und Linien austauschen, höchstens jede Sekunde)
    else if (this._tab === "kwflow" && this._data && Date.now() - (this._kwAt || 0) > 1000) {
      this._kwAt = Date.now();
      this._kwLive();
    }
    // Rollläden-Seite: Stellung sofort zeigen, sobald Home Assistant sie meldet
    else if (this._tab === "shutters" && this._data && !this._busy && !this._pop && this._rwChanged(hass)) {
      clearTimeout(this._rwT);
      this._rwT = setTimeout(() => this._tab === "shutters" && !this._pop && this._renderMain(), 150);
    }
    // Pop-up „Höhe einstellen“: Stellung live (nicht während des Ziehens)
    else if (this._pop?.id?.startsWith?.("rwpos:") && !this._rwDragging && Date.now() - (this._rwPosAt || 0) > 700) {
      this._rwPosAt = Date.now();
      const d = this._pop.draft || {};
      const cur = this._rwPos(hass.states[this._pop.id.slice(6)]);
      // Ziel erreicht oder lange her: wieder die echte Stellung zeigen
      if (d.pos != null && (cur === d.pos || Date.now() - (d.at || 0) > 90000)) this._pop.draft = {};
      this._renderPop();
    }
    // Startseite mit Shortcuts, Werten, Wetter oder Fenstern: Änderungen in HA zeigen (höchstens alle 3 s)
    else if (this._tab === "start" && this._data && !this._busy && Date.now() - (this._hassAt || 0) > 3000 &&
      this._widgets().some((w) => ["shortcuts", "values", "weather", "windows", "energy"].includes(w.type))) {
      this._hassAt = Date.now();
      this._renderMain();
    }
  }
  get hass() {
    return this._hass;
  }

  /** Einstellungs-Zeile: Titel mit „?“, Unterzeile, Wert oder Bedienelement rechts (ctl = Bedienelement, am Handy volle Breite). */
  _setRow(key, title, sub, value, text, ctl = false) {
    const on = !!this._help?.[key];
    return `
      <div class="wxr ${ctl ? "ctl" : ""}">
        <div class="wxr-l"><b>${title}<button class="qm ${on ? "on" : ""}" data-action="help" data-k="${key}" aria-label="Erklärung zu ${title}">?</button></b>${sub ? `<small>${sub}</small>` : ""}${on ? `<p class="wxr-h">${text}</p>` : ""}</div>
        <div class="wxr-v">${value}</div>
      </div>`;
  }

  /** Darstellung anwenden: aus den gespeicherten Einstellungen oder (Vorschau) aus dem offenen Pop-up. */
  _applyLook(src) {
    const p = src || this._data?.settings || {};
    let theme = p.look_theme || "auto";
    // Tablet: eigenes Design je Gerät (Standard: nach Sonnenstand – Fully meldet den Dunkelmodus oft nicht)
    if (this._tablet) { const t = this._tabletOpt("theme", "sun"); if (t !== "global") theme = t; }
    // auto = hell oder dunkel wie in Home Assistant eingestellt (Profil › Design); sun = dunkel nach Sonnenuntergang
    const dark = theme === "dark" || (theme === "auto" && !!this._hass?.themes?.darkMode) || (theme === "sun" && this._sunDark());
    this.toggleAttribute("dark", dark);
    // Weicht die Wahl von Home Assistant ab, gelten Hauswerks eigene Farben (sonst bliebe „Hell“ bei dunklem HA dunkel)
    this.toggleAttribute("own", dark !== !!this._hass?.themes?.darkMode);
    const c = /^#[0-9a-f]{6}$/i.test(p.look_accent || "") ? p.look_accent : null;
    if (c) {
      const [r, g, b] = [1, 3, 5].map((i) => parseInt(c.slice(i, i + 2), 16) / 255);
      const lum = 0.2126 * r + 0.7152 * g + 0.0722 * b;
      // im hellen Design etwas dunkler, damit Text in der Akzentfarbe auf Weiß lesbar bleibt
      this.style.setProperty("--accent", this.hasAttribute("dark") ? c : `color-mix(in srgb, ${c} 82%, #000)`);
      this.style.setProperty("--ink", lum > 0.6 ? "#1f2328" : "#fff");
    } else {
      this.style.removeProperty("--accent");
      this.style.removeProperty("--ink");
    }
    const bg = p.look_background || "pattern";
    this.setAttribute("bg", bg);
    if (bg === "daytime") this.setAttribute("sky", this._skyPhase());
    else this.removeAttribute("sky");
    this.setAttribute("size", this._lookSize());
  }

  /** Dunkel nach Sonnenstand: Sonne unter dem Horizont (sun.sun), ohne Sonne-Entität 19–7 Uhr. */
  _sunDark() {
    const s = this._hass?.states?.[this._data?.settings?.sun_entity || "sun.sun"];
    if (s && ["above_horizon", "below_horizon"].includes(s.state)) return s.state === "below_horizon";
    const h = new Date().getHours();
    return h < 7 || h >= 19;
  }

  /** Tageszeit für den Himmel in der Kopfzeile: aus sun.sun, sonst aus der Uhrzeit. */
  _skyPhase() {
    const s = this._hass?.states?.[this._data?.settings?.sun_entity || "sun.sun"];
    const el = Number(s?.attributes?.elevation);
    if (s && !isNaN(el)) {
      if (el > 6) return "day";
      if (el < -6) return "night";
      return s.attributes.rising ? "dawn" : "dusk";
    }
    const h = new Date().getHours();
    return h < 6 || h >= 21 ? "night" : h < 8 ? "dawn" : h < 18 ? "day" : "dusk";
  }

  /** Größe der Oberfläche: nur auf diesem Gerät gemerkt. */
  _lookSize() {
    try {
      return localStorage.getItem("hauswerk.groesse") || "m";
    } catch (e) {
      return "m";
    }
  }

  /** Uhrzeit und Wetter oben rechts (je nach Darstellung). */
  _headInfo() {
    const p = this._data.settings;
    const parts = [];
    if (p.look_header_clock) parts.push(`<span class="hclock">${new Date().toLocaleTimeString("de-DE", { hour: "2-digit", minute: "2-digit" })}</span>`);
    if (p.look_header_weather !== false) {
      const w = this._weather();
      if (w) parts.push(`<span class="hwx" title="${esc(w.name)}: ${esc(w.label)}"><ha-icon icon="${w.icon}"></ha-icon>${fmt(w.temp)}°</span>`);
    }
    return parts.length ? `<div class="hinfo">${parts.join("")}</div>` : "";
  }
  set narrow(value) {
    this._narrow = value;
    this.toggleAttribute("narrow", !!value);
  }
  set panel(value) {
    this._panel = value;
  }
  set route(_) {}

  connectedCallback() {
    if (this._hass && this._data && !this._unsub) this._subscribe();
    window.addEventListener("location-changed", this._onLocation);
    window.addEventListener("popstate", this._onLocation);
    // Uhrzeit in der Kopfzeile aktuell halten (ohne die Seite neu zu zeichnen)
    this._clock = setInterval(() => {
      const c = this.shadowRoot.querySelector(".hclock");
      if (c) c.textContent = new Date().toLocaleTimeString("de-DE", { hour: "2-digit", minute: "2-digit" });
    }, 15000);
    // Ablauftimer der Lichter (aus in m:ss) sekündlich, ohne neu zu zeichnen
    this._tick = setInterval(() => {
      for (const el of this.shadowRoot.querySelectorAll("[data-lw-until]")) el.textContent = this._lwLeft(el.dataset.lwUntil);
    }, 1000);
    this._timer = setInterval(() => {
      this._reports = {};
      if (["start", "overview", "report"].includes(this._tab)) this._renderMain();
    }, 5 * 60 * 1000);
  }
  disconnectedCallback() {
    window.removeEventListener("location-changed", this._onLocation);
    window.removeEventListener("popstate", this._onLocation);
    clearInterval(this._timer);
    clearInterval(this._clock);
    clearInterval(this._tick);
    if (this._io) this._io.disconnect();
    for (const sub of Object.values(this._fcSubs || {})) sub.then((u) => u()).catch(() => {});
    this._fcSubs = {};
    this._fc = {};
    if (this._unsub) {
      this._unsub.then((u) => u()).catch(() => {});
      this._unsub = null;
    }
    if (this._rwUnsub) {
      this._rwUnsub.then((u) => u && u()).catch(() => {});
      this._rwUnsub = null;
    }
    // Protokoll beim nächsten Öffnen neu laden
    if (this._logUnsub) this._logUnsub.then((u) => u()).catch(() => {});
    this._logUnsub = null;
    this._log = null;
  }

  async _init() {
    this._renderShell();
    try {
      this._data = await this._hass.callWS({ type: "hauswerk/heizen/get" });
      this._status = this._data.status;
      this._renderShell();
      this._renderMain();
      this._subscribe();
    } catch (err) {
      this._error = err.message || String(err);
      this._renderMain();
    }
  }

  _subscribe() {
    this._unsub = this._hass.connection.subscribeMessage(
      (status) => {
        this._status = status;
        if (["start", "overview"].includes(this._tab) && !this._busy) this._renderMain();
        else this._renderChrome();
      },
      { type: "hauswerk/heizen/subscribe" }
    );
    if (this._data?.rollwerk) {
      this._rwStatus = this._data.rollwerk.status;
      this._rwUnsub = this._hass.connection.subscribeMessage(
        (status) => {
          this._rwStatus = status;
          if (["shutters", "start"].includes(this._tab) && !this._busy && !this._pop) this._renderMain();
        },
        { type: "hauswerk/rollwerk/subscribe" }
      ).catch(() => null);
    }
    if (this._data?.lichtwerk) {
      this._lwStatus = this._data.lichtwerk.status;
      this._lwUnsub = this._hass.connection.subscribeMessage(
        (status) => {
          this._lwStatus = status;
          if (["lights", "start"].includes(this._tab) && !this._busy && !this._pop) this._renderMain();
        },
        { type: "hauswerk/lichtwerk/subscribe" }
      ).catch(() => null);
    }
  }

  async _ws(msg) {
    try {
      return await this._hass.callWS(msg);
    } catch (err) {
      this._toast(err.message || "Fehler beim Speichern");
      if (err && typeof err === "object") err.hwShown = true;
      throw err;
    }
  }

  // ------------------------------------------------------------ Fehler sichtbar machen
  /** Fehler merken, in der Konsole und im Protokoll von Home Assistant melden (je Meldung einmal). */
  _fail(where, err) {
    const msg = String(err?.message || err || "unbekannter Fehler");
    const stack = String(err?.stack || "").split("\n").slice(0, 8).join("\n");
    this._lastErr = { where, msg, stack, at: new Date().toISOString(), tab: this._tab, pop: this._pop?.id || null };
    console.error(`Hauswerk: Fehler in ${where}`, err);
    this._errSent = this._errSent || new Set();
    const key = `${where}|${msg}`;
    if (!this._errSent.has(key) && this._admin) {
      this._errSent.add(key);
      this._hass?.callWS({ type: "system_log/write", logger: "custom_components.hauswerk.panel", level: "error",
        message: `Hauswerk ${VERSION} · Panel-Fehler in ${where}: ${msg}\n${stack}` }).catch(() => null);
    }
    return this._lastErr;
  }

  /** Text für „Diagnose kopieren“. */
  _failText() {
    const e = this._lastErr || {};
    return [`Hauswerk ${VERSION} · Home Assistant ${this._hass?.config?.version || "?"}`, `Zeit: ${e.at || "–"}`, `Seite: ${e.tab || this._tab}${e.pop ? ` · Pop-up: ${e.pop}` : ""}`,
      `Wo: ${e.where || "–"}`, `Fehler: ${e.msg || "–"}`, e.stack ? `\n${e.stack}` : "", `\nBrowser: ${navigator.userAgent}`].filter(Boolean).join("\n");
  }

  /** Karte statt leerer Seite: was kaputt ist, Diagnose kopieren, neu laden. */
  _failCard(where, err, small = false) {
    const e = this._fail(where, err);
    if (small) return `<div class="hw-fail small"><ha-icon icon="mdi:alert-circle-outline"></ha-icon><span><b>Kann nicht angezeigt werden</b><small>${esc(e.msg)}</small></span><button class="link tiny" data-action="err-copy">Diagnose</button></div>`;
    return `<section class="card hw-fail"><ha-icon icon="mdi:alert-circle-outline"></ha-icon>
      <h2>Hier ist etwas schiefgelaufen</h2>
      <p>${esc(where)} konnte nicht angezeigt werden. Der Rest von Hauswerk läuft weiter – die Regelung in Home Assistant ist davon nicht betroffen.</p>
      <code>${esc(e.msg)}</code>
      <div class="hw-fail-b"><button class="secondary" data-action="err-copy"><ha-icon icon="mdi:content-copy"></ha-icon>Diagnose kopieren</button>
        <button class="secondary" data-action="err-reload"><ha-icon icon="mdi:reload"></ha-icon>Neu laden</button>
        <button class="link" data-action="tab" data-tab="start">Zur Startseite</button></div>
      <p class="muted small">Die Meldung steht auch im Protokoll von Home Assistant (Einstellungen › System › Protokolle). Den kopierten Text bei einem Fehlerbericht mitschicken – dann lässt sich der Fehler schnell finden.</p>
    </section>`;
  }

  get _admin() {
    return !!this._data?.is_admin && !this._tabletLocked();
  }

  /** Bedienen (Anwesenheit, Urlaub, Gäste, Party, Eco) dürfen alle angemeldeten Benutzer – auch am gesperrten Tablet. */
  get _operate() {
    return !!this._data;
  }

  /** Tablet gesperrt: nur bedienen, nichts einstellen (lange auf das Logo drücken entsperrt für 10 Minuten). */
  _tabletLocked() {
    return !!this._tablet && this._tabletOpt("lock", "0") === "1" && !(this._unlockUntil > Date.now());
  }

  _rooms() {
    return Object.values(this._data?.rooms || {}).sort((a, b) => a.name.localeCompare(b.name, "de"));
  }

  _roomColor(id) {
    const ids = this._rooms().map((r) => r.id);
    return ROOM_COLORS[Math.max(0, ids.indexOf(id)) % ROOM_COLORS.length];
  }

  _report(days) {
    if (this._reports[days]) return this._reports[days];
    if (!this._reports["loading" + days]) {
      this._reports["loading" + days] = true;
      this._hass
        .callWS({ type: "hauswerk/heizen/report", days })
        .then((r) => {
          this._analysis = this._analysis || {};
          this._analysis[days] = r._analysis || {};
          delete r._analysis;
          this._reports[days] = r;
        })
        .catch(() => (this._reports[days] = {}))
        .finally(() => {
          delete this._reports["loading" + days];
          this._renderMain();
        });
    }
    return null;
  }

  // ------------------------------------------------------------ Gerüst
  _renderShell() {
    this.shadowRoot.innerHTML = `
      <style>${STYLE}</style>
      <div id="sentinel" aria-hidden="true"></div>
      <header class="top" id="head"></header>
      <div class="app">
        <div id="chips"></div>
        <main id="main"><div class="loading"><div class="spinner"></div></div></main>
        <div id="tdots" class="tdots"></div>
      </div>
      <nav id="bnav" class="bnav" aria-label="Navigation"></nav>
      <div id="dialog"></div>
      <div id="pop"></div>
      <div id="toast" class="toast" hidden></div>
      <div id="saver" class="saver" hidden data-action="saver-wake"></div>`;
    this._tabletApply();
    this._renderChrome();
    // Kopfzeile schrumpft, sobald gescrollt wird (funktioniert mit jedem Scroll-Container)
    if (this._io) this._io.disconnect();
    const sentinel = this.shadowRoot.getElementById("sentinel");
    if (sentinel && "IntersectionObserver" in window) {
      this._io = new IntersectionObserver(([e]) => this.shadowRoot.getElementById("head")?.classList.toggle("slim", !e.isIntersecting));
      this._io.observe(sentinel);
    }
    if (!this._listening) {
      this._listening = true;
      const root = this.shadowRoot;
      root.addEventListener("click", (e) => this._onClick(e));
      root.addEventListener("pointerdown", (e) => this._wDragStart(e));
      root.addEventListener("pointerdown", (e) => this._rwWinDrag(e));
      root.addEventListener("pointerdown", (e) => this._tSwipeStart(e));
      root.addEventListener("pointerdown", (e) => this._unlockPress(e));
      if (!this._keyBound) {
        this._keyBound = true;
        window.addEventListener("keydown", (e) => {
          if (!this.isConnected || !this._data) return;
          const typing = e.composedPath().some((n) => ["INPUT", "TEXTAREA", "SELECT"].includes(n.tagName) || n.isContentEditable);
          if ((e.key === "/" && !typing) || (e.key.toLowerCase() === "k" && (e.ctrlKey || e.metaKey))) {
            if (this._pop?.id === "search") return;
            e.preventDefault();
            if (this._pop) this._closePop();
            this._openPop("search", { q: "" });
            setTimeout(() => this.shadowRoot.querySelector("#pop [data-action=g-search]")?.focus(), 30);
          }
          if (e.key === "?" && !typing && !this._pop) {
            e.preventDefault();
            const mod = MODULES.find((m) => m.views.includes(this._tab));
            this._openPop("legend", { first: mod?.name || "", q: "" });
          }
        });
      }
      const safeInput = (e, change) => {
        try {
          this._onInput(e, change);
        } catch (err) {
          this._fail("Eingabe", err);
          this._toast(`Das hat nicht geklappt: ${err?.message || err}`);
        }
      };
      root.addEventListener("input", (e) => safeInput(e));
      root.addEventListener("change", (e) => safeInput(e, true));

    }
  }

  _markTab() {
    this._renderChrome();
  }

  // ------------------------------------------------------------ Navigation (eigene Adresse je Modul)
  get _base() {
    return `/${this._panel?.url_path || "hauswerk"}`;
  }

  _viewFromPath() {
    const parts = location.pathname.split("/").filter(Boolean);
    if (parts[0] !== (this._panel?.url_path || "hauswerk")) return null;
    if (parts[1] === "heizen" && parts[2] === "raum" && parts[3]) {
      this._roomId = decodeURIComponent(parts[3]);
      return "room";
    }
    if (parts[1] === "heizen") {
      // /hauswerk/heizen ohne Unterseite = Räume
      const slug = `heizen/${parts[2] || "raeume"}`;
      return Object.keys(SLUGS).find((k) => SLUGS[k] === slug) || "overview";
    }
    // Module mit Unterseiten: /hauswerk/<modul>/<unterseite>, ohne Unterseite die erste
    const mod = MODULES.find((m) => m.id !== "heizen" && m.id === parts[1]);
    if (mod) return Object.keys(SLUGS).find((k) => SLUGS[k] === `${mod.id}/${parts[2] || ""}`) || mod.views[0];
    // /hauswerk/einstellungen = zentrale Hauswerk-Einstellungen
    if (parts[1] === "einstellungen") return "house";
    if (parts[1] === "protokoll") return "log";
    // alte Adressen (/hauswerk/raeume …) weiter verstehen
    const old = HEAT_VIEWS.find((v) => v.slug === parts[1]);
    return old ? old.id : DEFAULT_VIEW;
  }

  _setView(view, push = true) {
    if (this._tab === "plans" && view !== "plans" && this._plan?.dirty && !confirm("Ungespeicherte Änderungen am Heizplan verwerfen?")) return;
    if (view !== this._tab) {
      this._setQuery = "";
      if (this._tPage) this._tPage[view] = 0;
      if (this._tFit) delete this._tFit[view];
    }
    this._tab = view;
    if (view === "settings" || view === "house") this._settings = null;
    // Adresse nur innerhalb von Home Assistant ändern (nicht in der Vorschau-Datei)
    if (push && location.pathname.startsWith(this._base)) {
      history.pushState(null, "", `${this._base}/${SLUGS[view]}${view === "room" ? `/${encodeURIComponent(this._roomId)}` : ""}`);
      window.dispatchEvent(new CustomEvent("location-changed", { detail: { replace: false } }));
    }
    this._renderMain();
    window.scrollTo({ top: 0 });
  }

  // ------------------------------------------------------------ Kopfleiste, Modul-Reiter, Status-Chips
  _renderChrome() {
    const head = this.shadowRoot.getElementById("head");
    if (head) head.innerHTML = this._headHtml();
    const bnav = this.shadowRoot.getElementById("bnav");
    if (bnav) bnav.innerHTML = this._data && !this._error ? this._bnavHtml() : "";
    const chips = this.shadowRoot.getElementById("chips");
    if (chips)
      chips.innerHTML =
        this._data && !this._error
          ? (MODULES[0].views.includes(this._tab) ? this._heatNavHtml() : "") + (MODULES[1].views.includes(this._tab) ? this._rwNavHtml() : "") + (MODULES[2].views.includes(this._tab) ? this._kwNavHtml() : "") + (MODULES[3].views.includes(this._tab) ? this._lwNavHtml() : "")
          : "";
  }

  /** Untere Leiste fürs Handy: Start · Module · Einstellungen (Unterseiten eines Moduls über seine Unterleiste). */
  _bnavHtml() {
    const f = this._data ? this._facts() : null;
    const on = (ids) => (ids.includes(this._tab) ? "on" : "");
    const item = (tab, ids, icon, label, badge = "") =>
      `<button class="bn ${on(ids)}" data-action="tab" data-tab="${tab}"><span class="bi">${modIcon(icon)}${badge}</span><span>${label}</span></button>`;
    return [
      item("start", ["start"], "mdi:view-dashboard-outline", "Start"),
      ...MODULES.map((m) =>
        item(m.views.includes(this._tab) ? this._tab : m.views[0], m.views, m.logo ? `logo:${m.logo}` : m.icon, m.name,
          m.id === "heizen" && f && (f.open || f.heating) ? `<em class="${f.open ? "warn" : ""}">${f.open || f.heating}</em>` : "")
      ),
      item("house", ["house", "log"], "mdi:cog-outline", "Einstellungen"),
    ].join("");
  }

  _facts() {
    const rooms = this._rooms();
    const st = this._status?.rooms || {};
    const infos = rooms.map((r) => st[r.id] || {});
    return {
      rooms,
      heating: infos.filter((s) => s.heating).length,
      open: infos.filter((s) => s.windows_open).length,
      hints: this._hints().filter((h) => h.lvl === "warn").length,
      withPlan: rooms.filter((r) => r.schedule_entity || this._data.plans?.[r.plan_id] || (r.schedule || []).length).length,
    };
  }

  /** Alle Hinweise an einer Stelle: warn = sollte man beheben, info = gut zu wissen. */
  _hints() {
    const out = [];
    const S = this._hass?.states || {};
    const s = this._status || {};
    const set = this._data?.settings || {};
    const bad = (id) => !S[id] || ["unavailable", "unknown"].includes(S[id].state);
    const add = (lvl, icon, text, sub, action, data = {}) => out.push({ lvl, icon, text, sub, action, data });
    for (const [aid, a] of Object.entries(s.appliances || {})) {
      const c = (this._data?.settings?.kw_appliances || []).find((x) => x.id === aid);
      if (c && a.state === "done") add("warn", APP_TYPES[c.type]?.icon || "mdi:check-circle-outline", `${c.name} fertig`, a.last ? `${this._durTxt(a.last.dur)} · ${fmt(a.last.wh / 1000, 2)} kWh – ausräumen` : "ausräumen", "tab", { tab: "kwdev" });
    }
    if (s.waste_due) add("info", this._calIcon(s.waste_due.types[0])[0], `${s.waste_due.when === "morgen" ? "Morgen" : "Heute"} Müllabfuhr`, s.waste_due.types.join(" · "), "settings-go", { sub: "calendars" });
    for (const r of this._rooms()) {
      const rs = s.rooms?.[r.id] || {};
      const climates = r.climates || [];
      if (r.enabled === false) {
        add("info", "mdi:robot-off-outline", "Automatik aus", r.name, "room-edit", { id: r.id });
        continue;
      }
      if (!climates.length) add("warn", "mdi:thermostat", "Kein Thermostat zugeordnet", r.name, "room-edit", { id: r.id, rtab: "devices" });
      for (const c of climates) if (bad(c)) add("warn", "mdi:lan-disconnect", "Thermostat nicht erreichbar", `${r.name} · ${this._entityName(c)}`, "room-edit", { id: r.id, rtab: "devices" });
      if (r.temp_sensor && bad(r.temp_sensor)) add("warn", "mdi:thermometer-off", "Raumsensor nicht erreichbar", `${r.name} · ${this._entityName(r.temp_sensor)}`, "room-edit", { id: r.id, rtab: "devices" });
      else if (climates.length && rs.room_temp == null && s.rooms) add("warn", "mdi:thermometer-off", "Kein Messwert", r.name, "room-edit", { id: r.id, rtab: "devices" });
      for (const w of r.windows || []) if (bad(w)) add("info", "mdi:window-shutter-alert", "Fensterkontakt nicht erreichbar", `${r.name} · ${this._entityName(w)}`, "room-edit", { id: r.id, rtab: "devices" });
      if (r.schedule_entity && bad(r.schedule_entity)) add("warn", "mdi:calendar-remove", "Zeitplan nicht erreichbar", `${r.name} · ${this._entityName(r.schedule_entity)}`, "room-edit", { id: r.id });
      else if (!r.schedule_entity && !this._data.plans?.[r.plan_id] && !(r.schedule || []).length) add("info", "mdi:calendar-blank-outline", "Kein Heizplan – bleibt auf Eco", r.name, "plan-open", { id: r.id });
      for (const b of rs.battery_low || [])
        add("warn", b.level === 0 ? "mdi:battery-alert-variant-outline" : "mdi:battery-10", `Batterie schwach${b.level ? ` · ${fmt(b.level, 0)} %` : ""}`, `${r.name} · ${b.name}`, "room-edit", { id: r.id, rtab: "devices" });
      const air = rs.air || {};
      if (air.open?.done) add("warn", "mdi:window-closed-variant", "Fenster schließen – genug gelüftet", `${r.name} · ${air.open.done}`, "tab", { tab: "vent" });
      else if (air.long) add("info", "mdi:window-open-variant", "Fenster lange offen – Kippen kostet Wärme", `${r.name} · ${air.long.minutes} Min., ca. ${fmt(air.long.kwh)} kWh – lieber kurz stoßlüften`, "tab", { tab: "vent" });
      if (rs.vent) add("info", "mdi:weather-windy", `Jetzt ${rs.vent.minutes} Min. lüften`, `${r.name} · ${(rs.vent.reasons || []).join(", ")}${rs.vent.outside_g != null ? ` · draußen ${fmt(rs.vent.outside_g)} statt ${fmt(rs.vent.inside_g)} g/m³` : ""}`, "tab", { tab: "vent" });
      if (air.mold?.level === "bad" && !rs.vent) add("warn", "mdi:alert-octagon-outline", "Schimmelgefahr", `${r.name} · an Außenwänden ca. ${air.mold.wall_rh} % Luftfeuchte – lüften, Möbel von Außenwänden abrücken`, "tab", { tab: "vent" });
      else if (rs.humidity >= 70) add("info", "mdi:water-alert", `Luftfeuchte ${fmt(rs.humidity, 0)} %`, `${r.name} · Lüften bringt gerade wenig, draußen ist es ähnlich feucht`, "settings-go", { sub: "vent" });
      if (rs.cold_radiator && (s.cold_rooms || []).length < 2)
        add("warn", "mdi:radiator-off", "Heizkörper bleibt kalt", `${r.name} · Ventil ${fmt(rs.cold_radiator.valve, 0)} % seit ${rs.cold_radiator.minutes} Min., nur +${fmt(rs.cold_radiator.rise)} °C – entlüften oder Ventilstift prüfen`, "room-page", { id: r.id });
      for (const c of rs.conflicts || [])
        add("warn", "mdi:account-switch-outline", "Zweite Regelung stellt dasselbe Thermostat", `${r.name} · ${c.name} · ${c.by.join(", ")}`, "room-edit", { id: r.id, rtab: "devices" });
      for (const c of rs.pair_broken || [])
        add("info", "mdi:link-variant-off", "Heizkörper folgt dem Wandthermostat nicht", `${r.name} · ${this._entityName(c)} – Hauswerk stellt es selbst`, "room-edit", { id: r.id, rtab: "devices" });
      for (const c of rs.duty_blocked || [])
        add("warn", "mdi:access-point-off", "Gerät darf gerade nicht funken", `${r.name} · ${this._entityName(c)} · Duty Cycle erreicht`, "settings-go", { sub: "radio" });
      if (rs.window_virtual) add("info", "mdi:window-open-variant", "Fenster vermutlich offen", `${r.name} · Temperatur fällt schnell – Fensterpause`, "tab", { tab: "overview" });
    }
    for (const o of this._openWindows ? this._openWindows() : []) {
      const mins = o.s.last_changed ? (Date.now() - new Date(o.s.last_changed)) / 60000 : 0;
      if (mins >= 30) add("info", "mdi:window-open-variant", `Fenster seit ${mins < 90 ? `${Math.round(mins)} Min.` : `${fmt(mins / 60)} h`} offen`, `${o.room.name} · ${this._entityName(o.id)}`, "tab", { tab: "overview" });
    }
    if ((s.cold_rooms || []).length >= 2) add("warn", "mdi:water-boiler-alert", "Mehrere Heizkörper bleiben kalt", `${s.cold_rooms.map((id) => this._data.rooms[id]?.name || id).join(", ")} – liefert die Heizung Wärme? Vorlauf, Wasserdruck und Pumpe prüfen`, "settings-go", { sub: "demand", heat: true });
    if (s.demand?.error) add("warn", "mdi:water-boiler-off", "Wärmeerzeuger nicht erreichbar", `${this._entityName(this._data.settings.demand_entity)} – Wärmeanforderung pausiert`, "settings-go", { sub: "demand", heat: true });
    for (const f of s.hm_links?.findings || []) {
      const room = f.room ? this._data.rooms?.[f.room] : null;
      add(f.level === "warn" ? "warn" : "info", "mdi:link-variant-off", f.text.split(" – ")[0], `${room ? `${room.name} · ` : ""}${f.text.split(" – ")[1] || "Homematic-Verknüpfung"}`, "settings-go", { sub: "hmlinks" });
    }
    {
      const R = this._lwStatus?.report;
      const nm = (id) => this._lwLights().find((x) => x.id === id) ? this._lwName(this._lwLights().find((x) => x.id === id)) : this._entityName(id);
      for (const [id, h] of Object.entries(R?.health || {})) {
        if (h.fail) add("warn", "mdi:lightbulb-alert-outline", `${nm(id)} schaltet nicht`, `Lichtwerk wollte ${h.fail.want === "on" ? "an" : "aus"} – Funk, Strom oder Schalter prüfen`, "tab", { tab: "lwrep" });
        if (h.battery_low) add("warn", "mdi:battery-alert-variant-outline", `Batterie schwach · ${nm(id)}`, h.battery != null ? `${h.battery} % – bald wechseln` : "bald wechseln", "tab", { tab: "lwrep" });
      }
      for (const sg of R?.suggestions || []) add("info", "mdi:lightbulb-question-outline", sg.text.split(" – ")[0], `Lichtwerk · ${sg.text.split(" – ")[1] || ""}`, "tab", { tab: "lwrep" });
    }
    for (const f of this._lwStatus?.links?.findings || []) add(f.level === "warn" ? "warn" : "info", "mdi:link-variant-off", f.text.split(" – ")[0], `Lichtwerk · ${f.text.split(" – ")[1] || "Homematic-Verknüpfung"}`, "settings-go", { sub: "lwlinks" });
    if (s.radio?.busy) add("warn", "mdi:access-point-network", `Funk ausgelastet · ${fmt(s.radio.level, 0)} %`, `${this._entityName(s.radio.entity)} · Hauswerk sendet nur wichtige Änderungen`, "settings-go", { sub: "radio" });
    if (s.vacation_calendar_error) add("warn", "mdi:calendar-alert", "Urlaubskalender nicht lesbar", s.vacation_calendar_error, "settings-go", { sub: "vacation" });
    for (const [pid, err] of Object.entries(s.plan_errors || {})) add("warn", "mdi:calendar-alert", `Kalender von Plan „${this._data.plans?.[pid]?.name || pid}“ nicht lesbar`, err, "plan-sel", { kind: "plan", id: pid });
    for (const x of this._wxAlerts()) add("info", x.icon, x.text, x.sub, "settings-go", { sub: "weather" });
    {
      const kwIds = [...(set.kw_solar || []), set.kw_grid, set.kw_grid_export, set.kw_battery, set.kw_battery_soc, set.kw_home].filter(Boolean);
      for (const id of kwIds) if (bad(id)) add("info", "mdi:flash-off-outline", "Kraftwerk: Sensor nicht erreichbar", this._entityName(id), "tab", { tab: "kwset" });
    }
    if (!(set.persons || []).length) add("info", "mdi:account-question-outline", "Keine Personen gewählt", "Ohne Personen gibt es kein automatisches „Abwesend“", "settings-go", { sub: "presence" });
    return out.sort((a, b) => (a.lvl === b.lvl ? 0 : a.lvl === "warn" ? -1 : 1));
  }

  _headHtml() {
    const mod = MODULES.find((m) => m.views.includes(this._tab));
    const sub = SUB_VIEWS.find((v) => v.id === this._tab);
    const roomName = this._tab === "room" ? this._data?.rooms?.[this._roomId]?.name : null;
    const title = mod ? `${mod.name}${roomName ? ` · ${roomName}` : sub ? ` · ${sub.name}` : ""}` : this._tab === "house" ? "Einstellungen" : this._tab === "log" ? "Protokoll" : "Start";
    const f = this._data ? this._facts() : null;
    const badge = (id) => {
      if (!f || id !== "heizen") return "";
      return f.open ? `<em class="badge warn">${f.open} OFFEN</em>` : f.heating ? `<em class="badge ok">${f.heating} HEIZT</em>` : "";
    };
    const tab = (id, name, icon, target) => `
      <button class="mtab ${id === "start" ? (this._tab === "start" ? "active" : "") : mod?.id === id ? "active" : ""}" data-action="tab" data-tab="${target}">
        ${modIcon(icon)}<span class="mt"><b>${name}</b></span>${badge(id)}
      </button>`;
    const soon = (m) => `
      <button class="mtab soon" disabled title="${m.name}: kommt später" aria-label="${m.name}, noch nicht verfügbar">
        <ha-icon icon="${m.icon}"></ha-icon><span class="mt"><b>${m.name}</b></span>
      </button>`;
    return `
      <div class="bar">
        <button class="menu" data-action="menu" aria-label="Menü"><ha-icon icon="mdi:menu"></ha-icon></button>
        <div class="brand">${LOGO}</div>
        <div class="ttl"><small>HAUSWERK</small><b>${esc(title)}</b><span>Haussteuerung · Version ${VERSION}</span></div>
        <div class="hacts">
          ${this._data ? this._headInfo() : ""}
          ${this._data ? `<button class="bell gsearch" data-action="search-open" title="Suchen (/)" aria-label="Suchen"><ha-icon icon="mdi:magnify"></ha-icon></button>` : ""}
          ${(() => {
            if (!this._data) return "";
            const h = this._hints();
            const warn = h.filter((x) => x.lvl === "warn").length;
            return `<button class="bell ${warn ? "warn" : h.length ? "info" : ""}" data-action="hints-open" title="${h.length ? `${h.length} Hinweis${h.length > 1 ? "e" : ""}` : "Keine Hinweise"}" aria-label="Hinweise">
              <ha-icon icon="${h.length ? "mdi:bell-badge-outline" : "mdi:bell-outline"}"></ha-icon>${warn ? `<em>${warn}</em>` : h.length ? "<i></i>" : ""}</button>`;
          })()}
          ${this._data ? `<button class="bell gear ${["house", "log"].includes(this._tab) ? "on" : ""}" data-action="tab" data-tab="house" title="Hauswerk-Einstellungen (für alle Module)" aria-label="Einstellungen"><ha-icon icon="mdi:cog-outline"></ha-icon></button>` : ""}
        </div>
      </div>
      <nav class="mtabs">
        ${tab("start", "Start", "mdi:view-dashboard-outline", "start")}
        ${MODULES.map((m) => tab(m.id, m.name, m.logo ? `logo:${m.logo}` : m.icon, mod?.id === m.id ? this._tab : m.views[0])).join("")}
        ${COMING.map(soon).join("")}
      </nav>`;
  }

  /** Unterleiste im Modul Heizen: Räume, Heizpläne, Bericht, Einstellungen. */
  _heatNavHtml() {
    const f = this._facts();
    const badge = (id) => {
      if (id === "overview") return f.open ? `<em class="warn">${f.open} offen</em>` : f.heating ? `<em class="ok">${f.heating} heizt</em>` : "";
      if (id === "plans" && f.rooms.length - f.withPlan > 0) return `<em>${f.rooms.length - f.withPlan} ohne Plan</em>`;
      return "";
    };
    return `<nav class="heatnav">${HEAT_VIEWS.filter((v) => !v.hidden).map(
      (v) => `<button class="hnav ${this._tab === v.id || (v.id === "settings" && this._tab === "plans") || (v.id === "overview" && this._tab === "room") ? "on" : ""}" data-action="tab" data-tab="${v.id}"><ha-icon icon="${v.icon}"></ha-icon><span>${v.name}</span>${badge(v.id)}</button>`
    ).join("")}</nav>`;
  }

  _toast(text) {
    const el = this.shadowRoot.getElementById("toast");
    if (!el) return;
    el.textContent = text;
    el.hidden = false;
    clearTimeout(this._toastTimer);
    this._toastTimer = setTimeout(() => (el.hidden = true), 3500);
  }

  _renderMain() {
    const main = this.shadowRoot.getElementById("main");
    if (!main) return;
    if (this._error) {
      main.innerHTML = `<section class="card empty"><ha-icon icon="mdi:alert-circle-outline"></ha-icon><h2>Hauswerk antwortet nicht</h2><p>${esc(this._error)}</p></section>`;
      main.dataset.sig = "";
      return;
    }
    this._applyLook(this._pop?.id === "look" ? this._settings : null);
    this._renderChrome();
    // Hintergrund passend zum Bereich: Startseite oder Heizen
    this.setAttribute("view", MODULES[0].views.includes(this._tab) ? "heat" : "start");
    if (!this._data) return;
    const view = { start: this._viewStart, house: this._viewHouse, log: this._viewLog, overview: this._viewOverview, vent: this._viewVent, plans: this._viewPlans, report: this._viewReport, settings: this._viewSettings, room: this._viewRoom,
      shutters: this._viewShutters, shutset: () => this._settingsPage("rw"),
      kwflow: this._viewKwFlow, kwdev: this._viewKwDev, kwrep: this._viewKwRep, kwset: () => this._settingsPage("kw"),
      lights: this._viewLights, lwrep: this._viewLwRep, lightset: () => this._settingsPage("lw") }[this._tab] || this._viewStart;
    let html;
    try {
      html = view.call(this);
    } catch (err) {
      const name = SUB_VIEWS.find((v) => v.id === this._tab)?.name || { start: "Startseite", house: "Einstellungen", log: "Protokoll" }[this._tab] || this._tab;
      html = this._failCard(`Die Seite „${name}“`, err);
    }
    // Nur ändern, was sich ändert: gleiche Seite → unverändert lassen bzw. Knoten abgleichen statt neu aufbauen
    // (schneller, Scrollstand und Eingaben bleiben, langsame Tablets ruckeln weniger)
    const sig = `${this._tab}|${this._tablet ? 1 : 0}`;
    const last = this._lastMain;
    const target = this._tablet ? main.querySelector(".tpages > .tin") : main;
    if (last && last.sig === sig && target && main.dataset.sig === sig) {
      if (last.html === html) return;
      morph(target, html);
      this._lastMain = { sig, html };
      if (this._tablet) this._tabletFit();
      return;
    }
    this._lastMain = { sig, html };
    main.dataset.sig = sig;
    if (this._tablet) {
      main.innerHTML = `<div class="tpages"><div class="tin">${html}</div></div>`;
      this._tabletFit();
    } else main.innerHTML = html;
  }

  // ------------------------------------------------------------ Tabletmodus
  /** Tabletmodus an? Je Gerät gemerkt; „?tablet“ bzw. „?tablet=0“ in der Adresse schaltet ihn (z. B. Start-Adresse in Fully). */
  _tabletRead() {
    try {
      const q = new URLSearchParams(location.search);
      if (q.has("tablet")) localStorage.setItem("hauswerk.tablet", q.get("tablet") === "0" ? "0" : "1");
      return localStorage.getItem("hauswerk.tablet") === "1";
    } catch (e) {
      return false;
    }
  }

  _tabletOpt(key, dflt) {
    try {
      const v = localStorage.getItem(`hauswerk.tablet.${key}`);
      return v == null ? dflt : v;
    } catch (e) {
      return dflt;
    }
  }

  _tabletSet(key, value) {
    try {
      localStorage.setItem(key ? `hauswerk.tablet.${key}` : "hauswerk.tablet", String(value));
    } catch (e) {
      /* ohne Speicher: gilt bis zum Neuladen */
    }
  }

  /** Tabletmodus einschalten bzw. ausschalten: Leisten unten, Seiten statt Scrollen, Bildschirmschoner. */
  _tabletApply() {
    if (this._tablet == null) this._tablet = this._tabletRead();
    this.toggleAttribute("tablet", this._tablet);
    this._tPage = this._tPage || {};
    clearInterval(this._saverTimer);
    this._tabletSidebar(this._tablet && this._tabletOpt("sidebar", "1") === "1");
    if (!this._tablet) {
      this._saverHide();
      this._wakeLock?.release?.().catch?.(() => {});
      this._wakeLock = null;
      return;
    }
    this._lastAct = Date.now();
    if (!this._actBound) {
      this._actBound = true;
      const act = () => (this._lastAct = Date.now());
      for (const ev of ["pointerdown", "keydown", "wheel", "touchstart"]) window.addEventListener(ev, act, { capture: true, passive: true });
      window.addEventListener("resize", () => this._tablet && this._tabletFit(true));
      document.addEventListener("visibilitychange", () => this._tablet && document.visibilityState === "visible" && this._keepAwake());
    }
    this._keepAwake();
    this._saverTimer = setInterval(() => this._saverTick(), 10000);
    // Fully Kiosk: eigene Bewegungserkennung (Kamera) weckt ebenfalls
    try {
      window.__hauswerkWake = () => this._wake();
      if (window.fully && !this._fullyBound) {
        this._fullyBound = true;
        window.fully.bind("onMotion", "window.__hauswerkWake && window.__hauswerkWake()");
      }
    } catch (e) {
      /* Fully ohne JavaScript-Schnittstelle */
    }
  }

  /** Seitenleiste von Home Assistant ausblenden (Einstellung „immer ausblenden“ dieses Browsers) – beim Ausschalten wie vorher. */
  _tabletSidebar(hide) {
    const dock = (v) => this.dispatchEvent(new CustomEvent("hass-dock-sidebar", { detail: { dock: v }, bubbles: true, composed: true }));
    try {
      const PREV = "hauswerk.tablet.sidebar_prev";
      const cur = localStorage.getItem("dockedSidebar");
      if (hide) {
        if (localStorage.getItem(PREV) == null) localStorage.setItem(PREV, cur ?? "");
        if (cur !== '"always_hidden"') dock("always_hidden");
      } else {
        const prev = localStorage.getItem(PREV);
        if (prev == null) return;
        localStorage.removeItem(PREV);
        let v = "docked";
        try { v = prev ? JSON.parse(prev) : "docked"; } catch (e) { v = "docked"; }
        if (cur !== JSON.stringify(v)) dock(v);
      }
    } catch (e) {
      /* ohne Speicher: Seitenleiste bleibt, wie sie ist */
    }
  }

  /** Bildschirm anlassen (wo der Browser es erlaubt; in Fully zusätzlich „Bildschirm anlassen“ einschalten). */
  async _keepAwake() {
    try {
      if ("wakeLock" in navigator && !this._wakeLock) {
        this._wakeLock = await navigator.wakeLock.request("screen");
        this._wakeLock.addEventListener?.("release", () => (this._wakeLock = null));
      }
    } catch (e) {
      this._wakeLock = null;
    }
  }

  /** Abschnitt „Tabletmodus“ in Darstellung (gilt sofort, nur auf diesem Gerät). */
  /** Hauswerk als Startseite von Home Assistant: für mich, für alle oder nur dieses Gerät. */
  _startBox() {
    const url = this._panel?.url_path || "hauswerk";
    const d = this._dp;
    if (!d || Date.now() - d.at > 60000) this._dpLoad();
    const is = (v) => v === url;
    const other = (v) => (v && !is(v) ? this._dpName(v) : "");
    const state = !d ? "Wird geprüft …"
      : is(d.u) ? "Für dich auf allen Geräten"
      : is(d.s) && !d.u ? "Für alle Benutzer"
      : is(d.dev) && !d.u && !d.s ? "Nur auf diesem Gerät"
      : `Nein – Start ist ${other(d.u) || other(d.s) || "die Übersicht"}${(is(d.s) || is(d.dev)) && d.u ? " (dein Profil hat Vorrang)" : ""}`;
    const on = d && (is(d.u) || (is(d.s) && !d.u) || (is(d.dev) && !d.u && !d.s));
    const btn = (scope, label, icon, active, admin) => (admin && !(this._hass?.user?.is_admin && this._dp?.sysOk !== false) ? "" : `<button class="seg ${active ? "on" : ""}" data-action="dp-set" data-scope="${scope}" data-on="${active ? "0" : "1"}"><ha-icon icon="${icon}"></ha-icon>${label}</button>`);
    return `
      <div class="lbl" style="margin-top:18px"><ha-icon icon="mdi:home-import-outline"></ha-icon> Startseite von Home Assistant</div>
      <button class="xcard ${on ? "on" : ""}" data-action="dp-set" data-scope="${on ? (is(d?.u) ? "user" : is(d?.s) ? "system" : "device") : "user"}" data-on="${on ? "0" : "1"}" role="switch" aria-checked="${!!on}" ${d ? "" : "disabled"}><span class="xc-box" aria-hidden="true">${on ? "✓" : ""}</span>
        <span class="grow"><b>Hauswerk als Startseite</b><small>${esc(state)}${on ? "" : " · Tippen: für dich auf allen Geräten"}</small></span></button>
      <div class="segs small n3" style="margin-top:8px">
        ${btn("user", "Für mich", "mdi:account-outline", d && is(d.u))}
        ${btn("system", "Für alle", "mdi:account-group-outline", d && is(d.s), true)}
        ${btn("device", "Dieses Gerät", "mdi:tablet-cellphone", d && is(d.dev))}
      </div>
      <p class="muted small">Hauswerk ist ein eigenes Panel; hier lässt es sich direkt als Startseite festlegen. Reihenfolge: dein Profil, dann „für alle“, dann dieses Gerät. Nochmal tippen hebt es wieder auf.</p>
      <div class="lbl" style="margin-top:14px"><ha-icon icon="mdi:view-dashboard-outline"></ha-icon> Als Dashboard</div>
      ${d?.dash ? `<p class="note ok"><ha-icon icon="mdi:check-circle-outline"></ha-icon>Dashboard „${esc(d.dash.title)}“ ist angelegt – unter Einstellungen › Dashboards wie jedes andere als Standard wählbar.</p>`
        : this._hass?.user?.is_admin ? `<button class="secondary small" data-action="dash-create"><ha-icon icon="mdi:view-dashboard-edit-outline"></ha-icon>Hauswerk-Dashboard anlegen</button>` : ""}
      <p class="muted small">Oder selbst: Einstellungen › Dashboards › Dashboard hinzufügen › „Neu von Grund auf“ › ⋮ › Rohkonfigurations-Editor, dort eintragen:</p>
      <pre class="code">strategy:
  type: custom:hauswerk</pre>
      <p class="muted small">Dann steht Hauswerk in der Liste der Dashboards – wie Raumklima & Co. – und lässt sich dort als Standard festlegen oder für einzelne Benutzer wählen.</p>`;
  }

  _dpName(v) {
    const p = this._hass?.panels?.[v];
    return p?.title || (v === "lovelace" ? "Übersicht" : v);
  }

  async _dpLoad() {
    if (this._dpBusy || !this._hass?.callWS) return;
    this._dpBusy = true;
    const get = (type) => this._hass.callWS({ type, key: "core" }).then((r) => r?.value || {}).catch(() => null);
    const [u, sys] = await Promise.all([get("frontend/get_user_data"), get("frontend/get_system_data")]);
    let dev = null;
    try { dev = JSON.parse(localStorage.getItem("defaultPanel") || "null"); } catch (e) { dev = null; }
    this._dpRaw = { u: u || {}, s: sys };
    let dash = null;
    if (this._hass?.user?.is_admin) {
      try {
        const list = await this._hass.callWS({ type: "lovelace/dashboards/list" });
        dash = (list || []).find((x) => x.url_path === "dashboard-hauswerk") || null;
      } catch (e) { dash = null; }
    }
    this._dp = { u: u?.default_panel || null, s: sys?.default_panel || null, dev, at: Date.now(), sysOk: sys !== null, dash };
    this._dpBusy = false;
    if (this._pop?.id === "look") this._renderPop();
  }

  /** Lovelace-Dashboard „Hauswerk“ mit der Strategie custom:hauswerk anlegen (erscheint unter Einstellungen › Dashboards). */
  async _dashCreate() {
    try {
      await this._hass.callWS({ type: "lovelace/dashboards/create", url_path: "dashboard-hauswerk", title: "Hauswerk",
        icon: "mdi:home-lightning-bolt-outline", require_admin: false, show_in_sidebar: false, mode: "storage" });
      await this._hass.callWS({ type: "lovelace/config/save", url_path: "dashboard-hauswerk", config: { strategy: { type: "custom:hauswerk" } } });
      this._toast("Hauswerk-Dashboard angelegt – unter Einstellungen › Dashboards als Standard wählbar");
    } catch (err) {
      this._toast(`Das hat nicht geklappt: ${err?.message || err}`);
    }
    this._dp = null;
    await this._dpLoad();
  }

  async _dpSet(scope, on) {
    const url = this._panel?.url_path || "hauswerk";
    const val = (raw) => { const v = { ...(raw || {}) }; if (on) v.default_panel = url; else delete v.default_panel; return v; };
    try {
      if (scope === "device") {
        if (on) localStorage.setItem("defaultPanel", JSON.stringify(url)); else localStorage.removeItem("defaultPanel");
      } else {
        if (!this._dpRaw) await this._dpLoad();
        await this._hass.callWS({ type: scope === "user" ? "frontend/set_user_data" : "frontend/set_system_data", key: "core", value: val(scope === "user" ? this._dpRaw.u : this._dpRaw.s) });
      }
      this._toast(on ? `Hauswerk ist jetzt Startseite ${{ user: "für dich", system: "für alle", device: "auf diesem Gerät" }[scope]}` : "Startseite zurückgesetzt");
    } catch (err) {
      this._toast(`Das hat nicht geklappt: ${err?.message || err}`);
    }
    this._dp = null;
    await this._dpLoad();
  }

  _tabletBox() {
    const on = !!this._tablet;
    const saver = this._tabletOpt("saver", "2");
    const fully = this._tabletOpt("fully", "1") === "1";
    const opt = (k, v, l, cur) => `<button class="seg ${cur === v ? "on" : ""}" data-action="tablet-opt" data-k="${k}" data-v="${v}">${l}</button>`;
    return `
      <div class="lbl" style="margin-top:18px"><ha-icon icon="mdi:tablet-dashboard"></ha-icon> Tabletmodus · dieses Gerät</div>
      <button class="xcard ${on ? "on" : ""}" data-action="tablet-toggle" role="switch" aria-checked="${on}">
        <span class="xc-box" aria-hidden="true">${on ? "✓" : ""}</span>
        <span class="grow"><b>Tabletmodus</b><small>Leisten unten, kein Scrollen – höchstens zwei Seiten zum Wischen –, Bildschirmschoner mit großer Uhr.</small></span>
        <ha-icon class="xc-ic" icon="mdi:tablet"></ha-icon></button>
      ${on ? `
      <div class="field"><span>Hell / Dunkel auf diesem Tablet</span><div class="segs small">${[["sun", "Nach Sonnenstand"], ["global", "Wie Darstellung"], ["light", "Hell"], ["dark", "Dunkel"]].map(([v, l]) => opt("theme", v, l, this._tabletOpt("theme", "sun"))).join("")}</div></div>
      <p class="muted small">„Nach Sonnenstand“ wird dunkel, sobald die Sonne untergeht (sun.sun), und morgens wieder hell. „Wie Home Assistant“ klappt in Fully oft nicht, weil das Tablet den Dunkelmodus nicht meldet.</p>
      <div class="field"><span>Bildschirmschoner nach</span><div class="segs small">${[["0", "Aus"], ["1", "1 Min."], ["2", "2 Min."], ["5", "5 Min."], ["10", "10 Min."]].map(([v, l]) => opt("saver", v, l, saver)).join("")}</div></div>
      <p class="muted small">Abgedunkelt mit großer Uhr, Datum, Wetter mit Vorhersage, Hausstand, nächsten Rollladen-Fahrten, Terminen und Hinweisen; Warnungen erscheinen groß. Der Inhalt wandert jede Minute ein Stück gegen Einbrennen. Dabei geht es zurück zur Startseite. Antippen weckt auf, ohne etwas zu schalten.</p>
      <div class="field"><span>Nachts</span><div class="segs small">${[["dim", "Abgedunkelt"], ["black", "Schwarz, kleine Uhr"], ["off", "Display aus"]].map(([v, l]) => opt("night", v, l, this._tabletOpt("night", "dim"))).join("")}</div></div>
      <div class="field"><span>Nacht von … bis</span><div class="segs small">${["20", "21", "22", "23", "0"].map((v) => opt("night_from", v, `${v} Uhr`, this._tabletOpt("night_from", "22"))).join("")}</div>
        <div class="segs small" style="margin-top:6px">${["5", "6", "7", "8"].map((v) => opt("night_to", v, `${v} Uhr`, this._tabletOpt("night_to", "6"))).join("")}</div></div>
      ${this._tabletOpt("night", "dim") === "off" && !window.fully ? `<p class="muted small"><ha-icon icon="mdi:information-outline"></ha-icon>„Display aus“ geht nur in Fully mit JavaScript-Schnittstelle – sonst wie „Schwarz“.</p>` : ""}
      <div class="field"><span><ha-icon icon="mdi:motion-sensor"></ha-icon> Aufwecken bei Bewegung (z. B. Bewegungsmelder im Flur)</span>${this._picker("tablet_wake", this._settings?.tablet_wake || [])}</div>
      <p class="muted small">Gilt für alle Tablets; Bewegung hält den Bildschirm außerdem wach. In Fully kann zusätzlich die Bewegungserkennung der Kamera wecken (Fully › Bewegungserkennung).</p>
      <p class="muted small"><ha-icon icon="mdi:calendar"></ha-icon>Termine im Bildschirmschoner (z. B. Müllabfuhr) kommen aus <button class="link inline" data-action="settings-go" data-sub="calendars">Hauswerk › Kalender</button>.</p>
      ${this._data?.user_admin ? `<p class="muted small warnline"><ha-icon icon="mdi:shield-alert-outline"></ha-icon>Angemeldet als Administrator${this._data.user_name ? ` (${esc(this._data.user_name)})` : ""}: Die Sperre gilt nur in diesem Panel. Wirklich sicher ist ein eigener Benutzer ohne Admin-Rechte fürs Tablet – Home Assistant lässt ihn dann auch über andere Wege nichts einstellen; bedienen darf er weiterhin.</p>`
        : `<p class="muted small okline"><ha-icon icon="mdi:shield-check-outline"></ha-icon>Angemeldet als ${esc(this._data?.user_name || "Benutzer")} ohne Admin-Rechte: Einstellungen sind auch auf dem Server gesperrt${this._data?.is_admin ? " – außer, „Alle Benutzer dürfen ändern“ ist eingeschaltet" : ""}. Bedienen geht weiterhin.</p>`}
      <label class="check"><span><b>Tablet sperren</b><small>Nur bedienen – Temperatur, Rollläden, Anwesenheit –, nichts einstellen. Entsperren: 3 Sekunden auf das Hauswerk-Logo oben links drücken (10 Minuten).</small></span>
        <button class="seg ${this._tabletOpt("lock", "0") === "1" ? "on" : ""}" data-action="tablet-opt" data-k="lock" data-v="${this._tabletOpt("lock", "0") === "1" ? "0" : "1"}">${this._tabletOpt("lock", "0") === "1" ? "An" : "Aus"}</button></label>
      <label class="check"><span><b>Seitenleiste von Home Assistant ausblenden</b><small>Mehr Platz für Hauswerk. Über ☰ oben links lässt sie sich jederzeit kurz öffnen; ohne Tabletmodus kommt sie wie vorher zurück.</small></span>
        <button class="seg ${this._tabletOpt("sidebar", "1") === "1" ? "on" : ""}" data-action="tablet-opt" data-k="sidebar" data-v="${this._tabletOpt("sidebar", "1") === "1" ? "0" : "1"}">${this._tabletOpt("sidebar", "1") === "1" ? "An" : "Aus"}</button></label>
      ${window.fully ? `<label class="check"><span><b>Fully: Display mit abdunkeln</b><small>Senkt die Helligkeit über Fully, solange der Bildschirmschoner läuft.</small></span>
        <button class="seg ${fully ? "on" : ""}" data-action="tablet-opt" data-k="fully" data-v="${fully ? "0" : "1"}">${fully ? "An" : "Aus"}</button></label>` : ""}
      <button class="secondary" data-action="saver-test"><ha-icon icon="mdi:clock-outline"></ha-icon>Bildschirmschoner jetzt zeigen</button>` : ""}
      <p class="muted small"><ha-icon icon="mdi:information-outline"></ha-icon>Für Fully als Start-Adresse <code>…/hauswerk?tablet</code> eintragen – dann startet das Tablet immer im Tabletmodus. In Fully „Bildschirm anlassen“ und für das Abdunkeln die JavaScript-Schnittstelle einschalten.</p>`;
  }

  /** Seite ohne Scrollen: Größe (und bei Listen zwei Spalten) so wählen, dass alles auf eine Seite passt – höchstens zwei Seiten zum Wischen. */
  _tabletFit(full = false) {
    const main = this.shadowRoot.getElementById("main");
    const box = main?.querySelector(".tpages");
    const tin = box?.firstElementChild;
    if (!box || !tin) return;
    const W = main.clientWidth, H = main.clientHeight;
    if (!W || !H) return;
    const GAP = 40;
    const tab = this._tab;
    // Größe unter Darstellung (Kompakt · Normal · Groß) wirkt auch hier
    const f = { s: 0.85, m: 1, l: 1.2 }[this._lookSize()] || 1;
    const onePage = ["settings", "shutset", "kwset", "lightset", "house"].includes(tab);
    const ZOOMS = [1.4, 1.3, 1.2, 1.1, 1, 0.92, 0.85, 0.78, 0.72, 0.66, ...(onePage ? [0.6, 0.55] : [])].map((z) => Math.round(z * f * 100) / 100);
    const maxZ = Math.max(f, Math.min(1.4 * f, (W / 820) * f));
    const zs = ZOOMS.filter((z) => z <= maxZ + 0.001);
    // Kachel-Seiten blättern reihenweise (ohne CSS-Spalten – ältere Tablet-Browser teilen Raster nicht auf),
    // Listen-Seiten fließen in Spalten (bis zu drei).
    const rows = ["start", "overview", "shutters", "kwflow", "lights"].includes(tab) || W < 900;
    const ks = rows ? [1] : onePage && W >= 1100 ? [1, 2, 3] : [1, 2];
    const base = (z) => {
      tin.style.zoom = z;
      tin.style.width = `${W / z}px`;
      tin.style.transform = "";
      tin.style.clipPath = "";
      // Kopfleisten unabhängig von der Seitengröße: überall gleich hoch und gleich groß
      tin.querySelectorAll(".brief").forEach((b) => { b.style.zoom = 1 / z; });
    };
    // Reihen: Kacheln, die nicht geteilt werden dürfen, und die Seitenumbrüche dazwischen
    const pagesOf = () => {
      const top0 = tin.getBoundingClientRect().top;
      const atoms = [];
      const SOLID = ".card, article, .wdg, .brief, [data-wi], .rw-c, .srow, .hint, .setup-card";
      const walk = (el) => {
        for (const c of el.children) {
          const r = c.getBoundingClientRect();
          if (!r.height) continue;
          const cs = getComputedStyle(c);
          const box2 = !c.matches(SOLID) && c.children.length > 1 && (r.height > H * 0.55 || cs.display.includes("grid") || cs.flexWrap === "wrap" || cs.display === "block");
          if (box2) walk(c);
          else atoms.push({ t: r.top - top0, b: r.bottom - top0, head: c.matches(".shead, h3, h4") });
        }
      };
      walk(tin);
      atoms.sort((x, y) => x.t - y.t || x.b - y.b);
      const pages = [];
      let start = 0, end = 0;
      atoms.forEach((a, i) => {
        if (a.b - start > H + 1 && a.t > start + 1) {
          let ns = a.t;
          const prev = atoms[i - 1];
          if (prev && prev.head && prev.t > start && a.t - prev.b < 48) ns = prev.t;
          pages.push([start, Math.min(Math.max(end, start), ns)]);
          start = ns;
        }
        end = Math.max(end, a.b);
      });
      pages.push([start, Math.max(end, start)]);
      return { pages, total: tin.getBoundingClientRect().height };
    };
    // Kachel-Raster (Räume, Rollläden detailliert): feste Spalten, genau 2 Reihen je Seite, in beiden Modulen gleich
    const grid = rows && W >= 900 ? tin.querySelector(".rooms:not(.compact), .rw-grid.tgrid") : null;
    if (grid) {
      grid.classList.add("tgrid");
      const cols = Math.max(2, Math.min(4, Math.floor(W / 380)));
      const gapPx = 12;
      const fits = (z) => {
        base(z);
        tin.style.height = "auto";
        tin.style.columnWidth = "auto";
        grid.style.gridTemplateColumns = `repeat(${cols}, minmax(0, 1fr))`;
        grid.style.gridAutoRows = "auto";
        const top = grid.getBoundingClientRect().top - tin.getBoundingClientRect().top;
        const maxT = Math.max(0, ...[...grid.children].map((c) => c.getBoundingClientRect().height));
        return { ok: top + 2 * maxT + gapPx * z <= H + 1, top };
      };
      // gleiche Größe für Heizwerk und Rollwerk: die kleinere der beiden passenden Stufen
      let zFit = zs[zs.length - 1];
      for (const z of zs) if (fits(z).ok) { zFit = z; break; }
      this._tTileZ = { ...(this._tTileZ || {}), [tab]: zFit };
      const z = Math.min(...Object.values(this._tTileZ));
      const { top } = fits(z);
      const rowH = (H - top - gapPx * z) / 2;
      grid.style.gridAutoRows = `${rowH / z}px`;
      const r = pagesOf();
      this._tRows = r;
      this._tFit = { ...(this._tFit || {}), [tab]: { z, k: 1, n: r.pages.length, key: `${W}x${H}x${f}` } };
      this._tZoom = { ...(this._tZoom || {}), [tab]: z };
      this._tRowMode = true;
      const n = r.pages.length;
      this._tPages = n;
      const page = Math.min(this._tPage[tab] || 0, n - 1);
      this._tPage[tab] = page;
      this._tShow(page);
      const dots = this.shadowRoot.getElementById("tdots");
      if (dots) dots.innerHTML = n > 1 ? Array.from({ length: n }, (_, k) => `<button class="${k === page ? "on" : ""}" data-action="tpage" data-i="${k}" aria-label="Seite ${k + 1}"></button>`).join("") : "";
      return;
    }
    const layout = (z, k) => {
      base(z);
      if (rows) {
        tin.style.height = "auto";
        tin.style.columnWidth = "auto";
        tin.classList.remove("two");
        const r = pagesOf();
        this._tRows = r;
        return r.pages.length;
      }
      const colW = (W / z - ((k - 1) * GAP) / z) / k;
      tin.style.height = `${H / z}px`;
      tin.style.columnWidth = `${colW}px`;
      tin.style.columnGap = `${GAP / z}px`;
      tin.classList.toggle("two", k >= 2);
      const colV = (W - (k - 1) * GAP) / k;
      const cols = Math.max(1, Math.round((box.scrollWidth + GAP) / (colV + GAP)));
      return Math.ceil(cols / k);
    };
    const key = `${W}x${H}x${f}`;
    const prev = this._tFit?.[tab];
    let best = null;
    // schneller Weg: letzte Wahl gilt noch (gleiche Größe, nicht mehr Seiten als vorher)
    if (!full && prev && prev.key === key) {
      const n = layout(prev.z, prev.k);
      if (n <= prev.n) best = { ...prev, n };
    }
    if (!best) {
      // Lesbarkeit vor „alles auf eine Seite“: eine Seite nur, wenn sie kaum kleiner ist als zwei Seiten
      const opts = [];
      for (const k of ks) {
        let z1 = null, z2 = null;
        for (const z of zs) {
          const n = layout(z, k);
          if (n <= 2 && z2 == null) z2 = z;
          if (n === 1) { z1 = z; break; }
        }
        if (z1 != null && (onePage || z2 == null || z1 >= f || z1 >= z2 - 0.11 * f)) opts.push({ z: z1, k, n: 1 });
        else if (z2 != null) opts.push({ z: z2, k, n: 2 });
        else opts.push({ z: zs[zs.length - 1], k, n: layout(zs[zs.length - 1], k) });
      }
      opts.sort((x, y) => (Math.min(x.n, 3) > 2) - (Math.min(y.n, 3) > 2) || y.z - x.z || x.n - y.n || x.k - y.k);
      best = { ...opts[0], key };
      best.n = layout(best.z, best.k);
    }
    this._tFit = { ...(this._tFit || {}), [tab]: best };
    this._tZoom = { ...(this._tZoom || {}), [tab]: best.z };
    this._tRowMode = rows;
    const n = best.n;
    this._tPages = n;
    const page = Math.min(this._tPage[tab] || 0, n - 1);
    this._tPage[tab] = page;
    this._tShow(page);
    const dots = this.shadowRoot.getElementById("tdots");
    if (dots) dots.innerHTML = n > 1 ? Array.from({ length: n }, (_, k) => `<button class="${k === page ? "on" : ""}" data-action="tpage" data-i="${k}" aria-label="Seite ${k + 1}"></button>`).join("") : "";
  }

  /** Seite zeigen: Reihen-Modus verschiebt und schneidet zu, Spalten-Modus scrollt zur Spalte. */
  _tShow(page) {
    const box = this.shadowRoot.querySelector("#main .tpages");
    const tin = box?.firstElementChild;
    if (!box || !tin) return;
    const z = this._tZoom?.[this._tab] || 1;
    if (this._tRowMode) {
      const r = this._tRows;
      const [s, e] = r?.pages?.[page] || [0, 0];
      box.scrollLeft = 0;
      tin.style.transform = s ? `translateY(${-s / z}px)` : "";
      tin.style.clipPath = r ? `inset(${s / z}px 0 ${Math.max(0, r.total - e) / z}px 0)` : "";
    } else {
      tin.style.transform = "";
      tin.style.clipPath = "";
      box.scrollLeft = page * (box.clientWidth + 40);
    }
  }

  _tabletGo(page) {
    const box = this.shadowRoot.querySelector("#main .tpages");
    if (!box) return;
    const n = this._tPages || 1;
    page = Math.max(0, Math.min(n - 1, page));
    if (page === (this._tPage[this._tab] || 0)) return;
    this._tPage[this._tab] = page;
    // sofort springen (langsame Tablets ruckeln bei Animationen), kurz einblenden
    this._tShow(page);
    box.classList.remove("tflip");
    void box.offsetWidth;
    box.classList.add("tflip");
    this.shadowRoot.querySelectorAll("#tdots button").forEach((b, k) => b.classList.toggle("on", k === page));
  }

  /** Gesperrtes Tablet: 3 Sekunden auf das Hauswerk-Logo drücken entsperrt für 10 Minuten. */
  _unlockPress(e) {
    if (!this._tablet || this._tabletOpt("lock", "0") !== "1") return;
    if (!e.composedPath().some((n) => n.classList?.contains("brand"))) return;
    const timer = setTimeout(() => {
      this._unlockUntil = Date.now() + 10 * 60000;
      this._toast("Für 10 Minuten entsperrt");
      this._renderMain();
      setTimeout(() => this._renderMain(), 10 * 60000 + 500);
    }, 3000);
    const stop = () => { clearTimeout(timer); window.removeEventListener("pointerup", stop); window.removeEventListener("pointercancel", stop); };
    window.addEventListener("pointerup", stop);
    window.addEventListener("pointercancel", stop);
  }

  /** Wischen zwischen den Seiten: wechselt schon während der Bewegung (nicht erst beim Loslassen). */
  _tSwipeStart(e) {
    if (!this._tablet || (this._tPages || 1) < 2) return;
    const path = e.composedPath();
    if (!path.includes(this.shadowRoot.getElementById("main"))) return;
    if (path.some((n) => n.dataset?.drag !== undefined || n.dataset?.rwwin !== undefined || ["INPUT", "SELECT", "TEXTAREA"].includes(n.tagName))) return;
    const x0 = e.clientX, y0 = e.clientY;
    let done = false;
    const move = (ev) => {
      if (done) return;
      const dx = ev.clientX - x0, dy = ev.clientY - y0;
      if (Math.abs(dx) > 35 && Math.abs(dx) > Math.abs(dy) * 1.2) {
        done = true;
        this._swiped = Date.now();
        this._tabletGo((this._tPage[this._tab] || 0) + (dx < 0 ? 1 : -1));
      }
    };
    const up = (ev) => {
      move(ev);
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
      window.removeEventListener("pointercancel", up);
    };
    window.addEventListener("pointermove", move, { passive: true });
    window.addEventListener("pointerup", up);
    window.addEventListener("pointercancel", up);
  }

  // ------------------------------------------------------------ Bildschirmschoner
  /** Bewegung (Melder aus Home Assistant oder Fully): aufwecken bzw. wach halten. */
  _wake() {
    this._lastAct = Date.now();
    const el = this.shadowRoot?.getElementById("saver");
    if (el && !el.hidden) this._saverHide();
  }

  _wakeCheck(hass) {
    const ids = this._data.settings.tablet_wake || [];
    if (!ids.length) return;
    const on = ids.filter((id) => ["on", "detected", "home", "open", "true"].includes(String(hass.states[id]?.state).toLowerCase()));
    const sig = on.join(",");
    if (sig === this._wakeSig) return;
    const fresh = on.some((id) => !(this._wakeSig || "").split(",").includes(id));
    this._wakeSig = sig;
    if (fresh) this._wake();
  }

  _saverTick() {
    const min = Number(this._tabletOpt("saver", "2"));
    const el = this.shadowRoot.getElementById("saver");
    if (!el) return;
    if (!el.hidden) return this._saverRender();
    if (min > 0 && this._data && Date.now() - (this._lastAct || 0) >= min * 60000) this._saverShow();
  }

  _saverShow() {
    const el = this.shadowRoot.getElementById("saver");
    if (!el || !this._data) return;
    // zurück zur Startseite, offene Fenster schließen
    if (this._pop) this._closePopQuiet();
    if (this._dialog) { this._dialog = null; this._renderDialog(); }
    this._wEdit = false;
    if (this._tab !== "start" && !(this._tab === "plans" && this._plan?.dirty)) this._setView("start");
    this._tPage.start = 0;
    this._saverSeen = new Set([...this._hints(), ...this._urgent()].map((h) => `${h.text}|${h.sub}`));
    this._saverNew = {};
    this._saverAlert = false;
    el.hidden = false;
    this._calLoad();
    this._saverRender();
    try {
      if (window.fully) this._fullyBright = Number(window.fully.getScreenBrightness());
    } catch (e) {
      this._fullyBright = null;
    }
    this._saverLight();
  }

  /** Display über Fully: abdunkeln, nachts ggf. aus, bei neuem wichtigem Hinweis hell. */
  _saverLight() {
    const f = window.fully;
    if (!f) return;
    try {
      const night = this._saverNight();
      const mode = this._tabletOpt("night", "dim");
      if (this._saverAlert) {
        if (this._screenOff) { f.turnScreenOn(); this._screenOff = false; }
        if (this._fullyBright > 0) f.setScreenBrightness(this._fullyBright);
      } else if (night && mode === "off") {
        if (!this._screenOff) { f.turnScreenOff(true); this._screenOff = true; }
      } else {
        if (this._screenOff) { f.turnScreenOn(); this._screenOff = false; }
        if (this._tabletOpt("fully", "1") === "1" && this._fullyBright > 0)
          f.setScreenBrightness(Math.max(1, Math.round(this._fullyBright * (night ? 0.05 : 0.15))));
      }
    } catch (e) {
      /* Fully nicht erreichbar */
    }
  }

  _saverHide() {
    const el = this.shadowRoot?.getElementById("saver");
    if (el) el.hidden = true;
    this._lastAct = Date.now();
    try {
      if (window.fully && this._screenOff) window.fully.turnScreenOn();
      if (window.fully && this._fullyBright > 0) window.fully.setScreenBrightness(this._fullyBright);
    } catch (e) {
      /* Fully nicht erreichbar */
    }
    this._screenOff = false;
    this._fullyBright = null;
  }

  _saverNight() {
    const h = new Date().getHours();
    const from = Number(this._tabletOpt("night_from", "22")), to = Number(this._tabletOpt("night_to", "6"));
    return from > to ? h >= from || h < to : h >= from && h < to;
  }

  /** Wichtiges für den Bildschirmschoner: Warnungen, Sturm, offenes Fenster bei Regen. */
  _urgent() {
    const out = this._hints().filter((h) => h.lvl === "warn").map((h) => ({ ...h }));
    if (this._rwStatus?.storm) out.unshift({ lvl: "warn", live: true, icon: "mdi:weather-windy-variant", text: "Sturm", sub: "Rollläden fahren hoch" });
    const wid = this._data.settings.weather_entity || Object.keys(this._hass.states).find((e) => e.startsWith("weather."));
    const rain = ["rainy", "pouring", "lightning-rainy", "snowy-rainy", "hail", "snowy"].includes(this._hass.states[wid]?.state);
    if (rain) for (const o of this._openWindows()) out.unshift({ lvl: "warn", live: true, icon: "mdi:weather-pouring", text: "Fenster offen – es regnet", sub: this._entityName(o.id) === o.room.name ? o.room.name : `${o.room.name} · ${this._entityName(o.id)}` });
    return out;
  }

  /** Alle Termin-Kalender aus Hauswerk › Kalender: Standard-Kalender zuerst, dann weitere, dann Müllabholung. */
  _allCals() {
    const set = this._data?.settings || {};
    return [...new Set([set.main_calendar, ...(set.calendars || []), ...(set.waste_calendars || [])].filter(Boolean))];
  }

  /** Ausgeblendete Abfallarten (Hauswerk › Kalender › Müllabholung) nicht zeigen. */
  _calShown(e) {
    const set = this._data?.settings || {};
    if (!(set.waste_calendars || []).includes(e.cal)) return true;
    return !(set.waste_hidden || []).some((h) => h.toLowerCase() === String(e.title).toLowerCase());
  }

  /** Termine aus Kalendern (heute + days), zwischengespeichert; lädt im Hintergrund nach und zeichnet dann neu. */
  _calFetch(ids, days = 2) {
    ids = (ids || []).filter(Boolean);
    if (!ids.length || !this._hass?.callApi) return [];
    const key = `${ids.join(",")}|${days}`;
    this._calCache = this._calCache || {};
    const c = this._calCache[key];
    if (!c || (Date.now() - c.at > 15 * 60000 && !c.busy)) {
      const entry = (this._calCache[key] = { at: Date.now(), list: c?.list || [], busy: true });
      (async () => {
        const start = new Date(), end = new Date();
        start.setHours(0, 0, 0, 0);
        end.setDate(end.getDate() + days);
        end.setHours(0, 0, 0, 0);
        const list = [];
        for (const id of ids) {
          try {
            const ev = await this._hass.callApi("GET", `calendars/${id}?start=${encodeURIComponent(start.toISOString())}&end=${encodeURIComponent(end.toISOString())}`);
            for (const e of ev || []) {
              const item = { title: e.summary || "Termin", start: e.start?.dateTime || e.start?.date || e.start, allDay: !e.start?.dateTime && !!e.start?.date, cal: id };
              if (this._calShown(item)) list.push(item);
            }
          } catch (err) {
            /* Kalender nicht lesbar */
          }
        }
        entry.list = list.sort((a, b) => String(a.start).localeCompare(String(b.start)));
        entry.busy = false;
        if (this._tab === "start") this._renderMain();
      })();
    }
    return this._calCache[key].list;
  }

  /** Symbol für einen Termin: Müllarten erkennen, sonst Kalender. */
  _calIcon(title) {
    const t = String(title).toLowerCase();
    if (/rest|haus(müll|muell)/.test(t)) return ["mdi:trash-can-outline", "#64748b"];
    if (/bio|grün|gruen|kompost/.test(t)) return ["mdi:leaf", "#16a34a"];
    if (/papier|pappe|blau/.test(t)) return ["mdi:newspaper-variant-outline", "#2563eb"];
    if (/gelb|wertstoff|verpackung|plastik/.test(t)) return ["mdi:recycle", "#eab308"];
    if (/glas/.test(t)) return ["mdi:bottle-wine-outline", "#0d9488"];
    if (/sperr|schadstoff/.test(t)) return ["mdi:sofa-outline", "#a16207"];
    if (/müll|muell|abfall|tonne/.test(t)) return ["mdi:delete-outline", "#64748b"];
    return ["mdi:calendar", "#f472b6"];
  }

  /** „Heute“, „Morgen“ oder Wochentag. */
  _dayName(d) {
    const x = new Date(d);
    const td = new Date();
    td.setHours(0, 0, 0, 0);
    const diff = Math.round((new Date(x.getFullYear(), x.getMonth(), x.getDate()) - td) / 86400000);
    return diff <= 0 ? "Heute" : diff === 1 ? "Morgen" : x.toLocaleDateString("de-DE", { weekday: "long" });
  }

  /** „ab 14 Uhr Regen“ aus der Stunden-Vorhersage (nächste 12 Stunden), sonst null. */
  _rainHint() {
    const set = this._data.settings;
    const wid = set.weather_entity || Object.keys(this._hass.states).find((e) => e.startsWith("weather."));
    if (!wid || !(Number(this._hass.states[wid]?.attributes?.supported_features || 0) & 2)) return null;
    const RAIN = ["rainy", "pouring", "lightning-rainy", "snowy-rainy", "hail", "snowy"];
    const now = Date.now();
    const items = (this._forecast(wid, "hourly")?.list || []).filter((x) => new Date(x.datetime) > now - 30 * 60000).slice(0, 12);
    if (RAIN.includes(this._hass.states[wid]?.state)) {
      const dry = items.find((x) => !RAIN.includes(x.condition) && (x.precipitation_probability ?? 0) < 50);
      return dry ? `Regen bis etwa ${new Date(dry.datetime).toLocaleTimeString("de-DE", { hour: "2-digit" })} Uhr` : "Regen hält an";
    }
    const wet = items.find((x) => RAIN.includes(x.condition) || (x.precipitation_probability ?? 0) >= 60);
    if (!wet) return null;
    const snow = /snow/.test(wet.condition);
    return `ab ${new Date(wet.datetime).toLocaleTimeString("de-DE", { hour: "2-digit" })} Uhr ${snow ? "Schnee" : "Regen"}`;
  }

  // ------------------------------------------------------------ Lüften
  /** Lüften-Zustand eines Raums für Kachel und Listen: [icon, Kurztext, Farbe, Titel] oder null. */
  /** Kamin bzw. zusätzliche Wärme: [Symbol, Text, Farbe, Erklärung] oder null. */
  _fireChip(s) {
    const fp = s?.fireplace;
    if (!fp?.state) return null;
    const keep = " – zählt nicht für die Bewertung der Heizleistung.";
    if (fp.state === "on") return ["mdi:fireplace", "", C.warm, `Kamin an (${fp.source === "manuell" ? "von Hand" : "laut Signal"})${keep}`];
    if (fp.state === "maybe")
      return ["mdi:fireplace", "?", C.rest, fp.cause === "other"
        ? `Wärmer ohne Heizung (+${fmt(fp.rise)} °C in 30 Min.) – der Kamin ist laut Signal aus, also eine andere Wärmequelle${keep}`
        : `Wärmer ohne Heizung (+${fmt(fp.rise)} °C in 30 Min.) – vielleicht der Kamin, die Sonne oder Kochen. Sicher ist das nicht${keep}`];
    return ["mdi:fireplace", "", "#fdba74", `Nachwärme – der Raum ist noch wärmer als gewollt${keep}`];
  }

  _ventChip(s) {
    const a = s?.air || {};
    if (a.open?.done) return ["mdi:window-closed-variant", "schließen", "#ef4444", `Genug gelüftet – Fenster schließen (${a.open.done})`];
    if (a.open && a.open.cool) return ["mdi:snowflake", `kühlt ${Math.floor(a.open.minutes)} Min.`, "#38bdf8", "Fenster offen zum Kühlen – Hinweis, sobald es draußen wärmer ist"];
    if (a.open && !a.long) return ["mdi:timer-sand", `${Math.floor(a.open.minutes)}/${a.open.target} Min.`, "#22c55e", `Lüften läuft – empfohlen ${a.open.target} Min.`];
    if (a.long) return ["mdi:window-open-variant", `${a.long.minutes} Min.`, "#f59e0b", `Lange offen – ca. ${fmt(a.long.kwh)} kWh Wärme; lieber kurz stoßlüften`];
    if (s?.vent) return ["mdi:weather-windy", `${s.vent.minutes} Min.`, C.air, `Jetzt ${s.vent.minutes} Min. stoßlüften – ${(s.vent.reasons || []).join(", ")}`];
    if (a.mold?.level === "bad") return ["mdi:alert-octagon-outline", `${a.mold.wall_rh} %`, "#ef4444", `Schimmelgefahr: an Außenwänden ca. ${a.mold.wall_rh} % Luftfeuchte`];
    return null;
  }

  /** Feuchte-Grenze eines Raums wie im Backend (eigener Wert, sonst Bad 70 %, Schlaf-/Kinderzimmer 60 %). */
  _ventLimitOf(r) {
    const base = Number(this._data?.settings?.vent_rh ?? 65) || 65;
    if (r.vent_rh) return Number(r.vent_rh);
    const n = String(r.name || "").toLowerCase();
    if (r.use === "bad" || /bad|dusche|wc/.test(n)) return Math.max(base, 70);
    if (["schlafen", "kind"].includes(r.use) || /schlaf|kinder/.test(n)) return Math.min(base, 60);
    return base;
  }

  _viewVent() {
    const rooms = this._rooms().filter((r) => r.enabled !== false);
    const st = this._status?.rooms || {};
    const set = this._data.settings;
    const [outT, outRh] = (() => { const w = this._weather(); return [w?.temp ?? null, null]; })();
    const mins = outT == null ? 10 : outT < 0 ? 5 : outT < 10 ? 10 : outT < 15 ? 15 : 25;
    const amp = { ok: ["#22c55e", "kein Risiko"], warn: ["#f59e0b", "aufpassen"], bad: ["#ef4444", "Schimmelgefahr"] };
    const ago = (iso) => { const m = Math.round((Date.now() - new Date(iso)) / 60000); return m < 60 ? `vor ${Math.max(1, m)} Min.` : m < 1440 ? `vor ${Math.floor(m / 60)} Std.` : `vor ${Math.floor(m / 1440)} Tg.`; };
    const card = (r) => {
      const s = st[r.id] || {};
      const a = s.air || {};
      const chip = this._ventChip(s);
      let state;
      if (a.open) {
        const pc = a.open.cool ? 100 : Math.min(100, (a.open.minutes / a.open.target) * 100);
        state = `<div class="vt-run ${a.open.done ? "done" : ""}"><div class="vt-bar"><i style="width:${pc}%"></i></div>
          <b>${a.open.done ? `Genug gelüftet – Fenster schließen` : a.open.cool ? `Kühlt seit ${Math.floor(a.open.minutes)} Min.` : `Lüftet ${Math.floor(a.open.minutes)} von ${a.open.target} Min.`}</b>
          <small>${a.open.done ? esc(a.open.done) : a.open.cool ? "Hinweis kommt, sobald es draußen wärmer ist" : "Ende: Zeit um, Feuchte gesunken oder Raum zu kühl"}${a.long ? ` · ca. ${fmt(a.long.kwh)} kWh Wärme` : ""}</small></div>`;
      } else if (s.vent) state = `<div class="vt-need"><ha-icon icon="mdi:weather-windy"></ha-icon><span><b>Jetzt ${s.vent.minutes} Min. stoßlüften</b><small>${esc((s.vent.reasons || []).join(" · "))}</small></span></div>`;
      else state = `<div class="vt-ok"><ha-icon icon="mdi:check-circle-outline"></ha-icon><span>${s.humidity == null && a.co2 == null ? "Ohne Feuchtesensor nur Lüft-Timer und Bilanz" : "Kein Lüften nötig"}</span></div>`;
      const facts = [
        s.humidity != null ? [`${fmt(s.humidity, 0)} %`, `Luftfeuchte · ab ${fmt(a.limit, 0)} % lüften`, s.humidity >= (a.limit || 99) ? "#f59e0b" : ""] : null,
        a.mold ? [`${a.mold.wall_rh} %`, `an der Außenwand (${fmt(a.mold.wall_temp)} °C) · ${amp[a.mold.level][1]}`, amp[a.mold.level][0]] : null,
        a.co2 != null ? [`${a.co2} ppm`, "CO₂", a.co2 >= (set.vent_co2 || 1000) ? "#f59e0b" : ""] : null,
        a.last ? [ago(a.last.at), `zuletzt gelüftet · ${fmt(a.last.min, 0)} Min.${a.last.rh0 != null && a.last.rh1 != null ? ` · ${fmt(a.last.rh0, 0)} → ${fmt(a.last.rh1, 0)} %` : ""}`, ""] : null,
        a.week?.count ? [`${a.week.count}×`, `7 Tage · ${a.week.minutes} Min.${a.week.kwh ? ` · ca. ${fmt(a.week.kwh)} kWh` : ""}`, ""] : null,
      ].filter(Boolean);
      return `<article class="card vt-c" data-action="room-page" data-id="${esc(r.id)}" role="button" tabindex="0">
        <div class="vt-h"><span class="rdot" style="background:${this._roomColor(r.id)}"></span><b>${esc(r.name)}</b>${chip ? `<span class="vt-chip" style="--c:${chip[2]}" title="${esc(chip[3])}"><ha-icon icon="${chip[0]}"></ha-icon>${esc(chip[1])}</span>` : ""}</div>
        ${state}
        ${facts.length ? `<div class="vt-f">${facts.map(([v, l, c]) => `<span ${c ? `style="--c:${c}" class="on"` : ""}><b>${esc(v)}</b><small>${esc(l)}</small></span>`).join("")}</div>` : ""}
      </article>`;
    };
    const need = rooms.filter((r) => st[r.id]?.vent || st[r.id]?.air?.open?.done);
    const head = this._brief({
      cls: "card br-mod-heat", tone: need.some((r) => st[r.id]?.air?.open?.done) ? "warn" : need.length ? "active" : "ok", icon: "mdi:weather-windy",
      label: `<ha-icon icon="mdi:weather-windy"></ha-icon>Lüften`,
      big: `${mins}<span> Min.</span>`,
      title: need.length ? need.map((r) => `${r.name}: ${st[r.id].air?.open?.done ? "Fenster schließen" : `${st[r.id].vent.minutes} Min. lüften`}`).join(" · ") : "Gerade muss nirgends gelüftet werden",
      side: `<button class="link" data-action="settings-go" data-sub="vent"><ha-icon icon="mdi:tune-variant"></ha-icon>Einstellen</button>`,
      lines: [{ icon: "mdi:thermometer", text: `Richtwert Stoßlüften bei ${outT == null ? "–" : fmt(outT)} °C draußen: ${mins} Min. – Fenster ganz auf, Heizung pausiert` },
        { icon: "mdi:information-outline", text: "Kurz und weit öffnen statt kippen: tauscht die Luft, ohne Wände auszukühlen" }],
    });
    return head + `<div class="vt-grid">${rooms.map(card).join("")}</div>`;
  }

  _w_vent(w, z) {
    const st = this._status?.rooms || {};
    const list = this._rooms().map((r) => [r, st[r.id] || {}]).map(([r, s]) => [r, s, this._ventChip(s)]).filter(([, , c]) => c);
    if (!list.length) return `<div class="wok"><ha-icon icon="mdi:check-circle-outline"></ha-icon>Gerade muss nirgends gelüftet werden</div>`;
    return `<div class="wlist">${list.slice(0, z === "s" ? 2 : z === "m" ? 4 : 8).map(([r, s, c]) => `<button class="wl-row" data-action="tab" data-tab="vent"><ha-icon icon="${c[0]}" style="color:${c[2]}"></ha-icon><span class="grow"><b>${esc(r.name)}</b>${z !== "s" ? `<small>${esc(c[3])}</small>` : ""}</span><em style="color:${c[2]}">${esc(c[1])}</em></button>`).join("")}</div>`;
  }

  // ------------------------------------------------------------ neue Widgets
  _w_lage(w, z) {
    const items = [];
    if (this._rooms().length) items.push(["heizen", "overview", this._briefParts(this._heatBriefHtml())]);
    if (this._data.rollwerk && this._rwCovers().length) items.push(["rollwerk", "shutters", this._briefParts(this._rwBriefHtml())]);
    if (this._kwConfigured(this._data.settings)) {
      const fl = this._kwFlow();
      items.push(["kraftwerk", "kwflow", this._briefParts(this._kwBrief(fl, this._kwPrefs()?.ok ? this._kwStats("today") : null))]);
    }
    if (this._data.lichtwerk && this._lwLights().length) items.push(["lichtwerk", "lights", this._briefParts(this._lwBriefHtml())]);
    const list = items.filter(([, , b]) => b);
    if (!list.length) return `<p class="muted small">Noch kein Modul eingerichtet.</p>`;
    return `<div class="wlage ${z}">${list.map(([m, tab, b]) => `
      <button class="wl" data-action="tab" data-tab="${tab}" style="--c:${b.color}">
        <span class="wl-logo">${MODULE_LOGOS[m] || ""}</span>
        <span class="grow"><b>${esc(b.title)}</b>${z !== "s" && b.lines[0] ? `<small>${esc(b.lines[0])}${z === "l" && b.lines[1] ? ` · ${esc(b.lines[1])}` : ""}</small>` : ""}</span>
        <ha-icon class="wl-go" icon="mdi:chevron-right"></ha-icon>
      </button>`).join("")}</div>`;
  }

  /** Ereignisse der nächsten Stunden: Heizwechsel, Rollladen-Fahrten, Termine. */
  _events(w) {
    const now = new Date();
    const out = [];
    // Heizwerk: nächster Wechsel je Raum, gleiche Zeit zusammengefasst
    const st = this._status?.rooms || {};
    if (!this._status?.summer && !this._status?.vacation) {
      const heat = new Map();
      for (const r of this._rooms()) {
        if (r.enabled === false) continue;
        const info = this._schedInfo(r, st[r.id] || {});
        const mins = info.blocks && info.blocks.length ? this._nextSwitch(info.blocks, r, info.comfort) : st[r.id]?.next_change;
        if (mins == null || mins > 30 * 60) continue;
        const at = new Date(now.getTime() + Math.round(mins) * 60000);
        at.setSeconds(0, 0);
        const key = `${at.getTime()}|${info.comfort}`;
        if (!heat.has(key)) heat.set(key, { at, icon: info.comfort ? "mdi:leaf" : "mdi:sofa-outline", c: info.comfort ? "#60a5fa" : "#f59e0b", text: info.comfort ? "Eco" : "Komfort", names: [], go: "overview" });
        heat.get(key).names.push(r.name);
      }
      out.push(...heat.values());
    }
    // Rollwerk: „16:50 schließt“ je Rollladen
    const rw = new Map();
    for (const c of this._data.rollwerk ? this._rwCovers() : []) {
      const m = /(\d{1,2}):(\d{2}) (.+)$/.exec(c.rs?.next || "");
      if (!m) continue;
      const at = new Date(now);
      at.setHours(Number(m[1]), Number(m[2]), 0, 0);
      if (at < now) at.setDate(at.getDate() + 1);
      const key = `${at.getTime()}|${m[3]}`;
      const down = /schließt|Stufe/.test(m[3]);
      if (!rw.has(key)) rw.set(key, { at, icon: down ? "mdi:arrow-down-bold" : /öffnet/.test(m[3]) ? "mdi:arrow-up-bold" : "mdi:sun-thermometer-outline", c: "#0ea5e9", text: `Rollläden: ${m[3]}`, names: [], go: "shutters" });
      rw.get(key).names.push(this._entityName(c.id));
    }
    out.push(...rw.values());
    // Termine
    const cals = (w.entities || []).length ? w.entities : this._allCals();
    for (const e of this._calFetch(cals, 2)) {
      const at = new Date(e.start);
      if (!e.allDay && at < now - 30 * 60000) continue;
      const [icon, c] = this._calIcon(e.title);
      out.push({ at, allDay: e.allDay, icon, c, text: e.title, names: [] });
    }
    return out.sort((a, b) => a.at - b.at);
  }

  _w_events(w, z) {
    const list = this._events(w).slice(0, { s: 3, m: 5, l: 9 }[z] || 5);
    if (!list.length) return `<div class="wok"><ha-icon icon="mdi:check-circle-outline"></ha-icon>Heute steht nichts mehr an</div>`;
    const when = (e) => {
      const day = this._dayName(e.at);
      if (e.allDay) return day === "Heute" ? "heute" : day.toLowerCase();
      const hm = e.at.toLocaleTimeString("de-DE", { hour: "2-digit", minute: "2-digit" });
      return day === "Heute" ? hm : `${day === "Morgen" ? "morgen" : day.slice(0, 2)} ${hm}`;
    };
    return `<div class="wev">${list.map((e) => `
      <${e.go ? "button" : "div"} class="we" ${e.go ? `data-action="tab" data-tab="${e.go}"` : ""}>
        <span class="we-t">${when(e)}</span><ha-icon icon="${e.icon}" style="color:${e.c}"></ha-icon>
        <span class="grow"><b>${esc(e.text)}</b>${z !== "s" && e.names.length ? `<small>${esc(e.names.length > 3 ? `${e.names.slice(0, 3).join(", ")} +${e.names.length - 3}` : e.names.join(", "))}</small>` : ""}</span>
      </${e.go ? "button" : "div"}>`).join("")}</div>`;
  }

  _w_calendar(w, z) {
    const cals = (w.entities || []).length ? w.entities : this._allCals();
    if (!cals.length) return this._wSetup(w, "Noch kein Kalender gewählt.");
    const days = z === "l" ? 7 : 2;
    const list = this._calFetch(cals, days).filter((e) => e.allDay || new Date(e.start) > Date.now() - 30 * 60000);
    if (!list.length) return `<div class="wok"><ha-icon icon="mdi:calendar-check-outline"></ha-icon>${days === 2 ? "Heute und morgen keine Termine" : "Diese Woche keine Termine"}</div>`;
    const groups = new Map();
    for (const e of list.slice(0, { s: 3, m: 6, l: 14 }[z] || 6)) {
      const d = this._dayName(e.start);
      if (!groups.has(d)) groups.set(d, []);
      groups.get(d).push(e);
    }
    return `<div class="wcal">${[...groups.entries()].map(([d, es]) => `
      <div class="wc-d">${d}</div>${es.map((e) => { const [icon, c] = this._calIcon(e.title); return `
        <div class="wc-e"><span class="wc-i" style="--c:${c}"><ha-icon icon="${icon}"></ha-icon></span><b>${esc(e.title)}</b>
        <small>${e.allDay ? "ganztägig" : new Date(e.start).toLocaleTimeString("de-DE", { hour: "2-digit", minute: "2-digit" })}</small></div>`; }).join("")}`).join("")}</div>`;
  }

  /** Vorschläge für ein leeres Werte- bzw. Shortcut-Widget, mit einem Tipp übernehmen. */
  _wSuggestIds(kind) {
    const S = this._hass.states;
    const set = this._data.settings;
    const out = [];
    const add = (id) => id && S[id] && !out.includes(id) && out.push(id);
    if (kind === "values") {
      add(set.outside_sensor);
      add(set.kw_home || set.kw_grid);
      add((set.kw_solar || [])[0]);
      const hum = this._rooms().map((r) => r.humidity_sensor).find(Boolean);
      add(hum);
      for (const [id, st] of Object.entries(S)) {
        if (out.length >= 4) break;
        const dc = st.attributes?.device_class;
        if (id.startsWith("sensor.") && ["gas", "energy", "monetary", "temperature"].includes(dc) && /gas|preis|price|vorlauf|zähler|zaehler|verbrauch/i.test(id + (st.attributes.friendly_name || ""))) add(id);
      }
    } else {
      for (const d of ["scene", "script"]) for (const id of Object.keys(S).filter((e) => e.startsWith(`${d}.`)).sort()) if (out.length < 4) add(id);
      if (out.length < 4) for (const id of Object.keys(S).filter((e) => e.startsWith("light.")).sort()) if (out.length < 4) add(id);
    }
    return out.slice(0, 4);
  }

  _wSuggest(w, z, kind) {
    const ids = this._wSuggestIds(kind);
    const i = this._widgets().indexOf(w);
    const what = kind === "values" ? "Noch keine Werte." : "Noch keine Knöpfe.";
    if (!ids.length || !this._admin || i < 0) return this._wSetup(w, what);
    return this._wSetup(w, `${what} Vorschlag:`, `<div class="wsug">${ids.slice(0, z === "s" ? 2 : 4).map((id) => `<span><ha-icon icon="${this._hass.states[id]?.attributes?.icon || SC_ICONS[id.split(".")[0]] || "mdi:gauge"}"></ha-icon>${esc(this._entityName(id))}</span>`).join("")}</div>
<!--btn--><button class="primary small" data-action="w-sugg" data-i="${i}" data-ids="${esc(ids.join(","))}"><ha-icon icon="mdi:check"></ha-icon>Übernehmen</button>`);
  }

  /** Leeres Widget: kurzer Satz und „Einrichten“ (öffnet die Einstellungen des Widgets). */
  _wSetup(w, text, extra = "") {
    const i = this._widgets().indexOf(w);
    const [chips, go] = extra.split("<!--btn-->");
    return `<div class="wsetup"><p class="muted small">${text}</p>${chips || ""}<div class="wsetup-b">${go || ""}${this._admin && i >= 0 ? `<button class="secondary small" data-action="w-conf" data-i="${i}"><ha-icon icon="mdi:cog-outline"></ha-icon>${go ? "Selbst wählen" : "Einrichten"}</button>` : ""}</div></div>`;
  }

  /** Kalender-Termine für den Bildschirmschoner (heute und morgen), höchstens alle 15 Minuten neu. */
  async _calLoad(force = false) {
    const ids = this._allCals();
    if (!ids.length || !this._hass?.callApi) { this._cal = []; return; }
    if (!force && this._calAt && Date.now() - this._calAt < 15 * 60000) return;
    this._calAt = Date.now();
    const start = new Date(), end = new Date();
    end.setDate(end.getDate() + 2);
    end.setHours(0, 0, 0, 0);
    const list = [];
    for (const id of ids) {
      try {
        const ev = await this._hass.callApi("GET", `calendars/${id}?start=${encodeURIComponent(start.toISOString())}&end=${encodeURIComponent(end.toISOString())}`);
        for (const e of ev || []) {
          const item = { title: e.summary || "Termin", start: e.start?.dateTime || e.start?.date || e.start, allDay: !e.start?.dateTime && !!e.start?.date, cal: id };
          if (this._calShown(item)) list.push(item);
        }
      } catch (err) {
        /* Kalender nicht lesbar */
      }
    }
    this._cal = list.sort((a, b) => String(a.start).localeCompare(String(b.start))).slice(0, 4);
    this._saverRender();
  }

  _saverRender() {
    const el = this.shadowRoot.getElementById("saver");
    if (!el || el.hidden || !this._data) return;
    this._calLoad();
    const now = new Date();
    const t = Date.now();
    const time = now.toLocaleTimeString("de-DE", { hour: "2-digit", minute: "2-digit" });
    const date = now.toLocaleDateString("de-DE", { weekday: "long", day: "numeric", month: "long" });
    const night = this._saverNight();
    const mode = this._tabletOpt("night", "dim");
    const w = this._weather();
    // neue Hinweise merken (5 Minuten hervorgehoben)
    const urgent = this._urgent();
    const hints = this._hints().filter((h) => h.lvl !== "warn");
    for (const h of [...urgent, ...hints]) {
      const k = `${h.text}|${h.sub}`;
      if (!this._saverSeen.has(k)) { this._saverSeen.add(k); this._saverNew[k] = t; }
    }
    const fresh = (h) => { const x = this._saverNew[`${h.text}|${h.sub}`]; return x && t - x < 5 * 60000; };
    const alert = urgent.some(fresh);
    if (alert !== this._saverAlert) { this._saverAlert = alert; this._saverLight(); }
    else if (window.fully) this._saverLight();
    // gegen Einbrennen: Inhalt jede Minute ein wenig verschieben
    const minute = Math.floor(t / 60000);
    if (minute !== this._saverMin) {
      this._saverMin = minute;
      this._saverShift = [Math.round((Math.random() - 0.5) * 8), Math.round((Math.random() - 0.5) * 8)];
    }
    const [dx, dy] = this._saverShift || [0, 0];
    el.classList.toggle("night", night);
    el.classList.toggle("black", night && mode !== "dim");
    el.classList.toggle("alert", alert);
    const dark = night && mode !== "dim";
    // nachts nur Akutes (Sturm, Regen bei offenem Fenster) und Neues
    const shownUrgent = dark ? urgent.filter((h) => h.live || fresh(h)) : urgent;
    const more = (n, one, many) => `<small class="sv-more">und ${n} ${n === 1 ? one : many}</small>`;
    const urgentHtml = shownUrgent.length ? `<div class="sv-urgent">${shownUrgent.slice(0, 2).map((h) => `<div class="sv-u ${fresh(h) ? "new" : ""}"><ha-icon icon="${h.icon}"></ha-icon><span><b>${esc(h.text)}</b>${h.sub ? `<small>${esc(h.sub)}</small>` : ""}</span></div>`).join("")}${shownUrgent.length > 2 ? more(shownUrgent.length - 2, "weitere Warnung", "weitere Warnungen") : ""}</div>` : "";
    // Nacht „schwarz“ bzw. „Display aus“: nur kleine Uhr und Warnungen
    if (dark) {
      el.innerHTML = `<div class="sv-in" style="transform:translate(${dx}vw, ${dy}vh)"><div class="sv-time small">${time}</div>${urgentHtml}</div>`;
      return;
    }
    // Module als Symbole mit Zahlen: Logo, dann je Wert Symbol + Zahl
    const f = this._facts();
    const set = this._data.settings || {};
    const covers = this._data.rollwerk ? this._rwCovers() : [];
    const mods = [];
    const it = (icon, val, title) => `<span class="sv-i" title="${esc(title)}"><ha-icon icon="${icon}"></ha-icon>${val != null ? `<b>${esc(String(val))}</b>` : ""}</span>`;
    if (f.rooms.length) {
      const x = [it("mdi:fire", f.heating, "heizen")];
      if (f.open) x.push(it("mdi:window-open-variant", f.open, "Fenster offen"));
      if (this._status?.away) x.push(it("mdi:home-export-outline", null, "niemand zu Hause"));
      mods.push(["heizen", x]);
    }
    if (covers.length) {
      const pos = covers.map((c) => this._rwPos(c.st)).filter((v) => v != null);
      const x = [it("mdi:window-shutter-open", pos.filter((v) => v >= 95).length, "offen"), it("mdi:window-shutter", pos.filter((v) => v <= 5).length, "zu")];
      const sh = covers.filter((c) => c.rs?.cat === "shading").length;
      if (sh) x.push(it("mdi:sun-thermometer-outline", sh, "beschattet"));
      // nächste Fahrt: Uhrzeit, Richtung, Anzahl
      const nowMin = now.getHours() * 60 + now.getMinutes();
      const nx = covers.map((c) => /(\d{1,2}):(\d{2}) (.+)$/.exec(c.rs?.next || "")).filter(Boolean)
        .map((m) => ({ at: Number(m[1]) * 60 + Number(m[2]), hm: `${m[1].padStart(2, "0")}:${m[2]}`, what: m[3] })).filter((m) => m.at > nowMin).sort((a2, b2) => a2.at - b2.at);
      if (nx.length) {
        const first = nx.filter((m) => m.at === nx[0].at && m.what === nx[0].what);
        const dir = /schließt|Stufe/.test(nx[0].what) ? "mdi:arrow-down-bold" : /öffnet/.test(nx[0].what) ? "mdi:arrow-up-bold" : "mdi:sun-thermometer-outline";
        x.push(`<span class="sv-i sv-next" title="${esc(nx[0].what)}"><ha-icon icon="mdi:clock-outline"></ha-icon><b>${nx[0].hm}</b><ha-icon icon="${dir}"></ha-icon><b>${first.length}</b></span>`);
      }
      mods.push(["rollwerk", x]);
    }
    if ((set.kw_solar || []).length || set.kw_grid) {
      const fl = this._kwFlow();
      const x = [];
      if (fl.solar != null) x.push(it("mdi:solar-power-variant", this._kwFmt(fl.solar), "Solar"));
      if (fl.grid != null) x.push(it(fl.grid > 0 ? "mdi:transmission-tower-import" : "mdi:transmission-tower-export", this._kwFmt(Math.abs(fl.grid)), fl.grid > 0 ? "Bezug" : "Einspeisung"));
      if (fl.soc != null) x.push(it("mdi:home-battery-outline", `${fmt(fl.soc, 0)} %`, "Akku"));
      if (x.length) mods.push(["kraftwerk", x]);
    }
    if (this._data.lichtwerk && this._lwLights().length) {
      const ls = this._lwLights();
      const on = ls.filter((l) => l.st?.state === "on").length;
      const x = [it("mdi:lightbulb-on-outline", String(on), "Lichter an")];
      const nx = this._lwStatus?.next;
      if (nx && !nx.day) x.push(`<span class="sv-i sv-next" title="${esc(nx.reason)}"><ha-icon icon="mdi:clock-outline"></ha-icon><b>${t2(nx.min)}</b><ha-icon icon="${nx.action === "on" ? "mdi:lightbulb-on-outline" : "mdi:lightbulb-off-outline"}"></ha-icon><b>${nx.count || 1}</b></span>`);
      mods.push(["lichtwerk", x]);
    }
    // Vorhersage der nächsten Stunden
    let fcHtml = "";
    const wid = set.weather_entity || Object.keys(this._hass.states).find((e) => e.startsWith("weather."));
    if (wid && Number(this._hass.states[wid]?.attributes?.supported_features || 0) & 2) {
      const fc = this._forecast(wid, "hourly");
      const items = (fc?.list || []).filter((x) => new Date(x.datetime) > now - 30 * 60000).slice(0, 6);
      if (items.length) fcHtml = `<div class="sv-fc">${items.map((x) => `<span><small>${new Date(x.datetime).toLocaleTimeString("de-DE", { hour: "2-digit" })}</small><ha-icon icon="${(WEATHER[x.condition] || ["mdi:weather-partly-cloudy"])[0]}"></ha-icon><b>${fmt(x.temperature, 0)}°</b></span>`).join("")}</div>`;
    }
    const day = (d) => { const x = new Date(d); const td = new Date(); td.setHours(0, 0, 0, 0); const diff = Math.round((new Date(x.getFullYear(), x.getMonth(), x.getDate()) - td) / 86400000); return diff <= 0 ? "Heute" : diff === 1 ? "Morgen" : x.toLocaleDateString("de-DE", { weekday: "short" }); };
    const cal = (this._cal || []).filter((e) => e.allDay || new Date(e.start) > now - 30 * 60000);
    const side = [
      ...cal.slice(0, 3).map((e) => `<div class="sv-row"><ha-icon icon="${this._calIcon(e.title)[0]}" style="color:${this._calIcon(e.title)[1]}"></ha-icon><span><b>${day(e.start)}${e.allDay ? "" : ` ${new Date(e.start).toLocaleTimeString("de-DE", { hour: "2-digit", minute: "2-digit" })}`}</b><small>${esc(e.title)}</small></span></div>`),
    ];
    const smallHints = hints.slice(0, urgent.length ? 1 : 2);
    el.innerHTML = `
      <div class="sv-in" style="transform:translate(${dx}vw, ${dy}vh)">
        <div class="sv-time">${time}</div>
        <div class="sv-date">${esc(date)}</div>
        ${w ? `<div class="sv-wx"><ha-icon icon="${w.icon}"></ha-icon><b>${fmt(w.temp)}°</b><span>${esc(w.label)}</span>${fcHtml}</div>` : ""}
        ${mods.length ? `<div class="sv-mods">${mods.map(([m, x]) => `<div class="sv-mod"><span class="sv-logo">${MODULE_LOGOS[m] || ""}</span>${x.join("")}</div>`).join("")}</div>` : ""}
        ${urgentHtml}
        ${side.length ? `<div class="sv-side">${side.join("")}</div>` : ""}
        ${smallHints.length ? `<div class="sv-hints">${smallHints.map((h) => `<div class="sv-h ${fresh(h) ? "new" : ""}"><ha-icon icon="${h.icon}"></ha-icon><span><b>${esc(h.text)}</b>${h.sub ? `<small>${esc(h.sub)}</small>` : ""}</span></div>`).join("")}${hints.length > smallHints.length ? more(hints.length - smallHints.length, "weiterer Hinweis", "weitere Hinweise") : ""}</div>` : ""}
        <div class="sv-tap">Antippen zum Aufwecken</div>
      </div>`;
  }


  // ------------------------------------------------------------ Bausteine
  _chip(mode, label) {
    const m = MODE[mode] || MODE.aus;
    return `<span class="mode" style="--c:${m.c}"><ha-icon icon="${m.i}"></ha-icon>${esc(label)}</span>`;
  }

  _stepper(kind, key, value, { placeholder = null, small = false } = {}) {
    const shown = value ?? placeholder;
    return `
      <div class="stepper ${small ? "small" : ""}">
        <button class="sbtn" data-action="step" data-kind="${kind}" data-key="${esc(key)}" data-delta="-0.5" aria-label="kälter">−</button>
        <b style="color:${value == null ? "var(--muted)" : tint(tempColor(shown))}">${fmt(shown)} °C</b>
        <button class="sbtn" data-action="step" data-kind="${kind}" data-key="${esc(key)}" data-delta="0.5" aria-label="wärmer">+</button>
      </div>`;
  }

  _sectionHead(icon, title, right = "") {
    return `<div class="shead"><ha-icon icon="${icon}"></ha-icon><h3>${title}</h3><span class="grow"></span>${right}</div>`;
  }

  // ------------------------------------------------------------ Start (Zuhause mit Modul-Kacheln)
  _viewStart() {
    const f = this._facts();
    const n = f.rooms.length;
    const warn = this._hints().filter((h) => h.lvl === "warn");
    const list = this._widgets();
    const edit = this._wEdit && this._admin;
    return `
      ${warn.length && !list.some((w) => w.type === "hints") ? `
      <button class="hstrip" data-action="hints-open">
        <ha-icon icon="mdi:alert-circle-outline"></ha-icon>
        <span class="grow"><b>${warn.length} Hinweis${warn.length > 1 ? "e" : ""}</b> · ${esc(warn[0].text)}${warn[0].sub ? ` (${esc(warn[0].sub)})` : ""}${warn.length > 1 ? " …" : ""}</span>
        <span class="hs-go">Anzeigen<ha-icon icon="mdi:chevron-right"></ha-icon></span>
      </button>` : ""}

      ${(() => {
        if (!this._admin) return "";
        let off = false;
        try {
          off = localStorage.getItem("hauswerk.einrichtung.aus") === "1";
        } catch (err) {
          /* ohne Speicher */
        }
        const st = this._setupSteps().slice(1, -1);
        const done = st.filter((x) => x.done).length;
        if (off || st.filter((x) => !x.optional).every((x) => x.done)) return "";
        return `<section class="card setup-card"><span class="sr-ic" style="--c:#2dd4bf"><ha-icon icon="mdi:rocket-launch-outline"></ha-icon></span>
          <div class="grow"><b>Hauswerk einrichten</b><small>${done} von ${st.length} Schritten erledigt – Personen, Wetter, Räume, Rollläden, Energie</small>
          <div class="setup-prog"><i style="width:${Math.round((done / st.length) * 100)}%"></i></div></div>
          <button class="primary small" data-action="setup-open">Weiter</button><button class="icon tiny" data-action="setup-hide" title="Ausblenden"><ha-icon icon="mdi:close"></ha-icon></button></section>`;
      })()}
      <div class="shead outer">
        <ha-icon icon="mdi:widgets-outline"></ha-icon><h3>Übersicht</h3><span class="grow"></span>
        ${this._admin ? `
          ${edit ? `<button class="link" data-action="w-add-open"><ha-icon icon="mdi:plus"></ha-icon>Widget</button>` : ""}
          <button class="link" data-action="w-edit"><ha-icon icon="${edit ? "mdi:check" : "mdi:pencil-outline"}"></ha-icon>${edit ? "Fertig" : "Anpassen"}</button>` : ""}
      </div>
      ${list.length
        ? `${edit && this._tablet ? `<div class="tstart"><ha-icon icon="mdi:tablet-dashboard"></ha-icon><span class="grow"><b>Startseite im Tabletmodus</b><small>${this._tabletOwn() ? "Eigene Auswahl fürs Tablet – Handy und PC bleiben unverändert." : "Wie auf Handy und PC – Änderungen gelten überall."}</small></span>
          <div class="segs small"><button class="seg ${this._tabletOwn() ? "" : "on"}" data-action="tstart" data-v="same">Wie am Handy</button><button class="seg ${this._tabletOwn() ? "on" : ""}" data-action="tstart" data-v="own">Eigene</button></div></div>` : ""}${edit ? `<p class="muted small whint"><ha-icon icon="mdi:drag"></ha-icon>Am Griff ziehen, um Widgets zu verschieben.</p>` : ""}<div class="wgrid">${list.map((w, i) => this._widget(w, i, edit, list.length)).join("")}</div>`
        : `<section class="card empty small"><p>Keine Widgets.${this._admin ? ` <button class="link inline" data-action="w-add-open">Widget hinzufügen</button>` : ""}</p></section>`}
      ${n ? "" : `
      <section class="card empty">
        <ha-icon icon="mdi:home-plus-outline"></ha-icon><h2>Noch keine Räume</h2>
        <p>Lege einen Raum an und ordne Thermostate, Fensterkontakte und einen Raumsensor zu.</p>
        ${this._admin ? `<button class="primary" data-action="room-new"><ha-icon icon="mdi:plus"></ha-icon>Raum anlegen</button>` : ""}
      </section>`}`;
  }

  // ------------------------------------------------------------ Widgets der Startseite
  /** Widgets aus den Einstellungen (für alle Benutzer gleich), sonst eine Grundauswahl. */
  /** Hat das Tablet eine eigene Startseite? */
  _tabletOwn() {
    return !!this._tablet && Array.isArray(this._data?.settings?.start_widgets_tablet);
  }

  _widgets() {
    const list = this._tabletOwn() ? this._data.settings.start_widgets_tablet : this._data.settings.start_widgets;
    return Array.isArray(list) ? list : DEFAULT_WIDGETS.map((w, i) => ({ id: `d${i}`, title: null, entities: [], ...w }));
  }

  /** Größe eines Widgets: s = klein, m = mittel, l = groß (alte Angabe „w“ = groß). */
  _wSize(w) {
    return w.size === "w" ? "l" : ["s", "m", "l"].includes(w.size) ? w.size : "m";
  }

  /** Widgets der Startseite ziehen (Maus und Finger): die Karte wandert mit, losgelassen wird gespeichert. */
  _wDragStart(e) {
    const handle = e.composedPath().find((n) => n.dataset?.drag !== undefined);
    if (!handle || !this._wEdit) return;
    const card = handle.closest(".wdg");
    const grid = card?.parentElement;
    if (!card || !grid) return;
    e.preventDefault();
    const from = Number(card.dataset.wi);
    card.classList.add("dragging");
    let last = { x: e.clientX, y: e.clientY };
    let raf = 0;
    const scroller = () => {
      // am Rand des Bildschirms mitscrollen
      const edge = 70, h = window.innerHeight;
      const dy = last.y < edge ? -12 : last.y > h - edge - 60 ? 12 : 0;
      if (dy) {
        window.scrollBy(0, dy);
        this.shadowRoot.querySelector(".main, #main")?.scrollBy?.(0, dy);
      }
      raf = requestAnimationFrame(scroller);
    };
    raf = requestAnimationFrame(scroller);
    const move = (ev) => {
      last = { x: ev.clientX, y: ev.clientY };
      card.style.pointerEvents = "none";
      const over = this.shadowRoot.elementFromPoint(ev.clientX, ev.clientY)?.closest?.(".wdg");
      card.style.pointerEvents = "";
      if (!over || over === card || over.parentElement !== grid) return;
      const r = over.getBoundingClientRect();
      const after = ev.clientY > r.top + r.height / 2 || (Math.abs(ev.clientY - (r.top + r.height / 2)) < r.height / 4 && ev.clientX > r.left + r.width / 2);
      grid.insertBefore(card, after ? over.nextSibling : over);
    };
    const up = async () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
      window.removeEventListener("pointercancel", up);
      card.classList.remove("dragging");
      const order = [...grid.querySelectorAll(".wdg")].map((c) => Number(c.dataset.wi));
      if (order.every((v, k) => v === k)) return;
      const list = this._widgets();
      await this._saveWidgets(order.map((k) => clone(list[k])));
      this._toast("Reihenfolge gespeichert");
    };
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);
    window.addEventListener("pointercancel", up);
    void from;
  }

  async _saveWidgets(list) {
    const key = this._tabletOwn() ? "start_widgets_tablet" : "start_widgets";
    this._data.settings = await this._ws({ type: "hauswerk/heizen/settings/save", settings: { [key]: list } });
    this._renderMain();
  }

  _widget(w, i, edit, count) {
    const def = WIDGETS[w.type];
    if (!def) return "";
    const z = this._wSize(w);
    let body;
    try {
      body = this[`_w_${w.type}`](w, z);
    } catch (err) {
      body = this._failCard(`Widget „${def.name}“`, err, true);
    }
    const tools = edit
      ? `<span class="wtools">
          <button class="icon tiny wdrag" data-drag="${i}" title="Ziehen zum Verschieben" aria-label="Verschieben"><ha-icon icon="mdi:drag"></ha-icon></button>
          <button class="icon tiny wmv" data-action="w-move" data-i="${i}" data-d="-1" title="Nach vorne" ${i === 0 ? "disabled" : ""}><ha-icon icon="mdi:chevron-left"></ha-icon></button>
          <button class="icon tiny wmv" data-action="w-move" data-i="${i}" data-d="1" title="Nach hinten" ${i === count - 1 ? "disabled" : ""}><ha-icon icon="mdi:chevron-right"></ha-icon></button>
          <button class="icon tiny" data-action="w-conf" data-i="${i}" title="Einstellen"><ha-icon icon="mdi:cog-outline"></ha-icon></button>
          <button class="icon tiny danger-t" data-action="w-del" data-i="${i}" title="Entfernen"><ha-icon icon="mdi:close"></ha-icon></button>
        </span>`
      : def.go
        ? `<button class="link tiny" data-action="tab" data-tab="${def.go}" title="Öffnen"><span>Öffnen</span><ha-icon icon="mdi:chevron-right"></ha-icon></button>`
        : def.pop && this._admin && z !== "s"
          ? `<button class="icon tiny" data-action="settings-go" data-sub="${def.pop}" title="Einstellungen"><ha-icon icon="mdi:cog-outline"></ha-icon></button>`
          : "";
    return `
      <section class="card wdg sz-${z} ${edit ? "edit" : ""}" data-wi="${i}" style="--c:${def.c}">
        <div class="wh"><span class="wic"><ha-icon icon="${def.icon}"></ha-icon></span><b>${esc(w.title || def.name)}</b><span class="grow"></span>${tools}</div>
        <div class="wb">${body}</div>
      </section>`;
  }

  /** Kennzahlen fürs Heizen-Widget. */
  _heatFacts() {
    const f = this._facts();
    const st = this._status?.rooms || {};
    const temps = f.rooms.map((r) => st[r.id]?.room_temp).filter((t) => t != null);
    const avg = temps.length ? temps.reduce((a, b) => a + b, 0) / temps.length : null;
    const below = f.rooms.filter((r) => {
      const x = st[r.id] || {};
      return x.room_temp != null && x.target != null && !["aus", "fenster", "sommer", "warm", "entkalken"].includes(x.mode) && x.target - x.room_temp >= 0.5;
    }).length;
    const rep = this._report(14);
    const today = rep ? this._sumDay(rep, 13) : null;
    const v = this._status?.summer
      ? ["mdi:weather-sunny", "Sommerpause", "#facc15"]
      : f.open
        ? ["mdi:window-open-variant", `${f.open} Fenster offen`, "#22d3ee"]
        : below
          ? ["mdi:thermometer-chevron-up", `${below} unter Soll`, "#fb923c"]
          : ["mdi:check-circle-outline", "Alle im Soll", "#34d399"];
    return { f, st, avg, today, v };
  }

  _w_heat(w, z) {
    const { f, avg, today } = this._heatFacts();
    const b = this._briefParts(this._heatBriefHtml()) || { title: "", icon: "mdi:radiator", color: "#94a3b8", lines: [] };
    const head = `<div class="wbig"><span>${fmt(avg)}<small>°C</small></span></div>
      <div class="wline wlage-t" style="--c:${b.color}"><ha-icon icon="${b.icon}"></ha-icon><span>${esc(b.title)}</span></div>`;
    if (z === "s") return head;
    const mini = (icon, val, cap) => `<div class="wmini"><ha-icon icon="${icon}"></ha-icon><b>${val}</b><small>${cap}</small></div>`;
    const minis = `<div class="wminis">
        ${mini(f.heating ? "mdi:fire" : "mdi:fire-off", `${f.heating}/${f.rooms.length}`, "heizen")}
        ${mini(f.open ? "mdi:window-open-variant" : "mdi:window-closed-variant", f.open || "0", "offen")}
        ${mini("mdi:timer-outline", today ? fmt(today.heat / 60) : "–", "h heute")}
      </div>`;
    const lines = b.lines.slice(0, z === "l" ? 3 : 1).map((l) => `<div class="wline wl-sub"><ha-icon icon="mdi:circle-small"></ha-icon><span>${esc(l)}</span></div>`).join("");
    return z === "l" ? `<div class="wsplit"><div>${head}${minis}</div><div>${lines}</div></div>` : head + lines + minis;
  }

  /** Bekannte Personen mit Ort und Entfernung zu Hause (GPS der Person, sonst Entfernungs-Sensor). */
  _people(idsArg = null, zoneArg = null) {
    const st = this._hass.states;
    const ids = idsArg || ((this._data.settings.persons || []).length ? this._data.settings.persons : Object.keys(st).filter((e) => e.startsWith("person.")));
    const zoneId = zoneArg || this._data.settings.home_zone || "zone.home";
    const home = st[zoneId]?.attributes || st["zone.home"]?.attributes || {};
    // Zustand einer Person in der Wohnung: „home“ bei zone.home, sonst der Name der Zone
    const homeState = zoneId === "zone.home" ? "home" : st[zoneId]?.attributes?.friendly_name || "home";
    const rad = (d) => (d * Math.PI) / 180;
    const km = (a) => {
      if (a.latitude == null || home.latitude == null) return null;
      const dLat = rad(a.latitude - home.latitude), dLon = rad(a.longitude - home.longitude);
      const h = Math.sin(dLat / 2) ** 2 + Math.cos(rad(home.latitude)) * Math.cos(rad(a.latitude)) * Math.sin(dLon / 2) ** 2;
      return 6371 * 2 * Math.asin(Math.sqrt(h));
    };
    const toKm = (v, unit) => (v == null || isNaN(v) ? null : unit === "m" ? v / 1000 : unit === "mi" ? v * 1.609 : unit === "ft" ? v * 0.0003048 : v);
    return ids
      .map((id) => {
        const s = st[id];
        if (!s) return null;
        const a = s.attributes || {};
        const slug = id.split(".")[1];
        const name = a.friendly_name || slug;
        let dist = km(a);
        if (dist == null) {
          // Entfernungs-Sensor der Person, z. B. aus der Integration „Nähe“
          const sensor = (this._data.settings.proximity_sensors || []).concat(Object.keys(st).filter((e) => e.startsWith("sensor.") && st[e].attributes.device_class === "distance"))
            .find((e) => e.includes(slug) || (st[e]?.attributes?.friendly_name || "").toLowerCase().includes(name.toLowerCase()));
          if (sensor) dist = toKm(parseFloat(st[sensor].state), st[sensor].attributes.unit_of_measurement);
        }
        const home_ = s.state === homeState;
        const zone = !home_ && s.state !== "not_home" && !["unknown", "unavailable"].includes(s.state) ? st[`zone.${s.state}`]?.attributes?.friendly_name || s.state : null;
        const where = home_ ? "zu Hause" : zone || (["unknown", "unavailable"].includes(s.state) ? "unbekannt" : "unterwegs");
        // Abstand in Metern (erst ab 10 km in Kilometern)
        const distTxt = home_ || dist == null ? "" : dist < 10 ? `${(Math.round((dist * 1000) / 10) * 10).toLocaleString("de-DE")} m` : `${fmt(dist, 0)} km`;
        return { id, name, home: home_, where, dist, distTxt, pic: a.entity_picture || null };
      })
      .filter(Boolean)
      .sort((a, b) => (b.home - a.home) || (a.dist ?? 1e9) - (b.dist ?? 1e9));
  }

  /** Anwesenheit kompakt: alle sechs Schalter in einer Zeile, Stand in einer Zeile, Personen als Chips. */
  _presenceCompact(z) {
    const s = this._status || {};
    const set = this._data.settings;
    const mode = s.vacation ? "urlaub" : s.away ? "abwesend" : "home";
    const dis = this._operate ? "" : "disabled";
    const modes = [["home", "mdi:home-heart", "Zu Hause"], ["abwesend", "mdi:home-export-outline", "Abwesend"], ["urlaub", "mdi:palm-tree", "Urlaub"]];
    const tgs = [["guest", "mdi:account-group-outline", "Gäste", "Gäste: nie auf Abwesend absenken"], ["party", "mdi:party-popper", "Party", "Party: alle Räume auf Komfort"], ["eco_force", "mdi:leaf", "Eco", "Eco erzwingen: alle Räume auf Eco"]];
    // Stand: der Satz aus der großen Karte, hier in einer Zeile
    const full = this._presenceCard(true).match(/<p class="ptext">[\s\S]*?<span>([\s\S]*?)<\/span><\/p>/)?.[1] || "";
    const plain = full.replace(/<[^>]+>/g, "");
    const people = this._people();
    const av = (p) => (p.pic ? `<img src="${esc(p.pic)}" alt="">` : `<span>${esc(p.name.trim().slice(0, 1).toUpperCase())}</span>`);
    return `
      <div class="pc-row">
        <div class="pc-seg">${modes.map(([id, icon, l]) => `<button class="${mode === id ? "on" : ""}" data-action="presence" data-mode="${id}" title="${l}" ${dis}><ha-icon icon="${icon}"></ha-icon><span>${l}</span></button>`).join("")}</div>
        <div class="pc-tg">${tgs.map(([k, icon, l, t]) => `<label class="${set[k] ? "on" : ""}" title="${t}"><input type="checkbox" data-action="hmode" data-key="${k}" ${set[k] ? "checked" : ""} ${dis}><ha-icon icon="${icon}"></ha-icon><span>${l}</span></label>`).join("")}</div>
      </div>
      <p class="pc-st" title="${esc(plain)}"><ha-icon icon="mdi:information-outline"></ha-icon><span>${full}</span></p>
      ${people.length ? `<div class="pc-ppl">${people.map((p) => `<span class="pc-p ${p.home ? "home" : ""}" title="${esc(p.name)}: ${esc(p.where)}${p.distTxt ? ` · ${p.distTxt}` : ""}"><span class="pav">${av(p)}</span><b>${esc(p.name)}</b><small>${p.home ? `<ha-icon icon="mdi:home"></ha-icon>` : esc(p.distTxt || p.where)}</small></span>`).join("")}</div>`
        : `<p class="muted small" style="margin:8px 0 0">Keine Personen bekannt – unter Einstellungen › Anwesenheit wählen.</p>`}`;
  }

  _peopleHtml(z) {
    const people = this._people();
    if (!people.length) return z === "s" ? "" : `<p class="muted small" style="margin-top:10px">Keine Personen bekannt – unter Einstellungen › Anwesenheit wählen.</p>`;
    const av = (p) => (p.pic ? `<img src="${esc(p.pic)}" alt="">` : `<span>${esc(p.name.trim().slice(0, 1).toUpperCase())}</span>`);
    if (z === "s")
      return `<div class="ppl-s">${people.map((p) => `<span class="pav ${p.home ? "home" : ""}" title="${esc(p.name)}: ${esc(p.where)}${p.distTxt ? ` · ${p.distTxt}` : ""}">${av(p)}<em>${p.home ? "⌂" : esc(p.distTxt || "–")}</em></span>`).join("")}</div>`;
    return `<div class="ppl">${people
      .map(
        (p) => `
        <div class="prow ${p.home ? "home" : ""}">
          <span class="pav">${av(p)}</span>
          <span class="grow"><b>${esc(p.name)}</b><small><ha-icon icon="${p.home ? "mdi:home" : p.where === "unterwegs" ? "mdi:map-marker-distance" : "mdi:map-marker-outline"}"></ha-icon>${esc(p.where)}</small></span>
          <em>${p.home ? "" : esc(p.distTxt || "–")}</em>
        </div>`
      )
      .join("")}</div>`;
  }

  _w_presence(w, z) {
    if (z !== "s") return this._presenceCompact(z);
    // klein: nur der aktuelle Zustand und drei Knöpfe
    const s = this._status || {};
    const mode = s.vacation ? "urlaub" : s.away ? "abwesend" : "home";
    const dis = this._operate ? "" : "disabled";
    const b = (id, icon, label) => `<button class="pq ${mode === id ? "on" : ""}" data-action="presence" data-mode="${id}" title="${label}" ${dis}><ha-icon icon="${icon}"></ha-icon></button>`;
    const label = { home: "Zu Hause", abwesend: "Abwesend", urlaub: "Urlaub" }[mode];
    return `<div class="wstate">${label}${this._data.settings.guest ? " · Gäste" : ""}${this._data.settings.party ? " · Party" : ""}</div>
      <div class="pqs">${b("home", "mdi:home-heart", "Zu Hause")}${b("abwesend", "mdi:home-export-outline", "Abwesend")}${b("urlaub", "mdi:palm-tree", "Urlaub")}</div>
      ${this._peopleHtml("s")}`;
  }

  _w_weather(w, z) {
    const wx = this._weather();
    if (!wx) return `<p class="muted small">Keine Wetter-Entität gefunden. Unter Einstellungen › Wetter auswählen.</p>`;
    const head = `<div class="wwx"><ha-icon icon="${wx.icon}"></ha-icon><div><b>${fmt(wx.temp)} °C</b><span>${esc(wx.label)}</span></div></div>`;
    const rain = this._rainHint();
    const rainLine = rain ? `<div class="wline" style="--c:#3b82f6"><ha-icon icon="mdi:weather-pouring"></ha-icon>${esc(rain)}</div>` : "";
    if (z === "s") return head + rainLine;
    const extra = wx.extra ? `<p class="muted small" style="margin:8px 0 0">${wx.extra}</p>` : "";
    if (z === "m") return head + rainLine + extra;
    // groß: dazu die nächsten Stunden
    return `<div class="wsplit"><div>${head}${rainLine}${extra}</div><div>${this._w_forecast({ mode: "hourly", entities: [] }, "s", true)}</div></div>`;
  }

  _w_rooms(w, z) {
    const st = this._status?.rooms || {};
    const rooms = this._rooms();
    if (!rooms.length) return `<p class="muted small">Noch keine Räume.</p>`;
    if (z === "s") {
      const heating = rooms.filter((r) => st[r.id]?.heating).length;
      return `<div class="wbig"><span>${heating}<small>von ${rooms.length} heizen</small></span></div>
        <div class="wdots">${rooms.map((r) => `<i title="${esc(r.name)}: ${fmt(st[r.id]?.room_temp)} °C" style="background:${(MODE[st[r.id]?.mode] || MODE.aus).c}"></i>`).join("")}</div>`;
    }
    return `<div class="gmini ${z === "m" ? "two" : ""}">${rooms
      .map((r) => {
        const rs = st[r.id] || {};
        const m = MODE[rs.mode] || MODE.aus;
        return `<button class="gm" style="--acc:${this._roomColor(r.id)}; --c:${m.c}" data-action="room-open" data-id="${r.id}">
          <span class="gh"><ha-icon icon="${esc(roomIcon(r))}"></ha-icon><span class="gn">${esc(r.name)}</span>${rs.heating ? `<ha-icon class="gf" icon="mdi:fire"></ha-icon>` : ""}</span>
          <span class="gt">${fmt(rs.room_temp)}<small>°C</small></span>
          ${z === "l" ? `<span class="gl"><ha-icon icon="${m.i}"></ha-icon>${esc(rs.mode_label || "Automatik aus")}${rs.target != null && rs.mode !== "aus" ? ` · ${fmt(rs.target)} °C` : ""}</span>` : ""}
        </button>`;
      })
      .join("")}</div>`;
  }

  _w_shortcuts(w, z) {
    const ids = w.entities || [];
    if (!ids.length) return this._wSuggest(w, z, "shortcuts");
    return `<div class="wsc ${z}">${ids
      .map((id) => {
        const s = this._hass.states[id];
        const d = id.split(".")[0];
        const on = s && ["on", "open", "unlocked", "playing", "heat"].includes(s.state);
        const icon = s?.attributes?.icon || SC_ICONS[d] || "mdi:gesture-tap";
        const name = s?.attributes?.friendly_name || id;
        const stateTxt = ["script", "scene", "button", "input_button"].includes(d) ? "" : `<small>${s ? (on ? "an" : "aus") : "fehlt"}</small>`;
        return `<button class="sc ${on ? "on" : ""} ${s ? "" : "missing"}" data-action="w-sc" data-e="${esc(id)}" title="${esc(name)}">
          <ha-icon icon="${esc(icon)}"></ha-icon>${z === "s" ? "" : `<span>${esc(name)}</span>${z === "l" ? stateTxt : ""}`}</button>`;
      })
      .join("")}</div>`;
  }

  _openWindows() {
    const open = [];
    for (const r of this._rooms()) {
      for (const id of r.windows || []) {
        const s = this._hass.states[id];
        if (s && ["on", "open", "opening", "true"].includes(String(s.state).toLowerCase())) open.push({ room: r, s, id });
      }
    }
    return open;
  }

  _w_windows(w, z) {
    const open = this._openWindows();
    if (z === "s")
      return `<div class="wbig"><span style="color:${open.length ? tint("#22d3ee") : "inherit"}">${open.length}<small>offen</small></span></div>
        <div class="wline" style="--c:${open.length ? "#22d3ee" : "#34d399"}"><ha-icon icon="${open.length ? "mdi:window-open-variant" : "mdi:check"}"></ha-icon>${open.length ? esc(open.map((o) => o.room.name).join(", ")) : "alles zu"}</div>`;
    if (!open.length) return `<div class="wok"><ha-icon icon="mdi:window-closed-variant"></ha-icon>Alle Fenster und Türen zu</div>`;
    return `<div class="wlist">${open
      .map(({ room, s, id }) => {
        const mins = s.last_changed ? Math.max(0, Math.round((Date.now() - new Date(s.last_changed)) / 60000)) : null;
        const rs = this._status?.rooms?.[room.id] || {};
        return `<div class="wrow"><ha-icon icon="mdi:window-open-variant" style="color:#22d3ee"></ha-icon><span class="grow"><b>${esc(room.name)}</b><small>${esc(this._entityName(id))}${z === "l" ? ` · ${rs.mode === "fenster" ? "Heizung pausiert" : rs.window_pending ? "Pause beginnt gleich" : "heizt weiter"}` : ""}</small></span><em>${mins == null ? "" : mins < 60 ? `${mins} Min.` : `${fmt(mins / 60)} h`}</em></div>`;
      })
      .join("")}</div>`;
  }

  _w_schedule(w, z) {
    const st = this._status?.rooms || {};
    const rows = this._rooms()
      .filter((r) => r.enabled !== false)
      .map((r) => ({ r, i: this._schedInfo(r, st[r.id] || {}) }));
    if (!rows.length) return `<p class="muted small">Noch keine Räume.</p>`;
    if (z === "s") {
      // klein: der Raum, der als Nächstes warm wird
      const next = rows.filter((x) => !x.i.comfort && st[x.r.id]?.next_change != null).sort((a, b) => st[a.r.id].next_change - st[b.r.id].next_change)[0] || rows.find((x) => !x.i.comfort);
      const on = rows.filter((x) => x.i.comfort).length;
      return `<div class="wbig"><span>${on}<small>in Komfort</small></span></div>
        ${next ? `<div class="wline" style="--c:#f59e0b"><ha-icon icon="mdi:clock-outline"></ha-icon>${esc(next.r.name)}: ${esc(next.i.text.replace("Komfort ", ""))}</div>` : ""}`;
    }
    const day = this._planDay(0);
    return `<div class="wlist">${rows
      .map(({ r, i }) => `<div class="wrow ${z === "l" ? "tall" : ""}"><ha-icon icon="${esc(roomIcon(r))}"></ha-icon>
        <span class="grow"><b>${esc(r.name)}</b><small>${esc(i.src)}</small>${z === "l" && i.blocks ? this._dayBar(i.blocks, r, day, true) : ""}</span><em class="${i.comfort ? "hot" : ""}">${esc(i.text)}</em></div>`)
      .join("")}</div>`;
  }

  /** Eine Zeile der Hinweise (Glocke und Widget). */
  _hintRow(x) {
    const data = Object.entries(x.data).map(([k, v]) => `data-${k}="${esc(v)}"`).join(" ");
    const can = this._admin || !["room-edit", "plan-open", "plan-sel"].includes(x.action);
    return `<button class="hint ${x.lvl}" ${can ? `data-action="${x.action}" data-hint="1" ${data}` : "disabled"}>
      <span class="sr-ic"><ha-icon icon="${x.icon}"></ha-icon></span>
      <span class="sr-t"><b>${esc(x.text)}</b>${x.sub ? `<small class="wrap">${esc(x.sub)}</small>` : ""}</span>
      ${can ? `<ha-icon class="sr-go" icon="mdi:chevron-right"></ha-icon>` : ""}</button>`;
  }

  _w_hints(w, z) {
    const h = this._hints();
    const warn = h.filter((x) => x.lvl === "warn").length;
    if (!h.length) return `<div class="wok"><ha-icon icon="mdi:check-circle-outline"></ha-icon>Keine Hinweise – alles läuft.</div>`;
    if (z === "s")
      return `<div class="wbig"><span style="color:${warn ? tint("#f59e0b") : "inherit"}">${h.length}<small>Hinweis${h.length > 1 ? "e" : ""}</small></span></div>
        <button class="wline wlink" data-action="hints-open" style="--c:${warn ? "#f59e0b" : "#60a5fa"}"><ha-icon icon="${warn ? "mdi:alert-circle-outline" : "mdi:information-outline"}"></ha-icon>${warn ? `${warn} zu beheben` : "nur zur Info"}</button>`;
    const max = z === "l" ? 8 : 2;
    return `<div class="hints">${h.slice(0, max).map((x) => this._hintRow(x)).join("")}</div>
      ${h.length > max ? `<button class="link tiny wmore" data-action="hints-open">Alle ${h.length} Hinweise<ha-icon icon="mdi:chevron-right"></ha-icon></button>` : ""}`;
  }

  /** Heizleistung je Raum aus dem Bericht (14 Tage). */
  _w_power(w, z) {
    const rep = this._report(14);
    if (!rep) return `<div class="chart-empty"><div class="spinner"></div></div>`;
    const an = this._analysis?.[14] || {};
    const V = { weak: ["Reicht nicht", "#ef4444", "mdi:fire-alert"], sensor: ["Messung prüfen", "#f97316", "mdi:thermometer-alert"], tight: ["Knapp", "#f59e0b", "mdi:alert-circle-outline"],
      good: ["Passt", "#22c55e", "mdi:check-circle-outline"], reserve: ["Reserve", "#0ea5e9", "mdi:arrow-down-bold-circle-outline"], nodata: ["Zu wenig Daten", "#94a3b8", "mdi:timer-sand"] };
    const order = ["weak", "sensor", "tight", "good", "reserve", "nodata"];
    const list = this._rooms().map((r) => ({ r, a: an[r.id] })).filter((x) => x.a).sort((x, y) => order.indexOf(x.a.verdict) - order.indexOf(y.a.verdict));
    if (!list.length || list.every((x) => x.a.verdict === "nodata"))
      return `<div class="wok" style="--c:#94a3b8"><ha-icon icon="mdi:timer-sand"></ha-icon>Noch zu wenig Daten – die Einschätzung kommt nach einigen Tagen.</div>`;
    const need = list.filter((x) => ["weak", "sensor", "tight"].includes(x.a.verdict));
    const bad = need.filter((x) => x.a.verdict !== "tight").length;
    if (z === "s") {
      const k = bad ? "#ef4444" : need.length ? "#f59e0b" : "#22c55e";
      return `<div class="wbig"><span style="color:${need.length ? tint(k) : "inherit"}">${need.length}<small>${need.length === 1 ? "Raum" : "Räume"}</small></span></div>
        <div class="wline" style="--c:${k}"><ha-icon icon="${need.length ? V[need[0].a.verdict][2] : "mdi:check"}"></ha-icon>${need.length ? esc(need.map((x) => x.r.name).join(", ")) : "alle werden warm"}</div>`;
    }
    const rows = z === "l" ? list : need;
    if (!rows.length) return `<div class="wok"><ha-icon icon="mdi:check-circle-outline"></ha-icon>Alle Räume werden gut warm.</div>`;
    return `<div class="wlist">${rows
      .map(({ r, a }) => {
        const [vl, vc, vi] = V[a.verdict] || V.nodata;
        const f = a.facts || {};
        const top = (a.findings || []).find((x) => x.level === "warn") || (a.findings || [])[0];
        return `<div class="wrow"><span class="rdot" style="background:${this._roomColor(r.id)}"></span>
          <span class="grow"><b>${esc(r.name)}</b><small>${f.ok_pct != null ? `Komfort ${f.ok_pct} %` : ""}${f.valve != null ? ` · Ventil Ø ${f.valve} %` : ""}${z === "l" && top ? ` · ${esc(top.title)}` : ""}</small></span>
          <em class="wverd" style="--c:${vc}"><ha-icon icon="${vi}"></ha-icon>${vl}</em></div>`;
      })
      .join("")}</div>`;
  }

  _w_shutters(w, z) {
    if (!this._data.rollwerk) return `<p class="muted small">Rollwerk ist nicht geladen.</p>`;
    const covers = this._rwCovers();
    if (!covers.length)
      return `<div class="wok" style="--c:#94a3b8"><ha-icon icon="mdi:window-shutter"></ha-icon>Noch keine Rollläden</div>
        ${this._admin ? `<button class="link tiny wmore" data-action="cwiz-open"><ha-icon icon="mdi:plus"></ha-icon>Rollladen hinzufügen</button>` : ""}`;
    const pos = covers.map((c) => this._rwPos(c.st));
    const nOpen = pos.filter((x) => x != null && x >= 95).length;
    const nClosed = pos.filter((x) => x != null && x <= 5).length;
    const nShade = covers.filter((c) => c.rs.cat === "shading" || c.rs.shading).length;
    const manual = covers.filter((c) => c.rs.manual);
    const storm = this._rwStatus?.storm;
    const line = storm
      ? `<div class="wline" style="--c:#ef4444"><ha-icon icon="mdi:weather-windy-variant"></ha-icon>Sturm – alle hoch</div>`
      : manual.length
        ? `<div class="wline" style="--c:#8b5cf6"><ha-icon icon="mdi:hand-back-right-outline"></ha-icon>${manual.length} von Hand</div>`
        : nShade
          ? `<div class="wline" style="--c:#f97316"><ha-icon icon="mdi:sun-thermometer-outline"></ha-icon>${nShade} beschattet</div>`
          : `<div class="wline"><ha-icon icon="mdi:window-shutter"></ha-icon>${nClosed} zu</div>`;
    // nächste Fahrt
    const nowMin = new Date().getHours() * 60 + new Date().getMinutes();
    const nx = covers.map((c) => /(\d{1,2}):(\d{2}) (.+)$/.exec(c.rs?.next || "")).filter(Boolean)
      .map((m) => ({ at: Number(m[1]) * 60 + Number(m[2]), hm: `${m[1].padStart(2, "0")}:${m[2]}`, what: m[3] })).filter((m) => m.at > nowMin).sort((a, b) => a.at - b.at)[0];
    const nextLine = nx ? `<div class="wline" style="--c:#0ea5e9"><ha-icon icon="mdi:clock-outline"></ha-icon>${nx.hm} ${esc(nx.what)}</div>` : "";
    if (z === "s") return `<div class="wbig"><span>${nOpen}<small>von ${covers.length} offen</small></span></div>${storm || manual.length ? line : nextLine || line}`;
    const all = covers.map((c) => c.id).join(",");
    // je Raum kleine Fenster mit Stellung – Tipp öffnet „Höhe einstellen“
    const areas = new Map();
    for (const c of covers) {
      const a2 = c.rs.area || "Ohne Raum";
      if (!areas.has(a2)) areas.set(a2, []);
      areas.get(a2).push(c);
    }
    const win = (c) => {
      const p = this._rwPos(c.st);
      const flag = c.rs.manual ? "#8b5cf6" : c.rs.cat === "shading" ? "#f97316" : c.rs.contact_open ? "#f59e0b" : "";
      return `<button class="wsh" data-action="pop-open" data-pop="rwpos:${esc(c.id)}" title="${esc(this._entityName(c.id))}: ${p == null ? "–" : `${fmt(p, 0)} %`}" ${flag ? `style="--f:${flag}"` : ""}><span class="rwm-win" style="--v:${p ?? 0}"><i></i></span><small>${p == null ? "–" : `${fmt(p, 0)}`}</small></button>`;
    };
    const rooms = `<div class="wshr">${[...areas.entries()].sort((a3, b3) => a3[0].localeCompare(b3[0], "de")).map(([a3, cs]) => `<div class="wsha"><span>${esc(a3)}</span><div>${cs.map(win).join("")}</div></div>`).join("")}</div>`;
    const btns = `<div class="wbtns"><button class="secondary small" data-action="rw-cmd" data-ids="${all}" data-a="open"><ha-icon icon="mdi:arrow-up"></ha-icon>Alle hoch</button><button class="secondary small" data-action="rw-cmd" data-ids="${all}" data-a="close"><ha-icon icon="mdi:arrow-down"></ha-icon>Alle runter</button></div>`;
    return `${storm || manual.length ? line : ""}${nextLine}${rooms}${z === "l" ? btns : ""}`;
  }

  _w_rwnext(w, z) {
    if (!this._data.rollwerk) return `<p class="muted small">Rollwerk ist nicht geladen.</p>`;
    const covers = this._rwCovers().filter((c) => c.cfg.auto !== false);
    if (!covers.length) return `<div class="wok" style="--c:#94a3b8"><ha-icon icon="mdi:window-shutter"></ha-icon>Keine Rollläden mit Automatik</div>`;
    // gleiche Fahrten zusammenfassen: „19:42 Stufe 1 auf 50 %“ → Wohnzimmer, Küche
    const ev = new Map();
    for (const c of covers) {
      if (!c.rs.next) continue;
      if (!ev.has(c.rs.next)) ev.set(c.rs.next, []);
      ev.get(c.rs.next).push(this._entityName(c.id));
    }
    const key = (t) => (t.match(/(\d\d):(\d\d)/) || []).slice(1).join("");
    const list = [...ev.entries()].sort((a, b) => key(a[0]).localeCompare(key(b[0])));
    const split = (t) => { const m = t.match(/^(ca\. )?(\d\d:\d\d) (.*)$/); return m ? [(m[1] ? "~" : "") + m[2], m[3]] : ["", t]; };
    const tls = this._rwStatus?.timelines || {};
    const pids = [...new Set(covers.map((c) => c.cfg.profile || "standard"))].filter((p) => tls[p]);
    if (z === "s") {
      if (!list.length) return `<div class="wok" style="--c:#94a3b8"><ha-icon icon="mdi:weather-night"></ha-icon>Heute nichts mehr</div>`;
      const [t, what] = split(list[0][0]);
      return `<div class="wbig"><span>${esc(t)}</span></div><div class="wline" style="--c:#38bdf8"><ha-icon icon="mdi:clock-outline"></ha-icon>${esc(what)} · ${esc(list[0][1].length === 1 ? list[0][1][0] : `${list[0][1].length} Rollläden`)}</div>`;
    }
    const rows = list.slice(0, z === "l" ? 8 : 4).map(([text, names]) => {
      const [t, what] = split(text);
      return `<div class="wrow"><em class="wtime">${esc(t)}</em><span class="grow"><b>${esc(what)}</b><small>${esc(names.join(", "))}</small></span></div>`;
    }).join("");
    const bars = (z === "l" ? pids : pids.slice(0, 1)).map((p) => `<div class="wtl">${pids.length > 1 || z === "l" ? `<small>${esc(this._rwProfName(p))}</small>` : ""}${this._rwDayBar(tls[p], z !== "l", Object.values(this._rwStatus?.covers || {}).some((rs) => (rs.profile || "standard") === p && rs.shade_likely !== false))}</div>`).join("");
    return `${bars}${list.length ? `<div class="wlist">${rows}</div>` : `<div class="wok" style="--c:#94a3b8"><ha-icon icon="mdi:weather-night"></ha-icon>Heute keine Fahrten mehr</div>`}`;
  }

  _w_report(w, z) {
    const rep = this._report(7);
    if (!rep) return `<div class="chart-empty"><div class="spinner"></div></div>`;
    const days = Array.from({ length: 7 }, (_, i) => this._sumDay(rep, i).heat / 60);
    const sum = days.reduce((a, b) => a + b, 0);
    if (z === "s") return `<div class="wbig"><span>${fmt(sum)}<small>h</small></span></div><div class="wline"><ha-icon icon="mdi:calendar-week"></ha-icon>7 Tage · Ø ${fmt(sum / 7)} h</div>`;
    const max = Math.max(1, ...days);
    const dates = (rep[this._rooms()[0]?.id] || []).map((x) => x.date);
    const bars = `
      <div class="wbars">${days
        .map((h, i) => `<div class="wbar" title="${fmt(h)} h">${z === "l" ? `<em>${fmt(h)}</em>` : ""}<i style="height:${Math.max(3, (h / max) * 100)}%"></i><small>${i === 6 ? "heute" : dates[i] ? DAYS[(new Date(dates[i]).getDay() + 6) % 7] : ""}</small></div>`)
        .join("")}</div>`;
    const foot = `<p class="muted small" style="margin:8px 0 0">${fmt(sum)} h in 7 Tagen · Ø ${fmt(sum / 7)} h am Tag</p>`;
    if (z === "m") return bars + foot;
    // groß: dazu die Räume mit den meisten Stunden
    const per = this._rooms()
      .map((r) => ({ r, h: (rep[r.id] || []).reduce((a, x) => a + (x.heat_min || 0), 0) / 60 }))
      .sort((a, b) => b.h - a.h);
    const top = Math.max(1, ...per.map((x) => x.h));
    return `<div class="wsplit"><div>${bars}${foot}</div><div class="wlist">${per
      .map(({ r, h }) => `<div class="wrow"><span class="rdot" style="background:${this._roomColor(r.id)}"></span><span class="grow"><b>${esc(r.name)}</b><span class="hbar"><i style="width:${(h / top) * 100}%; background:${this._roomColor(r.id)}"></i></span></span><em>${fmt(h)} h</em></div>`)
      .join("")}</div></div>`;
  }

  /** Kälteeinbruch und Sturm aus der Vorhersage (Grenzen unter Hauswerk › Einstellungen › Wetter). */
  _wxAlerts() {
    const p = this._data?.settings || {};
    const S = this._hass?.states || {};
    const id = p.weather_entity || Object.keys(S).find((e) => e.startsWith("weather."));
    const st = id && S[id];
    if (!st || !this._hass.connection) return [];
    const feat = Number(st.attributes.supported_features || 0);
    const out = [];
    const day = (iso) => new Date(iso).toLocaleDateString("de-DE", { weekday: "short", day: "numeric", month: "numeric" });
    const cold = Number(p.cold_snap_temp ?? 0);
    if (feat & 1) {
      const fc = this._forecast(id, "daily");
      const low = (fc?.list || []).slice(0, 3).map((x) => ({ t: x.templow ?? x.temperature, at: x.datetime })).filter((x) => x.t != null)
        .reduce((a, b) => (a && a.t <= b.t ? a : b), null);
      if (low && low.t < cold) out.push({ icon: "mdi:snowflake-alert", text: `Kälteeinbruch: bis ${fmt(low.t)} °C`, sub: `${day(low.at)} · Grenze ${fmt(cold)} °C` });
    }
    const kmh = (v, u) => (v == null ? null : u === "m/s" ? v * 3.6 : u === "mph" ? v * 1.609 : u === "kn" ? v * 1.852 : v);
    const u = st.attributes.wind_speed_unit || "km/h";
    const limit = Number(p.storm_kmh ?? 70);
    let gust = kmh(st.attributes.wind_gust_speed ?? null, u);
    let at = null;
    if (feat & 2) {
      const fc = this._forecast(id, "hourly");
      for (const x of (fc?.list || []).filter((x) => new Date(x.datetime) - Date.now() < 24 * 3600e3)) {
        const v = kmh(x.wind_gust_speed ?? x.wind_speed ?? null, u);
        if (v != null && (gust == null || v > gust)) {
          gust = v;
          at = x.datetime;
        }
      }
    }
    if (gust != null && gust >= limit)
      out.push({ icon: "mdi:weather-windy", text: `Sturm: Böen bis ${fmt(gust, 0)} km/h`, sub: `${at ? `${day(at)}, ${new Date(at).toLocaleTimeString("de-DE", { hour: "2-digit", minute: "2-digit" })}` : "jetzt"} · Grenze ${fmt(limit, 0)} km/h` });
    return out;
  }

  /** Prognose einer weather-Entität abonnieren (wie die Wetterkarte von Home Assistant). */
  _forecast(entityId, type) {
    this._fc = this._fc || {};
    this._fcSubs = this._fcSubs || {};
    const key = `${entityId}|${type}`;
    if (!this._fcSubs[key]) {
      this._fcSubs[key] = this._hass.connection.subscribeMessage(
        (msg) => {
          this._fc[key] = { list: msg.forecast || [] };
          if (this._tab === "start" && !this._busy) this._renderMain();
        },
        { type: "weather/subscribe_forecast", entity_id: entityId, forecast_type: type }
      );
      this._fcSubs[key].catch((err) => {
        this._fc[key] = { error: err?.message || "Prognose nicht verfügbar" };
        if (this._tab === "start") this._renderMain();
      });
    }
    return this._fc[key];
  }

  _w_forecast(w, z, embedded = false) {
    const id = (w.entities || [])[0] || this._data.settings.weather_entity || Object.keys(this._hass.states).find((e) => e.startsWith("weather."));
    const st = id && this._hass.states[id];
    if (!st) return `<p class="muted small">Keine Wetter-Entität gefunden.${this._admin ? " Über „Anpassen“ › Zahnrad eine wählen." : ""}</p>`;
    // Was kann die Entität? 1 = täglich, 2 = stündlich, 4 = zweimal täglich
    const feat = Number(st.attributes.supported_features || 0);
    let type = w.mode || "hourly";
    if (type === "hourly" && !(feat & 2) && feat & 1) type = "daily";
    if (type === "daily" && !(feat & 1) && feat & 2) type = "hourly";
    const fc = this._forecast(id, type);
    if (!fc) return `<div class="chart-empty"><div class="spinner"></div></div>`;
    if (fc.error) return `<p class="muted small">${esc(fc.error)}</p>`;
    const hourly = type === "hourly";
    // Je Größe mehr Spalten: klein 4, mittel 6 (Stunden) bzw. 4 (Tage), groß 12 bzw. 7
    const count = embedded ? 6 : z === "s" ? (hourly ? 4 : 3) : z === "m" ? (hourly ? 6 : 4) : hourly ? 12 : 7;
    const items = fc.list.slice(0, count);
    if (!items.length) return `<p class="muted small">Keine Prognose verfügbar.</p>`;
    const temps = items.flatMap((x) => [x.temperature, x.templow]).filter((t) => t != null);
    const lo = Math.min(...temps), hi = Math.max(...temps);
    const unit = st.attributes.temperature_unit || "°C";
    // Hinweis für die Heizung: tiefster Wert der nächsten 24 h
    const next24 = hourly ? fc.list.filter((x) => new Date(x.datetime) - Date.now() < 24 * 3600e3) : fc.list.slice(0, 2);
    const lows = next24.map((x) => ({ t: x.templow ?? x.temperature, at: x.datetime })).filter((x) => x.t != null);
    const min = lows.length ? lows.reduce((a, b) => (b.t < a.t ? b : a)) : null;
    const set = this._data.settings;
    let hint = "";
    if (z === "s" || embedded) hint = "";
    else if (min && min.t <= 0) hint = `<span class="fchint" style="--c:#38bdf8"><ha-icon icon="mdi:snowflake-alert"></ha-icon>Frost: bis ${fmt(min.t)} ${unit}${hourly ? ` um ${new Date(min.at).toLocaleTimeString("de-DE", { hour: "2-digit", minute: "2-digit" })}` : ""}</span>`;
    else if (set.summer_mode === "auto" && min && min.t >= (set.summer_temp ?? 16)) hint = `<span class="fchint" style="--c:#facc15"><ha-icon icon="mdi:weather-sunny"></ha-icon>Mild: Sommerpause ab ${fmt(set.summer_temp ?? 16)} °C möglich</span>`;
    else if (min) hint = `<span class="fchint"><ha-icon icon="mdi:thermometer-low"></ha-icon>Tiefstwert ${hourly ? "24 h" : "bis morgen"}: ${fmt(min.t)} ${unit}</span>`;
    const label = (x, i) => {
      const d = new Date(x.datetime);
      if (hourly) return i === 0 ? "jetzt" : String(d.getHours()).padStart(2, "0") + (z === "s" || embedded ? "" : " Uhr");
      if (d.toDateString() === new Date().toDateString()) return "heute";
      return d.toLocaleDateString("de-DE", { weekday: "short" });
    };
    const pos = (t) => (hi > lo ? ((t - lo) / (hi - lo)) * 100 : 50);
    const detail = z === "l" && !embedded;
    return `
      ${hint ? `<div class="fchints">${hint}</div>` : ""}
      <div class="fc ${hourly ? "hourly" : "daily"} ${z === "s" || embedded ? "tight" : ""}">${items
        .map((x, i) => {
          const [icon, text] = WEATHER[x.condition] || ["mdi:weather-partly-cloudy", x.condition || ""];
          const rain = x.precipitation_probability ?? null;
          return `
          <div class="fci" title="${esc(text)}">
            <small>${label(x, i)}</small>
            <ha-icon icon="${icon}"></ha-icon>
            <b style="color:${tint(tempColor(x.temperature))}">${fmt(x.temperature, 0)}°</b>
            ${!hourly && x.templow != null ? `
              ${detail ? `<span class="fcr"><i style="bottom:${pos(x.templow)}%; height:${Math.max(6, pos(x.temperature) - pos(x.templow))}%"></i></span>` : ""}
              <em>${fmt(x.templow, 0)}°</em>` : ""}
            ${z !== "s" && !embedded ? `<small class="fcp ${rain >= 50 ? "wet" : ""}">${rain != null ? `<ha-icon icon="mdi:water-outline"></ha-icon>${fmt(rain, 0)} %` : x.precipitation ? `${fmt(x.precipitation)} mm` : "&nbsp;"}</small>` : ""}
          </div>`;
        })
        .join("")}</div>`;
  }

  _w_values(w, z) {
    const ids = w.entities || [];
    if (!ids.length) return this._wSuggest(w, z, "values");
    const val = (id) => {
      const s = this._hass.states[id];
      const unit = s?.attributes?.unit_of_measurement || "";
      const num = s && !isNaN(parseFloat(s.state)) && isFinite(s.state);
      return { s, txt: s ? `${num ? Number(s.state).toLocaleString("de-DE", { maximumFractionDigits: 2 }) : esc(s.state)}${unit ? ` ${esc(unit)}` : ""}` : "fehlt" };
    };
    if (z === "s") {
      // klein: der erste Wert groß, weitere als Zeile
      const a = val(ids[0]);
      return `<div class="wval"><b>${a.txt}</b><small>${esc(a.s?.attributes?.friendly_name || ids[0])}</small></div>
        ${ids[1] ? `<div class="wline"><ha-icon icon="mdi:plus"></ha-icon>${ids.length - 1} weitere</div>` : ""}`;
    }
    return `<div class="wlist ${z === "l" ? "cols" : ""}">${ids
      .map((id) => {
        const { s, txt } = val(id);
        return `<div class="wrow"><ha-icon icon="${esc(s?.attributes?.icon || "mdi:gauge")}"></ha-icon><span class="grow"><b>${esc(s?.attributes?.friendly_name || id)}</b>${z === "l" && s?.last_changed ? `<small>seit ${new Date(s.last_changed).toLocaleTimeString("de-DE", { hour: "2-digit", minute: "2-digit" })}</small>` : ""}</span><em>${txt}</em></div>`;
      })
      .join("")}</div>`;
  }
  // ------------------------------------------------------------ Modul 1: Räume
  _viewOverview() {
    const rooms = this._rooms();
    const st = this._status?.rooms || {};
    const s = this._status || {};
    const set = this._data.settings;
    const f = this._facts();
    const n = rooms.length;
    const avgOf = (list) => (list.length ? list.reduce((a, b) => a + b, 0) / list.length : null);
    const avg = avgOf(rooms.map((r) => st[r.id]?.room_temp).filter((t) => t != null));
    const avgTarget = avgOf(rooms.filter((r) => !["fenster", "aus", "sommer"].includes(st[r.id]?.mode)).map((r) => st[r.id]?.target).filter((t) => t != null));
    const hum = avgOf(rooms.map((r) => st[r.id]?.humidity).filter((h) => h != null));
    const below = rooms.filter((r) => {
      const x = st[r.id] || {};
      return x.room_temp != null && x.target != null && !["aus", "fenster", "sommer", "warm", "entkalken"].includes(x.mode) && x.target - x.room_temp >= 0.5;
    });
    const rep = this._report(14);
    const today = rep ? this._sumDay(rep, 13) : null;
    const w = this._weather();
    const compact = this._roomView() === "compact";

    return `
      ${this._heatBriefHtml()}

      <div class="shead outer">
        <ha-icon icon="mdi:floor-plan"></ha-icon><h3>Räume</h3><span class="count">${n}</span><span class="grow"></span>
        ${n ? `<div class="vtog" role="group" aria-label="Ansicht">
          <button class="${compact ? "" : "on"}" data-action="room-view" data-v="detail" title="Detailliert"><ha-icon icon="mdi:view-agenda-outline"></ha-icon><span>Detailliert</span></button>
          <button class="${compact ? "on" : ""}" data-action="room-view" data-v="compact" title="Kompakt"><ha-icon icon="mdi:view-grid-outline"></ha-icon><span>Kompakt</span></button>
        </div>` : ""}
        ${this._admin && n ? `<button class="link" data-action="room-new"><ha-icon icon="mdi:plus"></ha-icon>Raum</button>` : ""}
      </div>
      ${
        n
          ? `<div class="rooms ${compact ? "compact" : ""}">${rooms.map((r) => (compact ? this._roomMini(r) : this._roomCard(r))).join("")}</div>`
          : `<section class="card empty">
              <ha-icon icon="mdi:home-plus-outline"></ha-icon>
              <h2>Noch keine Räume</h2>
              <p>Lege einen Raum an und ordne Thermostate, Fensterkontakte und einen Raumsensor zu.</p>
              ${this._admin ? `<button class="primary" data-action="room-new"><ha-icon icon="mdi:plus"></ha-icon>Raum anlegen</button>` : ""}
            </section>`
      }`;
  }

  // ------------------------------------------------------------ Lage-Kachel (Kopf jedes Moduls)
  /** Kopfkachel: ein Satz zum Stand (Farbe = Zustand), darunter was gerade zählt, dazu passende Werte. */
  _brief({ cls = "", tone = "ok", icon, label, big = "", title, act = "", side = "", lines = [], chips = [] }) {
    const TONE = { ok: "#22c55e", active: "#fb923c", info: "#22d3ee", warn: "#ef4444", calm: "#94a3b8", hand: "#8b5cf6" };
    const line = (l) => {
      const tag = l.act ? "button" : "div";
      return `<${tag} class="br-l" ${l.act || ""} style="--c:${l.c || "var(--muted)"}"><ha-icon icon="${l.icon}"></ha-icon><span class="grow">${l.html ?? esc(l.text)}</span>${l.act ? `<ha-icon class="br-go" icon="mdi:chevron-right"></ha-icon>` : ""}</${tag}>`;
    };
    // Gleicher Aufbau in allen Modulen: Kopfzeile (Beschriftung, rechts kompakt), große Zahl + Satz, 2 Zeilen, Werte
    return `
      <section class="brief ${cls}" style="--tone:${TONE[tone] || tone}" data-tone="${tone}">
        <div class="br-head">${label ? `<div class="br-label">${label}</div>` : ""}<span class="grow"></span>${side}</div>
        <div class="br-line">${big ? `<div class="br-big">${big}</div>` : ""}
          <${act ? "button" : "div"} class="br-h" ${act}><ha-icon icon="${icon}"></ha-icon><span>${esc(title)}</span></${act ? "button" : "div"}></div>
        <div class="br-lines">${lines.slice(0, 2).map(line).join("")}</div>
        ${chips.length ? `<div class="br-chips">${chips.map(([i, v, l, c]) => `<span class="br-c" ${c ? `style="--c:${c}"` : ""}><ha-icon icon="${i}"></ha-icon><b>${v}</b><small>${l}</small></span>`).join("")}</div>` : ""}
      </section>`;
  }

  /** Uhrzeit „16:50“, „morgen 05:30“ oder „Mi 06:00“ in so vielen Minuten. */
  _whenIn(mins) {
    const now = new Date();
    const at = new Date(now.getTime() + mins * 60000);
    const tomorrow = new Date(now.getTime() + 864e5).toDateString() === at.toDateString();
    const hm = at.toLocaleTimeString("de-DE", { hour: "2-digit", minute: "2-digit" });
    return at.toDateString() === now.toDateString() ? hm : tomorrow ? `morgen ${hm}` : `${at.toLocaleDateString("de-DE", { weekday: "short" })} ${hm}`;
  }

  _inMin(mins) {
    return mins < 60 ? `in ${Math.max(1, Math.round(mins))} Min.` : mins < 24 * 60 ? `in ${fmt(mins / 60, mins < 600 ? 1 : 0)} h` : "";
  }

  /** Heizwerk-Lage aus dem aktuellen Stand (für Kopfkachel und Widget „Lage“). */
  _heatBriefHtml() {
    const rooms = this._rooms();
    const st = this._status?.rooms || {};
    const s = this._status || {};
    const set = this._data.settings;
    const f = this._facts();
    const avgOf = (list) => (list.length ? list.reduce((a, b) => a + b, 0) / list.length : null);
    const avg = avgOf(rooms.map((r) => st[r.id]?.room_temp).filter((t) => t != null));
    const hum = avgOf(rooms.map((r) => st[r.id]?.humidity).filter((h) => h != null));
    const below = rooms.filter((r) => {
      const x = st[r.id] || {};
      return x.room_temp != null && x.target != null && !["aus", "fenster", "sommer", "warm", "entkalken"].includes(x.mode) && x.target - x.room_temp >= 0.5;
    });
    const rep2 = this._report(14);
    const today = rep2 ? this._sumDay(rep2, 13) : null;
    return this._heatBrief({ rooms, st, s, set, f, avg, below, today, hum, w: this._weather() });
  }

  _rwBriefHtml() {
    const covers = this._rwCovers();
    if (!this._data.rollwerk || !covers.length) return "";
    const s = this._rwStatus || {};
    const pos = covers.map((c) => this._rwPos(c.st)).filter((x) => x != null);
    const all = covers.map((c) => c.id).join(",");
    const first = (covers.find((c) => (c.cfg.profile || "standard") === "standard") || covers[0])?.rs || {};
    return this._rwBrief({ covers, s, all, first, nOpen: pos.filter((x) => x >= 95).length, nClosed: pos.filter((x) => x <= 5).length, pos });
  }

  /** Stand aus einer Kopfkachel lesen: Zustand, Satz, Symbol, erste Zeile. */
  _briefParts(html) {
    if (!html) return null;
    const t = document.createElement("template");
    t.innerHTML = html;
    const b = t.content.querySelector(".brief");
    if (!b) return null;
    return { tone: b.dataset.tone, color: b.style.getPropertyValue("--tone"), title: b.querySelector(".br-h span")?.textContent || "",
      icon: b.querySelector(".br-h ha-icon")?.getAttribute("icon") || "mdi:information-outline", lines: [...b.querySelectorAll(".br-l .grow")].map((x) => x.textContent) };
  }

  /** Heizwerk-Lage: Stand, Gründe, Nächstes. */
  _heatBrief(ctx) {
    const { rooms, st, s, set, f, avg, below, today, hum, w } = ctx;
    const n = rooms.length;
    const roomAct = (r) => `data-action="room-page" data-id="${esc(r.id)}"`;
    const diffTxt = (r) => fmt((st[r.id].target - st[r.id].room_temp));
    // Kopfsatz und Zustand
    let tone = "ok", icon = "mdi:check-circle-outline", title;
    let act = "";
    const comfortNow = rooms.filter((r) => ["komfort", "vorheizen"].includes(st[r.id]?.mode)).length;
    if (!n) { tone = "calm"; icon = "mdi:home-plus-outline"; title = "Noch keine Räume angelegt"; }
    else if (s.summer) { tone = "calm"; icon = "mdi:weather-sunny"; title = "Sommerpause – die Thermostate ruhen"; }
    else if (f.open) { tone = "info"; icon = "mdi:window-open-variant"; title = `${f.open} ${f.open > 1 ? "Räume lüften" : "Raum lüftet"} – dort pausiert die Heizung`; }
    else if (s.vacation) { tone = "calm"; icon = "mdi:palm-tree"; title = `Urlaub – alle Räume auf ${fmt(set.vacation_temp)} °C`; }
    else if (s.away) { tone = "calm"; icon = "mdi:home-export-outline"; title = this._awayInfo(rooms[0] || {})?.text?.replace("Niemand da", "Niemand zu Hause") || "Niemand zu Hause – abgesenkt"; }
    else if (s.approaching) { tone = "active"; icon = "mdi:home-import-outline"; title = "Jemand kommt heim – es wird schon geheizt"; }
    else if (below.length === 1) {
      const r = below[0];
      tone = st[r.id].heating ? "active" : "warn"; icon = "mdi:thermometer-chevron-up";
      title = `${r.name} ${diffTxt(r)} °C unter Soll – ${st[r.id].heating ? "wird aufgeheizt" : "Heizung prüfen"}`;
      act = roomAct(r);
    } else if (below.length) {
      const heating = below.filter((r) => st[r.id].heating).length;
      tone = heating ? "active" : "warn"; icon = "mdi:thermometer-chevron-up";
      title = `${below.length} Räume unter Soll – ${heating === below.length ? "werden aufgeheizt" : heating ? `${heating} heizen` : "Heizung prüfen"}`;
    } else title = comfortNow ? `Alles im Plan – ${comfortNow} ${comfortNow > 1 ? "Räume" : "Raum"} auf Komfort` : "Alles im Plan";
    // Was gerade zählt
    const lines = [];
    const now = Date.now();
    for (const o of this._openWindows().slice(0, 2)) {
      const m = o.s.last_changed ? Math.round((now - new Date(o.s.last_changed)) / 60000) : null;
      lines.push({ icon: "mdi:window-open-variant", c: "#22d3ee", text: `Fenster ${this._entityName(o.id)} offen${m != null ? ` – Pause seit ${m < 90 ? `${m} Min.` : `${fmt(m / 60)} h`}` : ""}`, act: roomAct(o.room) });
    }
    for (const r of rooms) {
      const x = st[r.id] || {};
      if (!["manuell", "boost"].includes(x.mode)) continue;
      const until = x.override_until ? new Date(x.override_until).toLocaleTimeString("de-DE", { hour: "2-digit", minute: "2-digit" }) : null;
      lines.push({ icon: x.mode === "boost" ? "mdi:rocket-launch-outline" : "mdi:hand-back-right-outline", c: "#8b5cf6",
        text: x.mode === "boost" ? `${r.name}: Boost${until ? ` bis ${until}` : ""}` : `${r.name} von Hand auf ${fmt(x.target)} °C${until ? ` bis ${until}` : ""}`, act: roomAct(r) });
    }
    if (below.length > 1) for (const r of below.slice(0, 2))
      lines.push({ icon: "mdi:thermometer-chevron-up", c: "#fb923c", text: `${r.name}: ${diffTxt(r)} °C unter Soll${st[r.id].heating ? " – heizt" : ""}`, act: roomAct(r) });
    const doneV = rooms.filter((r) => st[r.id]?.air?.open?.done);
    if (doneV.length) lines.unshift({ icon: "mdi:window-closed-variant", c: "#ef4444", text: `Genug gelüftet – Fenster schließen: ${doneV.map((r) => r.name).join(", ")}`, act: `data-action="tab" data-tab="vent"` });
    const needV = rooms.filter((r) => st[r.id]?.vent);
    if (needV.length) lines.push({ icon: "mdi:weather-windy", c: "#0891b2", text: `Lüften: ${needV.map((r) => `${r.name} ${st[r.id].vent.minutes} Min.`).join(", ")}`, act: `data-action="tab" data-tab="vent"` });
    const wx = this._wxAlerts()[0];
    if (wx) lines.push({ icon: wx.icon, c: "#38bdf8", text: `${wx.text} – ${wx.sub}` });
    // Nächster Wechsel (gleiche Zeit zusammengefasst)
    if (!s.summer && !s.vacation) {
      const next = new Map();
      for (const r of rooms) {
        if (r.enabled === false) continue;
        const info = this._schedInfo(r, st[r.id] || {});
        const mins = info.blocks && info.blocks.length ? this._nextSwitch(info.blocks, r, info.comfort) : st[r.id]?.next_change;
        if (mins == null || mins > 36 * 60) continue;
        const key = `${Math.round(mins)}|${info.comfort ? "eco" : "komfort"}`;
        if (!next.has(key)) next.set(key, { mins, comfort: info.comfort, names: [], lead: 0 });
        const e = next.get(key);
        e.names.push(r.name);
        if (!info.comfort) e.lead = Math.max(e.lead, this._preLead(r, st[r.id] || {}) || 0);
      }
      const first = [...next.values()].sort((a, b) => a.mins - b.mins)[0];
      if (first) {
        const names = first.names.length > 2 ? `${first.names.length} Räumen` : first.names.join(" und ");
        const pre = !first.comfort && first.lead && !s.away ? ` (Vorheizen ab ${this._whenIn(first.mins - first.lead).replace("morgen ", "")})` : "";
        lines.push({ icon: first.comfort ? "mdi:leaf" : "mdi:sofa-outline", c: first.comfort ? "#60a5fa" : "#facc15",
          text: `${this._whenIn(first.mins).replace(/^(\d)/, "Um $1")} ${first.comfort ? "Eco" : "Komfort"} in ${names}${pre}` });
      }
    }
    const chips = [
      [f.heating ? "mdi:fire" : "mdi:fire-off", `${f.heating} von ${n}`, "heizen", f.heating ? "#fb923c" : ""],
      ...(hum != null && (hum >= 65 || hum <= 35) ? [[humidityInfo(hum).i, `${fmt(hum, 0)} %`, `Luftfeuchte · ${humidityInfo(hum).t}`, "#38bdf8"]] : []),
      ["mdi:timer-outline", today ? `${fmt(today.heat / 60)} h` : "–", "heute geheizt", ""],
    ];
    const date = new Date().toLocaleDateString("de-DE", { weekday: "long", day: "numeric", month: "long" });
    const side = w ? `<span class="br-wx" title="${esc(w.name)}${w.extra ? ` · ${String(w.extra).replace(/<[^>]+>/g, "")}` : ""}"><ha-icon icon="${w.icon}"></ha-icon><b>${fmt(w.temp)} °C</b><small>${esc(w.label)}</small></span>` : "";
    return this._brief({ cls: "card br-heat br-mod-heat", tone, icon, act, label: `<ha-icon icon="mdi:home-thermometer-outline"></ha-icon>Im Haus · ${date}`,
      big: `${fmt(avg)}<span>°C</span>`, title, side, lines, chips });
  }

  /** Raumkacheln: detailliert oder kompakt (je Gerät gemerkt). */
  /** Rollläden: detailliert oder kompakt (je Gerät gemerkt). */
  _rwView() {
    if (this._rwv) return this._rwv;
    try {
      this._rwv = localStorage.getItem("hauswerk.rollansicht") || "detail";
    } catch (e) {
      this._rwv = "detail";
    }
    return this._rwv;
  }

  _roomView() {
    if (this._view) return this._view;
    try {
      this._view = localStorage.getItem("hauswerk.raumansicht") || localStorage.getItem("heizwerk.raumansicht") || "detail";
    } catch (e) {
      this._view = "detail";
    }
    return this._view;
  }

  /** Wetter aus der gewählten weather-Entität, sonst der ersten gefundenen. */
  _weather() {
    const id = this._data.settings.weather_entity || Object.keys(this._hass.states).find((e) => e.startsWith("weather."));
    const w = id && this._hass.states[id];
    if (!w || ["unavailable", "unknown"].includes(w.state)) return null;
    const a = w.attributes || {};
    const [icon, label] = WEATHER[w.state] || ["mdi:weather-partly-cloudy", w.state];
    const extra = [a.wind_speed != null ? `Wind ${fmt(a.wind_speed, 0)} ${a.wind_speed_unit || "km/h"}` : "", a.humidity != null ? `${fmt(a.humidity, 0)} % Feuchte` : ""].filter(Boolean).join(" · ");
    return { icon, label, temp: this._status?.outside_temp ?? a.temperature, extra, name: a.friendly_name || id };
  }
  _gauge(avg, target) {
    // Eigener Ring: Bogen 135°…405°, Skala 14–26 °C
    const pct = (t) => Math.min(1, Math.max(0, ((t ?? 14) - 14) / 12));
    const R = 62, C = 2 * Math.PI * R, arc = 0.75 * C;
    const val = pct(avg) * arc;
    const tAng = 135 + pct(target) * 270;
    const tx = 80 + R * Math.cos((tAng * Math.PI) / 180);
    const ty = 80 + R * Math.sin((tAng * Math.PI) / 180);
    return `
      <div class="gauge" aria-hidden="true">
        <svg viewBox="0 0 160 160">
          <defs><linearGradient id="g" x1="0" x2="1" y1="1" y2="0"><stop offset="0" stop-color="#5eead4"/><stop offset=".6" stop-color="#fde047"/><stop offset="1" stop-color="#fb923c"/></linearGradient></defs>
          <circle cx="80" cy="80" r="${R}" fill="none" stroke="rgba(255,255,255,.14)" stroke-width="12" stroke-linecap="round"
            stroke-dasharray="${arc} ${C}" transform="rotate(135 80 80)"/>
          <circle cx="80" cy="80" r="${R}" fill="none" stroke="url(#g)" stroke-width="12" stroke-linecap="round"
            stroke-dasharray="${val} ${C}" transform="rotate(135 80 80)"/>
          ${target != null ? `<circle cx="${tx}" cy="${ty}" r="7" fill="#fff" stroke="rgba(0,0,0,.25)" stroke-width="2"/>` : ""}
          <text x="80" y="76" text-anchor="middle" class="g-small">Soll Ø</text>
          <text x="80" y="100" text-anchor="middle" class="g-big">${fmt(target)}°</text>
        </svg>
      </div>`;
  }

  _presenceCard(inline = false) {
    const s = this._status || {};
    const settings = this._data.settings;
    const mode = s.vacation ? "urlaub" : s.away ? "abwesend" : "home";
    const persons = (settings.persons || []).length;
    const text = {
      home: persons
        ? `Heizpläne laufen normal · abwesend nach ${settings.away_delay} Min. ohne Personen`
        : `Heizpläne laufen normal · <button class="link inline" data-action="settings-go" data-sub="presence">Personen wählen</button>, damit Abwesenheit erkannt wird`,
      abwesend: `${s.long_away ? `Lange niemand da – Frostschutz ${fmt(settings.frost_temp)} °C` : settings.away_action === "off" ? "Thermostate aus" : settings.away_mode === "offset" ? `Alle Räume ${fmt(settings.away_offset)} °C kühler` : `Alle Räume höchstens ${fmt(settings.away_temp)} °C`} · ${s.presence_force ? "von Hand gesetzt" : "endet, wenn jemand heimkommt"}`,
      urlaub: (() => {
        // Ende des Urlaubs: aus dem laufenden Kalendertermin oder dem eingetragenen Zeitraum
        const src = settings.vacation_source || "period";
        const ev = src === "calendar" ? (s.vacation_events || []).find((e) => new Date(e.start) <= new Date()) : null;
        const end = settings.vacation ? null : ev ? new Date(new Date(ev.end).getTime() - 1) : src === "period" && settings.vacation_to ? new Date(settings.vacation_to) : null;
        return `Alle Räume auf ${fmt(settings.vacation_temp)} °C${end ? ` bis ${end.toLocaleDateString("de-DE")}` : ""}${ev && !settings.vacation ? ` · laut Kalender: ${esc(ev.summary || "Termin")}` : ""}`;
      })(),
    }[mode];
    const dis = this._operate ? "" : "disabled";
    const seg = (id, icon, label) =>
      `<button class="pseg ${mode === id ? "on" : ""}" data-action="presence" data-mode="${id}" ${dis}><ha-icon icon="${icon}"></ha-icon><span>${label}</span></button>`;
    const toggle = (key, icon, label, title) =>
      `<label class="ptoggle ${settings[key] ? "on" : ""}" title="${title}"><input type="checkbox" data-action="hmode" data-key="${key}" ${settings[key] ? "checked" : ""} ${dis}><ha-icon icon="${icon}"></ha-icon><span>${label}</span></label>`;
    return `
      <section class="${inline ? "" : "card "}presence">
        <div class="pbar">
          <div class="psegs">
            ${seg("home", "mdi:home-heart", "Zu Hause")}
            ${seg("abwesend", "mdi:home-export-outline", "Abwesend")}
            ${seg("urlaub", "mdi:palm-tree", "Urlaub")}
          </div>
          <div class="ptoggles">
            ${toggle("guest", "mdi:account-group-outline", "Gäste", "Gäste: nie auf Abwesend absenken")}
            ${toggle("party", "mdi:party-popper", "Party", "Party: alle Räume auf Komfort")}
            ${toggle("eco_force", "mdi:leaf", "Eco", "Eco erzwingen: alle Räume auf Eco")}
          </div>
        </div>
        <p class="ptext"><ha-icon icon="mdi:information-outline"></ha-icon><span>${text}</span></p>
      </section>`;
  }

  _kpi(color, icon, label, value, unit, sub) {
    return `
      <div class="kpi" style="--k:${color}">
        <div class="kpi-l"><ha-icon icon="${icon}"></ha-icon>${label}</div>
        <div class="kpi-v">${value}<span>${unit}</span></div>
        <div class="kpi-s">${sub || "&nbsp;"}</div>
      </div>`;
  }

  _sumDay(rep, idx) {
    const out = { heat: 0, pause: 0, comfort: 0, open: 0 };
    for (const rows of Object.values(rep)) {
      const r = rows[idx];
      if (!r) continue;
      out.heat += r.heat_min;
      out.pause += r.pause_min;
      out.comfort += r.comfort_min;
      out.open += r.openings;
    }
    return out;
  }

  _sumRange(rep, from, to) {
    const out = { heat: 0, pause: 0, comfort: 0, open: 0 };
    for (let i = from; i < to; i++) {
      const d = this._sumDay(rep, i);
      for (const k in out) out[k] += d[k];
    }
    return out;
  }

  _stackChart(rep, days, key) {
    const rooms = this._rooms();
    const W = 1000, H = 240, padL = 44, padB = 28, padT = 10;
    const totals = Array.from({ length: days }, (_, i) => rooms.reduce((a, r) => a + ((rep[r.id] || [])[i]?.[key] || 0), 0));
    const hoursMode = key === "heat_min";
    const maxRaw = Math.max(...totals, hoursMode ? 60 : 10);
    const unit = hoursMode ? 60 : 1;
    const stepCount = 4;
    let step = Math.ceil(maxRaw / unit / stepCount);
    if (hoursMode && step > 2) step = Math.ceil(step / 2) * 2;
    if (!hoursMode) step = Math.max(5, Math.ceil(step / 5) * 5);
    const max = step * stepCount * unit;
    const y = (v) => padT + (H - padT - padB) * (1 - v / max);
    const bw = (W - padL) / days;
    const grid = Array.from({ length: stepCount + 1 }, (_, i) => {
      const v = i * step * unit;
      return `<line x1="${padL}" x2="${W}" y1="${y(v)}" y2="${y(v)}" class="gl"/><text x="${padL - 10}" y="${y(v) + 4}" text-anchor="end" class="ax">${int(v / unit)}</text>`;
    }).join("");
    const anyData = totals.some((t) => t > 0);
    let bars = "";
    let labels = "";
    const dates = (rep[rooms[0]?.id] || []).map((r) => r.date);
    for (let i = 0; i < days; i++) {
      let acc = 0;
      const x = padL + i * bw + bw * 0.2;
      rooms.forEach((r) => {
        const v = (rep[r.id] || [])[i]?.[key] || 0;
        if (!v) return;
        const y1 = y(acc + v), y0 = y(acc);
        bars += `<rect x="${x}" y="${y1}" width="${bw * 0.6}" height="${Math.max(0, y0 - y1 - 2)}" rx="4" fill="${this._roomColor(r.id)}"><title>${esc(r.name)}: ${hoursMode ? fmt(v / 60) + " h" : int(v) + " Min."}</title></rect>`;
        acc += v;
      });
      const isToday = i === days - 1;
      if (isToday || i % Math.ceil(days / 7) === (days - 1) % Math.ceil(days / 7)) {
        const label = isToday ? "heute" : dates[i] ? new Date(dates[i]).toLocaleDateString("de-DE", { day: "2-digit", month: "2-digit" }) : "";
        labels += `<text x="${padL + i * bw + bw / 2}" y="${H - 6}" text-anchor="middle" class="ax ${isToday ? "today" : ""}">${label}</text>`;
      }
    }
    return `
      <div class="chart-wrap">
        <svg class="chart" viewBox="0 0 ${W} ${H}" preserveAspectRatio="none">${grid}${bars}${labels}</svg>
        ${anyData ? "" : `<div class="chart-note">Noch keine Werte. Heizwerk zählt ab jetzt jede Minute mit.</div>`}
      </div>
      <div class="legend">
        <span class="muted">${hoursMode ? "Stunden" : "Minuten"}</span>
        ${rooms.map((r) => `<span><i style="background:${this._roomColor(r.id)}"></i>${esc(r.name)}</span>`).join("")}
      </div>`;
  }

  /** Raum ohne Thermostat: ruhige graue Kachel mit genau einem Knopf. */
  _roomSetup(room, mini = false) {
    return `
      <article class="${mini ? "rmini" : "room"} setup" id="room-${room.id}" style="--rc:${this._roomColor(room.id)}">
        <div class="${mini ? "rm-head" : "room-head"}">
          <${mini ? "span" : "div"} class="${mini ? "rm-ic" : "room-ic"}"><ha-icon icon="${esc(roomIcon(room))}"></ha-icon></${mini ? "span" : "div"}>
          ${mini ? `<b class="rm-name">${esc(room.name)}</b>` : `<div class="room-t"><h4>${esc(room.name)}</h4><small>noch nicht eingerichtet</small></div>`}
        </div>
        <div class="setup-b">
          ${mini ? "" : `<p><ha-icon icon="mdi:thermostat-box"></ha-icon>Ordne ein Thermostat zu – dann regelt Heizwerk diesen Raum.</p>`}
          ${this._admin ? `<button class="secondary" data-action="room-edit" data-id="${room.id}" data-rtab="devices"><ha-icon icon="mdi:link-variant-plus"></ha-icon>Geräte zuordnen</button>` : `<p class="muted small">Noch nicht eingerichtet</p>`}
        </div>
      </article>`;
  }

  _roomCard(room) {
    if (!(room.climates || []).length) return this._roomSetup(room);
    const s = this._status?.rooms?.[room.id] || {};
    const mode = s.mode || "aus";
    const until = s.override_until ? new Date(s.override_until).toLocaleTimeString("de-DE", { hour: "2-digit", minute: "2-digit" }) : null;
    const canStep = !["aus", "fenster", "sommer", "entkalken", "boost"].includes(mode);
    const canBoost = !["aus", "fenster", "entkalken"].includes(mode) && (room.climates || []).length;
    // Nur was auffällt, als kleines Symbol neben dem Namen (Text im Tooltip)
    const icons = [];
    const si = (icon, c, title, text = "") => `<span class="si" style="--c:${c}" title="${esc(title)}"><ha-icon icon="${icon}"></ha-icon>${text}</span>`;
    const vc = this._ventChip(s);
    if (vc) icons.push(si(vc[0], vc[2], vc[3], vc[1]));
    else if (s.windows_open) icons.push(si("mdi:window-open-variant", "#22d3ee", s.window_pending ? "Fenster offen – Pause beginnt gleich" : "Fenster offen"));
    const fc = this._fireChip(s);
    if (fc) icons.push(si(fc[0], fc[2], fc[3], fc[1]));
    if (s.occupied === true) icons.push(si("mdi:account-check-outline", "#fbbf24", "Präsenzmelder: jemand im Raum"));
    else if (s.occupied === false) icons.push(si("mdi:account-off-outline", "var(--muted)", "Präsenzmelder: niemand im Raum"));
    const dv = this._devIndicators(room);
    if (dv.valve != null)
      icons.push(si("mdi:valve", dv.valve > 0 ? "#fb923c" : "var(--muted)", `Ventil${dv.valves > 1 ? "e (höchster Wert)" : ""}: ${fmt(dv.valve, 0)} % offen`, `${fmt(dv.valve, 0)} %`));
    // Fußbodenheizung: nur das Symbol, solange sie heizt (Details als Quickinfo)
    if (dv.floor?.on) icons.push(si("mdi:heating-coil", "#f97316", `${dv.floor.label} heizt – ${dv.floor.names}`));
    if (s.assist?.on) icons.push(si("mdi:radiator", "#f97316", "Heizkörper hilft nach (Mischbetrieb)"));
    const hum = humidityInfo(s.humidity);
    if (hum) icons.push(si(hum.i, hum.t ? hum.c : "var(--muted)", `Luftfeuchte ${fmt(s.humidity, 0)} %${hum.t ? " – " + hum.t : ""}`, `${fmt(s.humidity, 0)} %`));
    const tr = !["aus", "fenster", "sommer", "entkalken", "warm", "boost"].includes(mode) ? trend(s.room_temp, s.target) : null;
    // Genau ein Hinweis, der wichtigste zuerst
    const note = (() => {
      if (!(room.climates || []).length) return `<div class="room-note warn"><ha-icon icon="mdi:alert-outline"></ha-icon>Kein Thermostat zugeordnet${this._admin ? `<span class="grow"></span><button class="link" data-action="room-edit" data-id="${room.id}" data-rtab="devices">Zuordnen</button>` : ""}</div>`;
      if (mode === "manuell" && until) return `<div class="room-note"><ha-icon icon="mdi:hand-back-right-outline"></ha-icon>Manuell bis ${until}<span class="grow"></span><button class="link" data-action="ovr-reset" data-id="${room.id}">Zurück zum Plan</button></div>`;
      if (mode === "boost" && until) return `<div class="room-note boost"><ha-icon icon="mdi:rocket-launch-outline"></ha-icon>Boost bis ${until}<span class="grow"></span><button class="link" data-action="ovr-reset" data-id="${room.id}">Beenden</button></div>`;
      if (s.window_pending) return `<div class="room-note"><ha-icon icon="mdi:window-open-variant"></ha-icon>Fenster offen – Heizpause beginnt gleich</div>`;
      if (mode === "vorheizen") {
        const mins = s.comfort_in ?? s.next_change;
        const at = mins != null ? new Date(Date.now() + mins * 60000).toLocaleTimeString("de-DE", { hour: "2-digit", minute: "2-digit" }) : null;
        return `<div class="room-note pre"><ha-icon icon="${s.preheat_mode === "smart" ? "mdi:brain" : "mdi:clock-fast"}"></ha-icon><span>Heizt vor${at ? ` – ${fmt(s.target)} °C ab ${at}` : ""}${s.preheat_mode === "smart" && s.heat_rate ? `<small> · ${fmt(s.heat_rate)} °C/h</small>` : ""}</span></div>`;
      }
      if (mode === "warm") return `<div class="room-note warmn"><ha-icon icon="mdi:thermometer-check"></ha-icon>Warm genug – aus, bis unter ${fmt(s.target)} °C</div>`;
      return "";
    })();
    const auto = room.enabled !== false;
    const menu = this._admin
      ? `<details class="rmenu">
          <summary class="icon" title="Mehr"><ha-icon icon="mdi:dots-horizontal"></ha-icon></summary>
          <div class="rm-pop">
            <button data-action="plan-open" data-id="${room.id}"><ha-icon icon="mdi:calendar-clock"></ha-icon>Heizplan</button>
            <button data-action="room-edit" data-id="${room.id}"><ha-icon icon="mdi:cog-outline"></ha-icon>Bearbeiten</button>
            <button data-action="room-auto" data-id="${room.id}"><ha-icon icon="${auto ? "mdi:robot-off-outline" : "mdi:robot-outline"}"></ha-icon>Automatik ${auto ? "ausschalten" : "einschalten"}</button>
          </div>
        </details>`
      : "";
    return `
      <article class="room tap ${mode === "aus" ? "off" : ""}" id="room-${room.id}" style="--rc:${this._roomColor(room.id)}" data-action="room-quick" data-id="${room.id}" title="Tippen für manuelle Änderungen">
        <div class="room-head">
          <div class="room-ic">
            <ha-icon icon="${esc(roomIcon(room))}"></ha-icon>
            ${s.heating ? `<span class="flame" title="Heizt"><ha-icon icon="mdi:fire"></ha-icon></span>` : ""}
          </div>
          <div class="room-t"><h4><button class="rlink" data-action="room-page" data-id="${room.id}" title="Raum öffnen">${esc(room.name)}</button></h4>${icons.length ? `<small><span class="sis">${icons.join("")}</span></small>` : ""}</div>
          <span title="${esc(s.cause || "")}">${this._chip(mode, s.mode_label || "Automatik aus")}</span>
          ${canBoost ? `<button class="icon ${mode === "boost" ? "hot" : ""}" title="${mode === "boost" ? "Boost beenden" : `Boost: ${this._data.settings.boost_minutes || 30} Min. volle Leistung`}" data-action="${mode === "boost" ? "ovr-reset" : "boost"}" data-id="${room.id}"><ha-icon icon="mdi:rocket-launch-outline"></ha-icon></button>` : ""}
          ${menu}
        </div>
        <div class="room-body">
          <div class="room-now">
            <div class="room-temp">${fmt(s.room_temp)}<span>°C</span></div>
            ${tr ? `<div class="trend" style="--c:${tr.c}"><ha-icon icon="${tr.i}"></ha-icon>${tr.t}</div>` : ""}
          </div>
          <div class="room-set">
            <small><ha-icon icon="mdi:target"></ha-icon>Soll</small>
            ${canStep ? this._stepper("ovr", room.id, s.target, { small: true }) : `<b class="tgt" style="color:${tint(tempColor(s.target))}">${fmt(s.target)} °C</b>`}
          </div>
        </div>
        ${this._schedStrip(room, s)}
        ${note}
      </article>`;
  }

  // ------------------------------------------------------------ Raum-Detailseite
  _viewRoom() {
    const room = this._data.rooms[this._roomId];
    const back = `<button class="link back" data-action="tab" data-tab="overview"><ha-icon icon="mdi:chevron-left"></ha-icon>Räume</button>`;
    if (!room) return `${back}<section class="card empty"><ha-icon icon="mdi:door-closed-cancel"></ha-icon><h2>Raum nicht gefunden</h2></section>`;
    const s = this._status?.rooms?.[room.id] || {};
    const S = this._hass.states;
    const set = this._data.settings;
    const d = this._data.defaults[room.type] || {};
    const val = (id, attr) => {
      const st = S[id];
      if (!st) return "fehlt";
      if (attr) return st.attributes[attr] != null ? `${fmt(st.attributes[attr])} °C` : "–";
      const u = st.attributes.unit_of_measurement || "";
      return `${isNaN(parseFloat(st.state)) ? st.state : fmt(parseFloat(st.state))}${u ? ` ${u}` : ""}`;
    };
    const dev = (icon, label, id, value, ok = true) => `
      <div class="wrow"><ha-icon icon="${icon}"></ha-icon><span class="grow"><b>${esc(this._devType(id))}</b><small>${esc(this._entityName(id))}${label ? ` · ${label}` : ""}</small></span><em class="${ok ? "" : "bad"}">${value}</em></div>`;
    const devices = [
      ...(room.climates || []).map((id) => {
        const st = S[id];
        const bad = !st || ["unavailable", "unknown"].includes(st.state);
        const v = this._valveOf(id);
        const follows = (s.followers || []).includes(id);
        const assist = (s.assist?.entities || []).includes(id);
        return dev(follows || assist ? "mdi:radiator" : "mdi:thermostat",
          assist ? `Zusatzheizung, gerade ${s.assist.on ? "an" : "zu"}` : follows ? "folgt dem Wandthermostat" : "stellt ein", id, bad ? "nicht erreichbar" : `${val(id, "current_temperature")} → ${val(id, "temperature")}${st.attributes.hvac_action === "heating" ? " · heizt" : ""}${v != null ? ` · Ventil ${fmt(v, 0)} %` : ""}`, !bad);
      }),
      ...(room.windows || []).map((id) => {
        const st = S[id];
        const open = st && ["on", "open", "opening", "true"].includes(String(st.state).toLowerCase());
        return dev(open ? "mdi:window-open-variant" : "mdi:window-closed-variant", "", id, !st ? "fehlt" : open ? "offen" : "zu", !!st);
      }),
      ...(room.show_entities || []).map((id) => {
        const st = S[id];
        const bad = !st || ["unavailable", "unknown"].includes(st.state);
        const v = this._valveOf(id);
        const dom = id.split(".")[0];
        const sw = this._switchOf(id);
        if (sw != null) return dev("mdi:heating-coil", "nur Anzeige", id, bad ? "nicht erreichbar" : sw ? "an – heizt" : "aus", !bad);
        const label = "nur Anzeige";
        return dev(v != null ? "mdi:valve" : dom === "climate" ? "mdi:thermostat-box" : "mdi:eye-outline", label, id, bad ? "nicht erreichbar" : v != null ? `${fmt(v, 0)} % offen${dom === "climate" ? ` · ${esc(this._fmtState(st))}` : ""}` : esc(this._fmtState(st)), !bad);
      }),
      room.temp_sensor ? dev("mdi:thermometer", "Raumtemperatur", room.temp_sensor, val(room.temp_sensor), !!S[room.temp_sensor]) : "",
      room.humidity_sensor ? dev("mdi:water-percent", "", room.humidity_sensor, val(room.humidity_sensor), !!S[room.humidity_sensor]) : "",
      room.presence_sensor ? dev("mdi:motion-sensor", "", room.presence_sensor, S[room.presence_sensor]?.state === "on" ? "jemand da" : "leer", !!S[room.presence_sensor]) : "",
    ].join("");
    const preMode = room.preheat_mode || set.preheat_mode || "fixed";
    const kv = (k, v) => `<div class="kv"><span>${k}</span><b>${v}</b></div>`;
    const settings = [
      kv("Komfort / Eco", `${fmt(room.comfort)} / ${fmt(room.eco)} °C`),
      kv("Heizplan", esc(this._planLabel(room))),
      kv("Vorheizen", preMode === "smart" ? `lernend${s.heat_rate ? ` · ${fmt(s.heat_rate)} °C/h` : ""}` : preMode === "off" ? "aus" : `${room.lead_min ?? this._leadFor(room.type)} Min.`),
      kv("Fensterpause nach", `${room.window_delay ?? d.window_delay ?? 0} s`),
      kv("Bei offenem Fenster", (room.pause_mode || d.pause_mode) === "off" ? "aus" : `${fmt(room.window_temp ?? set.frost_temp)} °C`),
      kv("Automatik", room.enabled === false ? "aus" : "an"),
    ].join("");
    const rep = this._report(7);
    const rows = rep?.[room.id] || [];
    const sum = (k) => rows.reduce((a, x) => a + (x[k] || 0), 0);
    const temps = rows.map((x) => x.avg_temp).filter((t) => t != null);
    const week = rep
      ? `<div class="wminis four">
          <div class="wmini"><ha-icon icon="mdi:fire"></ha-icon><b>${fmt(sum("heat_min") / 60)} h</b><small>geheizt</small></div>
          <div class="wmini"><ha-icon icon="mdi:sofa-outline"></ha-icon><b>${fmt(sum("comfort_min") / 60)} h</b><small>Komfort</small></div>
          <div class="wmini"><ha-icon icon="mdi:window-open-variant"></ha-icon><b>${int(sum("openings"))}×</b><small>gelüftet</small></div>
          <div class="wmini"><ha-icon icon="mdi:thermometer"></ha-icon><b>${temps.length ? fmt(temps.reduce((a, b) => a + b, 0) / temps.length) : "–"} °C</b><small>Ø Raum</small></div>
        </div>`
      : `<div class="chart-empty"><div class="spinner"></div></div>`;
    return `
      ${back}
      <div class="rpage">${this._roomCard(room)}</div>
      <section class="card">
        ${this._sectionHead("mdi:chart-line", "Letzte 24 Stunden", `<span class="rlegend"><span><i class="lt"></i>Raum</span><span><i class="ls"></i>Soll</span><span><i class="lh"></i>heizt</span><span><i class="lw"></i>Fenster offen</span></span>`)}
        ${this._historyChart(room)}
      </section>
      <div class="rp-grid">
        <section class="card">${this._sectionHead("mdi:devices", "Geräte", this._admin ? `<button class="link" data-action="room-edit" data-id="${room.id}" data-rtab="devices">Ändern</button>` : "")}<div class="wlist">${devices || `<p class="muted small">Noch keine Geräte zugeordnet.</p>`}</div></section>
        <section class="card">${this._sectionHead("mdi:tune-variant", "Einstellungen", this._admin ? `<button class="link" data-action="room-edit" data-id="${room.id}">Bearbeiten</button>` : "")}<div class="kvs">${settings}</div></section>
        <section class="card">${this._sectionHead("mdi:calendar-week", "Letzte 7 Tage", `<button class="link" data-action="tab" data-tab="report">Bericht</button>`)}${week}</section>
      </div>`;
  }

  /** Verlauf der letzten 24 h aus dem Recorder (Soll-Sensor von Heizwerk, sonst das Thermostat). */
  _history(room) {
    this._hist = this._hist || {};
    const h = this._hist[room.id];
    if (h && (h.loading || Date.now() - h.at < 5 * 60000)) return h;
    const sensor = this._data.target_sensors?.[room.id];
    const climate = (room.climates || [])[0];
    const ids = [sensor, climate, room.temp_sensor].filter(Boolean);
    this._hist[room.id] = { loading: true, at: Date.now() };
    if (!ids.length) {
      this._hist[room.id] = { at: Date.now(), error: "Keine Entitäten mit Verlauf" };
      return this._hist[room.id];
    }
    this._hass
      .callWS({ type: "history/history_during_period", start_time: new Date(Date.now() - 24 * 3600e3).toISOString(), entity_ids: ids, minimal_response: false, no_attributes: false, significant_changes_only: false })
      .then((res) => (this._hist[room.id] = { at: Date.now(), res, sensor, climate, temp: room.temp_sensor }))
      .catch((err) => (this._hist[room.id] = { at: Date.now(), error: err?.message || "Verlauf nicht verfügbar" }))
      .finally(() => this._tab === "room" && this._roomId === room.id && this._renderMain());
    return this._hist[room.id];
  }

  _historyChart(room) {
    const h = this._history(room);
    if (h.loading) return `<div class="chart-empty"><div class="spinner"></div></div>`;
    if (h.error) return `<p class="muted small">${esc(h.error)}</p>`;
    // Einträge vereinheitlichen: komprimiert (s, a, lu) oder ausführlich (state, attributes, last_updated)
    const norm = (list) =>
      (list || []).map((x) => ({ s: x.s ?? x.state, a: x.a ?? x.attributes ?? {}, t: x.lu != null ? x.lu * 1000 : new Date(x.last_updated || x.last_changed).getTime() }));
    const num = (v) => (v == null || v === "" || isNaN(parseFloat(v)) ? null : parseFloat(v));
    let pts = [];
    if (h.sensor && h.res[h.sensor]?.length) {
      let last = {};
      pts = norm(h.res[h.sensor]).map((x) => {
        // Attribute fehlen bei unveränderten Einträgen: letzten Stand weiterführen
        last = { ...last, ...x.a };
        return { t: x.t, target: num(x.s), temp: num(last.raumtemperatur), heat: !!last.heizt, win: !!last.fenster_offen };
      });
    } else if (h.climate && h.res[h.climate]?.length) {
      let last = {};
      pts = norm(h.res[h.climate]).map((x) => {
        last = { ...last, ...x.a };
        return { t: x.t, target: num(last.temperature), temp: num(last.current_temperature), heat: last.hvac_action === "heating", win: false };
      });
    }
    // eigener Raumsensor hat Vorrang für die Ist-Kurve
    const tempPts = h.temp && h.res[h.temp]?.length ? norm(h.res[h.temp]).map((x) => ({ t: x.t, v: num(x.s) })) : pts.map((p) => ({ t: p.t, v: p.temp }));
    if (!pts.length && !tempPts.length) return `<p class="muted small">Noch kein Verlauf aufgezeichnet.</p>`;
    const W = 1000, H = 220, L = 70, B = 24, T = 10;
    const t1 = Date.now(), t0 = t1 - 24 * 3600e3;
    const vals = [...tempPts.map((p) => p.v), ...pts.map((p) => p.target)].filter((v) => v != null);
    let lo = Math.floor(Math.min(...vals) - 0.5), hi = Math.ceil(Math.max(...vals) + 0.5);
    if (hi - lo < 4) hi = lo + 4;
    const x = (t) => L + ((Math.max(t0, t) - t0) / (t1 - t0)) * (W - L);
    const y = (v) => T + (H - T - B) * (1 - (v - lo) / (hi - lo));
    // Bänder: heizt (unten), Fenster offen (oben)
    const bands = (key, y0, hgt, cls) => {
      let out = "", start = null;
      pts.forEach((p, i) => {
        if (p[key] && start == null) start = p.t;
        const next = pts[i + 1]?.t ?? t1;
        if (start != null && (!p[key] || i === pts.length - 1)) {
          const end = p[key] ? next : p.t;
          out += `<rect class="${cls}" x="${x(start)}" y="${y0}" width="${Math.max(2, x(end) - x(start))}" height="${hgt}" rx="2"/>`;
          start = null;
        }
      });
      return out;
    };
    const line = (list, key) => {
      const ok = list.filter((p) => p[key] != null);
      if (!ok.length) return "";
      return ok.map((p, i) => `${i ? "L" : "M"}${x(p.t).toFixed(1)},${y(p[key]).toFixed(1)}`).join("") + `L${x(t1)},${y(ok[ok.length - 1][key]).toFixed(1)}`;
    };
    const step = (list, key) => {
      const ok = list.filter((p) => p[key] != null);
      if (!ok.length) return "";
      let dStr = `M${x(ok[0].t).toFixed(1)},${y(ok[0][key]).toFixed(1)}`;
      for (let i = 1; i < ok.length; i++) dStr += `H${x(ok[i].t).toFixed(1)}V${y(ok[i][key]).toFixed(1)}`;
      return dStr + `H${x(t1)}`;
    };
    // Beschriftung als HTML, damit sie auf schmalen Bildschirmen nicht verzerrt
    const ticks = Array.from({ length: 5 }, (_, i) => lo + ((hi - lo) * i) / 4);
    const grid = ticks.map((v) => `<line class="gl" x1="${L}" x2="${W}" y1="${y(v)}" y2="${y(v)}"/>`).join("");
    const ylab = ticks.map((v) => `<span style="top:${(y(v) / H) * 100}%">${fmt(v, 0)}°</span>`).join("");
    const hours = `<div class="hx">${Array.from({ length: 5 }, (_, i) => `<span>${i === 4 ? "jetzt" : new Date(t0 + i * 6 * 3600e3).toLocaleTimeString("de-DE", { hour: "2-digit", minute: "2-digit" })}</span>`).join("")}</div>`;
    return `
      <div class="chart-wrap hwrap">
        <div class="hy">${ylab}</div>
        <svg class="chart hist" viewBox="0 0 ${W} ${H}" preserveAspectRatio="none">
          ${grid}
          ${bands("heat", H - B - 8, 8, "bh")}
          ${bands("win", T, 8, "bw")}
          <path class="ps" d="${step(pts, "target")}"/>
          <path class="pt" d="${line(tempPts, "v")}"/>
        </svg>
        ${hours}
      </div>`;
  }

  /** Zeitfenster, nach denen der Raum heizt (null bei Zeitplan/Kalender aus Home Assistant). */
  _roomBlocks(room) {
    if (room.schedule_entity) return null;
    const plan = this._data.plans?.[room.plan_id];
    if (plan) return plan.calendar ? null : plan.schedule || [];
    return room.schedule || [];
  }

  /** Woher die Komfortzeiten kommen, ob gerade Komfort ist und wann sich das ändert. */
  _schedInfo(room, s) {
    const plan = this._data.plans?.[room.plan_id];
    const blocks = this._roomBlocks(room);
    const now = new Date();
    let src, icon, comfort = false;
    if (room.schedule_entity) {
      const cal = room.schedule_entity.startsWith("calendar.");
      icon = cal ? "mdi:calendar-sync" : "mdi:home-assistant";
      src = this._entityName(room.schedule_entity);
      comfort = this._hass.states[room.schedule_entity]?.state === "on";
    } else if (plan?.calendar) {
      icon = "mdi:calendar-sync";
      src = plan.name;
      comfort = (this._status?.plan_events?.[plan.id] || []).some((e) => new Date(e.start) <= now && now < new Date(e.end));
    } else {
      icon = plan ? "mdi:calendar-multiple" : "mdi:calendar-edit";
      src = plan ? plan.name : "Eigener Plan";
      const day = this._planDay(0);
      if (day !== (now.getDay() + 6) % 7) src += ` · heute frei, wie ${day === 5 ? "Samstag" : "Sonntag"}`;
      const min = now.getHours() * 60 + now.getMinutes();
      comfort = s?.plan_kind ? s.plan_kind === "komfort" : this._daySegments(blocks, room, day).some(([a, b, , c]) => c && a <= min && min < b);
    }
    let mins = s.next_change;
    if (blocks && blocks.length) mins = this._nextSwitch(blocks, room, comfort) ?? mins;
    let text;
    if (blocks && !blocks.length) text = "keine Komfortzeit – immer Eco";
    else if (mins == null) text = comfort ? "Komfortzeit läuft" : "keine Komfortzeit in Sicht";
    else {
      const at = new Date(now.getTime() + mins * 60000);
      const same = at.toDateString() === now.toDateString();
      const tomorrow = new Date(now.getTime() + 864e5).toDateString() === at.toDateString();
      const when = `${same ? "" : tomorrow ? "morgen " : at.toLocaleDateString("de-DE", { weekday: "short" }) + " "}${at.toLocaleTimeString("de-DE", { hour: "2-digit", minute: "2-digit" })}`;
      text = comfort ? `Komfort bis ${when}` : `Komfort ab ${when}`;
    }
    return { src, icon, comfort, text, blocks };
  }

  /** Wochentag (0 = Mo), dessen Heizplan heute + k Tage gilt: freie Werktage laut Arbeitstage-Kalender wie Sa/So. */
  _planDay(k = 0) {
    const d = new Date();
    d.setDate(d.getDate() + k);
    const wd = (d.getDay() + 6) % 7;
    const iso = d.toLocaleDateString("sv-SE");
    return wd < 5 && (this._status?.free_days || []).includes(iso) ? Number(this._data?.settings?.workday_as ?? 6) % 7 : wd;
  }

  /** Minuten bis Komfort beginnt bzw. endet, aus den Zeitfenstern (bis zu 7 Tage voraus). */
  _nextSwitch(blocks, room, comfort) {
    const now = new Date();
    const min = now.getHours() * 60 + now.getMinutes();
    for (let k = 0; k < 8; k++) {
      const segs = this._daySegments(blocks, room, this._planDay(k));
      for (const [a, , , c] of segs) {
        if (k === 0 && a <= min) continue;
        if (c !== comfort && a > 0) return k * 1440 + a - min;
        if (c !== comfort && a === 0 && k > 0) return k * 1440 - min;
      }
    }
    return null;
  }

  /** Heutiger Zeitplan als Streifen mit Jetzt-Marke (Raumkarten). */
  _schedStrip(room, s, mini = false) {
    if (room.enabled === false) return "";
    const info = this._schedInfo(room, s);
    const day = this._planDay(0);
    return `
      <div class="rsched ${mini ? "mini" : ""} ${info.comfort ? "on" : ""}">
        <div class="rs-top"><ha-icon icon="${info.icon}"></ha-icon><span class="rs-src">${esc(info.src)}</span><span class="grow"></span><b>${esc(info.text)}</b></div>
        ${info.blocks ? this._dayBar(info.blocks, room, day, true, this._preLead(room, s), this._awayInfo(room), this._todaySegs(s)) : ""}
        ${s?.cause && !mini ? `<div class="rs-why" title="Warum dieser Sollwert"><ha-icon icon="mdi:help-circle-outline"></ha-icon>${esc(s.cause)}</div>` : ""}
        ${info.blocks && !mini && (this._preLead(room, s) || this._awayInfo(room)) ? `<div class="rs-legend">${this._preLead(room, s) && !this._awayInfo(room) ? `<span class="rs-pre"><i></i>Vorheizen ${this._preLead(room, s)} Min. vorher${s?.preheat_mode === "smart" ? " (gelernt)" : ""}</span>` : ""}${this._awayInfo(room) ? `<span class="rs-abs"><i></i>${esc(this._awayInfo(room).text)}</span>` : ""}</div>` : ""}
      </div>`;
  }

  /** Kompakte Raumkachel: Temperatur, Soll, Betriebsart und der heutige Plan. */
  _wrapInd(html) {
    return html.trim() ? `<div class="rm-ind">${html}</div>` : "";
  }

  _roomMini(room) {
    if (!(room.climates || []).length) return this._roomSetup(room, true);
    const s = this._status?.rooms?.[room.id] || {};
    const mode = s.mode || "aus";
    const m = MODE[mode] || MODE.aus;
    const info = room.enabled === false ? null : this._schedInfo(room, s);
    const day = this._planDay(0);
    return `
      <article class="rmini tap ${mode === "aus" ? "off" : ""}" id="room-${room.id}" style="--rc:${this._roomColor(room.id)}; --c:${m.c}" data-action="room-quick" data-id="${room.id}" title="Tippen für manuelle Änderungen">
        <div class="rm-head">
          <span class="rm-ic"><ha-icon icon="${esc(roomIcon(room))}"></ha-icon></span>
          <button class="rm-name rlink" data-action="room-page" data-id="${room.id}" title="Raum öffnen">${esc(room.name)}</button>
          ${this._admin ? `<button class="icon tiny" data-action="room-edit" data-id="${room.id}" title="Bearbeiten"><ha-icon icon="mdi:cog-outline"></ha-icon></button>` : ""}
        </div>
        ${this._wrapInd(`
          ${s.heating ? `<ha-icon class="rm-fire" icon="mdi:fire" title="Heizt"></ha-icon>` : ""}
          ${(() => { const fc = this._fireChip(s); return fc ? `<span class="rm-dev on" style="color:${fc[2]}" title="${esc(fc[3])}"><ha-icon icon="${fc[0]}"></ha-icon>${esc(fc[1])}</span>` : ""; })()}
          ${(() => { const vc = this._ventChip(s); return vc ? `<span class="rm-dev on" style="color:${vc[2]}" title="${esc(vc[3])}"><ha-icon icon="${vc[0]}"></ha-icon>${esc(vc[1])}</span>` : s.windows_open ? `<ha-icon class="rm-win" icon="mdi:window-open-variant" title="Fenster offen"></ha-icon>` : ""; })()}
          ${(() => {
            const dv = this._devIndicators(room);
            return (dv.valve != null ? `<span class="rm-dev ${dv.valve > 0 ? "on" : ""}" title="Ventil ${fmt(dv.valve, 0)} % offen"><ha-icon icon="mdi:valve"></ha-icon>${fmt(dv.valve, 0)}%</span>` : "")
              + (dv.floor?.on ? `<span class="rm-dev on" title="${esc(dv.floor.label)} heizt – ${esc(dv.floor.names)}"><ha-icon icon="mdi:heating-coil"></ha-icon></span>` : "")
              + (s.assist?.on ? `<span class="rm-dev on" title="Heizkörper hilft nach (Mischbetrieb)"><ha-icon icon="mdi:radiator"></ha-icon></span>` : "");
          })()}
        `)}
        <div class="rm-body">
          <span class="rm-temp">${fmt(s.room_temp)}<small>°C</small></span>
          <span class="rm-tgt"><small>Soll</small><b style="color:${tint(tempColor(s.target))}">${fmt(s.target)} °C</b></span>
        </div>
        <div class="rm-mode" title="${esc(s.cause || "")}"><ha-icon icon="${m.i}"></ha-icon>${esc(s.mode_label || "Automatik aus")}${info ? `<span class="grow"></span><small>${esc(info.text)}</small>` : ""}</div>
        ${info?.blocks ? this._dayBar(info.blocks, room, day, true, this._preLead(room, s), this._awayInfo(room), this._todaySegs(s)) : ""}
      </article>`;
  }

  // ------------------------------------------------------------ Heizpläne: gemeinsame Pläne, im Raum auswählbar
  _viewPlans() {
    const rooms = this._rooms();
    const plans = this._planList();
    const P = this._plan;
    const valid = P && (P.kind === "plan" ? !P.id || this._data.plans?.[P.id] : this._data.rooms[P.id]);
    if (!valid) {
      this._plan = null;
      if (plans.length) this._selectPlan("plan", plans[0].id);
      else if (rooms.length) this._selectPlan("room", rooms[0].id);
    }
    const plan = this._plan;
    const dis = this._admin ? "" : "disabled";
    const isOn = (kind, id) => plan && plan.kind === kind && plan.id === id;
    const roomIc = (r) =>
      r.schedule_entity ? "mdi:home-assistant" : this._data.plans?.[r.plan_id] ? "mdi:link-variant" : (r.schedule || []).length ? "mdi:calendar-edit" : "mdi:calendar-blank-outline";
    const pills = `
      <button class="link back" data-action="tab" data-tab="settings"><ha-icon icon="mdi:chevron-left"></ha-icon>Einstellungen</button>
      <section class="card plangroups">
        <div class="pg">
          <span class="pg-l"><ha-icon icon="mdi:calendar-multiple"></ha-icon>Gemeinsame Pläne</span>
          <div class="pills">
            ${plans.map((p) => `<button class="pill ${isOn("plan", p.id) ? "on" : ""}" data-action="plan-sel" data-kind="plan" data-id="${p.id}"><ha-icon icon="${p.calendar ? "mdi:calendar-sync" : "mdi:calendar-clock"}"></ha-icon>${esc(p.name)}<em>${this._planRooms(p.id).length}</em></button>`).join("")}
            ${plan && plan.kind === "plan" && !plan.id ? `<button class="pill on"><ha-icon icon="mdi:calendar-plus"></ha-icon>${esc(plan.name || "Neuer Plan")}</button>` : ""}
            ${this._admin ? `<button class="pill add" data-action="plan-new"><ha-icon icon="mdi:plus"></ha-icon>Neuer Plan</button>` : ""}
          </div>
        </div>
        ${rooms.length ? `
        <div class="pg">
          <span class="pg-l"><ha-icon icon="mdi:floor-plan"></ha-icon>Räume</span>
          <div class="pills">
            ${rooms.map((r) => `<button class="pill ${isOn("room", r.id) ? "on" : ""}" style="--rc:${this._roomColor(r.id)}" data-action="plan-sel" data-kind="room" data-id="${r.id}" title="${esc(this._planLabel(r))}"><i></i>${esc(r.name)}<ha-icon class="pi" icon="${roomIc(r)}"></ha-icon></button>`).join("")}
          </div>
        </div>` : ""}
      </section>`;
    if (!plan) {
      return `${pills}<section class="card empty"><ha-icon icon="mdi:calendar-blank"></ha-icon><h2>Noch keine Heizpläne</h2>
        <p>Lege einen gemeinsamen Plan an und wähle ihn in den Räumen aus – oder lege zuerst einen Raum an.</p>
        ${this._admin ? `<button class="primary" data-action="plan-new"><ha-icon icon="mdi:plus"></ha-icon>Plan anlegen</button>` : ""}</section>`;
    }

    // Raum, der einem Zeitplan/Kalender oder einem gemeinsamen Plan folgt: nur Hinweis, Bearbeiten beim Plan
    if (plan.kind === "room") {
      const room = this._data.rooms[plan.id];
      const select = this._admin ? this._planSelect(room) : "";
      if (room.schedule_entity) {
        const se = this._hass.states[room.schedule_entity];
        const cal = room.schedule_entity.startsWith("calendar.");
        const nextIso = cal ? (se?.state === "off" ? se?.attributes?.start_time : null) : se?.attributes?.next_event;
        const next = nextIso ? new Date(nextIso).toLocaleString("de-DE", { weekday: "short", hour: "2-digit", minute: "2-digit" }) : null;
        return `${pills}
          <section class="card empty">
            <ha-icon icon="${cal ? "mdi:calendar-sync" : "mdi:home-assistant"}"></ha-icon>
            <h2>${esc(room.name)} folgt ${cal ? "einem Kalender" : "einem Zeitplan"} aus Home Assistant</h2>
            <p><b>${esc(this._entityName(room.schedule_entity))}</b> ist gerade <b>${se?.state === "on" ? (cal ? "mit Termin (Komfort)" : "an (Komfort)") : (cal ? "ohne Termin (Eco)" : "aus (Eco)")}</b>${next ? ` · nächster ${cal ? "Termin" : "Wechsel"} ${next}` : ""}.</p>
            ${select}
          </section>`;
      }
      const shared = this._data.plans?.[room.plan_id];
      if (shared) {
        return `${pills}
          <section class="card empty">
            <ha-icon icon="mdi:link-variant"></ha-icon>
            <h2>${esc(room.name)} nutzt den Plan „${esc(shared.name)}“</h2>
            <p>Änderungen am Plan gelten für alle Räume, die ihn nutzen: ${this._planRooms(shared.id).map((r) => esc(r.name)).join(", ")}.</p>
            ${select}
            <div class="row-btns">
              <button class="secondary" data-action="plan-sel" data-kind="plan" data-id="${shared.id}"><ha-icon icon="mdi:calendar-edit"></ha-icon>Plan bearbeiten</button>
              ${this._admin ? `<button class="secondary" data-action="plan-own" data-id="${room.id}"><ha-icon icon="mdi:content-copy"></ha-icon>Eigene Kopie für ${esc(room.name)}</button>` : ""}
            </div>
          </section>`;
      }
    }

    const ref = this._planRef();
    const day = plan.day;
    const using = plan.kind === "plan" && plan.id ? this._planRooms(plan.id) : [];
    const head =
      plan.kind === "plan"
        ? `
        <div class="plan-head">
          <div class="grow">
            ${this._admin ? `<input class="plan-name" type="text" maxlength="60" data-planname value="${esc(plan.name)}" placeholder="Name des Plans">` : `<h2>${esc(plan.name)}</h2>`}
            <div class="muted small">${using.length ? `Genutzt von ${using.map((r) => `<span class="uchip" style="--rc:${this._roomColor(r.id)}"><i></i>${esc(r.name)}</span>`).join(" ")}` : "Noch von keinem Raum genutzt – im Raum unter „Heizplan“ auswählen."}</div>
          </div>
          ${this._admin && plan.id ? `<button class="icon boxed" title="Plan löschen" data-action="plan-delete"><ha-icon icon="mdi:trash-can-outline"></ha-icon></button>` : ""}
        </div>
        <p class="muted small"><ha-icon icon="mdi:information-outline"></ha-icon>Komfort- und Eco-Temperatur kommen vom jeweiligen Raum; ein Zeitfenster kann eine eigene Temperatur haben.</p>`
        : `
        <div class="plan-head">
          <div class="grow"><h2>Eigener Heizplan</h2><div class="muted">${esc(ref.name)} · ${TYPES[ref.type].label}</div></div>
          <div class="plan-temps">
            <span class="tpill" style="--c:${tempColor(ref.comfort)}">Komfort <b>${fmt(ref.comfort)} °C</b></span>
            <span class="tpill" style="--c:#93c5fd">Eco <b>${fmt(ref.eco)} °C</b></span>
          </div>
        </div>
        ${this._admin ? `<div class="row-btns">${this._planSelect(ref)}<button class="link" data-action="plan-promote"><ha-icon icon="mdi:calendar-multiple"></ha-icon>Als gemeinsamen Plan speichern</button></div>` : ""}`;

    // Gemeinsamer Plan: feste Zeitfenster oder live aus einem Kalender
    const src =
      plan.kind === "plan"
        ? `<div class="field"><span><ha-icon icon="mdi:source-branch"></ha-icon> Komfortzeiten kommen aus</span>
            <div class="segs small">${[["times", "Zeitfenster", "mdi:clock-outline"], ["cal", "HA-Kalender (live)", "mdi:calendar-sync"]]
              .map(([v, l, i]) => `<button class="seg ${(plan.cal ? "cal" : "times") === v ? "on" : ""}" data-action="plan-src" data-v="${v}" ${dis}><ha-icon icon="${i}"></ha-icon>${l}</button>`)
              .join("")}</div></div>`
        : "";
    const saveBar = this._admin && plan.dirty ? `
      <div class="savebar">
        <button class="secondary" data-action="plan-revert">Verwerfen</button>
        <button class="primary" data-action="plan-save">Speichern</button>
      </div>` : "";
    if (plan.kind === "plan" && plan.cal) {
      const st = this._status || {};
      const saved = plan.id ? this._data.plans?.[plan.id] : null;
      const fresh = saved && saved.calendar === plan.calendar && (saved.keyword || "") === (plan.keyword || "");
      const events = fresh ? st.plan_events?.[plan.id] || [] : null;
      const err = fresh ? st.plan_errors?.[plan.id] : null;
      const now = new Date();
      const when = (iso) => new Date(iso).toLocaleString("de-DE", { weekday: "short", day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" });
      const hhmm = (iso) => new Date(iso).toLocaleTimeString("de-DE", { hour: "2-digit", minute: "2-digit" });
      return `
        ${pills}
        <section class="card">
          ${head}
          ${src}
          <div class="field"><span><ha-icon icon="mdi:calendar"></ha-icon> Kalender</span>${this._picker("plan_calendar", plan.calendar ? [plan.calendar] : [])}</div>
          <label class="field"><span><ha-icon icon="mdi:text-search"></ha-icon> Nur Termine mit diesen Wörtern (mit Komma getrennt, leer = alle)</span>
            <input type="text" maxlength="200" data-plankw value="${esc(plan.keyword || "")}" placeholder="z. B. Homeoffice, Heizen" ${dis}></label>
          <p class="muted small"><ha-icon icon="mdi:information-outline"></ha-icon>Läuft ein Termin, heizen alle Räume mit diesem Plan auf Komfort, sonst Eco – vor dem nächsten Termin wird vorgeheizt. Ganztägige Termine zählen nicht. Neue oder geänderte Termine übernimmt Heizwerk innerhalb von 5 Minuten.</p>
          ${err ? `<p class="note warn"><ha-icon icon="mdi:alert-outline"></ha-icon>Kalender nicht lesbar: ${esc(err)}</p>` : ""}
          ${events ? `
          <div class="lbl">Nächste Komfortzeiten</div>
          <div class="evlist">${events.length ? events.map((e) => {
            const on = new Date(e.start) <= now;
            return `<div class="ev ${on ? "live" : ""}"><ha-icon icon="${on ? "mdi:fire" : "mdi:calendar-clock"}"></ha-icon>
              <span class="grow"><b>${esc(e.summary || "Termin")}</b><small>${when(e.start)} – ${hhmm(e.end)}</small></span>${on ? `<em class="badge ok">JETZT</em>` : ""}</div>`;
          }).join("") : `<p class="muted small">In den nächsten 8 Tagen kein passender Termin – die Räume bleiben auf Eco.</p>`}</div>`
          : plan.calendar ? `<p class="muted small"><ha-icon icon="mdi:content-save-outline"></ha-icon>Nach dem Speichern zeigt Heizwerk hier die nächsten Termine.</p>` : ""}
        </section>
        ${saveBar}`;
    }

    this._planRefDay = [ref, day];
    this._planConf = planConflicts(plan.blocks);
    const conf = this._planConf;
    return `
      ${pills}
      <section class="card">
        ${head}
        ${src}
        <div class="lbl">Vorschau für Tag${plan.kind === "plan" ? ` <span class="muted small">(mit ${using.length ? esc(ref.name) : "Komfort 21 °C / Eco 18 °C"})</span>` : ""}</div>
        <div class="daypills">
          ${DAYS.map((d, i) => `<button class="dp ${i === day ? "on" : ""}" data-action="plan-preview" data-day="${i}">${d}</button>`).join("")}
        </div>
        <div id="plan-preview">${this._planPreview(plan, ref, day)}</div>
        <p class="muted small plan-rules"><ha-icon icon="mdi:information-outline"></ha-icon>Ohne Zeitfenster gilt automatisch <b>Eco</b> – Lücken muss niemand eintragen. Ein <b>Komfort</b>-Zeitfenster setzt den Komfortwert oder seine eigene Temperatur (nur in diesem Zeitfenster) als Sollwert; geheizt wird nur, wenn es kälter ist. Endet ein Zeitfenster vor seinem Beginn (z. B. 22:00–06:00), läuft es bis zum Folgetag.</p>
      </section>
      ${conf.length ? `<section class="card note warn plan-conf"><ha-icon icon="mdi:alert-outline"></ha-icon><span class="grow"><b>${conf.length === 1 ? "Ein Problem" : `${conf.length} Probleme`} – so lässt sich der Plan nicht speichern</b>${conf.map((c) => `<small>${esc(c.text)}</small>`).join("")}<small>Zeiten anpassen oder beim Zeitfenster „hat Vorrang“ wählen: das andere wird dort gekürzt bzw. geteilt.</small></span></section>` : ""}

      <div class="blocks">
        ${plan.blocks.length ? plan.blocks.map((b, i) => this._blockCard(b, i, ref, dis)).join("") : `<section class="card empty small"><p>Keine Komfortzeiten: ${plan.kind === "plan" ? "Räume mit diesem Plan bleiben" : `${esc(ref.name)} bleibt`} immer auf Eco.</p></section>`}
      </div>

      ${this._admin ? `
      <div class="plan-tools">
        <button class="addbtn" data-action="plan-add"><ha-icon icon="mdi:plus"></ha-icon>Zeitfenster hinzufügen</button>
        <label class="ghost select-link"><ha-icon icon="mdi:file-download-outline"></ha-icon>Vorlage laden
          <select data-action="plan-preset"><option value=""></option>${Object.entries(PLAN_PRESETS).map(([k, p]) => `<option value="${k}">${esc(p.label)}</option>`).join("")}</select>
        </label>
        <button class="ghost" data-action="import-open"><ha-icon icon="mdi:calendar-import"></ha-icon>Aus Kalender importieren</button>
      </div>
      <div class="savebar" id="plan-savebar" ${plan.dirty ? "" : "hidden"}>
        <button class="secondary" data-action="plan-revert">Verwerfen</button>
        <button class="primary" data-action="plan-save" ${conf.length ? "disabled title=\"Erst die Überschneidungen auflösen\"" : ""}>Speichern</button>
      </div>` : ""}`;
  }

  /** Tagesbalken, Legende und Wochenübersicht des Plan-Editors. */
  _planPreview(plan, ref, day) {
    return `
        ${this._dayBar(plan.blocks, ref, day)}
        <div class="muted small legend-line">${["Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag", "Sonntag"][day]}
          <span><i style="background:color-mix(in srgb, #60a5fa 38%, var(--card2))"></i>Eco (ohne Zeitfenster)</span>
          <span><i class="ecow-i"></i>Eco-Zeitfenster</span>
          <span><i style="background:${tempColor(ref.comfort)}"></i>Komfort</span>
          <span><i style="background:linear-gradient(90deg,#fde047,#fb923c)"></i>eigene Temperatur</span>
        </div>
        <div class="week-mini">
          ${DAYS.map((d, i) => `<div class="wm-row"><span>${d}</span>${this._dayBar(plan.blocks, ref, i, true)}</div>`).join("")}
        </div>`;
  }

  /** Nach einer Uhrzeit-Änderung nur Vorschau, Dauer und Speicherleiste anpassen – ohne Neuzeichnen,
   *  damit der Uhrzeit-Wähler am Handy offen bleibt und die Seite nicht springt. */
  _planSoftUpdate(i) {
    const root = this.shadowRoot;
    this._plan.dirty = true;
    const bar = root.getElementById("plan-savebar");
    if (bar) bar.hidden = false;
    const prev = root.getElementById("plan-preview");
    if (prev && this._planRefDay) prev.innerHTML = this._planPreview(this._plan, ...this._planRefDay);
    const b = this._plan.blocks[i];
    const dur = root.querySelector(`.dur[data-i="${i}"]`);
    if (b && dur) {
      let d = hm(b.end) - hm(b.start);
      if (d <= 0) d += 1440;
      dur.textContent = `${Math.floor(d / 60)} h${d % 60 ? ` ${d % 60} min` : ""}${hm(b.end) <= hm(b.start) ? " · bis zum Folgetag" : ""}`;
    }
  }

  /** Räume, die einen gemeinsamen Plan nutzen. */
  _planRooms(planId) {
    return this._rooms().filter((r) => r.plan_id === planId && !r.schedule_entity);
  }

  /** Raum für Vorschau-Farben: der Raum selbst bzw. der erste Raum, der den Plan nutzt. */
  _planRef() {
    const P = this._plan;
    if (P.kind === "room") return this._data.rooms[P.id];
    const first = P.id ? this._planRooms(P.id)[0] : null;
    return first || { name: "Beispiel", type: "heizkoerper", comfort: 21, eco: 18 };
  }

  /** Auswahl, welchem Plan ein Raum folgt (direkt speichern). */
  _planSelect(room) {
    if (room.schedule_entity) {
      return `<button class="secondary" data-action="room-edit" data-id="${room.id}"><ha-icon icon="mdi:calendar-edit"></ha-icon>Im Raum auf einen Heizplan umstellen</button>`;
    }
    return `
      <label class="field inline-sel"><span><ha-icon icon="mdi:calendar-clock"></ha-icon> ${esc(room.name)} folgt</span>
        <select data-action="room-plan" data-id="${room.id}">
          ${this._planList().map((p) => `<option value="${p.id}" ${room.plan_id === p.id ? "selected" : ""}>Plan „${esc(p.name)}“</option>`).join("")}
          <option value="" ${this._data.plans?.[room.plan_id] ? "" : "selected"}>Eigener Plan</option>
        </select>
      </label>`;
  }

  _selectPlan(kind, id) {
    const day = this._plan?.day ?? (new Date().getDay() + 6) % 7;
    const src = kind === "plan" ? this._data.plans?.[id] : this._data.rooms[id];
    this._plan = { kind, id, name: src?.name || "", blocks: clone(src?.schedule || []), dirty: false, day,
      cal: kind === "plan" && !!src?.calendar, calendar: src?.calendar || null, keyword: src?.keyword || "" };
  }
  /** Segmente eines Tages: [start, end, temp, isComfort], lückenlos 0–1440. */
  /** Tagesablauf (0 = Mo): [[Beginn, Ende, Soll, Komfort?, Art, eigene Temperatur?]] – Regeln wie in logic.day_segments. */
  _daySegments(blocks, room, day) {
    const comfort = Number(room.comfort ?? 21), eco = Number(room.eco ?? 18);
    const cuts = new Set([0, 1440]);
    const base = day * 1440;
    for (const [s, e] of planWeek(blocks)) for (const sh of [0, WEEK, -WEEK]) for (const m of [s + sh - base, e + sh - base]) if (m > 0 && m < 1440) cuts.add(m);
    const pts = [...cuts].sort((a, b) => a - b);
    const segs = [];
    for (let k = 0; k < pts.length - 1; k++) {
      const st = planState(blocks, base + pts[k], comfort, eco);
      const last = segs[segs.length - 1];
      if (last && last[2] === st.target && last[4] === st.kind && last[5] === st.custom && last[6] === st.index) last[1] = pts[k + 1];
      else segs.push([pts[k], pts[k + 1], st.target, st.kind === "komfort", st.kind, st.custom, st.index]);
    }
    return segs;
  }

  /** Heutiger Ablauf aus der Steuerung (status.plan_today), damit Kachel und Regelung dasselbe zeigen. */
  _todaySegs(s) {
    return Array.isArray(s?.plan_today) ? s.plan_today.map((x) => [x.start, x.end, x.target, x.kind === "komfort", x.kind, x.custom, x.index]) : null;
  }

  /** Vorlaufzeit fürs Vorheizen in Minuten (wie Heizwerk sie gerade rechnet), 0 = kein Vorheizen. */
  _preLead(room, s) {
    const mode = room.preheat_mode || this._data.settings.preheat_mode || "fixed";
    if (mode === "off" || room.enabled === false) return 0;
    if (s?.preheat_lead) return Number(s.preheat_lead);
    return mode === "fixed" ? Number(room.lead_min ?? this._leadFor(room.type) ?? 0) : 0;
  }

  /** Abwesenheit, wie Heizwerk sie gerade anwendet (nur solange niemand da ist), sonst null. */
  _awayInfo(room) {
    const st = this._status || {};
    if (!st.away || st.vacation || room.enabled === false) return null;
    const set = this._data.settings || {};
    if ((set.away_action || "lower") === "off") return { off: true, text: "Niemand da – Thermostate aus" };
    if ((set.away_mode || "temp") === "offset") {
      const d = Number(set.away_offset ?? 2);
      return { offset: d, text: `Niemand da – ${fmt(d)} °C kühler als geplant` };
    }
    const t = Number(set.away_temp ?? 17);
    return { temp: t, text: `Niemand da – höchstens ${fmt(t)} °C` };
  }

  /** Soll laut Abwesenheit für eine geplante Temperatur (null = Thermostate aus). */
  _awayTemp(away, t) {
    if (away.off) return null;
    return away.offset != null ? t - away.offset : Math.min(away.temp, t);
  }

  _dayBar(blocks, room, day, mini = false, lead = 0, away = null, given = null) {
    const segs = given && day === this._planDay(0) ? given : this._daySegments(blocks, room, day);
    const now = new Date();
    const today = this._planDay(0);
    const nowPct = ((now.getHours() * 60 + now.getMinutes()) / 1440) * 100;
    const t2 = (m) => `${String(Math.floor(m / 60)).padStart(2, "0")}:${String(m % 60).padStart(2, "0")}`;
    const nowMinPre = now.getHours() * 60 + now.getMinutes();
    // Vorheizen: vor jedem Komfort-Beginn, der auf Eco folgt (bei Mitternacht ohne Vortag)
    const pre = lead > 0
      ? segs.map(([st, , t, comfort], i) => (comfort && i > 0 && !segs[i - 1][3] ? [Math.max(segs[i - 1][0], st - lead), st, t] : null)).filter(Boolean)
          .filter(([a]) => !(away && day === today && a >= nowMinPre))
          .map(([a, b, t]) => `<div class="dseg dpre" style="left:${(a / 1440) * 100}%;width:${((b - a) / 1440) * 100}%;--pc:${tempColor(t)}" title="Vorheizen ab ${t2(a)} (${b - a} Min.) für ${fmt(t)} °C um ${t2(b)}"></div>`).join("")
      : "";
    const nowMin = now.getHours() * 60 + now.getMinutes();
    // Abwesend: ab jetzt bis Tagesende, wo der Plan wärmer ist als erlaubt (gestreift grau)
    const awayOn = away && day === today;
    const abs = awayOn
      ? segs.map(([st, e, t]) => [Math.max(st, nowMin), e, t]).filter(([a, e, t]) => e > a && (away.off || this._awayTemp(away, t) < t))
          .map(([a, e, t]) => {
            const at = this._awayTemp(away, t);
            return `<div class="dseg dabs" style="left:${(a / 1440) * 100}%;width:${((e - a) / 1440) * 100}%" title="${t2(a)}–${t2(e)} · Abwesend: ${at == null ? "Thermostate aus" : `${fmt(at)} °C statt ${fmt(t)} °C`} (solange niemand da ist)"></div>`;
          }).join("")
      : "";
    const bar = segs
      .map(
        ([s, e, t, comfort, kind, custom]) =>
          `<div class="dseg ${comfort ? "" : "eco"} ${kind === "eco_window" ? "ecow" : ""}" style="left:${(s / 1440) * 100}%;width:${((e - s) / 1440) * 100}%;background:${tempColor(t)}" title="${t2(s)}–${e === 1440 ? "24:00" : t2(e)} · ${comfort ? (custom ? "Komfort, eigene Temperatur" : "Komfort") : kind === "eco_window" ? "Eco-Zeitfenster" : "Eco (kein Zeitfenster)"} · ${fmt(t)} °C"></div>`
      )
      .join("");
    if (mini) return `<div class="dbar mini">${bar}${pre}${abs}${day === today ? `<div class="now" style="left:${nowPct}%"></div>` : ""}</div>`;
    return `
      <div class="dbar">${bar}${pre}${abs}${day === today ? `<div class="now" style="left:${nowPct}%"></div>` : ""}</div>
      <div class="dscale">${[0, 6, 12, 18, 24].map((h) => `<span>${h}</span>`).join("")}</div>`;
  }

  _blockCard(b, i, room, dis) {
    const days = b.days || [];
    let dur = hm(b.end) - hm(b.start);
    if (dur <= 0) dur += 1440;
    const durTxt = dur > 0 ?`${Math.floor(dur / 60)} h${dur % 60 ? ` ${dur % 60} min` : ""}` : "";
    const bad = (this._planConf || []).filter((c) => c.i === i || c.j === i);
    return `
      <section class="block ${bad.length ? "conflict" : ""} ${b.kind === "eco" ? "ecoblk" : ""}" style="--tc:${b.kind === "eco" ? "#60a5fa" : tempColor(b.temp ?? room.comfort)}">
        <div class="blk-no">Zeitfenster ${i + 1}</div>
        <div class="block-top">
          <div class="times">
            <label class="timebox"><input type="time" value="${esc(b.start)}" data-plan="start" data-i="${i}" ${dis}><ha-icon icon="mdi:clock-outline"></ha-icon></label>
            <span class="muted">bis</span>
            <label class="timebox"><input type="time" value="${esc(b.end)}" data-plan="end" data-i="${i}" ${dis}><ha-icon icon="mdi:clock-outline"></ha-icon></label>
<span class="dur" data-i="${i}">${durTxt}${durTxt && hm(b.end) <= hm(b.start) ? " · bis zum Folgetag" : ""}</span>
          </div>
          <div class="block-temp">
            ${b.kind === "eco" ? `<b class="blk-eco">${room.eco != null ? `${fmt(room.eco)} °C` : "Eco"}</b><span class="tiny muted">Eco-Wert</span>`
              : `${this._admin ? this._stepper("blk", i, b.temp, { placeholder: room.comfort }) : `<b style="color:${tint(tempColor(b.temp ?? room.comfort))}">${fmt(b.temp ?? room.comfort)} °C</b>`}
            ${b.temp != null && this._admin ? `<button class="link tiny" data-action="blk-comfort" data-i="${i}">= Komfortwert</button>` : ""}`}
          </div>
          ${this._admin ? `<button class="icon boxed" title="Entfernen" data-action="plan-del" data-i="${i}"><ha-icon icon="mdi:trash-can-outline"></ha-icon></button>` : ""}
        </div>
        <div class="blk-kind-row">
          <div class="segs small blk-kind">${[["comfort", "Komfort", "mdi:sofa-outline"], ["eco", "Eco", "mdi:leaf"]].map(([v, l, ic]) => `<button class="seg ${(b.kind === "eco" ? "eco" : "comfort") === v ? "on" : ""}" data-action="blk-kind" data-i="${i}" data-v="${v}" ${dis}><ha-icon icon="${ic}"></ha-icon>${l}</button>`).join("")}</div>
          <span class="tiny muted">${b.kind === "eco" ? "ausdrücklich Eco (sonst nicht nötig – Lücken sind Eco)" : b.temp != null ? "eigene Temperatur – gilt nur in diesem Zeitfenster" : "Komfortwert des Raums"}</span>
        </div>
        ${bad.map((c) => `<div class="blk-conf"><ha-icon icon="mdi:alert-circle-outline"></ha-icon><span class="grow">${esc(c.text)}</span>${c.j != null && this._admin ? `<button class="secondary small" data-action="plan-resolve" data-win="${i}">Zeitfenster ${i + 1} hat Vorrang</button>` : ""}</div>`).join("")}
        <div class="lbl">Gilt an (mehrere Tage möglich)</div>
        <div class="daypills">
          ${DAYS.map((d, di) => `<button class="dp ${days.includes(di) ? "on" : ""}" data-action="plan-day" data-i="${i}" data-day="${di}" ${dis}>${d}</button>`).join("")}
        </div>
        ${this._admin ? `
        <div class="quick">
          <button class="link" data-action="plan-days" data-i="${i}" data-set="0,1,2,3,4">Mo–Fr</button>
          <button class="link" data-action="plan-days" data-i="${i}" data-set="5,6">Sa–So</button>
          <button class="link" data-action="plan-days" data-i="${i}" data-set="0,1,2,3,4,5,6">Alle Tage</button>
          <button class="link" data-action="plan-copy" data-i="${i}"><ha-icon icon="mdi:content-copy"></ha-icon>Kopie</button>
        </div>` : ""}
      </section>`;
  }


  // ------------------------------------------------------------ Lichtwerk
  _lwNavHtml() {
    return `<nav class="heatnav">${LW_VIEWS.map((v) => `<button class="hnav ${this._tab === v.id ? "on" : ""}" data-action="tab" data-tab="${v.id}"><ha-icon icon="${v.icon}"></ha-icon><span>${v.name}</span></button>`).join("")}</nav>`;
  }

  /** Lichter mit Einstellung (cfg), Zustand (st) und Status aus Lichtwerk (ls). */
  _lwLights() {
    const lw = this._data.lichtwerk || {};
    const S = this._hass?.states || {};
    const stat = this._lwStatus?.lights || {};
    return (this._data.settings.lw_lights || []).map((id) => ({ id, cfg: lw.lights?.[id] || {}, st: S[id], ls: stat[id] || {} }));
  }

  _lwProfiles() {
    const all = this._data.lichtwerk?.profiles || {};
    return Object.entries(all).map(([id, p]) => ({ id, ...p })).sort((a, b) => (a.id === "standard" ? -1 : b.id === "standard" ? 1 : String(a.name).localeCompare(String(b.name), "de")));
  }

  _lwProfName(pid) {
    const all = this._data.lichtwerk?.profiles || {};
    return (all[pid || "standard"] || all.standard || Object.values(all)[0])?.name || "Standard";
  }

  _lwName(l) {
    return l.cfg?.name || l.ls?.name || this._entityName(l.id);
  }

  /** Farbe der Leuchte für das Symbol: RGB, sonst aus der Farbtemperatur, sonst warmweiß. */
  _lwColor(l) {
    if (l.st?.state !== "on") return "var(--muted)";
    const a = l.st.attributes || {};
    if (Array.isArray(a.rgb_color) && a.color_mode && !["color_temp", "brightness", "onoff"].includes(a.color_mode)) return `rgb(${a.rgb_color.join(",")})`;
    const k = a.color_temp_kelvin;
    if (k) return k < 2600 ? "#fbbf24" : k < 3300 ? "#fcd34d" : k < 4200 ? "#fde68a" : "#e0f2fe";
    return "#facc15";
  }

  _lwPct(l) {
    if (l.st?.state !== "on") return null;
    const b = l.st.attributes?.brightness;
    return b != null ? Math.round(b / 2.55) : 100;
  }

  /** „16:48“ / „morgen 06:12“ für den nächsten Wechsel. */
  _lwWhen(n) {
    if (!n) return "";
    return `${n.day ? "morgen " : ""}${t2(n.min)}`;
  }

  /** Tagesleiste: wann das Licht laut Profil an ist (gelb), Nachtlicht (indigo), Jetzt-Marke. */
  _lwDayBar(l, small = false) {
    const plan = l.ls.plan || [];
    const nw = l.ls.night_window;
    const now = new Date();
    const nowPct = ((now.getHours() * 60 + now.getMinutes()) / 1440) * 100;
    const prof = this._data.lichtwerk?.profiles?.[l.cfg.profile || "standard"] || {};
    const scs = prof.scenes_on ? (prof.scenes || []).filter((x) => x.from).map((x) => ({ ...x, m: hm(x.from) })).sort((a, b) => a.m - b.m) : [];
    // Szene je Minute: letzte begonnene, sonst die letzte vom Vortag
    const sceneAt = (m) => scs.filter((x) => x.m <= m).pop() || scs[scs.length - 1];
    const cuts = scs.map((x) => x.m);
    const segs = plan.flatMap((p) => {
      const tip = `${t2(p.start)}–${p.end >= 1440 ? "24:00" : t2(p.end)} an · ${esc(p.reason || "")}${p.until ? ` · aus: ${esc(p.until)}` : ""}`;
      if (!scs.length) return [`<div class="lwseg" style="left:${(p.start / 1440) * 100}%;width:${((p.end - p.start) / 1440) * 100}%" title="${tip}"></div>`];
      const pts = [p.start, ...cuts.filter((c) => c > p.start && c < p.end), p.end];
      return pts.slice(0, -1).map((a, i) => {
        const sc = sceneAt(a);
        return `<div class="lwseg sc" style="left:${(a / 1440) * 100}%;width:${((pts[i + 1] - a) / 1440) * 100}%;background:${lwKelvinColor(sc.kelvin || (prof.color === "temp" ? prof.kelvin : null))};opacity:${0.35 + 0.65 * ((sc.brightness ?? prof.brightness ?? 80) / 100)}" title="${tip} · ${esc(sc.name || sc.from)} ${sc.brightness ?? prof.brightness ?? 80} %"></div>`;
      });
    }).join("");
    let night = "";
    if (nw) {
      const a = hm(nw[0]), b = hm(nw[1]);
      const parts = a < b ? [[a, b]] : [[a, 1440], [0, b]];
      night = parts.map(([x, y]) => `<div class="lwseg night" style="left:${(x / 1440) * 100}%;width:${((y - x) / 1440) * 100}%" title="Nachtlicht ${nw[0]}–${nw[1]}"></div>`).join("");
    }
    return `<div class="lwbar ${small ? "small" : ""}"><div class="lwtrack"></div>${segs}${night}<div class="now" style="left:${nowPct}%"></div></div>
      ${small ? "" : `<div class="dscale">${[0, 6, 12, 18, 24].map((h) => `<span>${h}</span>`).join("")}</div>`}`;
  }

  /** Lichtwerk-Lage für Kopfkachel und Widget „Lage“. */
  _lwBrief(lights) {
    const s = this._lwStatus || {};
    const on = lights.filter((l) => l.st?.state === "on");
    const manual = lights.filter((l) => l.ls.manual && !l.ls.ccu && l.cfg.auto !== false);
    const hmip = lights.filter((l) => l.ls.ccu);
    const motion = lights.filter((l) => l.ls.motion);
    const bad = lights.filter((l) => !l.st || ["unavailable", "unknown"].includes(l.st.state));
    const act = (l) => `data-action="pop-open" data-pop="lwbri:${esc(l.id)}"`;
    let tone = "ok", icon = "mdi:lightbulb-outline", title;
    const nx = s.next;
    if (s.away && on.length) { tone = "warn"; icon = "mdi:home-alert-outline"; title = `Niemand zu Hause – ${on.length} ${on.length === 1 ? "Licht brennt" : "Lichter brennen"}`; }
    else if (nx) {
      const l = lights.find((x) => x.id === nx.entity_id);
      tone = manual.length ? "hand" : on.length ? "active" : "ok";
      icon = nx.action === "on" ? "mdi:lightbulb-on-outline" : "mdi:lightbulb-off-outline";
      title = `${nx.day ? "Morgen um" : "Um"} ${t2(nx.min)} ${nx.action === "on" ? "an" : "aus"} – ${nx.count > 1 ? `${nx.count} Lichter` : esc(l ? this._lwName(l) : "Licht")} (${nx.reason})`;
    } else {
      tone = on.length ? "active" : "calm";
      icon = on.length ? "mdi:lightbulb-group" : "mdi:weather-night";
      title = on.length ? `${on.length} ${on.length === 1 ? "Licht an" : "Lichter an"} – keine Schaltung geplant` : "Alles aus – keine Schaltung geplant";
    }
    const lines = [];
    for (const l of hmip.slice(0, 2))
      lines.push({ icon: "mdi:link-variant", c: "#0ea5e9", text: `${this._lwName(l)} HmIP an`, act: act(l) });
    for (const l of manual.slice(0, 2))
      lines.push({ icon: "mdi:hand-back-right-outline", c: C.hand, text: `${this._lwName(l)} von Hand ${l.st?.state === "on" ? "an" : "aus"} – Automatik wartet${l.ls.manual.until ? ` bis ${new Date(l.ls.manual.until).toLocaleTimeString("de-DE", { hour: "2-digit", minute: "2-digit" })}` : " bis zum nächsten Wechsel"}`, act: act(l) });
    for (const l of motion.slice(0, 1)) lines.push({ icon: "mdi:motion-sensor", c: C.ok, text: `${this._lwName(l)}: Bewegung`, act: act(l) });
    const night = on.filter((l) => l.ls.night);
    if (night.length) lines.push({ icon: "mdi:weather-night", c: "#6366f1", text: `Nachtlicht: ${night.map((l) => this._lwName(l)).join(", ")}` });
    if (bad.length) lines.push({ icon: "mdi:lightbulb-alert-outline", c: C.alert, text: `${bad.length} nicht erreichbar: ${bad.slice(0, 3).map((l) => this._lwName(l)).join(", ")}` });
    const chips = [["mdi:lightbulb-on-outline", String(on.length), "an", ""], ["mdi:lightbulb-outline", String(lights.length - on.length), "aus", ""],
      ...(manual.length ? [["mdi:hand-back-right-outline", String(manual.length), "von Hand", C.hand]] : []),
      ...(motion.length ? [["mdi:motion-sensor", String(motion.length), "Bewegung", C.ok]] : [])];
    const ids = on.map((l) => l.id).join(",");
    const side = `<span class="br-acts">${this._admin ? `<button class="br-act" data-action="pop-open" data-pop="lwadd" title="Licht hinzufügen"><ha-icon icon="mdi:plus"></ha-icon></button>` : ""}${on.length ? `<button class="br-act" data-action="lw-cmd" data-ids="${ids}" data-a="off" title="Alle aus"><ha-icon icon="mdi:lightbulb-off-outline"></ha-icon><span>Alle aus</span></button>` : ""}</span>`;
    return this._brief({ cls: "card br-mod-lw", tone, icon, label: `<ha-icon icon="mdi:lightbulb-outline"></ha-icon>Lichtwerk · jetzt`, big: `${on.length}<span>/${lights.length} an</span>`, title, side, lines, chips });
  }

  _lwBriefHtml() {
    const lights = this._lwLights();
    return this._data.lichtwerk && lights.length ? this._lwBrief(lights) : "";
  }

  _viewLights() {
    if (!this._data.lichtwerk) return `<section class="card empty"><ha-icon icon="mdi:lightbulb-alert-outline"></ha-icon><h2>Lichtwerk nicht geladen</h2><p>Bitte Home Assistant neu starten.</p></section>`;
    const lights = this._lwLights();
    if (!lights.length)
      return `<section class="card empty"><ha-icon icon="mdi:lightbulb-outline"></ha-icon><h2>Noch keine Lichter</h2>
        <p>Wähle die Lichter, die Lichtwerk schalten soll – nach Sonne, Helligkeit, Uhrzeit, Bewegung oder einer anderen Entität, mit Nachtlicht und dynamischem Licht. Vorbild ist das Blueprint „Smart Light“.</p>
        ${this._admin ? `<button class="primary" data-action="pop-open" data-pop="lwadd"><ha-icon icon="mdi:auto-fix"></ha-icon>Licht hinzufügen</button>` : ""}</section>`;
    const head = this._lwBrief(lights);
    const groups = new Map();
    for (const l of lights) {
      const area = l.ls.area || "Ohne Raum";
      if (!groups.has(area)) groups.set(area, []);
      groups.get(area).push(l);
    }
    const view = this._lwView();
    const compact = view === "compact";
    const tile = (l, areaLabel = "") => {
      const bad = !l.st || ["unavailable", "unknown"].includes(l.st.state);
      const on = l.st?.state === "on";
      const pct = this._lwPct(l);
      const dim = l.id.startsWith("light.") && (l.ls.modes || []).some((m) => m !== "onoff");
      const stTxt = bad ? "nicht erreichbar" : on ? `an${dim && pct != null ? ` · ${pct} %` : ""}` : "aus";
      const flags = [];
      const mot = this._lwMotion(l);
      const ccuMotion = this._lwLinkPeers(l).some((x) => x.name === l.ls.ccu && x.kind === "motion");
      if (l.ls.ccu) flags.push([ccuMotion ? "mdi:motion-sensor" : "mdi:link-variant", "HmIP", "#0ea5e9"]);
      else if (l.ls.manual && l.cfg.auto !== false) flags.push(["mdi:hand-back-right-outline", "von Hand – Automatik wartet", C.hand]);
      if (l.ls.motion) flags.push(["mdi:motion-sensor", "Bewegung", C.ok]);
      if (on && l.ls.night) flags.push(["mdi:weather-night", "Nachtlicht", "#6366f1"]);
      if (on && l.ls.off) flags.push(["mdi:timer-outline", this._lwOffTxt(l.ls.off), C.ok]);
      const hl = l.ls.health || {};
      if (hl.fail) flags.push(["mdi:alert-circle-outline", `schaltet nicht (sollte ${hl.fail.want === "on" ? "an" : "aus"})`, C.alert]);
      if (hl.battery_low) flags.push(["mdi:battery-alert-variant-outline", hl.battery != null ? `Batterie ${hl.battery} %` : "Batterie schwach", C.alert]);
      if (hl.weak) flags.push(["mdi:wifi-strength-1-alert", `Funk schwach${hl.signal != null ? ` · ${hl.signal} dBm` : ""}`, C.sun]);
      const nx = l.ls.next;
      const info = [
        ...(on && l.ls.since ? [["mdi:clock-outline", `an seit ${new Date(l.ls.since).toLocaleTimeString("de-DE", { hour: "2-digit", minute: "2-digit" })}`]] : []),
        ...(nx && l.cfg.auto !== false ? [[nx.action === "on" ? "mdi:lightbulb-on-outline" : "mdi:lightbulb-off-outline", `${nx.action === "on" ? "an" : "aus"} ${this._lwWhen(nx)}`, nx.reason]] : []),
        ...(l.cfg.auto !== false ? [["mdi:tune-variant", this._lwProfName(l.cfg.profile)]] : []),
      ];
      return `
        <article class="card lw-c ${bad ? "bad" : ""} ${on ? "on" : ""}" style="--lc:${this._lwColor(l)}">
          <div class="rw-top">
            <button class="lw-bulb ${on ? "on" : ""}" data-action="lw-cmd" data-ids="${esc(l.id)}" data-a="${on ? "off" : "on"}" title="${on ? "Ausschalten" : "Einschalten"}" ${bad ? "disabled" : ""}><ha-icon icon="${bad ? "mdi:lightbulb-alert-outline" : on ? "mdi:lightbulb-on" : "mdi:lightbulb-outline"}"></ha-icon>${mot ? `<span class="lw-mot" title="Schaltet über Bewegungsmelder: ${esc(mot.join(", "))}"><ha-icon icon="mdi:motion-sensor"></ha-icon></span>` : ""}</button>
            <button class="grow lw-name" data-action="pop-open" data-pop="lwbri:${esc(l.id)}" title="Helligkeit">${areaLabel && areaLabel.toLowerCase() !== this._lwName(l).toLowerCase() ? `<small class="rw-al">${esc(areaLabel)}</small>` : ""}<b>${esc(this._lwName(l))}</b><small>${esc(stTxt)}${l.ls.cause && l.cfg.auto !== false ? ` · ${esc(l.ls.cause)}` : ""}</small></button>
            ${this._admin ? `<button class="icon" data-action="pop-open" data-pop="lwl:${esc(l.id)}" title="Einstellungen dieses Lichts"><ha-icon icon="mdi:cog-outline"></ha-icon></button>` : ""}
          </div>
          ${l.cfg.auto !== false ? `<div class="rw-next">${this._lwDayBar(l, true)}</div>` : ""}
          ${flags.length ? `<div class="rw-flags">${flags.map(([i, t, c]) => `<span style="--c:${c}"><ha-icon icon="${i}"></ha-icon>${t}</span>`).join("")}${l.ls.manual && !l.ls.ccu && l.cfg.auto !== false ? `<button class="link" data-action="lw-cmd" data-ids="${esc(l.id)}" data-a="resume"><ha-icon icon="mdi:robot-outline"></ha-icon>Automatik übernimmt</button>` : ""}</div>` : ""}
          <div class="rw-info">${info.map(([i, t, tt]) => `<span title="${esc(tt || t)}"><ha-icon icon="${i}"></ha-icon>${esc(t)}</span>`).join("")}</div>
          ${dim && !bad ? `<div class="lw-dim"><ha-icon icon="mdi:brightness-6"></ha-icon><div class="lw-meter"><i style="width:${pct ?? 0}%"></i></div><b>${pct != null ? `${pct} %` : "aus"}</b><button class="sbtn" data-action="pop-open" data-pop="lwbri:${esc(l.id)}" title="Helligkeit"><ha-icon icon="mdi:tune-vertical"></ha-icon></button></div>` : ""}
        </article>`;
    };
    const mini = (l) => {
      const bad = !l.st || ["unavailable", "unknown"].includes(l.st.state);
      const on = l.st?.state === "on";
      const pct = this._lwPct(l);
      const mot = this._lwMotion(l);
      const flag = l.ls.ccu ? [this._lwLinkPeers(l).some((x) => x.name === l.ls.ccu && x.kind === "motion") ? "mdi:motion-sensor" : "mdi:link-variant", "#0ea5e9"] : l.cfg.auto === false ? (mot ? ["mdi:motion-sensor", "var(--muted)"] : null) : l.ls.manual ? ["mdi:hand-back-right-outline", C.hand] : l.ls.motion ? ["mdi:motion-sensor", C.ok] : on && l.ls.night ? ["mdi:weather-night", "#6366f1"] : mot ? ["mdi:motion-sensor", "var(--muted)"] : null;
      return `
        <article class="card rw-m lw-m ${bad ? "bad" : ""}" style="--lc:${this._lwColor(l)}" data-action="pop-open" data-pop="lwbri:${esc(l.id)}" role="button" tabindex="0" title="Helligkeit">
          <div class="rwm-top"><b>${esc(this._lwName(l))}</b>${on && l.ls.off?.at ? `<small class="lw-offm"><span data-lw-until="${esc(l.ls.off.at)}">${this._lwLeft(l.ls.off.at)}</span></small>` : ""}${flag ? `<ha-icon icon="${flag[0]}" style="color:${flag[1]}"></ha-icon>` : ""}</div>
          <div class="rwm-pos"><ha-icon class="lw-mi" icon="${bad ? "mdi:lightbulb-alert-outline" : on ? "mdi:lightbulb-on" : "mdi:lightbulb-outline"}"></ha-icon><b>${bad ? "–" : on ? (pct != null && pct < 100 ? `${pct} %` : "an") : "aus"}</b>${l.ls.next && l.cfg.auto !== false ? `<small class="rwm-nx">${this._lwWhen(l.ls.next).replace("morgen ", "")} ${l.ls.next.action === "on" ? "↑" : "↓"}</small>` : ""}</div>
          <div class="rwm-ctl"><button class="sbtn" data-action="lw-cmd" data-ids="${esc(l.id)}" data-a="${on ? "off" : "on"}" ${bad ? "disabled" : ""} title="${on ? "Aus" : "An"}"><ha-icon icon="mdi:power"></ha-icon></button></div>
        </article>`;
    };
    const tog = `<div class="shead outer"><ha-icon icon="mdi:lightbulb-group-outline"></ha-icon><h3>Licht</h3><span class="count">${lights.length}</span><span class="grow"></span>
      <div class="vtog" role="group" aria-label="Ansicht">
        <button class="${view === "detail" || !["compact", "rooms"].includes(view) ? "on" : ""}" data-action="lw-view" data-v="detail" title="Detailliert"><ha-icon icon="mdi:view-agenda-outline"></ha-icon><span>Detailliert</span></button>
        <button class="${compact ? "on" : ""}" data-action="lw-view" data-v="compact" title="Kompakt"><ha-icon icon="mdi:view-grid-outline"></ha-icon><span>Kompakt</span></button>
        <button class="${view === "rooms" ? "on" : ""}" data-action="lw-view" data-v="rooms" title="Räume"><ha-icon icon="mdi:floor-plan"></ha-icon><span>Räume</span></button>
      </div></div>`;
    const sorted = [...groups.entries()].sort((a, b) => (a[0] === "Ohne Raum") - (b[0] === "Ohne Raum") || a[0].localeCompare(b[0], "de"));
    if (view === "rooms") return head + tog + `<div class="rw-grid ${this._tablet ? "tgrid" : ""}">${sorted.map(([area, list]) => this._lwRoomTile(area, list)).join("")}</div>`;
    if (this._tablet && !compact) return head + tog + `<div class="rw-grid tgrid">${sorted.map(([area, list]) => list.map((l) => tile(l, area)).join("")).join("")}</div>`;
    // meist nur ein Licht je Raum: ein gemeinsames Raster, der Raum steht in der Kachel (statt fast leerer Zeilen)
    if (!compact && lights.length / groups.size < 1.6) return head + tog + `<div class="rw-grid">${sorted.map(([area, list]) => list.map((l) => tile(l, area)).join("")).join("")}</div>`;
    return head + tog + sorted.map(([area, list]) => `<div class="rw-area ${compact ? "compact" : ""}"><h3>${esc(area)}</h3><div class="rw-grid ${compact ? "compact" : ""}">${list.map((l) => (compact ? mini(l) : tile(l))).join("")}</div></div>`).join("");
  }

  /** Lichtwerk › Bericht: Vorschläge, Gerätezustand, Brenndauer und Energie der letzten 7 Tage, von Hand. */
  _viewLwRep() {
    const R = this._lwStatus?.report;
    if (!R) return `<section class="card empty"><ha-icon icon="mdi:chart-bar"></ha-icon><h2>Noch kein Bericht</h2><p>Lichtwerk sammelt ab jetzt Brenndauer, Energie und Schaltungen von Hand.</p></section>`;
    const lights = this._lwLights();
    const name = (id) => { const l = lights.find((x) => x.id === id); return l ? this._lwName(l) : this._entityName(id); };
    const rows = Object.entries(R.lights || {}).sort((a, b) => b[1].week_h - a[1].week_h);
    const tot = rows.reduce((a, [, r]) => ({ h: a.h + r.week_h, kwh: a.kwh + (r.kwh || 0), m: a.m + r.manual }), { h: 0, kwh: 0, m: 0 });
    const dayNames = (R.days || []).map((d) => new Date(`${d}T12:00`).toLocaleDateString("de-DE", { weekday: "short" }).slice(0, 2));
    const maxH = Math.max(1, ...rows.flatMap(([, r]) => r.hours));
    const sugg = R.suggestions || [];
    const health = Object.entries(R.health || {}).filter(([, h]) => h.fail || h.battery_low || h.weak);
    const sCard = sugg.length ? `<section class="card"><div class="shead"><ha-icon icon="mdi:lightbulb-question-outline"></ha-icon><h3>Vorschläge</h3></div><div class="evlist">${sugg.map((x) => `<div class="ev"><ha-icon icon="${x.kind === "usage" ? "mdi:motion-sensor" : x.action === "on" ? "mdi:lightbulb-on-outline" : "mdi:lightbulb-off-outline"}" style="color:#6366f1"></ha-icon><span class="grow"><b>${esc(x.text.split(" – ")[0])}</b><small>${esc(x.text.split(" – ")[1] || "")}${x.lights?.length ? ` · ${x.lights.map(name).map(esc).join(", ")}` : ""}</small></span>${this._admin ? `<button class="secondary small" data-action="pop-open" data-pop="lwp:${esc(x.profile)}:${x.kind === "usage" ? "motion" : x.action === "on" ? "on" : "off"}">Profil öffnen</button>` : ""}</div>`).join("")}</div></section>` : "";
    const hCard = health.length ? `<section class="card"><div class="shead"><ha-icon icon="mdi:heart-pulse"></ha-icon><h3>Gerätezustand</h3></div><div class="evlist">${health.map(([id, h]) => `<div class="ev"><ha-icon icon="${h.fail ? "mdi:lightbulb-alert-outline" : h.battery_low ? "mdi:battery-alert-variant-outline" : "mdi:wifi-strength-1-alert"}" style="color:${C.alert}"></ha-icon><span class="grow"><b>${esc(name(id))}</b><small>${[h.fail ? `schaltet nicht – Lichtwerk wollte ${h.fail.want === "on" ? "an" : "aus"} (${new Date(h.fail.at).toLocaleString("de-DE", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" })})` : "", h.battery_low ? `Batterie ${h.battery != null ? `${h.battery} %` : "schwach"}` : "", h.weak ? `Funk schwach${h.signal != null ? ` (${h.signal} dBm)` : ""}` : ""].filter(Boolean).map(esc).join(" · ")}</small></span></div>`).join("")}</div></section>` : "";
    const table = `<section class="card"><div class="shead"><ha-icon icon="mdi:chart-bar"></ha-icon><h3>Letzte 7 Tage</h3><span class="grow"></span><small class="muted">${fmt(tot.h, 1)} Std.${tot.kwh ? ` · ${fmt(tot.kwh, 2)} kWh` : ""} · ${tot.m}× von Hand</small></div>
      <div class="lwrep">${rows.map(([id, r]) => `<div class="lwrep-r">
        <button class="lwrep-n" data-action="pop-open" data-pop="${this._admin ? `lwl:${esc(id)}` : `lwbri:${esc(id)}`}"><b>${esc(name(id))}</b><small>${fmt(r.week_h, 1)} Std. · heute ${fmt(r.today_h, 1)} Std.${r.kwh != null ? ` · ${fmt(r.kwh, 2)} kWh` : r.power ? "" : " · Leistung eintragen"}${r.manual ? ` · ${r.manual}× von Hand` : ""}</small></button>
        <div class="lwrep-b" title="${esc(r.hours.map((h, i) => `${dayNames[i]} ${fmt(h, 1)} Std.`).join(" · "))}">${r.hours.map((h, i) => `<span><i style="height:${Math.max(h > 0 ? 6 : 0, (h / maxH) * 100)}%"></i><small>${dayNames[i]}</small></span>`).join("")}</div></div>`).join("") || `<p class="muted">Noch keine Lichter.</p>`}</div>
      <p class="muted small"><ha-icon icon="mdi:information-outline"></ha-icon>Energie aus der Messung am Gerät oder der eingetragenen Leistung (Leuchte › Einstellungen). „Von Hand“ zählt nur Leuchten mit aktivem Profil; HmIP-Schaltungen zählen nicht.</p></section>`;
    return this._lwBriefHtml() + sCard + hCard + table;
  }

  /** Raumkachel: alle Leuchten eines Raums – alle an/aus, je Leuchte Zeile mit Zustand, HmIP/von Hand, Ablauftimer. */
  _lwRoomTile(area, list) {
    const S = this._hass.states;
    const bad = (l) => !l.st || ["unavailable", "unknown"].includes(l.st.state);
    const on = list.filter((l) => l.st?.state === "on");
    const ok = list.filter((l) => !bad(l));
    const ids = ok.map((l) => l.id).join(",");
    const mot = [...new Set(list.flatMap((l) => this._lwMotion(l) || []))];
    const timers = on.map((l) => l.ls.off?.at).filter(Boolean).sort();
    const profs = [...new Set(list.filter((l) => l.cfg.auto !== false).map((l) => this._lwProfName(l.cfg.profile)))];
    const lead = on[0] || list[0];
    const sub = [`${on.length} von ${list.length} an`, profs.length === 1 ? profs[0] : profs.length > 1 ? `${profs.length} Profile` : "Profil aus"].join(" · ");
    const row = (l) => {
      const o = l.st?.state === "on";
      const pct = this._lwPct(l);
      const dim = l.id.startsWith("light.") && (l.ls.modes || []).some((m) => m !== "onoff");
      const f = [];
      if (l.ls.ccu) f.push(`<ha-icon icon="mdi:link-variant" style="color:#0ea5e9" title="HmIP"></ha-icon>HmIP`);
      else if (l.ls.manual && l.cfg.auto !== false) f.push(`<ha-icon icon="mdi:hand-back-right-outline" style="color:${C.hand}" title="von Hand"></ha-icon>`);
      if (o && l.ls.off?.at) f.push(`<ha-icon icon="mdi:timer-outline" style="color:${C.ok}"></ha-icon><span data-lw-until="${esc(l.ls.off.at)}">${this._lwLeft(l.ls.off.at)}</span>`);
      return `<div class="lwr"><ha-icon icon="${bad(l) ? "mdi:lightbulb-alert-outline" : o ? "mdi:lightbulb-on" : "mdi:lightbulb-outline"}" style="color:${bad(l) ? C.alert : this._lwColor(l)}"></ha-icon>
        <button class="lwr-n" data-action="pop-open" data-pop="lwbri:${esc(l.id)}"><b>${esc(this._lwName(l))}</b><small>${bad(l) ? "nicht erreichbar" : o ? `an${dim && pct != null ? ` · ${pct} %` : ""}` : "aus"}</small></button>
        ${f.length ? `<span class="lwr-f">${f.join("")}</span>` : ""}
        <button class="sbtn" data-action="lw-cmd" data-ids="${esc(l.id)}" data-a="${o ? "off" : "on"}" ${bad(l) ? "disabled" : ""} title="${o ? "Aus" : "An"}"><ha-icon icon="mdi:power"></ha-icon></button></div>`;
    };
    return `
      <article class="card lw-c lw-room ${on.length ? "on" : ""}" style="--lc:${this._lwColor(lead)}" data-area="${esc(area)}">
        <div class="rw-top">
          <button class="lw-bulb ${on.length ? "on" : ""}" data-action="lw-cmd" data-ids="${esc(on.length ? on.map((l) => l.id).join(",") : ids)}" data-a="${on.length ? "off" : "on"}" title="${on.length ? "Alle aus" : "Alle an"}" ${ok.length ? "" : "disabled"}><ha-icon icon="${on.length ? "mdi:lightbulb-group" : "mdi:lightbulb-group-outline"}"></ha-icon>${mot.length ? `<span class="lw-mot" title="Bewegungsmelder: ${esc(mot.join(", "))}"><ha-icon icon="mdi:motion-sensor"></ha-icon></span>` : ""}</button>
          <div class="grow lw-name"><b>${esc(area)}</b><small>${esc(sub)}${timers.length ? ` · aus in <span data-lw-until="${esc(timers[0])}">${this._lwLeft(timers[0])}</span>` : ""}</small></div>
          ${this._admin ? `<button class="icon" data-action="pop-open" data-pop="lwroom:${esc(area)}" title="Profil für den ganzen Raum"><ha-icon icon="mdi:cog-outline"></ha-icon></button>` : ""}
        </div>
        <div class="lwr-list">${list.map(row).join("")}</div>
      </article>`;
  }

  _lwView() {
    try { return localStorage.getItem("hauswerk_lw_view") || "detail"; } catch (e) { return "detail"; }
  }

  /** Einstellungen von Lichtwerk (Liste). */
  _lwRows(p) {
    const lights = this._lwLights();
    const profiles = this._lwProfiles();
    const autos = this._data.lichtwerk?.automations || [];
    const lux = p.lw_lux_sensor ? this._entityName(p.lw_lux_sensor) : "automatisch";
    return [
      { g: "Lichter", id: "lwadd", icon: "mdi:auto-fix", c: "#6366f1", title: "Licht hinzufügen", sum: "Assistent: Lichter wählen, Profil aus Vorlage (Abendlicht, Außenlicht, Flur mit Bewegung …)", words: "assistent neu hinzufügen licht lampe leuchte" },
      ...lights.map((l) => ({ g: "Lichter", id: `lwl:${l.id}`, icon: "mdi:lightbulb-outline", c: l.cfg.auto === false ? "#94a3b8" : "#818cf8", title: this._lwName(l), off: l.cfg.auto === false, offTxt: "PROFIL AUS",
        sum: [`Profil „${this._lwProfName(l.cfg.profile)}“${l.cfg.auto === false ? " (aus)" : ""}`, l.ls.area ? `Raum ${l.ls.area}` : ""].filter(Boolean).join(" · "), words: `${l.id} licht profil` })),
      ...profiles.map((x) => {
        const n = lights.filter((l) => (l.cfg.profile || "standard") === x.id).length;
        return { g: "Profile", id: `lwp:${x.id}:on`, icon: "mdi:tune-variant", c: "#f59e0b", title: `${x.name} · ${n} ${n === 1 ? "Licht" : "Lichter"}`, sum: this._lwProfSum(x), words: `profil ${x.name} sonne helligkeit zeit bewegung nachtlicht` };
      }),
      { g: "Profile", id: "lwp::on", icon: "mdi:plus", c: "#6366f1", title: "Neues Profil", sum: "aus einer Vorlage oder als Kopie von „Standard“ – entspricht einer Smart-Light-Automation", words: "profil neu anlegen vorlage" },
      { g: "Allgemein", id: "lwgeneral", icon: "mdi:brightness-auto", c: "#6366f1", title: "Helligkeit & Hinweise", sum: `Helligkeit: ${lux} · Hinweis, wenn Licht ${p.lw_away_min ?? 30} Min. brennt und niemand da ist`, words: "lux helligkeit sensor abwesend hinweis" },
      ...(this._lwStatus?.links?.available ? [{ g: "Allgemein", id: "lwlinks", icon: "mdi:link-variant", c: (this._lwStatus.links.findings || []).some((f) => f.level === "warn") ? "#f97316" : "#0ea5e9", title: "Homematic-Verknüpfungen",
        sum: (() => { const n = Object.values(this._lwStatus.links.lights || {}).filter((x) => x.peers.length).length; return `${n ? `${n} ${n === 1 ? "Leuchte schaltet" : "Leuchten schalten"} auch direkt in der CCU` : "keine Leuchte direkt verknüpft"}${(this._lwStatus.links.findings || []).length ? ` · ${this._lwStatus.links.findings.length} Hinweis${this._lwStatus.links.findings.length === 1 ? "" : "e"}` : ""}`; })(),
        words: "homematic ccu direktverknüpfung verknüpfung bewegungsmelder taster" }] : []),
      { g: "Allgemein", id: "lwauto", icon: "mdi:robot-confused-outline", c: "#64748b", title: "Bestehende Licht-Automationen", sum: autos.length ? `${autos.filter((a) => a.state === "on").length} von ${autos.length} aktiv – nach der Übernahme abschalten` : "keine gefunden", words: "automation blueprint smart light übernehmen" },
      { g: "Allgemein", act: "lw-log", icon: "mdi:text-box-search-outline", c: "#64748b", title: "Protokoll", sum: "Schaltungen mit Ursache, von Hand und Einstellungs-Änderungen von Lichtwerk", words: "protokoll log" },
      { g: "Allgemein", go: "house", icon: "mdi:home-cog-outline", c: "#94a3b8", title: "Aus Hauswerk übernommen", sum: "Anwesenheit, Urlaub, Arbeitstage-Kalender, Sonnenstand und Benachrichtigungen – gelten für alle Module", words: "anwesenheit urlaub sonne hauswerk" },
    ];
  }

  /** Bewegungsmelder einer Leuchte: aus dem Profil und aus HmIP-Direktverknüpfungen (nicht bei Profil aus). */
  _lwMotion(l) {
    // Profil aus: nur die HmIP-Melder – die schalten in der CCU auch ohne Lichtwerk
    const prof = l.cfg.auto === false ? {} : this._data.lichtwerk?.profiles?.[l.cfg.profile || "standard"] || {};
    const names = [...(prof.motion || []).map((e) => this._entityName(e)), ...(this._lwLinkPeers(l).filter((x) => x.kind === "motion").map((x) => `${x.name} (HmIP)`))];
    return names.length ? [...new Set(names)] : null;
  }

  _lwLeft(iso) {
    const sec = Math.max(0, Math.round((new Date(iso) - Date.now()) / 1000));
    return sec >= 3600 ? `${Math.floor(sec / 3600)}:${String(Math.floor((sec % 3600) / 60)).padStart(2, "0")} h` : `${Math.floor(sec / 60)}:${String(sec % 60).padStart(2, "0")}`;
  }

  /** Ablauftimer: „aus in 0:42“ (läuft live) bzw. „aus 1 Min. nach der letzten Bewegung“. */
  _lwOffTxt(off) {
    if (off.at) return `aus in ${off.src === "HmIP" && !off.learned ? "~" : ""}<span data-lw-until="${esc(off.at)}">${this._lwLeft(off.at)}</span>`;
    const m = off.while >= 60 ? `${fmt(off.while / 60, off.while % 60 ? 1 : 0)} Min.` : `${Math.round(off.while)} s`;
    return `aus ${m} nach der letzten Bewegung`;
  }

  _lwLinkPeers(l) {
    return (l.ls.links || this._lwStatus?.links?.lights?.[l.id])?.peers || [];
  }

  _lwPeer(x) {
    const kt = { motion: "Bewegungsmelder", button: "Taster", other: "Gerät" }[x.kind] || "Gerät";
    return `<span class="hl-p" title="${esc(`${kt} · ${x.model || ""}`)}"><ha-icon icon="${LW_LK[x.kind] || LW_LK.other}"></ha-icon>${esc(x.name)}</span>`;
  }

  /** Abschnitt „Direktverknüpfungen in der CCU“ im Fenster einer Leuchte. */
  _lwLinksBox(eid) {
    const info = this._lwStatus?.links?.lights?.[eid];
    if (!info) return "";
    const f = (this._lwStatus.links.findings || []).filter((x) => x.light === eid);
    return `<div class="lbl">Direktverknüpfungen in der CCU</div>
      <div class="hl-w lw-hl"><span class="hl-ps">${info.peers.length ? info.peers.map((x) => this._lwPeer(x)).join("") : `<em class="hl-none">${info.own ? "nur die eigenen Taster der Leuchte" : "keine – Lichtwerk schaltet allein"}</em>`}</span></div>
      ${info.peers.length ? `<p class="muted small"><ha-icon icon="mdi:information-outline"></ha-icon>Schaltet die Direktverknüpfung diese Leuchte, steht „HmIP“ statt „von Hand“ – Lichtwerk wartet, bis sie wieder aus ist.</p>` : ""}
      ${f.map((x) => `<p class="note ${x.level === "warn" ? "warn" : ""}"><ha-icon icon="mdi:link-variant-off"></ha-icon>${esc(x.text.split(" – ")[1] || x.text)}</p>`).join("")}`;
  }

  _lwProfSum(x) {
    const on = [x.on_sun && `Sonne unter ${fmt(x.sun_on ?? -1, 0)}°`, x.on_lux && `unter ${fmt(x.lux_on ?? 30, 0)} lx`, x.on_time && `um ${x.time_on}`, x.on_entity && x.entity && `${this._entityName(x.entity)} an`, (x.motion || []).length && "Bewegung", x.on_covers && "Rollläden zu"].filter(Boolean);
    const off = [x.off_time && `spätestens ${x.time_off}`, x.off_sun && "Sonnenaufgang", x.off_lux && `über ${fmt(x.lux_off ?? 80, 0)} lx`, x.off_entity && "Entität aus"].filter(Boolean);
    return `${on.length ? `an: ${on.join(" / ")}` : "kein Einschalt-Auslöser"} · ${off.length ? `aus: ${off.join(" / ")}` : "aus von Hand"}${x.night ? ` · Nachtlicht ${x.night_from}–${x.night_to}` : ""}${x.scenes_on && (x.scenes || []).length ? ` · ${x.scenes.length} Tageszeiten` : ""}`;
  }

  /** Fenster von Lichtwerk: Helligkeit, Einstellungen je Licht, Assistent, Allgemein, Automationen. */
  _lwPop(id) {
    const p = this._settings;
    const { sw, minutes } = this._setHelpers(p);
    const dis = this._admin ? "" : "disabled";
    const S = this._hass.states;
    if (id.startsWith("lwbri:")) {
      const eid = id.slice(6);
      const l = this._lwLights().find((x) => x.id === eid) || { id: eid, cfg: {}, st: S[eid], ls: {} };
      const prof = { ...(this._data.lichtwerk?.profiles?.[l.cfg.profile || "standard"] || {}) };
      const pct = this._lwPct(l);
      const d = this._pop.draft;
      if (d.v == null) d.v = pct ?? prof.brightness ?? 80;
      const dim = eid.startsWith("light.") && (l.ls.modes || S[eid]?.attributes?.supported_color_modes || []).some((m) => m !== "onoff");
      const presets = [["off", "Aus", "mdi:lightbulb-off-outline"], ...(prof.night ? [[prof.night_brightness ?? 10, "Nachtlicht", "mdi:weather-night"]] : []), [prof.brightness ?? 80, "Normal", "mdi:lightbulb-outline"], [100, "Hell", "mdi:lightbulb-on"]];
      return {
        icon: "mdi:lightbulb-outline", c: "#6366f1", title: esc(this._lwName(l)), sub: `Lichtwerk · ${l.st?.state === "on" ? `an${pct != null ? ` · ${pct} %` : ""}` : "aus"}`, open: true,
        body: `
          ${l.ls.cause && l.cfg.auto !== false ? `<div class="rq-why"><ha-icon icon="mdi:help-circle-outline"></ha-icon><span><b>Automatik</b><small>${esc(l.ls.cause)}</small>${l.ls.next ? `<small class="muted">Als Nächstes: ${l.ls.next.action === "on" ? "an" : "aus"} ${this._lwWhen(l.ls.next)} (${esc(l.ls.next.reason)})</small>` : ""}</span></div>` : ""}
          ${l.ls.ccu ? `<div class="room-note"><ha-icon icon="mdi:link-variant"></ha-icon>HmIP · ${esc(l.ls.ccu)}${l.cfg.auto !== false ? " – Lichtwerk wartet, bis die Direktverknüpfung ausschaltet" : ""}</div>` : ""}
          ${l.ls.manual && !l.ls.ccu && l.cfg.auto !== false ? `<div class="room-note"><ha-icon icon="mdi:hand-back-right-outline"></ha-icon>Von Hand – Automatik wartet<span class="grow"></span><button class="link" data-action="lw-cmd" data-ids="${esc(eid)}" data-a="resume">Automatik übernimmt</button></div>` : ""}
          ${dim ? `<div class="lw-slider"><input type="range" min="1" max="100" step="1" value="${d.v}" data-lwbri><b id="lwbri-v">${d.v} %</b></div>` : ""}
          <div class="rq-quick lw-pre">${presets.map(([v, t, i]) => `<button class="pill" data-action="lw-pre" data-ids="${esc(eid)}" data-v="${v}"><ha-icon icon="${i}"></ha-icon>${t}${v !== "off" && dim ? ` · ${v} %` : ""}</button>`).join("")}</div>
          
          ${l.cfg.auto !== false ? `<p class="muted small"><ha-icon icon="mdi:information-outline"></ha-icon>Von Hand geschaltet wartet die Automatik ${prof.manual_hold === "hours" ? `${prof.manual_hours ?? 2} Std.` : "bis zum nächsten Wechsel"}.</p>` : ""}`,
        foot: `<button class="secondary" data-action="pop-close">Schließen</button>${dim ? `<button class="primary" data-action="lw-bri-apply" data-ids="${esc(eid)}"><ha-icon icon="mdi:check"></ha-icon>${d.v} % übernehmen</button>` : ""}`,
      };
    }
    if (id.startsWith("lwl:")) {
      const eid = id.slice(4);
      const d = this._pop.draft;
      if (!d.cfg) d.cfg = { profile: "standard", auto: true, name: null, ...(this._data.lichtwerk?.lights?.[eid] || {}) };
      const profs = this._lwProfiles();
      return {
        icon: "mdi:lightbulb-outline", c: "#6366f1", title: esc(this._entityName(eid)), sub: `Lichtwerk · ${esc(eid)}`,
        body: `
          <label class="field"><span><ha-icon icon="mdi:form-textbox"></ha-icon> Name (leer = aus Home Assistant)</span><input type="text" maxlength="40" data-lwl="name" value="${esc(d.cfg.name || "")}" placeholder="${esc(this._entityName(eid))}" ${dis}></label>
          ${(this._lwStatus?.report?.lights?.[eid]?.power_src === "sensor") ? `<p class="muted small"><ha-icon icon="mdi:flash-outline"></ha-icon>Leistung gemessen am Gerät: ${fmt(this._lwStatus.report.lights[eid].power ?? 0, 1)} W</p>`
            : `<label class="field"><span><ha-icon icon="mdi:flash-outline"></ha-icon> Leistung (für den Bericht, leer = nur Brenndauer)</span><div class="unit"><input type="number" min="0" max="5000" step="0.5" data-lwl="watt" value="${d.cfg.watt ?? ""}" placeholder="z. B. 9" ${dis}><i>W</i></div></label>`}
          <label class="field"><span><ha-icon icon="mdi:tune-variant"></ha-icon> Profil</span><select data-lwl="profile" ${dis}>${profs.map((x) => `<option value="${esc(x.id)}" ${(d.cfg.profile || "standard") === x.id ? "selected" : ""}>${esc(x.name)}</option>`).join("")}</select></label>
          ${d.cfg.auto === false ? `<p class="note"><ha-icon icon="mdi:robot-off-outline"></ha-icon>Das Profil ist an dieser Leuchte aus – Lichtwerk zeigt sie nur an.</p>` : ""}
          <p class="muted small">${esc(this._lwProfSum(profs.find((x) => x.id === (d.cfg.profile || "standard")) || {}))} · <button class="link inline" data-action="pop-open" data-pop="lwp:${esc(d.cfg.profile || "standard")}:on">Profil bearbeiten</button></p>
          ${this._lwLinksBox(eid)}
          <div class="wxrows">${this._setRow("lwauto1", "Profil aktiv", "Lichtwerk schaltet diese Leuchte nach dem Profil", `<label class="switch"><input type="checkbox" data-lwl="auto" ${d.cfg.auto !== false ? "checked" : ""} ${dis}><span></span></label>`, "Aus: Das Profil gilt für diese Leuchte nicht – Lichtwerk zeigt sie nur an und schaltet sie nicht (z. B. im Sommer, bei Besuch oder zum Ausprobieren). Profil und Einstellungen bleiben erhalten; einschalten geht auch direkt an der Kachel. Andere Leuchten mit demselben Profil laufen weiter.")}</div>`,
        foot: `${this._admin ? `<button class="icon boxed danger" data-action="lwl-remove" data-id="${esc(eid)}" title="Aus Lichtwerk entfernen"><ha-icon icon="mdi:delete-outline"></ha-icon></button>` : ""}
          <button class="secondary" data-action="pop-close">${this._admin ? "Abbrechen" : "Schließen"}</button>
          ${this._admin ? `<button class="primary" data-action="lwl-save" data-id="${esc(eid)}"><ha-icon icon="mdi:content-save-outline"></ha-icon>Speichern</button>` : ""}`,
      };
    }
    if (id.startsWith("lwroom:")) {
      const area = id.slice(7);
      const list = this._lwLights().filter((l) => (l.ls.area || "Ohne Raum") === area);
      const d = this._pop.draft;
      if (!d.ids) {
        const profs = [...new Set(list.map((l) => l.cfg.profile || "standard"))];
        Object.assign(d, { ids: list.map((l) => l.id), profile: profs[0] || "standard", auto: list.some((l) => l.cfg.auto !== false) });
      }
      const profs = this._lwProfiles();
      const mixed = new Set(list.map((l) => l.cfg.profile || "standard")).size > 1;
      return {
        icon: "mdi:floor-plan", c: "#6366f1", title: esc(area), sub: `Lichtwerk · ${list.length} ${list.length === 1 ? "Leuchte" : "Leuchten"}`,
        body: `
          <p class="muted small">Ein Profil für alle Leuchten des Raums – z. B. Wand und Decke im Windfang gemeinsam. Einzelne Leuchten lassen sich danach weiter unter ihren Einstellungen ändern.</p>
          ${mixed ? `<p class="note"><ha-icon icon="mdi:information-outline"></ha-icon>Bisher unterschiedliche Profile: ${list.map((l) => `${esc(this._lwName(l))} – ${esc(this._lwProfName(l.cfg.profile))}`).join(", ")}</p>` : ""}
          <label class="field"><span><ha-icon icon="mdi:tune-variant"></ha-icon> Profil für alle</span><select data-lwroom="profile">${profs.map((x) => `<option value="${esc(x.id)}" ${d.profile === x.id ? "selected" : ""}>${esc(x.name)}</option>`).join("")}</select></label>
          <p class="muted small">${esc(this._lwProfSum(profs.find((x) => x.id === d.profile) || {}))}</p>
          <div class="wxrows">${this._setRow("lwroom_auto", "Profil aktiv", "für alle Leuchten des Raums", `<label class="switch"><input type="checkbox" data-lwroom="auto" ${d.auto ? "checked" : ""}><span></span></label>`, "Aus: Lichtwerk schaltet die Leuchten dieses Raums nicht – HmIP-Direktverknüpfungen der CCU schalten weiter.")}</div>`,
        foot: `<button class="secondary" data-action="pop-close">Abbrechen</button><button class="primary" data-action="lw-room-save"><ha-icon icon="mdi:content-save-outline"></ha-icon>Für ${list.length} ${list.length === 1 ? "Leuchte" : "Leuchten"} speichern</button>`,
      };
    }
    if (id === "lwlinks") {
      const L = this._lwStatus?.links || {};
      const rows = this._lwLights().filter((l) => L.lights?.[l.id]).sort((a, b) => (L.lights[b.id].peers.length - L.lights[a.id].peers.length) || this._lwName(a).localeCompare(this._lwName(b), "de"));
      return {
        icon: "mdi:link-variant", c: "#0ea5e9", title: "Homematic-Verknüpfungen", sub: `Lichtwerk · Direktverknüpfungen aus der CCU${L.at ? ` · gelesen ${new Date(L.at).toLocaleString("de-DE", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" })}` : ""}`,
        body: `
          <p class="muted small">Was die CCU direkt verknüpft hat (Bewegungsmelder, Taster), schaltet ohne Home Assistant. Lichtwerk liest das (nur lesen, alle 6 Stunden): Schaltet die CCU eine Leuchte, gilt das nicht als „von Hand“ – Lichtwerk wartet, bis die CCU sie wieder ausschaltet. Meldet ein Profil denselben Bewegungsmelder, würde doppelt geschaltet.</p>
          ${L.error ? `<p class="note warn"><ha-icon icon="mdi:alert-outline"></ha-icon>${esc(L.error)}</p>` : ""}
          ${(L.findings || []).length ? `<div class="lbl">Hinweise</div><div class="evlist">${L.findings.map((f) => `<div class="ev"><ha-icon icon="mdi:link-variant-off" style="color:${f.level === "warn" ? "#f97316" : "#0ea5e9"}"></ha-icon><span class="grow"><b>${esc(f.text.split(" – ")[0])}</b><small>${esc(f.text.split(" – ")[1] || "")}</small></span></div>`).join("")}</div>` : ""}
          <div class="lbl">Je Leuchte</div>
          <div class="hl-list">${rows.map((l) => `<div class="hl-room"><div class="hl-w"><span class="hl-wn"><ha-icon icon="mdi:lightbulb-outline"></ha-icon>${esc(this._lwName(l))}</span><ha-icon class="hl-arrow" icon="mdi:arrow-left"></ha-icon><span class="hl-ps">${L.lights[l.id].peers.length ? L.lights[l.id].peers.map((x) => this._lwPeer(x)).join("") : `<em class="hl-none">${L.lights[l.id].own ? "nur eigene Taster" : "keine Verknüpfung"}</em>`}</span></div></div>`).join("") || `<p class="muted">Keine Homematic-Leuchte in Lichtwerk – oder noch nichts gelesen.</p>`}</div>`,
        foot: `<button class="secondary" data-action="pop-close">Schließen</button>${this._admin ? `<button class="primary" data-action="lwlinks-refresh"><ha-icon icon="mdi:refresh"></ha-icon>Neu lesen</button>` : ""}`,
      };
    }
    if (id === "lwadd") {
      const d = this._pop.draft;
      d.pick = d.pick || [];
      const have = new Set(this._data.settings.lw_lights || []);
      const ids = Object.keys(S).filter((e) => /^(light|switch|input_boolean)\./.test(e) && !have.has(e) && (e.startsWith("light.") || /licht|lampe|leuchte|light|lamp/.test(`${e} ${S[e].attributes?.friendly_name || ""}`.toLowerCase())));
      const byArea = new Map();
      for (const e of ids) {
        const a = this._areaOf(e) || "Ohne Raum";
        if (!byArea.has(a)) byArea.set(a, []);
        byArea.get(a).push(e);
      }
      const chip = (e) => { const on = d.pick.includes(e); const bad = ["unavailable", "unknown"].includes(S[e]?.state); return `<button class="pchip ${on ? "on" : ""}" data-action="lwadd-tog" data-id="${esc(e)}" aria-pressed="${on}"><i></i>${esc(this._entityName(e))}${bad ? " · nicht erreichbar" : ""}</button>`; };
      const profs = this._lwProfiles();
      if (!d.prof) d.prof = profs[0]?.id || "standard";
      return {
        icon: "mdi:auto-fix", c: "#6366f1", title: "Licht hinzufügen", sub: "Lichtwerk · wie eine Smart-Light-Automation je Profil",
        body: `
          <div class="lbl">1 · Welche Lichter?</div>
          ${[...byArea.entries()].sort((a, b) => (a[0] === "Ohne Raum") - (b[0] === "Ohne Raum") || a[0].localeCompare(b[0], "de")).map(([a, list]) => `<div class="chg"><small>${esc(a)}</small><div class="pchips">${list.map(chip).join("")}</div></div>`).join("") || `<p class="muted">Alle Lichter sind schon in Lichtwerk.</p>`}
          <div class="lbl">2 · Profil</div>
          <div class="pchips">${profs.map((x) => `<button class="pchip ${d.prof === x.id ? "on" : ""}" data-action="lwadd-prof" data-v="${esc(x.id)}"><i></i>${esc(x.name)}</button>`).join("")}</div>
          <div class="lbl">… oder neues Profil aus Vorlage</div>
          <div class="lw-presets">${Object.entries(LW_PRESETS).map(([k, x]) => `<button class="lw-preset ${d.prof === `new:${k}` ? "on" : ""}" data-action="lwadd-prof" data-v="new:${k}"><ha-icon icon="${x.icon}"></ha-icon><span><b>${x.name}</b><small>${x.text}</small></span></button>`).join("")}</div>`,
        foot: `<button class="secondary" data-action="pop-close">Abbrechen</button><button class="primary" data-action="lwadd-save" ${d.pick.length ? "" : "disabled"}><ha-icon icon="mdi:plus"></ha-icon>${d.pick.length || ""} hinzufügen</button>`,
      };
    }
    if (id === "lwgeneral") {
      const luxIds = Object.keys(S).filter((e) => e.startsWith("sensor.") && S[e].attributes?.device_class === "illuminance");
      return {
        icon: "mdi:brightness-auto", c: "#6366f1", title: "Helligkeit & Hinweise", sub: "Lichtwerk · gilt für alle Profile",
        body: `
          <label class="field"><span><ha-icon icon="mdi:brightness-5"></ha-icon> Helligkeit draußen (für „unter … lx“)</span><select data-set="lw_lux_sensor" ${dis}><option value="">automatisch (erster Lux-Sensor)</option>${luxIds.map((e) => `<option value="${esc(e)}" ${p.lw_lux_sensor === e ? "selected" : ""}>${esc(this._entityName(e))} · ${esc(S[e].state)} lx</option>`).join("")}</select></label>
          <p class="muted small">Je Profil lässt sich ein eigener Sensor wählen (z. B. im Raum). Sonnenstand, Anwesenheit, Urlaub und Arbeitstage kommen aus Hauswerk.</p>
          <label class="field narrow"><span><ha-icon icon="mdi:home-alert-outline"></ha-icon> Hinweis, wenn Licht brennt und niemand zu Hause ist, nach</span>${minutes("lw_away_min", 30, 5, 720, 5)}</label>
          <p class="muted small">Benachrichtigung „Licht an, niemand zu Hause“ und „Leuchte nicht erreichbar“ einstellen unter <button class="link inline" data-action="pop-open" data-pop="notify">Hauswerk › Benachrichtigungen</button>.</p>`,
      };
    }
    if (id === "lwauto") {
      const autos = this._data.lichtwerk?.automations || [];
      return {
        icon: "mdi:robot-confused-outline", c: "#64748b", title: "Bestehende Licht-Automationen", sub: "Lichtwerk · nach der Übernahme abschalten",
        body: `<p class="muted small">Automationen, die vermutlich Licht schalten (nach dem Namen). Ist das Licht in Lichtwerk eingerichtet, sollten sie aus sein – sonst schalten zwei Stellen dasselbe Licht. Abschalten heißt nicht löschen: in Home Assistant jederzeit wieder einschaltbar.</p>
          <div class="evlist">${autos.map((a) => `<div class="ev"><ha-icon icon="${a.state === "on" ? "mdi:robot-outline" : "mdi:robot-off-outline"}"></ha-icon><span class="grow"><b>${esc(a.name)}</b><small>${a.state === "on" ? "aktiv" : "aus"} · ${esc(a.entity_id)}</small></span>${a.state === "on" && this._admin ? `<button class="secondary small" data-action="lw-auto-off" data-id="${esc(a.entity_id)}">Abschalten</button>` : ""}</div>`).join("") || `<p class="muted">Keine gefunden.</p>`}</div>`,
      };
    }
    return null;
  }

  /** Profil-Editor (eine Smart-Light-Automation). */
  _lwpPop(pid, sec) {
    const d = this._pop.draft;
    const profiles = this._data.lichtwerk?.profiles || {};
    if (!d.prof) {
      d.pid = pid || null;
      d.prof = clone(profiles[pid] || { ...(profiles.standard || Object.values(profiles)[0] || {}), name: "Neues Profil" });
    }
    const p = d.prof;
    const dis = this._admin ? "" : "disabled";
    const S = this._hass.states;
    const row = (k, title, sub, ctl, text) => (text ? this._setRow(`lwp_${k}`, title, sub, ctl, text, true)
      : `<div class="wxr ctl"><div class="wxr-l"><b>${title}</b>${sub ? `<small>${sub}</small>` : ""}</div><div class="wxr-v">${ctl}</div></div>`);
    const num = (k, def, min, max, step, unit) => `<div class="unit"><input type="number" min="${min}" max="${max}" step="${step}" data-lwp="${k}" data-kind="num" value="${p[k] ?? ""}" placeholder="${def}" ${dis}><i>${unit}</i></div>`;
    const time = (k, def) => `<input type="time" data-lwp="${k}" data-kind="time" value="${esc(p[k] || def)}" ${dis}>`;
    const bool = (k, def = false) => `<label class="switch"><input type="checkbox" data-lwp="${k}" data-kind="bool" ${(p[k] ?? def) ? "checked" : ""} ${dis}><span></span></label>`;
    const choice = (k, opts, def) => `<div class="segs small">${opts.map(([v, l, i]) => `<button class="seg ${String(p[k] ?? def) === String(v) ? "on" : ""}" data-action="lwp-set" data-k="${k}" data-v="${v}" ${dis}>${i ? `<ha-icon icon="${i}"></ha-icon>` : ""}${l}</button>`).join("")}</div>`;
    const ent = (k, test, none = "keine") => {
      const ids = Object.keys(S).filter((e) => test(e, S[e].attributes || {}) || e === p[k]).sort((a, b) => this._entityName(a).localeCompare(this._entityName(b), "de"));
      return `<select class="rwsel" data-lwp="${k}" data-kind="entity" ${dis}><option value="">${none}</option>${ids.map((e) => `<option value="${esc(e)}" ${p[k] === e ? "selected" : ""}>${esc(this._entityName(e))}</option>`).join("")}</select>`;
    };
    const note = (t, icon = "mdi:information-outline") => `<p class="muted small"><ha-icon icon="${icon}"></ha-icon>${t}</p>`;
    const stage = (icon, title, k, inner, def = false) => `<div class="rwstage"><div class="rwstage-h"><ha-icon icon="${icon}"></ha-icon><b>${title}</b>${bool(k, def)}</div>${(p[k] ?? def) ? inner : ""}</div>`;
    const elev = this._lwStatus?.elevation;
    let body = "";
    switch (sec) {
      case "on":
        body = `${note("Wie im Blueprint „Smart Light“: ein Auslöser schaltet beim <b>Wechsel</b> ein – danach bleibt das Licht an, bis ein Ausschalt-Auslöser kommt. Mehrere Auslöser = jeder schaltet ein.", "mdi:lightbulb-on-outline")}
          ${stage("mdi:weather-sunset-down", "Sonne sinkt", "on_sun", `<div class="wxrows">${row("so", "unter", `Sonnenhöhe abends${elev != null ? ` · jetzt ${fmt(elev, 1)}°` : ""}`, num("sun_on", -1, -18, 30, 0.5, "°"), "0° = Sonnenuntergang, −6° = Ende der Dämmerung. Positive Werte schalten früher, z. B. 3° für dunkle Räume.")}</div>`, true)}
          ${stage("mdi:brightness-4", "Helligkeit fällt", "on_lux", `<div class="wxrows">${row("lo", "unter", "", num("lux_on", 30, 0, 100000, 5, "lx"))}${row("ls", "Sensor", "leer = allgemeiner Sensor", ent("lux_sensor", (e, a) => e.startsWith("sensor.") && a.device_class === "illuminance", "allgemein"))}</div>`)}
          ${stage("mdi:clock-outline", "Uhrzeit", "on_time", `<div class="wxrows">${row("to", "um", "", time("time_on", "17:00"))}</div>`)}
          ${stage("mdi:toggle-switch-outline", "Entität geht an", "on_entity", `<div class="wxrows">${row("en", "Entität", "z. B. Fernseher, Schalter, Tür", ent("entity", (e) => /^(binary_sensor|switch|input_boolean|media_player|light|remote|person|device_tracker)\./.test(e), "wählen"))}</div>`)}
          ${stage("mdi:window-shutter", "Rollläden schließen", "on_covers", note("An, sobald abends alle Rollläden im selben Bereich wie das Licht zu sind (Rollwerk oder von Hand)."))}`;
        break;
      case "off":
        body = `${stage("mdi:clock-end", "Spätestens um", "off_time", `<div class="wxrows">${row("tf", "Uhrzeit", "", time("time_off", "23:00"))}</div>`, true)}
          ${stage("mdi:weather-sunset-up", "Sonne steigt", "off_sun", `<div class="wxrows">${row("sf", "über", "Sonnenhöhe morgens", num("sun_off", 1, -18, 30, 0.5, "°"))}</div>`, true)}
          ${stage("mdi:brightness-7", "Helligkeit steigt", "off_lux", `<div class="wxrows">${row("lf", "über", "", num("lux_off", 80, 0, 100000, 5, "lx"), "Etwas über dem Einschaltwert, sonst schaltet das Licht seinen eigenen Sensor aus.")}</div>`)}
          ${stage("mdi:toggle-switch-off-outline", "Entität geht aus", "off_entity", p.entity ? note(`${esc(this._entityName(p.entity))} – unter Einschalten gewählt`) : note("Erst unter „Einschalten“ eine Entität wählen."))}`;
        break;
      case "motion": {
        const sensors = Object.keys(S).filter((e) => e.startsWith("binary_sensor.") && ["motion", "occupancy", "presence"].includes(S[e].attributes?.device_class));
        body = `${note("Wie „Sensor Light“: Bewegung schaltet an, nach der Wartezeit ohne Bewegung wieder aus – zusätzlich zu den festen Auslösern.", "mdi:motion-sensor")}
          <div class="pchips">${sensors.map((e) => { const on = (p.motion || []).includes(e); return `<button class="pchip ${on ? "on" : ""}" data-action="lwp-tog" data-k="motion" data-v="${esc(e)}" ${dis}><i></i>${esc(this._entityName(e))}</button>`; }).join("") || `<span class="muted small">Kein Bewegungs- oder Anwesenheitsmelder gefunden</span>`}</div>
          ${(p.motion || []).length ? `<div class="wxrows">${row("mo", "Aus nach", "ohne Bewegung", num("motion_off", 3, 0.5, 240, 0.5, "Min."))}${row("md", "Nur wenn dunkel", "Sonne bzw. Helligkeit wie unter Einschalten", bool("motion_dark", true))}</div>` : ""}`;
        break;
      }
      case "days":
        body = `<div class="lbl">Wochentage</div><div class="daypills">${DAYS.map((x, i) => `<button class="dp ${(p.days ?? [0, 1, 2, 3, 4, 5, 6]).includes(i) ? "on" : ""}" data-action="lwp-tog" data-k="days" data-v="${i}" ${dis}>${x}</button>`).join("")}</div>
          <div class="lbl">Arbeitstage-Kalender (Hauswerk)</div>${choice("day_mode", [["all", "Alle Tage"], ["workday", "Nur Arbeitstage"], ["free", "Nur freie Tage"]], "all")}
          ${note("An nicht gewählten Tagen schaltet das Profil nicht ein – ausgeschaltet wird trotzdem.")}`;
        break;
      case "light":
        body = `<div class="wxrows">${row("br", "Helligkeit", "", num("brightness", 80, 1, 100, 1, "%"))}${row("tn", "Übergang an", "nur Leuchten, die es können", num("transition_on", 1, 0, 300, 0.5, "s"))}${row("tf2", "Übergang aus", "", num("transition_off", 2, 0, 300, 0.5, "s"))}</div>
          <div class="lbl">Farbe</div>${choice("color", [["keep", "Wie eingestellt"], ["temp", "Farbtemperatur", "mdi:thermometer"], ["rgb", "Farbe", "mdi:palette"]], "keep")}
          ${p.color === "temp" ? `<div class="wxrows">${row("kv", "Farbtemperatur", "2200 warm … 6500 kalt", num("kelvin", 2700, 2000, 6500, 100, "K"))}</div>` : ""}
          ${p.color === "rgb" ? `<label class="field narrow"><span>Farbe</span><input type="color" data-lwp="rgb" data-kind="text" value="${esc(p.rgb || "#ffb464")}" ${dis}></label>` : ""}`;
        break;
      case "scenes": {
        const sc = p.scenes || [];
        const inner = `<div class="lwsc-list">${sc.map((x, i) => `<div class="lwsc">
            <input type="time" data-lwsc="${i}:from" value="${esc(x.from || "")}" ${dis} aria-label="ab">
            <input type="text" data-lwsc="${i}:name" value="${esc(x.name || "")}" maxlength="30" placeholder="Name" ${dis}>
            <div class="unit"><input type="number" min="1" max="100" step="1" data-lwsc="${i}:brightness" value="${x.brightness ?? ""}" placeholder="${p.brightness ?? 80}" ${dis}><i>%</i></div>
            <div class="unit"><input type="number" min="2000" max="6500" step="100" data-lwsc="${i}:kelvin" value="${x.kelvin ?? ""}" placeholder="Farbe" ${dis}><i>K</i></div>
            <i class="lwsc-dot" style="background:${lwKelvinColor(x.kelvin)};opacity:${0.35 + 0.65 * ((x.brightness ?? 80) / 100)}"></i>
            ${this._admin ? `<button class="icon" data-action="lwsc-del" data-i="${i}" title="Entfernen"><ha-icon icon="mdi:close"></ha-icon></button>` : ""}</div>`).join("")}</div>
          ${this._admin ? `<div class="rq-quick"><button class="pill" data-action="lwsc-add" ${sc.length >= 8 ? "disabled" : ""}><ha-icon icon="mdi:plus"></ha-icon>Tageszeit</button>${sc.length ? "" : `<button class="pill" data-action="lwsc-preset"><ha-icon icon="mdi:auto-fix"></ha-icon>Morgen · Tag · Abend · Nacht</button>`}</div>` : ""}
          ${note("Ab der Uhrzeit gilt die Szene bis zur nächsten (über Mitternacht weiter). Leere Farbe = wie unter „Licht“. Brennt das Licht beim Wechsel, wird übergeblendet. Nachtlicht hat Vorrang.")}`;
        body = `${note("Je Tageszeit eigene Helligkeit und Lichtfarbe – z. B. morgens kühl und hell, abends warm und gedimmt. Ersetzt „Licht“ und „Dynamisch“, solange eingeschaltet.", "mdi:clock-time-four-outline")}
          ${stage("mdi:clock-time-four-outline", "Szenen nach Tageszeit", "scenes_on", inner)}
          ${!p.scenes_on && this._admin ? `<div class="rq-quick"><button class="pill" data-action="lwsc-preset"><ha-icon icon="mdi:auto-fix"></ha-icon>${sc.length ? "Einschalten mit Vorlage Morgen · Tag · Abend · Nacht" : "Morgen · Tag · Abend · Nacht"}</button></div>` : ""}`;
        break;
      }
      case "dyn":
        body = `${note("Helligkeit und Farbtemperatur passen sich an: nach der Sonnenhöhe (abends wärmer und gedimmt) oder nach der Helligkeit draußen.", "mdi:theme-light-dark")}
          ${choice("dynamic", [["off", "Aus"], ["sun", "Nach Sonne", "mdi:white-balance-sunny"], ["lux", "Nach Helligkeit", "mdi:brightness-5"]], "off")}
          ${(p.dynamic || "off") !== "off" ? `<div class="wxrows">${row("dl", "Helligkeit von", "", num("dyn_min", 35, 1, 100, 1, "%"))}${row("dh", "bis", "", num("dyn_max", 100, 1, 100, 1, "%"))}${row("dw", "warm", "", num("dyn_warm", 2200, 2000, 6500, 100, "K"))}${row("dc", "kalt", "", num("dyn_cold", 4000, 2000, 6500, 100, "K"))}</div>` : ""}`;
        break;
      case "night":
        body = `${stage("mdi:weather-night", "Nachtlicht", "night", `<div class="wxrows">${row("nf", "von", "", time("night_from", "22:30"))}${row("nt", "bis", "", time("night_to", "06:00"))}${row("nb", "Helligkeit", "", num("night_brightness", 10, 1, 100, 1, "%"))}${row("nk", "Farbtemperatur", "wenn Farbe gewählt", num("night_kelvin", 2200, 2000, 6500, 100, "K"))}${row("na", "Bei Wechsel anpassen", "brennt das Licht schon, wird übergeblendet", bool("night_adjust", true))}</div>`)}
          ${note("Im Nachtlicht-Zeitraum geht das Licht gedimmt an – ideal mit Bewegung im Flur.")}`;
        break;
      case "more":
        body = `<div class="lbl">Von Hand geschaltet</div>${choice("manual_hold", [["next", "bis zum nächsten Wechsel"], ["hours", "für eine Zeit"]], "next")}
          ${p.manual_hold === "hours" ? `<div class="wxrows">${row("mh", "Dauer", "", num("manual_hours", 2, 0.25, 48, 0.25, "Std."))}</div>` : ""}
          <div class="lbl">Pause-Schalter (Bypass)</div><div class="wxrows">${row("bp", "Schalter", "an = Lichtwerk pausiert", ent("bypass", (e) => /^(input_boolean|switch|binary_sensor)\./.test(e), "keiner"))}</div>
          ${p.bypass ? choice("bypass_action", [["keep", "so lassen"], ["on", "Licht an"], ["off", "Licht aus"]], "keep") : ""}
          <div class="lbl">Niemand zu Hause</div>${choice("away", [["off", "Licht aus"], ["keep", "wie geplant"]], "off")}
          <div class="wxrows">${row("sim", "Urlaub: Anwesenheit vortäuschen", "Zeiten zufällig ±30 Min., schaltet trotz Abwesenheit", bool("simulate"))}</div>`;
        break;
    }
    const meta = LW_SECTIONS.find(([x]) => x === sec) || LW_SECTIONS[0];
    const isNew = !d.pid;
    const users = Object.entries(this._data.lichtwerk?.lights || {}).filter(([, c]) => (c.profile || "standard") === (d.pid || "")).map(([id]) => this._entityName(id));
    return {
      icon: meta[2], c: "#6366f1", title: isNew ? "Neues Profil" : esc(p.name || ""), sub: `Lichtwerk-Profil · ${meta[1]}`,
      body: `${isNew ? `<div class="lw-presets small">${Object.entries(LW_PRESETS).map(([k, x]) => `<button class="lw-preset" data-action="lwp-preset" data-v="${k}"><ha-icon icon="${x.icon}"></ha-icon><span><b>${x.name}</b></span></button>`).join("")}</div>` : ""}
        <label class="field rwname"><span><ha-icon icon="mdi:form-textbox"></ha-icon> Name des Profils</span><input type="text" data-lwp="name" data-kind="text" value="${esc(p.name || "")}" maxlength="60" placeholder="z. B. Außenlicht" ${dis}></label>
        <p class="muted small lwsum">${esc(this._lwProfSum(p))}</p>
        <div class="rwsecs">${LW_SECTIONS.map(([x, t, i]) => `<button class="rwsec ${x === sec ? "on" : ""}" data-action="lwp-sec" data-sec="${x}" style="--c:#6366f1"><ha-icon icon="${i}"></ha-icon>${t}</button>`).join("")}</div>${body}
        ${d.pid ? note(users.length ? `Genutzt von: ${users.map(esc).join(", ")}` : "Noch kein Licht nutzt dieses Profil.", "mdi:lightbulb-outline") : ""}
        ${d.confirm ? `<div class="rwdel"><b><ha-icon icon="mdi:delete-alert-outline"></ha-icon>Profil löschen? Lichter bekommen „${esc(this._lwProfiles().find((x) => x.id !== d.pid)?.name || "")}“.</b><div class="rwdel-b"><button class="secondary" data-action="lwp-del-no">Behalten</button><button class="primary danger-bg" data-action="lwp-del">Löschen</button></div></div>` : ""}`,
      foot: `${this._admin && d.pid && this._lwProfiles().length > 1 ? `<button class="icon boxed danger" data-action="lwp-del" title="Profil löschen"><ha-icon icon="mdi:delete-outline"></ha-icon></button>` : ""}
        <button class="secondary" data-action="pop-close">${this._admin ? "Abbrechen" : "Schließen"}</button>
        ${this._admin ? `<button class="primary" data-action="lwp-save"><ha-icon icon="mdi:content-save-outline"></ha-icon>${isNew ? "Anlegen" : "Speichern"}</button>` : ""}`,
    };
  }

  _areaOf(eid) {
    const ent = this._hass?.entities?.[eid];
    const dev = ent?.device_id ? this._hass?.devices?.[ent.device_id] : null;
    const aid = ent?.area_id || dev?.area_id;
    return aid ? this._hass?.areas?.[aid]?.name || aid : null;
  }

  /** Widget „Licht“. */
  _w_light(w, z) {
    const lights = this._lwLights();
    if (!lights.length) return `<p class="muted small">Noch keine Lichter in Lichtwerk.</p>`;
    const on = lights.filter((l) => l.st?.state === "on");
    const nx = this._lwStatus?.next;
    const head = `<div class="wbig"><span style="color:${on.length ? tint("#facc15") : "inherit"}">${on.length}<small>von ${lights.length} an</small></span></div>
      ${nx ? `<small class="muted wnext">${nx.action === "on" ? "an" : "aus"} ${this._lwWhen(nx)} · ${esc(nx.reason)}</small>` : ""}`;
    if (z === "s") return `${head}${on.length ? `<button class="secondary small" data-action="lw-cmd" data-ids="${on.map((l) => l.id).join(",")}" data-a="off"><ha-icon icon="mdi:lightbulb-off-outline"></ha-icon>Alle aus</button>` : ""}`;
    const list = (z === "l" ? lights : on.length ? on : lights.slice(0, 4)).slice(0, z === "l" ? 12 : 5);
    return `${head}<div class="wlist">${list.map((l) => {
      const o = l.st?.state === "on";
      const pct = this._lwPct(l);
      return `<div class="wrow"><ha-icon icon="${o ? "mdi:lightbulb-on" : "mdi:lightbulb-outline"}" style="color:${this._lwColor(l)}"></ha-icon><span class="grow"><b>${esc(this._lwName(l))}</b><small>${esc(l.ls.cause || "")}</small></span><button class="sbtn" data-action="lw-cmd" data-ids="${esc(l.id)}" data-a="${o ? "off" : "on"}" title="${o ? "Aus" : "An"}">${o ? (pct != null && pct < 100 ? `${pct} %` : "an") : "aus"}</button></div>`;
    }).join("")}</div>`;
  }

  // ------------------------------------------------------------ Kraftwerk
  /** Leistung eines Sensors in Watt (W, kW, MW), sonst null. */
  _kwW(id) {
    const s = id && this._hass.states[id];
    if (!s || ["unavailable", "unknown", ""].includes(s.state)) return null;
    const v = parseFloat(s.state);
    if (!Number.isFinite(v)) return null;
    const u = String(s.attributes?.unit_of_measurement || "W");
    return u === "kW" ? v * 1000 : u === "MW" ? v * 1e6 : v;
  }

  _kwFmt(w, sign = false) {
    if (w == null) return "–";
    const a = Math.abs(w);
    const t = a >= 1000 ? `${fmt(a / 1000, a >= 10000 ? 1 : 2)} kW` : `${fmt(a, 0)} W`;
    return sign && w < 0 ? `−${t}` : sign && w > 0 ? `+${t}` : t;
  }

  _kwConfigured(p = this._data?.settings || {}) {
    return !!((p.kw_solar || []).length || p.kw_grid || p.kw_battery || p.kw_home);
  }

  /** Energiefluss jetzt: Quellen, Verbrauch und wer wohin liefert (Watt). */
  _kwFlow(p = this._data?.settings || {}) {
    const W = (id) => this._kwW(id);
    const solarIds = p.kw_solar || [];
    const sv = solarIds.map(W).filter((x) => x != null);
    const solar = solarIds.length ? (sv.length ? Math.max(0, sv.reduce((a, b) => a + b, 0)) : null) : null;
    let grid = null;
    if (p.kw_grid) {
      const g = W(p.kw_grid);
      if (g != null) {
        if (p.kw_grid_export) grid = Math.max(0, g) - Math.max(0, W(p.kw_grid_export) ?? 0);
        else grid = p.kw_grid_invert ? -g : g;
      }
    }
    let batt = null;
    if (p.kw_battery) {
      const b = W(p.kw_battery);
      if (b != null) batt = p.kw_battery_invert ? -b : b;
    }
    const socS = p.kw_battery_soc && this._hass.states[p.kw_battery_soc];
    const soc = socS && Number.isFinite(parseFloat(socS.state)) ? parseFloat(socS.state) : null;
    const measured = p.kw_home ? W(p.kw_home) : null;
    const calc = (solar ?? 0) + (grid ?? 0) + (batt ?? 0);
    const home = measured != null ? Math.max(0, measured) : solar != null || grid != null || batt != null ? Math.max(0, calc) : null;
    // Wer liefert wohin: Solar zuerst ins Haus, dann in die Batterie, der Rest ins Netz
    const s = solar ?? 0, h = home ?? 0, charge = Math.max(0, -(batt ?? 0)), dis = Math.max(0, batt ?? 0);
    const sh = Math.min(s, h);
    const sb = Math.min(s - sh, charge);
    const sg = Math.max(0, Math.min(s - sh - sb, Math.max(0, -(grid ?? 0))));
    const gb = Math.max(0, charge - sb);
    const bh = Math.min(dis, h - sh);
    const gh = Math.max(0, h - sh - bh);
    const bg = Math.max(0, dis - bh);
    const cons = (p.kw_consumers || []).map((id) => ({ id, name: this._kwConsName(id, p), icon: this._kwConsIcon(id, p), w: W(id) })).sort((a, b) => (b.w ?? -1) - (a.w ?? -1));
    return { solar, grid, batt, soc, home, measured: measured != null, f: { sh, sb, sg, gh, gb, bh, bg }, cons,
      has: { solar: solarIds.length > 0, grid: !!p.kw_grid, batt: !!p.kw_battery } };
  }

  /** Name eines Verbrauchers: eigener Name, sonst Name der Entität. */
  _kwConsName(id, p = this._data?.settings || {}) {
    return String(p.kw_names?.[id] || "").trim() || this._entityName(id);
  }

  /** Symbol nach dem Namen (eigener Name zuerst, dann Name und ID der Entität). */
  _kwConsIcon(id, p = this._data?.settings || {}) {
    const hay = [p.kw_names?.[id], this._entityName(id), id].filter(Boolean).map((x) => String(x).toLowerCase());
    for (const h of hay) for (const [re, icon] of KW_ICONS) if (re.test(h)) return icon;
    return "mdi:power-plug-outline";
  }

  /** Texte und Linien des Fluss-Bilds – für das erste Zeichnen und die Live-Aktualisierung. */
  _kwView(fl) {
    const g = fl.grid;
    const own = fl.home ? Math.round(((fl.f.sh + fl.f.bh) / fl.home) * 100) : null;
    const b = fl.batt;
    return {
      text: {
        solar: this._kwFmt(fl.solar),
        "solar-s": fl.solar == null ? "kein Wert" : fl.solar < 5 ? "keine Sonne" : "Erzeugung",
        grid: this._kwFmt(g == null ? null : Math.abs(g)),
        "grid-s": g == null ? "kein Wert" : g > 5 ? "Bezug" : g < -5 ? "Einspeisung" : "ausgeglichen",
        home: this._kwFmt(fl.home),
        "home-s": own != null && fl.home > 5 ? `${own} % selbst` : fl.measured ? "gemessen" : "errechnet",
        batt: this._kwFmt(b == null ? null : Math.abs(b)),
        "batt-s": `${fl.soc != null ? `${fmt(fl.soc, 0)} % · ` : ""}${b == null ? "kein Wert" : b > 5 ? "entlädt" : b < -5 ? "lädt" : "Ruhe"}`,
      },
      cls: { grid: g == null ? "" : g > 5 ? "imp" : g < -5 ? "exp" : "" },
      lines: { sh: fl.f.sh, sb: fl.f.sb, sg: fl.f.sg, gh: fl.f.gh, gb: fl.f.gb, bh: fl.f.bh, bg: fl.f.bg },
    };
  }

  /** Fluss-Bild: Solar oben, Netz links, Haus rechts, Batterie unten. */
  _kwDiagram(fl, small = false) {
    const v = this._kwView(fl);
    // Knoten in Prozent der Fläche (Seitenverhältnis 1:0.84)
    const N = { solar: [50, 13], grid: [13, 50], home: [87, 50], batt: [50, 87] };
    const X = (k) => N[k][0] * 3, Y = (k) => N[k][1] * 2.52; // viewBox 300 × 252
    const L = {
      sh: `M${X("solar") + 18},${Y("solar") + 14} Q${X("home") - 20},${Y("solar") + 14} ${X("home") - 14},${Y("home") - 24}`,
      sg: `M${X("solar") - 18},${Y("solar") + 14} Q${X("grid") + 20},${Y("solar") + 14} ${X("grid") + 14},${Y("grid") - 24}`,
      sb: `M${X("solar")},${Y("solar") + 30} L${X("batt")},${Y("batt") - 30}`,
      gh: `M${X("grid") + 30},${Y("grid")} L${X("home") - 30},${Y("home")}`,
      gb: `M${X("grid") + 14},${Y("grid") + 24} Q${X("grid") + 20},${Y("batt") - 14} ${X("batt") - 18},${Y("batt") - 14}`,
      bg: `M${X("batt") - 18},${Y("batt") - 14} Q${X("grid") + 20},${Y("batt") - 14} ${X("grid") + 14},${Y("grid") + 24}`,
      bh: `M${X("batt") + 18},${Y("batt") - 14} Q${X("home") - 20},${Y("batt") - 14} ${X("home") - 14},${Y("home") + 24}`,
    };
    const need = { sh: fl.has.solar, sg: fl.has.solar && fl.has.grid, sb: fl.has.solar && fl.has.batt, gh: fl.has.grid, gb: fl.has.grid && fl.has.batt, bg: fl.has.grid && fl.has.batt, bh: fl.has.batt };
    const COL = { sh: "#f59e0b", sg: "#f59e0b", sb: "#f59e0b", gh: "#8b5cf6", gb: "#8b5cf6", bg: "#ec4899", bh: "#ec4899" };
    const paths = Object.entries(L).filter(([k]) => need[k]).map(([k, d]) =>
      `<path d="${d}" class="kl-base"/><path d="${d}" class="kl ${v.lines[k] > 10 ? "on" : ""}" data-kwl="${k}" style="--c:${COL[k]};${this._kwAnim(v.lines[k])}"/>`).join("");
    const node = (k, icon, c, show = true) => show ? `
      <div class="kn kn-${k} ${v.cls[k] || ""}" style="left:${N[k][0]}%;top:${N[k][1]}%;--c:${c}">
        <span class="kn-c"><ha-icon icon="${icon}"></ha-icon><b data-kwv="${k}">${esc(v.text[k])}</b></span>
        <small data-kwv="${k}-s">${esc(v.text[`${k}-s`])}</small>
      </div>` : "";
    return `<div class="kwd ${small ? "small" : ""}">
      <svg viewBox="0 0 300 252" preserveAspectRatio="none" aria-hidden="true">${paths}</svg>
      ${node("solar", "mdi:solar-power-variant", "#f59e0b", fl.has.solar)}
      ${node("grid", "mdi:transmission-tower", "#8b5cf6", fl.has.grid)}
      ${node("home", "mdi:home-lightning-bolt-outline", "#0ea5e9")}
      ${node("batt", fl.soc != null && fl.soc < 20 ? "mdi:battery-low" : "mdi:home-battery-outline", "#ec4899", fl.has.batt)}
    </div>`;
  }

  /** Dauer und Phase der Animation: die Phase hängt an der Uhr, damit neu Zeichnen nicht ruckelt. */
  _kwAnim(w) {
    const d = Number(this._kwDur(w));
    return `--d:${d}s;animation-delay:-${((Date.now() / 1000) % d).toFixed(2)}s`;
  }

  /** Je mehr Leistung, desto schneller laufen die Punkte (Sekunden pro Durchlauf). */
  _kwDur(w) {
    if (!w || w <= 10) return 4;
    return Math.max(0.5, 4 - Math.log10(w) * 0.9).toFixed(2);
  }

  /** Live: nur Zahlen und Linien austauschen, damit die Animation nicht neu startet. */
  _kwLive() {
    const root = this.shadowRoot;
    if (!root.querySelector(".kwd")) return;
    const fl = this._kwFlow();
    const v = this._kwView(fl);
    root.querySelectorAll("[data-kwv]").forEach((el) => { const t = v.text[el.dataset.kwv]; if (t != null && el.textContent !== t) el.textContent = t; });
    root.querySelectorAll("[data-kwl]").forEach((el) => {
      const w = v.lines[el.dataset.kwl];
      el.classList.toggle("on", w > 10);
      const d = `${this._kwDur(w)}s`;
      if (el.style.getPropertyValue("--d") !== d) el.setAttribute("style", `--c:${el.style.getPropertyValue("--c")};${this._kwAnim(w)}`);
    });
    root.querySelectorAll(".kn-grid").forEach((el) => { el.classList.toggle("imp", v.cls.grid === "imp"); el.classList.toggle("exp", v.cls.grid === "exp"); });
    const cons = root.getElementById("kw-cons");
    if (cons) cons.innerHTML = this._kwConsHtml(fl);
    const brief = root.getElementById("kw-brief");
    if (brief) brief.innerHTML = this._kwBrief(fl, this._kwPrefs()?.ok ? this._kwStats("today") : null);
  }

  _kwConsHtml(fl) {
    if (!fl.cons.length) return "";
    const home = fl.home || 0;
    const known = fl.cons.reduce((a, c) => a + Math.max(0, c.w ?? 0), 0);
    const rows = [...fl.cons, ...(home > known + 5 ? [{ id: "", name: "Sonstiges", w: home - known, rest: true }] : [])];
    const max = Math.max(1, home, ...rows.map((c) => c.w ?? 0));
    return rows.map((c) => `<div class="kc-row ${c.rest ? "rest" : ""}"><span class="kc-ic"><ha-icon icon="${c.rest ? "mdi:dots-horizontal" : c.icon}"></ha-icon></span><span class="grow"><b>${esc(c.name)}</b>
      <span class="kc-bar"><i style="width:${Math.max(0, Math.min(100, ((c.w ?? 0) / max) * 100)).toFixed(1)}%"></i></span></span>
      <em>${this._kwFmt(c.w)}${home > 5 && c.w != null ? `<small>${fmt((Math.max(0, c.w) / home) * 100, 0)} %</small>` : ""}</em></div>`).join("");
  }

  // ---- Tageswerte aus dem Energie-Dashboard von Home Assistant
  /** Energie-Dashboard lesen (einmal je Sitzung bzw. nach „Neu laden“). */
  _kwPrefs() {
    if (this._kwP !== undefined) return this._kwP;
    this._kwP = null;
    this._hass.callWS({ type: "energy/get_prefs" })
      .then((r) => (this._kwP = this._kwParse(r)))
      .catch(() => (this._kwP = this._kwParse({})))
      .finally(() => {
        this._renderMain();
        if (this._pop && ["setup", "kwdetect"].includes(this._pop.id)) this._renderPop();
      });
    return null;
  }

  _kwParse(r) {
    const out = { solar: [], imp: [], exp: [], bin: [], bout: [], cost: [], comp: [], priceImp: null, priceExp: null, rates: { solar: [], grid: [], batt: [] }, devices: [] };
    const rate = (o, list) => { for (const [k, v] of Object.entries(o || {})) if (/rate|power/.test(k) && typeof v === "string" && v.startsWith("sensor.")) list.push(v); };
    for (const src of r?.energy_sources || []) {
      if (src.type === "solar") { if (src.stat_energy_from) out.solar.push(src.stat_energy_from); rate(src, out.rates.solar); }
      if (src.type === "battery") { if (src.stat_energy_from) out.bout.push(src.stat_energy_from); if (src.stat_energy_to) out.bin.push(src.stat_energy_to); rate(src, out.rates.batt); }
      if (src.type === "grid") {
        rate(src, out.rates.grid);
        const from = src.flow_from || (src.stat_energy_from ? [src] : []);
        const to = src.flow_to || (src.stat_energy_to ? [src] : []);
        for (const f of from) {
          if (f.stat_energy_from) out.imp.push(f.stat_energy_from);
          if (f.stat_cost) out.cost.push(f.stat_cost);
          if (out.priceImp == null) out.priceImp = f.number_energy_price ?? f.entity_energy_price ?? null;
          rate(f, out.rates.grid);
        }
        for (const f of to) {
          if (f.stat_energy_to) out.exp.push(f.stat_energy_to);
          if (f.stat_compensation) out.comp.push(f.stat_compensation);
          if (out.priceExp == null) out.priceExp = f.number_energy_price ?? f.entity_energy_price ?? null;
        }
      }
    }
    for (const d of r?.device_consumption || []) if (d.stat_consumption) out.devices.push({ stat: d.stat_consumption, name: d.name || null, rate: d.stat_rate || null });
    out.ok = !!(out.solar.length || out.imp.length || out.exp.length);
    return out;
  }

  /** Preis je kWh: Zahl oder aktueller Wert einer Entität (dann „ca.“). */
  _kwPrice(x) {
    if (x == null) return null;
    if (typeof x === "number") return { v: x, approx: false };
    const n = parseFloat(this._hass.states[x]?.state);
    return Number.isFinite(n) ? { v: n, approx: true } : null;
  }

  /**
   * Summen je Zeitraum aus der Statistik (kWh): Tag „today“ (stündlich), 7/30 Tage (täglich), 12 Monate (monatlich).
   * Ergebnis: { buckets: [{start, solar, imp, exp, bin, bout, cost, comp}], total }
   */
  _kwStats(range) {
    const P = this._kwPrefs();
    if (!P) return null;
    this._kwS = this._kwS || {};
    const c = this._kwS[range];
    if (c && Date.now() - c.at < 5 * 60000) return c.data;
    if (!this._kwS[`loading${range}`]) {
      this._kwS[`loading${range}`] = true;
      const now = new Date();
      const start = new Date(now);
      start.setHours(0, 0, 0, 0);
      let period = "hour";
      if (range === "7" || range === "30") { start.setDate(start.getDate() - (Number(range) - 1)); period = "day"; }
      if (range === "365") { start.setMonth(start.getMonth() - 11, 1); period = "month"; }
      const groups = { solar: P.solar, imp: P.imp, exp: P.exp, bin: P.bin, bout: P.bout, cost: P.cost, comp: P.comp };
      const ids = [...new Set(Object.values(groups).flat())];
      const done = (data) => { this._kwS[range] = { at: Date.now(), data }; delete this._kwS[`loading${range}`]; this._renderMain(); };
      if (!ids.length) { done({ buckets: [], total: null }); return null; }
      this._hass.callWS({ type: "recorder/statistics_during_period", start_time: start.toISOString(), end_time: now.toISOString(),
        statistic_ids: ids, period, types: ["change"], units: { energy: "kWh" } })
        .then((res) => {
          const map = new Map();
          for (const [g, list] of Object.entries(groups))
            for (const id of list)
              for (const x of res?.[id] || []) {
                const t = typeof x.start === "number" ? x.start : Date.parse(x.start);
                if (!map.has(t)) map.set(t, { start: t, solar: 0, imp: 0, exp: 0, bin: 0, bout: 0, cost: 0, comp: 0, costN: 0, compN: 0 });
                const b = map.get(t);
                b[g] += Math.max(0, x.change || 0);
                if (g === "cost") b.costN++;
                if (g === "comp") b.compN++;
              }
          const buckets = [...map.values()].sort((a, b) => a.start - b.start).map((b) => this._kwDerive(b, P));
          const total = this._kwDerive(buckets.reduce((a, b) => { for (const k of ["solar", "imp", "exp", "bin", "bout", "cost", "comp", "costN", "compN"]) a[k] += b[k]; return a; },
            { start: start.getTime(), solar: 0, imp: 0, exp: 0, bin: 0, bout: 0, cost: 0, comp: 0, costN: 0, compN: 0 }), P);
          done({ buckets, total });
        })
        .catch(() => done({ buckets: [], total: null, error: true }));
    }
    return c ? c.data : null;
  }

  /** Abgeleitete Werte: Verbrauch, Eigenverbrauch, Autarkie, Kosten. */
  _kwDerive(b, P) {
    const use = Math.max(0, b.solar + b.imp + b.bout - b.exp - b.bin);
    const selfUse = Math.max(0, b.solar - b.exp);
    const pi = this._kwPrice(P.priceImp), pe = this._kwPrice(P.priceExp);
    const cost = P.cost.length ? b.cost : pi ? b.imp * pi.v : null;
    const comp = P.comp.length ? b.comp : pe ? b.exp * pe.v : null;
    return { ...b, use, selfUse, own: b.solar > 0.01 ? Math.min(100, (selfUse / b.solar) * 100) : null,
      autark: use > 0.01 ? Math.max(0, Math.min(100, ((use - b.imp) / use) * 100)) : null,
      costV: cost, compV: comp, approx: (!P.cost.length && pi?.approx) || (!P.comp.length && pe?.approx) };
  }

  _kwKwh(x) {
    return x == null ? "–" : `${fmt(x, x >= 100 ? 0 : 1)} kWh`;
  }

  _kwEur(x) {
    return x == null ? "–" : `${x.toLocaleString("de-DE", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €`;
  }

  /** Kennzahlen eines Zeitraums als Kacheln. */
  _kwKpis(t, P) {
    const k = (icon, c, val, cap, sub = "") => `<div class="kk" style="--c:${c}"><ha-icon icon="${icon}"></ha-icon><b>${val}</b><small>${cap}</small>${sub ? `<em>${sub}</em>` : ""}</div>`;
    const net = t.costV != null || t.compV != null ? (t.costV ?? 0) - (t.compV ?? 0) : null;
    return `<div class="kks">
      ${P.solar.length ? k("mdi:solar-power-variant", "#f59e0b", this._kwKwh(t.solar), "erzeugt", t.own != null ? `${fmt(t.own, 0)} % selbst genutzt` : "") : ""}
      ${k("mdi:home-lightning-bolt-outline", "#0ea5e9", this._kwKwh(t.use), "verbraucht", t.autark != null ? `${fmt(t.autark, 0)} % autark` : "")}
      ${P.imp.length ? k("mdi:transmission-tower-import", "#8b5cf6", this._kwKwh(t.imp), "Netzbezug", t.costV != null ? `${t.approx ? "ca. " : ""}${this._kwEur(t.costV)}` : "") : ""}
      ${P.exp.length ? k("mdi:transmission-tower-export", "#10b981", this._kwKwh(t.exp), "eingespeist", t.compV != null ? `${t.approx ? "ca. " : ""}+${this._kwEur(t.compV)}` : "") : ""}
      ${P.bin.length || P.bout.length ? k("mdi:home-battery-outline", "#ec4899", this._kwKwh(t.bout), "aus Batterie", `${this._kwKwh(t.bin)} geladen`) : ""}
      ${net != null ? k("mdi:cash", net > 0 ? "#ef4444" : "#22c55e", this._kwEur(Math.abs(net)), net > 0 ? "Kosten netto" : "Ertrag netto", "Bezug − Einspeisung") : ""}
    </div>`;
  }

  _kwEnergyHint() {
    return `<section class="card kw-hint"><ha-icon icon="mdi:chart-box-outline"></ha-icon><div class="grow">
      <b>Tageswerte aus dem Energie-Dashboard</b>
      <small>Erzeugung, Bezug, Einspeisung, Autarkie und Kosten liest Kraftwerk aus dem Energie-Dashboard von Home Assistant – nichts doppelt eintragen. Dort sind noch keine Zähler für Netz oder Solar eingetragen.</small>
      ${this._admin ? `<button class="link" data-action="kw-energy"><ha-icon icon="mdi:open-in-new"></ha-icon>Energie-Dashboard einrichten</button>` : ""}</div></section>`;
  }

  _viewKwFlow() {
    const p = this._data.settings;
    if (!this._kwConfigured(p))
      return `<section class="card empty"><span class="mlogo big">${MODULE_LOGOS.kraftwerk}</span><h2>Kraftwerk einrichten</h2>
        <p>Kraftwerk zeigt live, woher dein Strom kommt und wohin er fließt – Solar, Netz, Batterie und Verbraucher. Dafür braucht es Leistungs-Sensoren (W oder kW), z. B. vom Wechselrichter oder Stromzähler.</p>
        ${this._admin ? `<button class="primary" data-action="pop-open" data-pop="kwdetect"><ha-icon icon="mdi:auto-fix"></ha-icon>Sensoren automatisch erkennen</button>
        <button class="link" data-action="tab" data-tab="kwset">Selbst wählen</button>` : ""}</section>`;
    const fl = this._kwFlow(p);
    const P = this._kwPrefs();
    const st = P?.ok ? this._kwStats("today") : null;
    const today = !P ? `<div class="chart-empty"><div class="spinner"></div></div>`
      : !P.ok ? "" : st?.total ? this._kwKpis(st.total, P) : `<div class="chart-empty"><div class="spinner"></div></div>`;
    return `
      <div id="kw-brief">${this._kwBrief(fl, st)}</div>
      <section class="card kw-flow">
        ${this._sectionHead("mdi:flash-outline", "Jetzt", `<span class="kw-live"><i></i>live</span>`)}
        ${this._kwDiagram(fl)}
      </section>
      ${fl.cons.length ? `<section class="card">${this._sectionHead("mdi:power-plug-outline", "Verbraucher jetzt")}<div id="kw-cons" class="kc">${this._kwConsHtml(fl)}</div></section>` : ""}
      ${P && !P.ok ? this._kwEnergyHint() : `<section class="card">${this._sectionHead("mdi:calendar-today", "Heute", `<button class="link tiny" data-action="tab" data-tab="kwrep"><span>Verlauf</span><ha-icon icon="mdi:chevron-right"></ha-icon></button>`)}${today}</section>`}`;
  }

  /** Kraftwerk-Lage: was der Strom gerade bedeutet. */
  _kwBrief(fl, st) {
    const W = (x) => this._kwFmt(Math.abs(x));
    const solar = fl.solar ?? 0, grid = fl.grid, batt = fl.batt ?? 0, home = fl.home;
    let tone = "calm", icon = "mdi:flash-outline", title;
    const top = (fl.cons || []).find((c) => (c.w ?? 0) > 200);
    if (grid != null && grid < -100) { tone = "ok"; icon = "mdi:solar-power-variant"; title = `${W(grid)} Überschuss – gute Zeit für Waschmaschine & Co.`; }
    else if (fl.has.solar && solar > 50 && (grid == null || Math.abs(grid) <= 100)) { tone = "ok"; icon = "mdi:solar-power-variant"; title = `Solar deckt den Verbrauch${home != null ? ` (${W(home)})` : ""}`; }
    else if (fl.has.batt && batt > 50 && (grid == null || grid <= 100)) { tone = "ok"; icon = "mdi:home-battery-outline"; title = `Akku versorgt das Haus – ${W(batt)}`; }
    else if (grid != null && grid > 2500) { tone = "active"; icon = "mdi:transmission-tower-import"; title = `Hoher Netzbezug – ${W(grid)}${top ? `, vor allem ${top.name}` : ""}`; }
    else if (grid != null && grid > 0) { icon = "mdi:transmission-tower-import"; title = `Bezug ${W(grid)}${home != null && home < 400 ? " – nur Grundlast" : ""}`; }
    else title = home != null ? `Verbrauch ${W(home)}` : "Keine Leistungswerte";
    const lines = [];
    for (const c of this._data?.settings?.kw_appliances || []) {
      const a = this._status?.appliances?.[c.id];
      if (a && ["running", "ending", "done"].includes(a.state))
        lines.unshift({ icon: APP_TYPES[c.type]?.icon || "mdi:power-plug-outline", c: a.state === "done" ? "#22c55e" : "#0ea5e9", text: `${c.name}: ${this._appLine(a)}`, act: `data-action="tab" data-tab="kwdev"` });
    }
    if (top && !title.includes(top.name)) lines.push({ icon: top.icon, c: "#0ea5e9", text: `Größter Verbraucher: ${top.name} ${W(top.w)}` });
    if (fl.has.batt && fl.soc != null)
      lines.push({ icon: "mdi:home-battery-outline", c: fl.soc < 15 ? "#ef4444" : "#ec4899", text: `Akku ${fmt(fl.soc, 0)} %${batt > 5 ? ` – entlädt ${W(batt)}` : batt < -5 ? ` – lädt ${W(batt)}` : ""}${fl.soc < 15 ? " – fast leer" : ""}` });
    const t = st?.total;
    if (t && (t.autark != null || t.exp)) lines.push({ icon: "mdi:calendar-today", c: "#22c55e", text: `Heute ${t.autark != null ? `${fmt(t.autark, 0)} % selbst gedeckt` : ""}${t.autark != null && t.exp ? ", " : ""}${t.exp ? `${this._kwKwh(t.exp)} eingespeist` : ""}`, act: `data-action="tab" data-tab="kwrep"` });
    const chips = [
      ...(fl.has.solar ? [["mdi:solar-power-variant", W(solar), "Solar", "#f59e0b"]] : []),
      ...(home != null ? [["mdi:home-lightning-bolt-outline", W(home), "Haus", "#0ea5e9"]] : []),
      ...(grid != null ? [[grid > 0 ? "mdi:transmission-tower-import" : "mdi:transmission-tower-export", W(grid), grid > 0 ? "Bezug" : "Einspeisung", grid > 0 ? "#8b5cf6" : "#10b981"]] : []),
    ];
    const hv = home != null ? W(home).split(" ") : null;
    return this._brief({ cls: "card br-mod-kw", tone, icon, label: `<ha-icon icon="mdi:flash-outline"></ha-icon>Kraftwerk · jetzt`, big: hv ? `${hv[0]}<span>${hv[1] || ""} Haus</span>` : "",
      side: `<span class="kw-live"><i></i>live</span>`, title, lines, chips });
  }

  // ------------------------------------------------------------ Geräte mit Fertigerkennung
  _durTxt(sec) {
    if (sec == null) return "–";
    const m = Math.round(sec / 60);
    return m < 60 ? `${m} Min.` : `${Math.floor(m / 60)}:${String(m % 60).padStart(2, "0")} Std.`;
  }

  /** Kurzer Stand für Zeilen: „läuft seit 0:45 Std. – noch ca. 50 Min.“ */
  _appLine(a) {
    const now = Date.now() / 1000;
    if (a.state === "running" && a.run) {
      const rest = a.run.eta ? a.run.eta - now : null;
      return `läuft seit ${this._durTxt(a.run.elapsed)}${rest != null ? (rest > 60 ? ` – noch ca. ${this._durTxt(rest)}` : " – müsste gleich fertig sein") : ""}`;
    }
    if (a.state === "ending" && a.run) return `Ende wird geprüft – ${this._durTxt(a.run.quiet)} von ${this._durTxt(a.run.wait)} Ruhe`;
    if (a.state === "done" && a.last) return `fertig seit ${new Date(a.last.end * 1000).toLocaleTimeString("de-DE", { hour: "2-digit", minute: "2-digit" })} – ausräumen`;
    return a.learning ? "Lernphase – bereit" : "bereit";
  }

  _viewKwDev() {
    const list = this._data.settings.kw_appliances || [];
    const st = this._status?.appliances || {};
    const card = (c) => {
      const a = st[c.id] || { state: "idle", learning: true, n: 0, model: {} };
      const m = a.model || {};
      const [label, col, sic] = APP_STATE[a.state] || APP_STATE.idle;
      const watt = a.watt;
      const now = Date.now() / 1000;
      let main = "";
      if (a.run && (a.state === "running" || a.state === "ending")) {
        const pc = a.state === "ending" ? Math.min(100, (a.run.quiet / Math.max(1, a.run.wait)) * 100) : a.run.eta ? Math.min(100, ((now - a.run.start) / Math.max(1, a.run.eta - a.run.start)) * 100) : 0;
        main = `<div class="ap-run ${a.state}"><div class="vt-bar"><i style="width:${pc}%"></i></div><b>${esc(this._appLine(a))}</b>
          <small>${fmt(a.run.wh / 1000, 2)} kWh bisher${a.run.pauses ? ` · ${a.run.pauses} Pause${a.run.pauses > 1 ? "n" : ""}` : ""}${a.state === "ending" ? " · kurze Pausen im Programm sind normal – erst nach genug Ruhe gilt es als fertig" : ""}</small></div>`;
      } else if (a.state === "done" && a.last)
        main = `<div class="ap-run done"><b>Fertig – ${this._durTxt(a.last.dur)}, ${fmt(a.last.wh / 1000, 2)} kWh</b><small>Ende ${new Date(a.last.end * 1000).toLocaleTimeString("de-DE", { hour: "2-digit", minute: "2-digit" })} · erkannt ${new Date(a.last.detected * 1000).toLocaleTimeString("de-DE", { hour: "2-digit", minute: "2-digit" })}${a.last.why && a.last.why !== "Ruhe" ? ` · ${esc(a.last.why)}` : ""}</small></div>`;
      else main = `<div class="ap-run idle"><b>${a.learning ? `Lernphase – ${a.n} von 3 Durchläufen` : "Bereit"}</b><small>${a.learning ? "Bis dahin wartet Kraftwerk vorsichtig länger, bevor es „fertig“ meldet." : "Startet automatisch, sobald das Gerät Strom zieht."}</small></div>`;
      const btn = (act, txt, icon, cls = "secondary") => `<button class="${cls} small" data-action="app-act" data-id="${esc(c.id)}" data-a="${act}"><ha-icon icon="${icon}"></ha-icon>${txt}</button>`;
      const acts = a.state === "done" ? btn("ack", "Gesehen", "mdi:check", "primary") + btn("still_running", "Läuft noch", "mdi:play-outline") + btn("no_run", "Kein Durchlauf", "mdi:close")
        : a.state === "running" || a.state === "ending" ? btn("finished", "Ist schon fertig", "mdi:check-all") + btn("no_run", "Kein Durchlauf", "mdi:close") : "";
      const learned = a.n ? [
        `Gelernt aus ${a.n} Durchl${a.n === 1 ? "auf" : "äufen"}`,
        m.dur_lo != null ? `Dauer meist ${this._durTxt(m.dur_lo)}${m.dur_hi && m.dur_hi - m.dur_lo > 120 ? `–${this._durTxt(m.dur_hi)}` : ""}` : "",
        m.pause_max ? `längste Pause im Programm ${this._durTxt(m.pause_max)}` : "keine Pausen im Programm",
        `fertig nach ${this._durTxt(m.end_wait)} Ruhe`,
        m.tail_s ? `Nachlauf (Knitterschutz/Anzeige) bis ${this._durTxt(m.tail_s)}${m.tail_w ? `, Spitzen bis ${fmt(m.tail_w, 0)} W` : ""}` : "",
        `aktiv ab ${fmt(m.active_w, 0)} W${m.quiet_w != null ? ` (Ruhe/Anzeige bis ${fmt(m.quiet_w, 1)} W)` : ""}`,
        m.kwh_med ? `Ø ${fmt(m.kwh_med, 2)} kWh` : "",
        m.interval ? `Messwert etwa alle ${this._durTxt(m.interval)}` : "",
      ].filter(Boolean).join(" · ") : `Startwerte für ${APP_TYPES[c.type]?.label || "Gerät"}: fertig nach ${this._durTxt(m.end_wait)} Ruhe, aktiv ab ${fmt(m.active_w, 0)} W`;
      const hist = (a.history || []).slice(0, 5);
      return `<article class="card ap-c">
        <div class="vt-h"><span class="sr-ic" style="--c:${col}"><ha-icon icon="${APP_TYPES[c.type]?.icon || "mdi:power-plug-outline"}"></ha-icon></span><b>${esc(c.name)}</b>
          <span class="vt-chip" style="--c:${col}"><ha-icon icon="${sic}"></ha-icon>${a.learning && a.state === "idle" ? "Lernphase" : label}</span>
          <button class="icon" data-action="pop-open" data-pop="kwapp:${esc(c.id)}" title="Einstellen"><ha-icon icon="mdi:cog-outline"></ha-icon></button></div>
        ${main}
        <div class="ap-w"><ha-icon icon="mdi:flash-outline"></ha-icon>${a.gap ? `<span class="warn">Messwert fehlt – zählt nicht als Ende</span>` : `jetzt ${watt == null ? "–" : `${fmt(watt, watt < 10 ? 1 : 0)} W`}`}</div>
        ${acts ? `<div class="ap-acts">${acts}</div>` : ""}
        <details class="role-help"><summary>Was Kraftwerk gelernt hat</summary><p class="muted small">${esc(learned)}</p>
          ${hist.length ? `<div class="ap-hist">${hist.map((h) => `<span><b>${new Date(h.start * 1000).toLocaleDateString("de-DE", { weekday: "short", day: "numeric", month: "numeric" })} ${new Date(h.start * 1000).toLocaleTimeString("de-DE", { hour: "2-digit", minute: "2-digit" })}</b>${this._durTxt(h.dur)} · ${fmt(h.wh / 1000, 2)} kWh${h.max_pause ? ` · Pause bis ${this._durTxt(h.max_pause)}` : ""}${h.why && h.why !== "Ruhe" ? ` · ${esc(h.why)}` : ""}</span>`).join("")}</div>` : ""}
        </details>
      </article>`;
    };
    const head = this._sectionHead("mdi:washing-machine", "Geräte mit Fertigerkennung", this._admin ? `<button class="link" data-action="pop-open" data-pop="kwapp:new"><ha-icon icon="mdi:plus"></ha-icon>Gerät</button>` : "");
    if (!list.length)
      return head + `<section class="card empty"><ha-icon icon="mdi:washing-machine"></ha-icon><h2>Waschmaschine, Trockner & Co. melden, wenn sie fertig sind</h2>
        <p class="muted">Kraftwerk lernt am Stromverbrauch einer Mess-Steckdose, wie ein Durchlauf aussieht – mit Pausen, Nachlauf und Knitterschutz – und meldet das Ende einmal aufs Handy.</p>
        ${this._admin ? `<button class="primary" data-action="pop-open" data-pop="kwapp:new"><ha-icon icon="mdi:plus"></ha-icon>Gerät einrichten</button>` : ""}</section>`;
    return head + `<div class="vt-grid">${list.map(card).join("")}</div>`;
  }

  /** Einrichtung eines Geräts: Name, Typ, Leistungssensor, Zusatzsensoren, Kanäle. */
  _kwAppPop(id) {
    const d = this._pop.draft;
    const list = this._data.settings.kw_appliances || [];
    const S = this._hass.states;
    if (!d.init) {
      const c = list.find((x) => x.id === id);
      Object.assign(d, c ? { id: c.id, name: c.name, type: c.type, kwa_power: c.power, kwa_door: c.door || null, kwa_status: c.status || null,
        status_done: (c.status_done || []).join(", "), notify: [...(c.notify || []).map((x) => (x.includes(":") || x === "ha" ? x : `svc:${x}`)), ...(c.notify_ha && !(c.notify || []).includes("ha") ? ["ha"] : [])], important: !!c.important }
        : { id: null, name: "", type: "waschmaschine", kwa_power: null, kwa_door: null, kwa_status: null, status_done: "", notify: [...(this._data.settings.notify_channels || [])], important: false });
      d.init = true;
    }
    // Leistungssensor vorschlagen: passend zum Typ, mit W/kW
    const powers = Object.keys(S).filter((e) => e.startsWith("sensor.") && ["W", "kW"].includes(S[e].attributes?.unit_of_measurement));
    const re = APP_TYPES[d.type]?.match;
    const sugg = re ? powers.filter((e) => re.test(`${e} ${S[e].attributes?.friendly_name || ""}`.toLowerCase()) && !list.some((x) => x.power === e && x.id !== d.id)) : [];
    const ps = d.kwa_power ? S[d.kwa_power] : null;
    const unit = ps?.attributes?.unit_of_measurement;
    const sw2 = (k, on) => `<label class="switch"><input type="checkbox" data-kwapp-flag="${k}" ${on ? "checked" : ""}><span></span></label>`;
    const a = (this._status?.appliances || {})[d.id] || null;
    return {
      icon: APP_TYPES[d.type]?.icon || "mdi:power-plug-outline", c: "#f59e0b", title: d.id ? esc(d.name || "Gerät") : "Gerät einrichten", sub: "Kraftwerk · Fertigerkennung",
      body: `
        <label class="field"><span>Name</span><input type="text" maxlength="40" data-kwapp="name" value="${esc(d.name)}" placeholder="${esc(APP_TYPES[d.type]?.label || "")}"></label>
        <div class="field"><span>Gerätetyp</span><div class="segs small">${Object.entries(APP_TYPES).map(([k, t]) => `<button class="seg ${d.type === k ? "on" : ""}" data-action="kwapp-type" data-v="${k}"><ha-icon icon="${t.icon}"></ha-icon>${t.label}</button>`).join("")}</div></div>
        <p class="muted small">Der Typ setzt nur die vorsichtigen Startwerte (z. B. Trockner: kurzes Warten, Waschmaschine/Geschirrspüler: lange Pausen möglich). Danach lernt Kraftwerk aus jedem Durchlauf.</p>
        <div class="lbl">Leistungssensor</div>
        ${sugg.length && !d.kwa_power ? `<div class="pchips">${sugg.map((e) => `<button class="pchip" data-action="kwapp-pick" data-id="${esc(e)}"><i></i>${esc(this._entityName(e))} · ${esc(S[e].state)} ${esc(S[e].attributes.unit_of_measurement)}</button>`).join("")}</div>` : ""}
        <div class="field">${this._picker("kwa_power", d.kwa_power ? [d.kwa_power] : [])}</div>
        ${ps ? `<p class="muted small"><ha-icon icon="mdi:flash-outline"></ha-icon>jetzt ${esc(ps.state)} ${esc(unit || "")}${!["W", "kW", "mW"].includes(unit) ? ` – <b>Einheit „${esc(unit || "keine")}“ ist keine Leistung</b>, bitte einen Sensor in W oder kW wählen` : ""}${["unavailable", "unknown"].includes(ps.state) ? " – gerade nicht erreichbar; fehlende Werte zählen nie als Ende" : ""}. Viele Mess-Steckdosen melden nur bei Änderung – das ist in Ordnung.</p>` : ""}
        <details class="role-help" ${d.kwa_door || d.kwa_status ? "open" : ""}><summary>Weitere Sensoren (optional)</summary>
          <div class="field"><span><ha-icon icon="mdi:door-open"></ha-icon> Türkontakt</span>${this._picker("kwa_door", d.kwa_door ? [d.kwa_door] : [])}</div>
          <p class="muted small">Wird die Tür geöffnet, während das Ende geprüft wird, gilt das Gerät sofort als fertig – und Kraftwerk lernt, wie viel Ruhe wirklich reichte. Ist es fertig, gilt das Öffnen als „Gesehen“.</p>
          <div class="field"><span><ha-icon icon="mdi:list-status"></ha-icon> Status des Geräts</span>${this._picker("kwa_status", d.kwa_status ? [d.kwa_status] : [])}</div>
          ${d.kwa_status ? `<label class="field"><span>Zustand „fertig“ (mehrere mit Komma)</span><input type="text" data-kwapp="status_done" value="${esc(d.status_done)}" placeholder="z. B. Finished, fertig, WM ist fertig"><small class="muted">jetzt: ${esc(S[d.kwa_status]?.state ?? "–")}</small></label>` : ""}
        </details>
        <div class="lbl">Fertigmeldung an</div>
        ${this._chPicker("app", d.notify)}
        <div class="wxrows">
          ${this._setRow("kwimp", "Wichtig", "durchbricht „Nicht stören“, Ansage auch in der Ruhezeit", sw2("important", d.important), "iPhone: zeitkritisch, Android: hohe Priorität.")}
        </div>
        <p class="muted small">Je Durchlauf und Kanal kommt höchstens eine Meldung – auch nach Neustarts oder Verbindungsabbrüchen. Erkannt wird in Home Assistant selbst, das Dashboard muss nicht offen sein.</p>
        ${d.id && this._admin ? `<div class="lbl">Lernen</div><div class="ap-acts">
          <button class="secondary small" data-action="app-act" data-id="${esc(d.id)}" data-a="learn_history"><ha-icon icon="mdi:history"></ha-icon>Aus dem Verlauf lernen (10 Tage)</button>
          <button class="secondary small" data-action="app-act" data-id="${esc(d.id)}" data-a="reset"><ha-icon icon="mdi:restore"></ha-icon>Neu lernen</button></div>
          <p class="muted small">${a ? `Gelernt aus ${a.n} Durchläufen. ` : ""}„Aus dem Verlauf lernen“ spielt die gespeicherten Messwerte der letzten Tage nach – ohne Meldungen.</p>` : ""}`,
      foot: `${d.id && this._admin ? `<button class="danger" data-action="kwapp-del" title="Gerät entfernen"><ha-icon icon="mdi:trash-can-outline"></ha-icon></button>` : ""}<span class="grow"></span>
        <button class="secondary" data-action="pop-close">Abbrechen</button>${this._admin ? `<button class="primary" data-action="kwapp-save" ${d.kwa_power && String(d.name || "").trim() ? "" : "disabled"}><ha-icon icon="mdi:content-save-outline"></ha-icon>Speichern</button>` : ""}`,
    };
  }

  async _kwAppSave(del = false) {
    const d = this._pop.draft;
    const list = clone(this._data.settings.kw_appliances || []);
    const slug = (x) => String(x).toLowerCase().replace(/ä/g, "ae").replace(/ö/g, "oe").replace(/ü/g, "ue").replace(/ß/g, "ss").replace(/[^a-z0-9]+/g, "_").replace(/^_|_$/g, "").slice(0, 30) || "geraet";
    let id = d.id;
    if (!id) { id = slug(d.name); while (list.some((x) => x.id === id)) id += "_2"; }
    const item = { id, name: String(d.name).trim(), type: d.type, power: d.kwa_power, door: d.kwa_door || null, status: d.kwa_status || null,
      status_done: String(d.status_done || "").split(",").map((x) => x.trim()).filter(Boolean), notify: d.notify || [], notify_ha: false, important: !!d.important };
    const next = del ? list.filter((x) => x.id !== id) : list.some((x) => x.id === id) ? list.map((x) => (x.id === id ? item : x)) : [...list, item];
    try {
      this._data.settings = await this._ws({ type: "hauswerk/heizen/settings/save", settings: { kw_appliances: next } });
      this._toast(del ? `${item.name} entfernt` : `${item.name} gespeichert${d.id ? "" : " – Lernphase beginnt"}`);
      this._closePop();
      this._renderMain();
    } catch (err) {
      this._toast(`Das hat nicht geklappt: ${err?.message || err}`);
    }
  }

  async _appAct(id, action) {
    try {
      const res = await this._ws({ type: "hauswerk/kraftwerk/appliance/action", device: id, action });
      const c = (this._data.settings.kw_appliances || []).find((x) => x.id === id);
      this._toast(action === "learn_history" ? `${c?.name}: ${res.runs} Durchläufe aus dem Verlauf gelernt` : `${c?.name}: ${res.text}`);
    } catch (err) {
      this._toast(`Das hat nicht geklappt: ${err?.message || err}`);
    }
  }

  _viewKwRep() {
    const P = this._kwPrefs();
    if (!P) return `<section class="card"><div class="chart-empty"><div class="spinner"></div></div></section>`;
    if (!P.ok) return this._kwEnergyHint();
    const range = this._kwRange || "today";
    const st = this._kwStats(range);
    const tabs = `<div class="segs small kw-range">${[["today", "Heute"], ["7", "7 Tage"], ["30", "30 Tage"], ["365", "12 Monate"]]
      .map(([v, l]) => `<button class="seg ${range === v ? "on" : ""}" data-action="kw-range" data-v="${v}">${l}</button>`).join("")}</div>`;
    if (!st) return `${tabs}<section class="card"><div class="chart-empty"><div class="spinner"></div></div></section>`;
    if (!st.buckets.length) return `${tabs}<section class="card empty small"><p>${st.error ? "Die Statistik von Home Assistant ist gerade nicht lesbar." : "Für diesen Zeitraum gibt es noch keine Werte."}</p></section>`;
    const lab = (t) => {
      const d = new Date(t);
      return range === "today" ? `${d.getHours()}` : range === "365" ? d.toLocaleDateString("de-DE", { month: "short" }) : range === "7" ? d.toLocaleDateString("de-DE", { weekday: "short" }) : `${d.getDate()}.`;
    };
    // Balken: oben Verbrauch (aus Solar, aus Batterie, aus dem Netz), unten Einspeisung
    const up = st.buckets.map((b) => b.use), down = st.buckets.map((b) => b.exp);
    const max = Math.max(0.01, ...up, ...down);
    const hasDown = down.some((x) => x > 0.005);
    const bars = st.buckets.map((b) => {
      const fromSolar = Math.max(0, Math.min(b.use, b.solar - b.exp - b.bin));
      const fromBatt = Math.min(Math.max(0, b.use - fromSolar), b.bout);
      const fromGrid = Math.max(0, b.use - fromSolar - fromBatt);
      const h = (x) => `${((x / max) * 100).toFixed(2)}%`;
      const tip = `${lab(b.start)}: ${fmt(b.use, 2)} kWh verbraucht · Solar ${fmt(b.solar, 2)} · Netz ${fmt(b.imp, 2)} · eingespeist ${fmt(b.exp, 2)} kWh${b.autark != null ? ` · ${fmt(b.autark, 0)} % autark` : ""}`;
      return `<div class="kb" title="${esc(tip)}"><div class="kb-up">${fromGrid > 0 ? `<i class="g" style="height:${h(fromGrid)}"></i>` : ""}${fromBatt > 0 ? `<i class="b" style="height:${h(fromBatt)}"></i>` : ""}${fromSolar > 0 ? `<i class="s" style="height:${h(fromSolar)}"></i>` : ""}</div>
        ${hasDown ? `<div class="kb-down">${b.exp > 0 ? `<i class="e" style="height:${h(b.exp)}"></i>` : ""}</div>` : ""}<small>${lab(b.start)}</small></div>`;
    }).join("");
    const every = st.buckets.length > 14 ? Math.ceil(st.buckets.length / 10) : 1;
    const legend = [["s", "Solar direkt"], ...(P.bout.length ? [["b", "aus Batterie"]] : []), ["g", "aus dem Netz"], ...(hasDown ? [["e", "eingespeist"]] : [])]
      .map(([c, l]) => `<span><i class="${c}"></i>${l}</span>`).join("");
    const title = { today: "Heute", 7: "Letzte 7 Tage", 30: "Letzte 30 Tage", 365: "Letzte 12 Monate" }[range];
    return `${tabs}
      <section class="card">${this._sectionHead("mdi:sigma", title)}${this._kwKpis(st.total, P)}</section>
      <section class="card">${this._sectionHead("mdi:chart-bar", range === "today" ? "Je Stunde" : range === "365" ? "Je Monat" : "Je Tag")}
        <div class="kbars ${every > 1 ? "thin" : ""}" style="--every:${every}">${bars}</div>
        <div class="klegend">${legend}</div>
        <p class="muted small">Quelle: Energie-Dashboard von Home Assistant${P.cost.length || P.priceImp != null ? " · Kosten mit den dort hinterlegten Preisen" : ""}.</p>
      </section>`;
  }

  // ---- Einstellungen
  _kwRows(p) {
    const P = this._kwPrefs();
    const fl = this._kwFlow(p);
    const names = (ids) => ids.map((id) => this._entityName(id)).join(", ");
    const sug = this._kwSuggest();
    const found = ["kw_solar", "kw_grid", "kw_battery", "kw_battery_soc", "kw_home"].filter((k) => (Array.isArray(sug[k]) ? sug[k].length : sug[k]) && !(Array.isArray(p[k]) ? p[k].length : p[k])).length;
    return [
      { g: "Einrichten", id: "kwdetect", icon: "mdi:auto-fix", c: "#f59e0b", title: "Automatisch erkennen",
        sum: found ? `${found} passende Sensoren gefunden – übernehmen?` : "Sucht Leistungs-Sensoren für Solar, Netz, Batterie und Haus", warn: !!found && !this._kwConfigured(p), words: "erkennen automatisch vorschlag assistent" },
      { g: "Leistung jetzt", id: "kwsolar", icon: "mdi:solar-power-variant", c: "#f59e0b", title: "Solar",
        sum: (p.kw_solar || []).length ? `${names(p.kw_solar)} · jetzt ${this._kwFmt(fl.solar)}` : "Kein Sensor – ohne PV-Anlage leer lassen", words: "solar pv photovoltaik wechselrichter erzeugung" },
      { g: "Leistung jetzt", id: "kwgrid", icon: "mdi:transmission-tower", c: "#8b5cf6", title: "Netz",
        sum: p.kw_grid ? `${names([p.kw_grid, p.kw_grid_export].filter(Boolean))} · jetzt ${fl.grid == null ? "–" : `${this._kwFmt(Math.abs(fl.grid))} ${fl.grid > 5 ? "Bezug" : fl.grid < -5 ? "Einspeisung" : ""}`}` : "Kein Sensor", words: "netz zähler bezug einspeisung smartmeter" },
      { g: "Leistung jetzt", id: "kwbatt", icon: "mdi:home-battery-outline", c: "#ec4899", title: "Batterie",
        sum: p.kw_battery ? `${names([p.kw_battery])} · ${fl.soc != null ? `${fmt(fl.soc, 0)} % · ` : ""}${fl.batt == null ? "–" : fl.batt > 5 ? `entlädt ${this._kwFmt(fl.batt)}` : fl.batt < -5 ? `lädt ${this._kwFmt(-fl.batt)}` : "Ruhe"}` : "Kein Speicher – leer lassen", words: "batterie speicher akku ladestand soc" },
      { g: "Leistung jetzt", id: "kwhome", icon: "mdi:home-lightning-bolt-outline", c: "#0ea5e9", title: "Hausverbrauch",
        sum: p.kw_home ? `${names([p.kw_home])} · jetzt ${this._kwFmt(fl.home)}` : `errechnet aus Solar, Netz und Batterie${fl.home != null ? ` · jetzt ${this._kwFmt(fl.home)}` : ""}`, words: "haus verbrauch last" },
      { g: "Leistung jetzt", id: "kwcons", icon: "mdi:power-plug-outline", c: "#64748b", title: "Verbraucher",
        sum: (p.kw_consumers || []).length ? p.kw_consumers.map((id) => this._kwConsName(id, p)).join(", ") : "z. B. Wärmepumpe, Wallbox, Waschmaschine – optional", words: "verbraucher wärmepumpe wallbox steckdose geräte" },
      { g: "Tageswerte", act: "kw-energy", icon: "mdi:chart-box-outline", c: "#10b981", title: "Energie-Dashboard von Home Assistant",
        sum: !P ? "wird gelesen …" : P.ok ? [P.solar.length ? "Solar ✓" : "", P.imp.length ? "Netzbezug ✓" : "", P.exp.length ? "Einspeisung ✓" : "", P.bin.length || P.bout.length ? "Batterie ✓" : "", P.cost.length || P.priceImp != null ? "Preise ✓" : "ohne Preise"].filter(Boolean).join(" · ") : "Noch nicht eingerichtet – dort Netz und Solar eintragen",
        warn: !!P && !P.ok, words: "energie dashboard kwh zähler preis kosten statistik" },
      { g: "Allgemein", act: "kw-log", icon: "mdi:text-box-search-outline", c: "#64748b", title: "Protokoll", sum: "Änderungen an den Einstellungen von Kraftwerk", words: "protokoll log änderungen" },
    ];
  }

  /** Vorschläge: aus dem Energie-Dashboard (Leistungs-Sensoren oder Sensoren am selben Gerät), sonst nach Namen. */
  _kwSuggest() {
    const S = this._hass.states;
    const ents = this._hass.entities || {};
    const P = this._kwP || null;
    const isPower = (id) => { const a = S[id]?.attributes || {}; return id.startsWith("sensor.") && (a.device_class === "power" || ["W", "kW", "MW"].includes(a.unit_of_measurement)); };
    const power = Object.keys(S).filter(isPower);
    const nm = (id) => `${S[id]?.attributes?.friendly_name || ""} ${id}`.toLowerCase();
    const sameDevice = (statId, re) => {
      const dev = ents[statId]?.device_id;
      if (!dev) return null;
      const list = power.filter((id) => ents[id]?.device_id === dev);
      return list.find((id) => re && re.test(nm(id))) || (list.length === 1 ? list[0] : null);
    };
    const byName = (re, not) => power.filter((id) => re.test(nm(id)) && !(not && not.test(nm(id))));
    const out = { kw_solar: [], kw_grid: null, kw_battery: null, kw_battery_soc: null, kw_home: null, why: {} };
    // Solar
    if (P?.rates.solar.length) { out.kw_solar = P.rates.solar; out.why.kw_solar = "aus dem Energie-Dashboard"; }
    else if (P?.solar.length) { out.kw_solar = P.solar.map((id) => sameDevice(id, /pv|solar|dc|ac|leistung|power/)).filter(Boolean); if (out.kw_solar.length) out.why.kw_solar = "am selben Gerät wie der Solar-Zähler"; }
    if (!out.kw_solar.length) { const l = byName(/(\bpv\b|pv_|solar|photovolt|wechselrichter|inverter)/, /(prognose|forecast|batter|akku|speicher|grid|netz|einspeis|bezug|energy|ertrag|yield|today|heute)/); if (l.length) { out.kw_solar = l.slice(0, 2); out.why.kw_solar = "nach Namen"; } }
    // Netz
    if (P?.rates.grid.length) { out.kw_grid = P.rates.grid[0]; out.why.kw_grid = "aus dem Energie-Dashboard"; }
    else if (P?.imp.length) { out.kw_grid = sameDevice(P.imp[0], /(netz|grid|bezug|import|wirk|active|power|leistung)/); if (out.kw_grid) out.why.kw_grid = "am selben Gerät wie der Netzzähler"; }
    if (!out.kw_grid) { const l = byName(/(grid|netz|bezug|einspeis|smart.?meter|stromz(ä|ae)hler|hausanschluss|zaehler|zähler|\bmeter\b)/, /(batter|akku|speicher|\bpv\b|solar)/); if (l.length) { out.kw_grid = l[0]; out.why.kw_grid = "nach Namen"; } }
    // Batterie
    if (P?.rates.batt.length) { out.kw_battery = P.rates.batt[0]; out.why.kw_battery = "aus dem Energie-Dashboard"; }
    else if (P?.bout.length) { out.kw_battery = sameDevice(P.bout[0], /(batter|akku|speicher|power|leistung)/); if (out.kw_battery) out.why.kw_battery = "am selben Gerät wie der Batterie-Zähler"; }
    if (!out.kw_battery) { const l = byName(/(batter|akku|speicher|storage)/, /(soc|ladestand|level|state of charge|spannung|volt|temp)/); if (l.length) { out.kw_battery = l[0]; out.why.kw_battery = "nach Namen"; } }
    const soc = Object.keys(S).filter((id) => id.startsWith("sensor.") && S[id].attributes?.unit_of_measurement === "%" && /(batter|akku|speicher|storage)/.test(nm(id)) && /(soc|lade|charge|level|stand)/.test(nm(id)) && !/(phone|handy|iphone|pixel|tablet|watch|uhr|thermostat|kontakt|fenster|bewegung|motion)/.test(String(S[id].attributes?.friendly_name || id.slice(7)).toLowerCase()));
    const dev = out.kw_battery && ents[out.kw_battery]?.device_id;
    out.kw_battery_soc = (dev && soc.find((id) => ents[id]?.device_id === dev)) || (out.kw_battery ? soc[0] : null) || null;
    // Haus
    const home = byName(/((haus|home|house).*(verbrauch|consum|load|last))|((verbrauch|consum|load).*(haus|home|house))/);
    if (home.length) { out.kw_home = home[0]; out.why.kw_home = "nach Namen"; }
    return out;
  }

  _kwPop(id) {
    const p = this._settings;
    const { sw } = this._setHelpers(p);
    const row = (k, title, sub, value, text, ctl) => this._setRow(k, title, sub, value, text, ctl);
    const fl = this._kwFlow(p);
    const live = (txt, c = "#94a3b8") => `<div class="rq-facts"><span style="--c:${c}"><ha-icon icon="mdi:flash-outline"></ha-icon>${txt}</span></div>`;
    switch (id) {
      case "kwdetect": {
        const sug = this._kwSuggest();
        const roles = [["kw_solar", "Solar", "mdi:solar-power-variant", "#f59e0b"], ["kw_grid", "Netz", "mdi:transmission-tower", "#8b5cf6"], ["kw_battery", "Batterie", "mdi:home-battery-outline", "#ec4899"],
          ["kw_battery_soc", "Ladestand", "mdi:battery-50", "#ec4899"], ["kw_home", "Hausverbrauch", "mdi:home-lightning-bolt-outline", "#0ea5e9"]];
        const val = (id2) => { const w = this._kwW(id2); const s = this._hass.states[id2]; return s?.attributes?.unit_of_measurement === "%" ? `${s.state} %` : this._kwFmt(w, true); };
        const list = roles.map(([k, l, icon, c]) => {
          const v = sug[k];
          const ids = Array.isArray(v) ? v : v ? [v] : [];
          const cur = Array.isArray(p[k]) ? p[k] : p[k] ? [p[k]] : [];
          const same = ids.length && JSON.stringify(ids) === JSON.stringify(cur);
          return `<div class="kwsug ${ids.length ? "" : "none"}" style="--c:${c}"><span class="sr-ic"><ha-icon icon="${icon}"></ha-icon></span>
            <span class="grow"><b>${l}</b><small>${ids.length ? `${esc(ids.map((x) => `${this._entityName(x)} (${val(x)})`).join(", "))} · ${sug.why[k] || ""}` : "nichts gefunden"}${cur.length && !same ? ` · jetzt: ${esc(cur.map((x) => this._entityName(x)).join(", "))}` : ""}</small></span>
            ${ids.length ? same ? `<em class="badge ok">GEWÄHLT</em>` : `<button class="secondary small" data-action="kw-take" data-k="${k}" ${this._admin ? "" : "disabled"}>Übernehmen</button>` : ""}</div>`;
        }).join("");
        return { icon: "mdi:auto-fix", c: "#f59e0b", title: "Automatisch erkennen", sub: "Kraftwerk",
          body: `<p class="muted">Kraftwerk sucht Leistungs-Sensoren (W/kW): zuerst im Energie-Dashboard von Home Assistant und an denselben Geräten wie die dort eingetragenen Zähler, sonst nach Namen. Prüfe die Werte – sie sollten zu dem passen, was gerade passiert.</p>
            <div class="kwsugs">${list}</div>
            ${this._admin ? `<button class="link" data-action="kw-take" data-k="all"><ha-icon icon="mdi:check-all"></ha-icon>Alle übernehmen</button>` : ""}
            <p class="muted small">Danach unter Netz und Batterie die Richtung prüfen: Bezug soll als „Bezug“ erscheinen, Laden als „lädt“.</p>` };
      }
      case "kwsolar":
        return { icon: "mdi:solar-power-variant", c: "#f59e0b", title: "Solar", sub: "Kraftwerk · Leistung jetzt",
          body: `<p class="muted">Aktuelle Leistung der PV-Anlage in W oder kW – bei mehreren Wechselrichtern alle wählen, sie werden addiert.</p>
            <div class="field"><span><ha-icon icon="mdi:solar-power-variant"></ha-icon> PV-Leistung</span>${this._picker("kw_solar", p.kw_solar || [])}</div>
            ${(p.kw_solar || []).length ? live(`jetzt ${this._kwFmt(fl.solar)}`, "#f59e0b") : ""}` };
      case "kwgrid":
        return { icon: "mdi:transmission-tower", c: "#8b5cf6", title: "Netz", sub: "Kraftwerk · Leistung jetzt",
          body: `<p class="muted">Ein Sensor mit Vorzeichen (meist + = Bezug, − = Einspeisung), z. B. vom Smart Meter oder Zählerlesekopf. Liefert dein Zähler Bezug und Einspeisung getrennt, wähle unten zusätzlich die Einspeisung.</p>
            <div class="field"><span><ha-icon icon="mdi:transmission-tower-import"></ha-icon> Netz-Leistung${p.kw_grid_export ? " (Bezug)" : ""}</span>${this._picker("kw_grid", p.kw_grid)}</div>
            ${this._expertOn("kraftwerk") || p.kw_grid_invert || p.kw_grid_export ? `
            <div class="wxrows">${p.kw_grid_export ? "" : row("kwg1", "Vorzeichen umdrehen", "an, wenn Einspeisung positiv angezeigt wird", sw("kw_grid_invert"), "Manche Zähler zeigen die Einspeisung positiv. Schalte das an, wenn unten bei Sonne „Bezug“ steht, obwohl du einspeist.")}</div>
            <div class="field"><span><ha-icon icon="mdi:transmission-tower-export"></ha-icon> Einspeisung getrennt (optional)</span>${this._picker("kw_grid_export", p.kw_grid_export)}</div>` : `<p class="muted small"><ha-icon icon="mdi:school-outline"></ha-icon>Vorzeichen umdrehen und getrennte Einspeisung: Experteneinstellungen unter Kraftwerk › Einstellungen.</p>`}
            ${p.kw_grid ? live(fl.grid == null ? "kein Wert" : `jetzt ${this._kwFmt(Math.abs(fl.grid))} ${fl.grid > 5 ? "Bezug" : fl.grid < -5 ? "Einspeisung" : "ausgeglichen"}`, fl.grid > 5 ? "#8b5cf6" : "#10b981") : ""}` };
      case "kwbatt":
        return { icon: "mdi:home-battery-outline", c: "#ec4899", title: "Batterie", sub: "Kraftwerk · Leistung jetzt",
          body: `<p class="muted">Lade-/Entladeleistung des Speichers mit Vorzeichen (meist + = Entladen, − = Laden) und der Ladestand in %.</p>
            <div class="field"><span><ha-icon icon="mdi:home-battery-outline"></ha-icon> Batterie-Leistung</span>${this._picker("kw_battery", p.kw_battery)}</div>
            ${this._expertOn("kraftwerk") || p.kw_battery_invert ? `<div class="wxrows">${row("kwb1", "Vorzeichen umdrehen", "an, wenn Laden positiv angezeigt wird", sw("kw_battery_invert"), "Schalte das an, wenn unten „entlädt“ steht, während der Speicher bei Sonne lädt.")}</div>` : ""}
            <div class="field"><span><ha-icon icon="mdi:battery-50"></ha-icon> Ladestand (%)</span>${this._picker("kw_battery_soc", p.kw_battery_soc)}</div>
            ${p.kw_battery ? live(`${fl.soc != null ? `${fmt(fl.soc, 0)} % · ` : ""}${fl.batt == null ? "kein Wert" : fl.batt > 5 ? `entlädt ${this._kwFmt(fl.batt)}` : fl.batt < -5 ? `lädt ${this._kwFmt(-fl.batt)}` : "Ruhe"}`, "#ec4899") : ""}` };
      case "kwhome":
        return { icon: "mdi:home-lightning-bolt-outline", c: "#0ea5e9", title: "Hausverbrauch", sub: "Kraftwerk · Leistung jetzt",
          body: `<p class="muted">Leer lassen: Kraftwerk rechnet den Verbrauch aus Solar + Netz + Batterie. Nur wählen, wenn dein Wechselrichter oder Energiemanager ihn selbst misst.</p>
            <div class="field"><span><ha-icon icon="mdi:home-lightning-bolt-outline"></ha-icon> Hausverbrauch</span>${this._picker("kw_home", p.kw_home)}</div>
            ${live(`jetzt ${this._kwFmt(fl.home)} · ${fl.measured ? "gemessen" : "errechnet"}`, "#0ea5e9")}` };
      case "kwcons": {
        const ids = p.kw_consumers || [];
        // Namen entfernter Verbraucher nicht mitschleppen
        if (p.kw_names) p.kw_names = Object.fromEntries(Object.entries(p.kw_names).filter(([k, v]) => ids.includes(k) && String(v || "").trim()));
        const names = ids.length ? `<div class="lbl">Namen und Symbole</div><div class="kwnames">${ids.map((id) => `
            <label class="kwname"><span class="kc-ic"><ha-icon icon="${this._kwConsIcon(id, p)}" data-kwicon="${esc(id)}"></ha-icon></span>
              <span class="grow"><input type="text" maxlength="40" data-kwname="${esc(id)}" value="${esc(p.kw_names?.[id] || "")}" placeholder="${esc(this._entityName(id))}" ${this._admin ? "" : "disabled"}>
              <small>${esc(id)} · jetzt ${this._kwFmt(this._kwW(id))}</small></span></label>`).join("")}</div>
            <p class="muted small"><ha-icon icon="mdi:information-outline"></ha-icon>Leer lassen = Name aus Home Assistant. Das Symbol wählt Kraftwerk nach dem Namen, z. B. Wärmepumpe, Wallbox, Waschmaschine, Trockner, Spülmaschine, Kühlschrank, Herd, Heizstab, Klima, Pool, Fernseher, Server, Licht.</p>` : "";
        return { icon: "mdi:power-plug-outline", c: "#64748b", title: "Verbraucher", sub: "Kraftwerk · optional",
          body: `<p class="muted">Einzelne Geräte mit Leistungsmessung, z. B. Wärmepumpe, Wallbox, Waschmaschine oder Mess-Steckdosen. Sie erscheinen unter dem Energiefluss mit ihrem Anteil am Hausverbrauch.</p>
            <div class="field"><span><ha-icon icon="mdi:power-plug-outline"></ha-icon> Verbraucher</span>${this._picker("kw_consumers", ids)}</div>${names}` };
      }
    }
    return { icon: "mdi:help", c: "#94a3b8", title: id, body: "" };
  }

  // ---- Widget
  _w_energy(w, z) {
    const p = this._data.settings;
    if (!this._kwConfigured(p))
      return `<div class="wok" style="--c:#94a3b8"><ha-icon icon="mdi:solar-power-variant"></ha-icon>Kraftwerk noch nicht eingerichtet</div>
        ${this._admin ? `<button class="link tiny wmore" data-action="tab" data-tab="kwflow">Einrichten<ha-icon icon="mdi:chevron-right"></ha-icon></button>` : ""}`;
    const fl = this._kwFlow(p);
    const v = this._kwView(fl);
    const P = this._kwPrefs();
    const t = P?.ok ? this._kwStats("today")?.total : null;
    if (z === "s") {
      const main = fl.has.solar ? [fl.solar, "Solar"] : [fl.home, "Haus"];
      return `<div class="wbig"><span>${esc(this._kwFmt(main[0]).replace(/ (k?W)$/, ""))}<small>${/kW$/.test(this._kwFmt(main[0])) ? "kW" : "W"} ${main[1]}</small></span></div>
        <div class="wline" style="--c:${fl.grid > 5 ? "#8b5cf6" : "#10b981"}"><ha-icon icon="${fl.grid > 5 ? "mdi:transmission-tower-import" : "mdi:transmission-tower-export"}"></ha-icon>${fl.grid == null ? "–" : `${v.text["grid-s"]} ${v.text.grid}`}</div>`;
    }
    if (z === "m") {
      // Mini-Fluss: Solar → Haus → Netz (bzw. Netz → Haus), Akku darunter
      const node = (icon, val, cap, c) => `<span class="wfn" style="--c:${c}"><ha-icon icon="${icon}"></ha-icon><b>${esc(val)}</b><small>${esc(cap)}</small></span>`;
      const arrow = (on, dir = "→") => `<span class="wfa ${on ? "on" : ""}">${dir}</span>`;
      const exp = fl.grid != null && fl.grid < -5;
      return `<div class="wflow">
        ${fl.has.solar ? node("mdi:solar-power-variant", v.text.solar, "Solar", "#f59e0b") + arrow((fl.solar || 0) > 5) : ""}
        ${node("mdi:home-lightning-bolt-outline", v.text.home, "Haus", "#0ea5e9")}
        ${fl.has.grid ? (exp ? arrow(true) : arrow((fl.grid || 0) > 5, "←")) + node(exp ? "mdi:transmission-tower-export" : "mdi:transmission-tower-import", v.text.grid, exp ? "Einspeisung" : "Bezug", exp ? "#10b981" : "#8b5cf6") : ""}
      </div>
      ${fl.has.batt ? `<div class="wline" style="--c:#ec4899"><ha-icon icon="mdi:home-battery-outline"></ha-icon>Akku ${fl.soc != null ? `${fmt(fl.soc, 0)} %` : ""}${fl.batt > 5 ? ` · entlädt ${esc(v.text.batt)}` : fl.batt < -5 ? ` · lädt ${esc(v.text.batt)}` : ""}</div>` : ""}
      ${t ? `<div class="wline" style="--c:#10b981"><ha-icon icon="mdi:calendar-today"></ha-icon>Heute ${t.solar ? `${this._kwKwh(t.solar)} erzeugt · ` : ""}${t.autark != null ? `${fmt(t.autark, 0)} % selbst` : ""}</div>` : ""}`;
    }
    if (z === "m-alt") {
      const mini = (icon, val, cap, c) => `<div class="wmini" style="--c:${c}"><ha-icon icon="${icon}" style="color:${c}"></ha-icon><b>${esc(val)}</b><small>${esc(cap)}</small></div>`;
      return `<div class="wminis four">
        ${fl.has.solar ? mini("mdi:solar-power-variant", v.text.solar, "Solar", "#f59e0b") : ""}
        ${fl.has.grid ? mini(fl.grid > 5 ? "mdi:transmission-tower-import" : "mdi:transmission-tower-export", v.text.grid, v.text["grid-s"], fl.grid > 5 ? "#8b5cf6" : "#10b981") : ""}
        ${mini("mdi:home-lightning-bolt-outline", v.text.home, "Haus", "#0ea5e9")}
        ${fl.has.batt ? mini("mdi:home-battery-outline", fl.soc != null ? `${fmt(fl.soc, 0)} %` : v.text.batt, fl.batt > 5 ? "entlädt" : fl.batt < -5 ? "lädt" : "Batterie", "#ec4899") : ""}
      </div>${t ? `<div class="wline" style="--c:#10b981"><ha-icon icon="mdi:calendar-today"></ha-icon>Heute ${t.solar ? `${this._kwKwh(t.solar)} erzeugt · ` : ""}${t.autark != null ? `${fmt(t.autark, 0)} % autark` : `${this._kwKwh(t.use)} verbraucht`}</div>` : ""}`;
    }
    return `<div class="wsplit"><div>${this._kwDiagram(fl, true)}</div><div>${t ? this._kwKpis(t, P) : `<p class="muted small">Tageswerte kommen aus dem Energie-Dashboard von Home Assistant.</p>`}</div></div>`;
  }

  // ------------------------------------------------------------ Rollwerk
  _rwCovers() {
    return (this._data?.settings?.rw_covers || []).map((id) => ({ id, st: this._hass.states[id], cfg: this._data.rollwerk?.covers?.[id] || {}, rs: this._rwStatus?.covers?.[id] || {} }));
  }

  /** Hat sich ein Rollladen in Home Assistant geändert (Zustand oder Stellung)? */
  _rwChanged(hass) {
    const ids = this._data?.settings?.rw_covers || [];
    const sig = ids.map((id) => { const st = hass.states[id]; return st ? `${st.state}:${st.attributes?.current_position ?? ""}` : "-"; }).join("|");
    if (sig === this._rwSig) return false;
    this._rwSig = sig;
    return true;
  }

  /** Pop-up „Höhe einstellen“: Fenster zum Ziehen, Behanghöhen aus dem Profil, hoch/Stopp/runter. */
  _rwPosPop(id) {
    const c = this._rwCovers().find((x) => x.id === id) || { id, st: this._hass.states[id], cfg: {}, rs: {} };
    const bad = !c.st || ["unavailable", "unknown"].includes(c.st.state);
    const cur = this._rwPos(c.st);
    const want = this._pop?.draft?.pos;
    const v = want ?? cur ?? 0;
    const moving = c.st?.state === "opening" ? "fährt hoch" : c.st?.state === "closing" ? "fährt runter" : "";
    const txt = (x) => (x >= 100 ? "offen" : x <= 0 ? "zu" : `${fmt(x, 0)} % offen`);
    const presets = RW_HEIGHTS;
    const auto = c.cfg.auto !== false;
    return {
      icon: "mdi:window-shutter", c: "#0ea5e9", title: this._entityName(id), sub: `Rollwerk · Höhe einstellen`,
      body: `
        <div class="rwpos">
          <div class="rwwin ${bad ? "off" : ""}" data-rwwin="${esc(id)}" style="--v:${v}" role="slider" aria-label="Höhe" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${v}" tabindex="0">
            <div class="rwwin-glass"></div>
            <div class="rwwin-sh"><i></i></div>
            ${presets.map(([n, pv]) => `<span class="rwwin-mark" style="--m:${pv}" title="${esc(n)} · ${fmt(pv, 0)} %"></span>`).join("")}
            <span class="rwwin-val">${fmt(v, 0)} %</span>
          </div>
          <div class="rwpos-side">
            <div class="rwpos-now"><b>${bad ? "nicht erreichbar" : want != null && want !== cur ? `fährt auf ${txt(want)}` : moving || (cur == null ? esc(c.st.state) : txt(cur))}</b>
              <small>${want != null && cur != null && want !== cur ? `gerade ${txt(cur)}` : "Zum Verstellen im Fenster ziehen oder eine Höhe wählen."}</small></div>
            <div class="rwpos-btns">
              <button class="sbtn" data-action="rw-cmd" data-ids="${esc(id)}" data-a="open" title="hoch" ${bad ? "disabled" : ""}><ha-icon icon="mdi:arrow-up"></ha-icon></button>
              <button class="sbtn" data-action="rw-cmd" data-ids="${esc(id)}" data-a="stop" title="Stopp" ${bad ? "disabled" : ""}><ha-icon icon="mdi:stop"></ha-icon></button>
              <button class="sbtn" data-action="rw-cmd" data-ids="${esc(id)}" data-a="close" title="runter" ${bad ? "disabled" : ""}><ha-icon icon="mdi:arrow-down"></ha-icon></button>
            </div>
          </div>
        </div>
        <div class="sub-h"><ha-icon icon="mdi:tune-vertical"></ha-icon>Behanghöhe</div>
        <div class="rwpre">${presets.map(([n, pv, ic]) => `<button class="rwpre-b ${Math.abs(v - pv) <= 2 ? "on" : ""}" data-action="rwpos-go" data-id="${esc(id)}" data-v="${pv}" ${bad ? "disabled" : ""}>
          <ha-icon icon="${ic}"></ha-icon><span><span class="rwpre-n">${esc(n)}</span><b>${fmt(pv, 0)} %</b></span></button>`).join("")}</div>
        ${auto ? `<p class="muted small"><ha-icon icon="mdi:hand-back-right-outline"></ha-icon>${c.rs.manual ? "Von Hand verstellt – die Automatik wartet bis zum nächsten Wechsel." : "Von Hand verstellt, wartet die Automatik danach bis zum nächsten Wechsel."}</p>
          ${c.rs.manual ? `<button class="secondary" data-action="rw-cmd" data-ids="${esc(id)}" data-a="resume"><ha-icon icon="mdi:robot-outline"></ha-icon>Automatik übernimmt</button>` : ""}`
          : `<p class="muted small"><ha-icon icon="mdi:robot-off-outline"></ha-icon>Automatik für diesen Rollladen ist aus.</p>`}
`,
      foot: `<button class="secondary" data-action="pop-close">Fertig</button>`,
    };
  }

  /** Rollladen auf eine Höhe fahren (aus dem Pop-up). */
  _rwPosGo(id, v) {
    v = Math.max(0, Math.min(100, Math.round(v)));
    if (this._pop) this._pop.draft = { ...(this._pop.draft || {}), pos: v, at: Date.now() };
    this._renderPop();
    return this._ws({ type: "hauswerk/rollwerk/command", entity_ids: [id], action: "position", position: v });
  }

  /** Im Fenster ziehen: Höhe folgt dem Finger, gefahren wird beim Loslassen. */
  _rwWinDrag(e) {
    const win = e.composedPath().find((n) => n.dataset?.rwwin !== undefined);
    if (!win || win.classList.contains("off")) return;
    e.preventDefault();
    const rect = win.getBoundingClientRect();
    const at = (y) => Math.max(0, Math.min(100, Math.round((1 - (y - rect.top) / rect.height) * 100 / 5) * 5));
    let v = at(e.clientY);
    const show = () => {
      win.style.setProperty("--v", v);
      win.setAttribute("aria-valuenow", v);
      const lab = win.querySelector(".rwwin-val");
      if (lab) lab.textContent = `${v} %`;
    };
    this._rwDragging = true;
    show();
    const move = (ev) => { v = at(ev.clientY); show(); };
    const up = () => {
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
      window.removeEventListener("pointercancel", up);
      this._rwDragging = false;
      this._rwPosGo(win.dataset.rwwin, v);
    };
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);
    window.addEventListener("pointercancel", up);
  }

  _rwPos(st) {
    if (!st) return null;
    const p = Number(st.attributes?.current_position);
    return Number.isFinite(p) ? p : st.state === "open" ? 100 : st.state === "closed" ? 0 : null;
  }

  _kwNavHtml() {
    return `<nav class="heatnav">${KW_VIEWS.map((v) => `<button class="hnav ${this._tab === v.id ? "on" : ""}" data-action="tab" data-tab="${v.id}"><ha-icon icon="${v.icon}"></ha-icon><span>${v.name}</span></button>`).join("")}</nav>`;
  }

  /** Mini-Fenster mit Stellung; Marke = wohin die Automatik fahren würde (wenn es abweicht). */
  _rwWin(c, p, cls = "") {
    const want = c.rs?.want;
    const mark = c.cfg?.auto !== false && want != null && p != null && Math.abs(want - p) > 3;
    return `<span class="rwm-win ${cls}" style="--v:${p ?? 0}${mark ? `;--t:${want}` : ""}" ${mark ? `title="Automatik will ${want >= 100 ? "offen" : want === 0 ? "zu" : `${want} %`}"` : ""}><i></i>${mark ? "<em></em>" : ""}</span>`;
  }

  /** Zusatz-Infos einer Rollladen-Kachel, wichtigstes zuerst: [icon, Text, Farbe, Titel]. */
  _rwInfo(c) {
    const S = this._hass?.states || {};
    const rs = c.rs || {};
    const out = [];
    const ago = (iso) => { const m = Math.round((Date.now() - new Date(iso)) / 60000); return m < 60 ? `${Math.max(1, m)} Min.` : m < 1440 ? `${Math.floor(m / 60)} Std.` : `${Math.floor(m / 1440)} Tg.`; };
    // Gerät: nur wenn auffällig
    const dev = rs.dev || {};
    const low = Number(this._data?.settings?.battery_low ?? 20);
    if (dev.battery != null && dev.battery <= low) out.push(["mdi:battery-alert-variant-outline", `Batterie ${dev.battery} %`, "#ef4444", "Batterie am Rollladen schwach"]);
    if (dev.weak) out.push(["mdi:wifi-strength-1-alert", "Funk schwach", "#f59e0b", `Signal ${dev.signal}`]);
    // Fenster/Tür und Raum aus Heizwerk
    const ct = rs.contacts || {};
    const opened = [...(ct.open || []), ...(ct.tilted || [])].filter((e) => ["on", "open", "opening", "tilted"].includes(S[e]?.state));
    const temp = rs.room_temp != null ? `${fmt(rs.room_temp)} °C` : "";
    if (opened.length || rs.contact_open || rs.contact_tilted) {
      const since = opened.map((e) => S[e]?.last_changed).filter(Boolean).sort()[0];
      const door = rs.contact_open;
      out.push([door ? "mdi:door-open" : "mdi:window-open-variant", `${door ? "offen" : "gekippt"}${since ? ` seit ${ago(since)}` : ""}${temp ? ` · ${temp}` : ""}`, door ? C.sun : C.air, opened.map((e) => this._entityName(e)).join(", ")]);
    } else if (temp) out.push(["mdi:thermometer", temp, "", rs.room?.name ? `Raum ${rs.room.name}` : "Raumtemperatur"]);
    // Sonne aufs Fenster bzw. Beschattung später
    const tl = this._rwStatus?.timelines?.[rs.profile || c.cfg?.profile || "standard"] || {};
    const nowHm = new Date().toTimeString().slice(0, 5);
    if (rs.sun_on) out.push(["mdi:white-balance-sunny", rs.shading ? "Sonne – beschattet" : "Sonne aufs Fenster", "#f59e0b", "Die Sonne steht gerade in der Fensterrichtung des Profils"]);
    else {
      // nur, wenn die Außentemperatur-Bedingung der Beschattung gerade erfüllt ist (sonst ganz ausblenden)
      const next = rs.shade_temp_ok === true && rs.shade_likely !== false ? (tl.shade || []).find(([a]) => a && a > nowHm) : null;
      if (next) out.push(["mdi:weather-sunny", `Beschattung ab ${next[0]}`, "#f97316", `voraussichtlich ${next[0]}–${next[1]}`]);
    }
    // letzte Fahrt
    const last = rs.last;
    if (last?.at) {
      const d = new Date(last.at * 1000);
      const today = d.toDateString() === new Date().toDateString();
      const t = `${today ? "" : `${d.toLocaleDateString("de-DE", { weekday: "short" })} `}${d.toLocaleTimeString("de-DE", { hour: "2-digit", minute: "2-digit" })}`;
      const dir = last.pos == null ? "" : last.pos >= 95 ? "↑" : last.pos <= 5 ? "↓" : `→ ${last.pos} %`;
      const why = last.by === "hand" ? "von Hand" : last.by === "panel" ? "im Panel" : String(last.why || "");
      out.push(["mdi:history", `${t} ${dir} · ${why.length > 26 ? `${why.slice(0, 25)}…` : why}`.replace(/\s+/g, " ").trim(), last.by === "auto" ? "" : "#8b5cf6", `Letzte Fahrt: ${why}`]);
    }
    // Lamellen
    const tilt = c.st?.attributes?.current_tilt_position;
    if (tilt != null) out.push(["mdi:blinds-horizontal", `Lamellen ${fmt(tilt, 0)} %`, "", "Lamellenstellung"]);
    // Profil
    const prof = this._data?.rollwerk?.profiles?.[rs.profile || c.cfg?.profile || "standard"];
    if (prof?.name) out.push(["mdi:tune-variant", prof.name, "", "Profil"]);
    return out;
  }

  /** Felder „Öffnet“ / „Stufe 1“ / „Schließt“: nur die berechnete Uhrzeit, sonst ein neutraler Platzhalter. */
  _rwTimes(c) {
    const t = c.rs?.times;
    if (!t) return "";
    const feats = new Set(this._rwProfOf(c)?.features ?? ["up", "down"]);
    const field = (key, label, icon) => {
      const v = t[key];
      return `<span class="rw-t" data-rwt="${key}" title="${v ? `${label}${v.tomorrow ? " morgen" : ""} um ${v.at} Uhr` : `${label}: keine Uhrzeit vorhersagbar`}"><small><ha-icon icon="${icon}"></ha-icon>${label}${v?.tomorrow ? " morgen" : ""}</small><b>${v ? `${v.at} Uhr` : "–"}</b></span>`;
    };
    const parts = [];
    if (feats.has("up")) parts.push(field("open", "Öffnet", "mdi:arrow-up"));
    if (t.stage1) parts.push(field("stage1", "Stufe 1", "mdi:arrow-collapse-down"));
    if (feats.has("down")) parts.push(field("close", "Schließt", "mdi:arrow-down"));
    return parts.length ? `<div class="rw-times">${parts.join("")}</div>` : "";
  }

  _rwProfOf(c) {
    const pid = c.rs?.profile || c.cfg?.profile || "standard";
    return this._data?.rollwerk?.profiles?.[pid] || this._data?.rollwerk?.profiles?.standard || { features: ["up", "down"] };
  }

  /** „16:30 schließt“ → kurze Form mit Pfeil für die kompakte Kachel. */
  _rwNextShort(next) {
    if (!next) return "";
    const m = String(next).match(/(\d{1,2}:\d{2})\s+(.*)$/);
    if (!m) return "";
    const what = m[2];
    const icon = /öffnet/.test(what) ? "mdi:arrow-up" : /schließt|Stufe/.test(what) ? "mdi:arrow-down" : /Beschattung möglich/.test(what) ? "mdi:weather-sunny" : /Beschattung endet/.test(what) ? "mdi:weather-sunny-off" : "mdi:clock-outline";
    return `${m[1]}<ha-icon icon="${icon}"></ha-icon>`;
  }

  _rwNavHtml() {
    return `<nav class="heatnav">${SHUT_VIEWS.map((v) => `<button class="hnav ${this._tab === v.id ? "on" : ""}" data-action="tab" data-tab="${v.id}"><ha-icon icon="${v.icon}"></ha-icon><span>${v.name}</span></button>`).join("")}</nav>`;
  }

  _viewShutters() {
    const covers = this._rwCovers();
    const s = this._rwStatus || {};
    if (!this._data.rollwerk) return `<section class="card empty"><ha-icon icon="mdi:window-shutter-alert"></ha-icon><h2>Rollwerk nicht geladen</h2><p>Bitte Home Assistant neu starten.</p></section>`;
    if (!covers.length)
      return `<section class="card empty"><ha-icon icon="mdi:window-shutter"></ha-icon><h2>Noch keine Rollläden</h2>
        <p>Wähle die Rollläden, die Rollwerk fahren soll – morgens auf, abends zu, Sonnenschutz, Lüften und Sturmschutz.</p>
        ${this._admin ? `<button class="primary" data-action="cwiz-open"><ha-icon icon="mdi:auto-fix"></ha-icon>Rollladen hinzufügen</button>` : ""}</section>`;
    const pos = covers.map((c) => this._rwPos(c.st)).filter((x) => x != null);
    const nOpen = pos.filter((x) => x >= 95).length;
    const nClosed = pos.filter((x) => x <= 5).length;
    const sun = s.sun || {};
    const fact = (icon, val, cap, c = "") => `<div class="kv2" ${c ? `style="--c:${c}"` : ""}><ha-icon icon="${icon}"></ha-icon><span><b>${esc(val)}</b><small>${esc(cap)}</small></span></div>`;
    const all = covers.map((c) => c.id).join(",");
    const first = (covers.find((c) => (c.cfg.profile || "standard") === "standard") || covers[0])?.rs || {};
    const head = this._rwBrief({ covers, s, all, first, nOpen, nClosed, pos });
    const groups = new Map();
    for (const c of covers) {
      const area = c.rs.area || "Ohne Raum";
      if (!groups.has(area)) groups.set(area, []);
      groups.get(area).push(c);
    }
    const tile = (c, areaLabel = "") => {
      const p = this._rwPos(c.st);
      const bad = !c.st || ["unavailable", "unknown"].includes(c.st.state);
      const moving = c.st?.state === "opening" ? "fährt hoch" : c.st?.state === "closing" ? "fährt runter" : "";
      const posTxt = bad ? "nicht erreichbar" : moving || (p == null ? c.st.state : p >= 95 ? "offen" : p <= 5 ? "zu" : `${fmt(p, 0)} % offen`);
      const flags = [];
      const cat = c.rs.cat;
      if (cat === "storm") flags.push(["mdi:weather-windy-variant", "Sturmschutz", "#ef4444"]);
      else if (cat === "force") flags.push(["mdi:gesture-tap-button", "Erzwungen", "#ef4444"]);
      else if (c.rs.contact_open) flags.push(["mdi:door-open", "offen – Aussperrschutz", "#f59e0b"]);
      else if (c.rs.contact_tilted) flags.push(["mdi:window-open-variant", "gekippt – lüften", "#22c55e"]);
      else if (cat === "shading") flags.push(["mdi:sun-thermometer-outline", "Beschattung", "#f97316"]);
      else if (cat === "away") flags.push(["mdi:home-export-outline", "niemand zu Hause", "#94a3b8"]);
      if (c.rs.resident) flags.push(["mdi:sleep", "Bewohner schläft", "#a78bfa"]);
      if (c.rs.manual) flags.push(["mdi:hand-back-right-outline", c.rs.blocked ? "von Hand – Automatik wartet" : "von Hand", "#8b5cf6"]);
      if (c.cfg.auto === false) flags.push(["mdi:robot-off-outline", "Automatik aus", "#94a3b8"]);
      const icon = bad ? "mdi:window-shutter-alert" : p != null && p >= 95 ? "mdi:window-shutter-open" : "mdi:window-shutter";
      const info = bad ? [] : this._rwInfo(c);
      const infoHtml = info.map(([i, t, k, tt]) => `<span ${k ? `style="--c:${k}" class="on"` : ""} title="${esc(tt || t)}"><ha-icon icon="${i}"></ha-icon>${esc(t)}</span>`).join("");
      const why = c.rs.reason && c.cfg.auto !== false ? `Automatik: ${c.rs.reason}${c.rs.target != null ? ` → ${c.rs.target >= 100 ? "offen" : c.rs.target === 0 ? "zu" : `${c.rs.target} %`}` : ""}` : "";
      return `
        <article class="card rw-c ${bad ? "bad" : ""}" data-action="pop-open" data-pop="rwpos:${esc(c.id)}" role="button" tabindex="0" title="Höhe einstellen">
          <div class="rw-top">
            ${bad ? `<span class="sr-ic" style="--c:#64748b"><ha-icon icon="${icon}"></ha-icon></span>` : this._rwWin(c, p, "big")}
            <span class="grow">${areaLabel ? `<small class="rw-al">${esc(areaLabel)}</small>` : ""}<b>${esc(this._entityName(c.id))}</b><small>${esc(posTxt)}${why ? ` · ${esc(why)}` : ""}</small></span>
            ${this._admin ? `<button class="icon" data-action="pop-open" data-pop="rwc:${esc(c.id)}" title="Einstellungen dieses Rollladens"><ha-icon icon="mdi:cog-outline"></ha-icon></button>` : ""}
          </div>
          ${c.cfg.auto !== false && this._rwStatus?.timelines?.[c.cfg.profile || "standard"] ? `<div class="rw-next">${this._rwDayBar(this._rwStatus.timelines[c.cfg.profile || "standard"], true, c.rs.shade_likely !== false)}${this._rwTimes(c)}</div>` : ""}
          ${flags.length ? `<div class="rw-flags">${flags.map(([i, l, k]) => `<span style="--c:${k}"><ha-icon icon="${i}"></ha-icon>${l}</span>`).join("")}${c.rs.manual ? `<button class="link" data-action="rw-cmd" data-ids="${esc(c.id)}" data-a="resume"><ha-icon icon="mdi:robot-outline"></ha-icon>Automatik übernimmt</button>` : ""}</div>` : ""}
          ${info.length && !this._tablet ? `<div class="rw-info">${infoHtml}</div>` : ""}
          <div class="rw-ctl">
            <button class="sbtn" data-action="rw-cmd" data-ids="${esc(c.id)}" data-a="open" title="hoch" ${bad ? "disabled" : ""}><ha-icon icon="mdi:arrow-up"></ha-icon></button>
            <button class="sbtn" data-action="rw-cmd" data-ids="${esc(c.id)}" data-a="stop" title="Stopp" ${bad ? "disabled" : ""}><ha-icon icon="mdi:stop"></ha-icon></button>
            <button class="sbtn" data-action="rw-cmd" data-ids="${esc(c.id)}" data-a="close" title="runter" ${bad ? "disabled" : ""}><ha-icon icon="mdi:arrow-down"></ha-icon></button>
            ${this._tablet && info.length ? `<span class="rw-info in-ctl">${infoHtml}</span>` : `<span class="rw-h" data-rwh="${esc(c.id)}"><ha-icon icon="mdi:arrow-expand-vertical"></ha-icon>Behanghöhe <b>${p != null && !bad ? `${fmt(p, 0)} %` : "–"}</b></span>`}
          </div>
        </article>`;
    };
    // kompakt: Name, Stellung als Balken, ↑ ↓ – Tipp öffnet „Höhe einstellen“
    const mini = (c) => {
      const p = this._rwPos(c.st);
      const bad = !c.st || ["unavailable", "unknown"].includes(c.st.state);
      const moving = c.st?.state === "opening" ? "fährt hoch" : c.st?.state === "closing" ? "fährt runter" : "";
      const flag = c.rs.cat === "storm" ? ["mdi:weather-windy-variant", "#ef4444"] : c.rs.contact_open ? ["mdi:door-open", "#f59e0b"] : c.rs.cat === "shading" ? ["mdi:sun-thermometer-outline", "#f97316"]
        : c.rs.manual ? ["mdi:hand-back-right-outline", "#8b5cf6"] : c.rs.contact_tilted ? ["mdi:window-open-variant", C.air] : c.cfg.auto === false ? ["mdi:robot-off-outline", "#94a3b8"] : null;
      return `
        <article class="card rw-m ${bad ? "bad" : ""}" data-action="pop-open" data-pop="rwpos:${esc(c.id)}" role="button" tabindex="0" title="Höhe einstellen">
          <div class="rwm-top"><b>${esc(this._entityName(c.id))}</b>${flag ? `<ha-icon icon="${flag[0]}" style="color:${flag[1]}"></ha-icon>` : ""}</div>
          <div class="rwm-pos">${this._rwWin(c, p)}<b>${bad ? "–" : moving || (p == null ? "" : `${fmt(p, 0)} %`)}</b>${c.cfg.auto !== false && this._rwNextShort(c.rs.next) ? `<small class="rwm-nx" title="Als Nächstes: ${esc(c.rs.next)}">${this._rwNextShort(c.rs.next)}</small>` : ""}</div>
          <div class="rwm-ctl">
            <button class="sbtn" data-action="rw-cmd" data-ids="${esc(c.id)}" data-a="open" title="hoch" ${bad ? "disabled" : ""}><ha-icon icon="mdi:arrow-up"></ha-icon></button>
            <button class="sbtn" data-action="rw-cmd" data-ids="${esc(c.id)}" data-a="close" title="runter" ${bad ? "disabled" : ""}><ha-icon icon="mdi:arrow-down"></ha-icon></button>
          </div>
        </article>`;
    };
    const compact = this._rwView() === "compact";
    const tog = `<div class="shead outer"><ha-icon icon="mdi:window-shutter"></ha-icon><h3>Rollläden</h3><span class="count">${covers.length}</span><span class="grow"></span>
      <div class="vtog" role="group" aria-label="Ansicht">
        <button class="${compact ? "" : "on"}" data-action="rw-view" data-v="detail" title="Detailliert"><ha-icon icon="mdi:view-agenda-outline"></ha-icon><span>Detailliert</span></button>
        <button class="${compact ? "on" : ""}" data-action="rw-view" data-v="compact" title="Kompakt"><ha-icon icon="mdi:view-grid-outline"></ha-icon><span>Kompakt</span></button>
      </div></div>`;
    // Tabletmodus, detailliert: ein gemeinsames Raster (2 Reihen je Seite, wie die Heizwerk-Räume), Raum steht in der Kachel
    if (this._tablet && !compact) {
      const sorted = [...groups.entries()].sort((a, b) => a[0].localeCompare(b[0], "de"));
      return head + tog + `<div class="rw-grid tgrid">${sorted.map(([area, list]) => list.map((c) => tile(c, area)).join("")).join("")}</div>`;
    }
    return head + tog + [...groups.entries()].sort((a, b) => a[0].localeCompare(b[0], "de"))
      .map(([area, list]) => `<div class="rw-area ${compact ? "compact" : ""}"><h3>${esc(area)}</h3><div class="rw-grid ${compact ? "compact" : ""}">${list.map((c) => (compact ? mini(c) : tile(c))).join("")}</div></div>`).join("");
  }

  /** Rollwerk-Lage: Sturm, nächste Fahrt, was abweicht. */
  _rwBrief({ covers, s, all, first, nOpen, nClosed, pos }) {
    const now = new Date();
    const nowMin = now.getHours() * 60 + now.getMinutes();
    const name = (c) => this._entityName(c.id);
    const list = (cs) => (cs.length > 2 ? `${cs.length} Rollläden` : cs.map(name).join(" und "));
    const coverAct = (c) => `data-action="pop-open" data-pop="rwpos:${esc(c.id)}"`;
    let tone = "ok", icon = "mdi:check-circle-outline", title;
    // nächste Fahrt: „16:50 schließt“ je Rollladen, gleiche zusammengefasst
    const nexts = new Map();
    for (const c of covers) {
      const m = /(\d{1,2}):(\d{2}) (.+)$/.exec(c.rs?.next || "");
      if (!m) continue;
      const at = Number(m[1]) * 60 + Number(m[2]);
      const key = `${at}|${m[3]}`;
      if (!nexts.has(key)) nexts.set(key, { at, what: m[3], approx: (c.rs.next || "").startsWith("ca."), covers: [] });
      nexts.get(key).covers.push(c);
    }
    const nx = [...nexts.values()].filter((x) => x.at > nowMin).sort((a, b) => a.at - b.at)[0];
    const hm = (m) => `${String(Math.floor(m / 60)).padStart(2, "0")}:${String(m % 60).padStart(2, "0")}`;
    const shading = covers.filter((c) => c.rs.cat === "shading");
    const manual = covers.filter((c) => c.rs.manual);
    if (s.storm) { tone = "warn"; icon = "mdi:weather-windy-variant"; title = `Sturm – alle Rollläden oben${s.gust != null ? ` (Böen ${fmt(s.gust, 0)} km/h)` : ""}`; }
    else if (nx) {
      tone = shading.length ? "active" : manual.length ? "hand" : "ok";
      icon = /schließt|Stufe/.test(nx.what) ? "mdi:arrow-down-circle-outline" : /öffnet/.test(nx.what) ? "mdi:arrow-up-circle-outline" : "mdi:sun-thermometer-outline";
      title = `${nx.approx ? "Ca. " : ""}${nx.approx ? "um" : "Um"} ${hm(nx.at)} ${nx.what} – ${list(nx.covers)} (${this._inMin(nx.at - nowMin)})`;
    } else {
      tone = shading.length ? "active" : manual.length ? "hand" : "calm";
      icon = "mdi:weather-night";
      title = `Heute keine Fahrten mehr${first.up ? ` – morgen öffnet ab ${first.up[0]}` : ""}`;
    }
    const lines = [];
    if (shading.length) {
      const sun = s.sun || {};
      lines.push({ icon: "mdi:sun-thermometer-outline", c: "#f97316", text: `Beschattung: ${list(shading)}${sun.elevation != null ? ` – Sonne ${fmt(sun.elevation, 0)}° hoch, Richtung ${fmt(sun.azimuth, 0)}°` : ""}`, act: coverAct(shading[0]) });
    }
    for (const c of manual.slice(0, 2)) {
      const p = this._rwPos(c.st);
      const until = /(\d{1,2}:\d{2})/.exec(c.rs.next || "")?.[1];
      lines.push({ icon: "mdi:hand-back-right-outline", c: "#8b5cf6", text: `${name(c)} von Hand${p != null ? ` auf ${fmt(p, 0)} %` : ""} – Automatik wartet${until ? ` bis ${until}` : ""}`, act: coverAct(c) });
    }
    for (const c of covers.filter((x) => x.rs.contact_open).slice(0, 1))
      lines.push({ icon: "mdi:door-open", c: "#f59e0b", text: `${name(c)}: Tür offen – bleibt oben`, act: coverAct(c) });
    if (!s.storm && s.gust != null && s.storm_kmh && s.gust >= 0.6 * s.storm_kmh)
      lines.push({ icon: "mdi:weather-windy", c: "#ef4444", text: `Böen ${fmt(s.gust, 0)} km/h – Sturmschutz ab ${fmt(s.storm_kmh, 0)}` });
    if (s.free_day) lines.push({ icon: "mdi:calendar-star", text: "Heute gilt der Wochenend-Zeitplan" });
    const half = pos.length - nOpen - nClosed;
    const chips = [
      ["mdi:window-shutter-open", String(nOpen), "offen", ""],
      ["mdi:window-shutter", String(nClosed), "zu", ""],
      ...(half ? [["mdi:window-shutter-settings", String(half), "halb", ""]] : []),
      ...(shading.length ? [["mdi:sun-thermometer-outline", String(shading.length), "beschattet", "#f97316"]] : []),
    ];
    const side = `<span class="br-acts">${this._admin ? `<button class="br-act" data-action="cwiz-open" title="Rollladen hinzufügen"><ha-icon icon="mdi:plus"></ha-icon></button>` : ""}<button class="br-act" data-action="rw-cmd" data-ids="${all}" data-a="open" title="Alle hoch"><ha-icon icon="mdi:arrow-up"></ha-icon><span>Alle</span></button><button class="br-act" data-action="rw-cmd" data-ids="${all}" data-a="close" title="Alle runter"><ha-icon icon="mdi:arrow-down"></ha-icon><span>Alle</span></button></span>`;
    return this._brief({ cls: "card br-mod-rw", tone, icon, label: `<ha-icon icon="mdi:window-shutter"></ha-icon>Rollwerk · jetzt`, big: `${nOpen}<span>/${covers.length} offen</span>`, title, side, lines, chips });
  }

  _rwProfiles() {
    const all = this._data.rollwerk?.profiles || {};
    return Object.entries(all).map(([id, p]) => ({ id, ...p })).sort((a, b) => (a.id === "standard" ? -1 : b.id === "standard" ? 1 : String(a.name).localeCompare(String(b.name), "de")));
  }

  _rwProfName(pid) {
    const all = this._data.rollwerk?.profiles || {};
    return (all[pid || "standard"] || all.standard || Object.values(all)[0])?.name || "Standard";
  }

  /** Wonach öffnet/schließt das Profil? time | sun | cal | free */
  _rwMode(p) {
    const f = p.features || [];
    if (!f.includes("time")) return "free";
    if (p.time_mode === "calendar") return "cal";
    return f.includes("sun") || f.includes("brightness") ? "sun" : "time";
  }

  /** Tagesleiste: Nacht, offen, Beschattung möglich, jetzt-Strich und Zeiten darunter. */
  _rwDayBar(tl, small = false, shade = true) {
    if (!tl) return "";
    if (!shade) tl = { ...tl, shade: [] };
    const m = (hm) => (hm ? Number(hm.slice(0, 2)) * 60 + Number(hm.slice(3, 5)) : null);
    const pc = (x) => `${((x / 1440) * 100).toFixed(2)}%`;
    const o = m(tl.open), c = m(tl.close);
    const from = o ?? 0, to = c ?? 1440;
    const now = new Date();
    const nowM = now.getHours() * 60 + now.getMinutes();
    const s1 = m(tl.stage1);
    const segs = [`<i class="d-day" style="left:${pc(from)};width:${pc(Math.max(0, to - from))}"></i>`]
      .concat(s1 != null ? [`<i class="d-half" style="left:${pc(s1)};width:${pc(Math.max(10, to - s1))}"></i>`] : [])
      .concat((tl.shade || []).map(([a, b]) => `<i class="d-shade" style="left:${pc(m(a))};width:${pc(Math.max(10, m(b) - m(a)))}"></i>`));
    const lab = [tl.open ? `<span style="left:${pc(o)}">${tl.approx ? "~" : ""}${tl.open}</span>` : "", s1 != null ? `<span class="s1" style="left:${pc(s1)}">${tl.stage1} · ${fmt(tl.stage1_pos ?? 50, 0)} %</span>` : "", tl.close ? `<span style="left:${pc(c)}">${tl.approx ? "~" : ""}${tl.close}</span>` : ""].join("");
    return `<div class="rwday ${small ? "small" : ""}"><div class="rwday-bar">${segs.join("")}<b class="d-now" style="left:${pc(nowM)}"></b></div>${small ? "" : `<div class="rwday-lab">${lab}</div>`}</div>`;
  }

  /** Kurztext eines Profils für Listen. */
  _rwProfSum(p) {
    const tl = this._rwStatus?.timelines?.[p.id];
    const mode = this._rwMode(p);
    const parts = [];
    if (tl?.open || tl?.close) parts.push(`heute ${tl.open || "–"} auf · ${tl.close || "–"} zu`);
    else parts.push({ time: "nach Uhrzeit", sun: "mit der Sonne", cal: "nach Kalender", free: "nur Sonne/Helligkeit" }[mode]);
    if (p.close_stage1 && (p.features || []).includes("down")) parts.push(`abends ${fmt(p.pos_stage1 ?? 50, 0)} %${p.close_stage2 !== false ? `, dann ${fmt(p.pos_close ?? 0, 0)} %` : ""}`);
    if ((p.features || []).includes("shading")) parts.push(`Sonnenschutz${p.window_dir != null ? ` (${this._rwDirName(p.window_dir)})` : ""}`);
    if (p.away_mode && p.away_mode !== "normal") parts.push("Abwesend: " + (p.away_mode === "closed" ? "zu" : "beschattet"));
    return parts.join(" · ");
  }

  _rwDirName(deg) {
    return ["Nord", "Nordost", "Ost", "Südost", "Süd", "Südwest", "West", "Nordwest"][Math.round(((Number(deg) % 360) + 360) % 360 / 45) % 8];
  }

  _rwRows(p) {
    const covers = this._rwCovers();
    const s = this._rwStatus || {};
    const profiles = this._rwProfiles();
    const rows = [
      { g: "Rollläden", id: "cwiz", icon: "mdi:auto-fix", c: "#0ea5e9", title: "Rollladen hinzufügen", sum: "Assistent: Richtung, Fensterkontakt, Raum und Profil in sechs Schritten", words: "assistent neu hinzufügen rollladen" },
      { g: "Rollläden", id: "rwcovers", icon: "mdi:window-shutter-settings", c: "#0ea5e9", title: "Welche Rollläden?",
        sum: covers.length ? `${covers.length} gewählt` : "Noch keine gewählt", warn: !covers.length, words: "rollladen rollo jalousie auswahl geräte" },
      ...covers.map((c) => ({
        g: "Rollläden", id: `rwc:${c.id}`, icon: "mdi:window-shutter", c: c.cfg.auto === false ? "#94a3b8" : "#38bdf8",
        title: this._entityName(c.id), off: c.cfg.auto === false,
        sum: (() => { const room = this._rwRoomFor(c.id); const own = c.cfg.contact_open || c.cfg.contact_tilted; const inh = this._rwRoomContacts(room);
          return [`Profil „${this._rwProfName(c.cfg.profile)}“`, room ? `Raum ${room.name}` : "", own ? "eigene Kontakte" : c.cfg.contacts !== "none" && room && (inh.open.length || inh.tilted.length) ? "Fenster aus Heizwerk" : "", c.cfg.storm === false ? "ohne Sturmschutz" : ""].filter(Boolean).join(" · "); })(),
        words: `${c.id} verhalten profil fenster tür kontakt`,
      })),
      ...profiles.map((x) => {
        const n = covers.filter((c) => (c.cfg.profile || "standard") === x.id).length;
        return { g: "Profile", id: `rwp:${x.id}:tag`, icon: "mdi:tune-variant", c: "#f59e0b", title: `${x.name} · ${n} ${n === 1 ? "Rollladen" : "Rollläden"}`,
          sum: this._rwProfSum(x), words: `verhalten profil ${x.name} zeiten sonnenschutz lüften ausnahmen` };
      }),
      { g: "Profile", id: "rwp::tag", icon: "mdi:plus", c: "#0ea5e9", title: "Neues Profil", sum: "z. B. für eine Fassade oder das Schlafzimmer – startet als Kopie von „Standard“", words: "profil verhalten neu anlegen kopie" },
      { g: "Allgemein", id: "rwstorm", icon: "mdi:weather-windy-variant", c: "#ef4444", title: "Sturmschutz",
        sum: p.rw_storm !== false ? `hoch ab ${fmt(p.storm_kmh ?? 70, 0)} km/h Böen${s.gust != null ? ` · jetzt ${fmt(s.gust, 0)} km/h` : ""}` : "Aus", words: "sturm wind böen schutz" },
      { g: "Allgemein", id: "rwrecovery", x: true, icon: "mdi:restart", c: "#64748b", title: "Nach Neustart",
        sum: { never: "nichts nachholen", outage: "verpasste Wechsel nachholen", always: "immer auf Sollstellung fahren" }[p.rw_recovery || "never"], words: "neustart stromausfall nachholen recovery" },
      { g: "Allgemein", act: "rw-log", icon: "mdi:text-box-search-outline", c: "#64748b", title: "Protokoll",
        sum: "Fahrten, Übersteuerungen von Hand und Einstellungs-Änderungen von Rollwerk", words: "protokoll log fahrten verlauf änderungen" },
      { g: "Allgemein", go: "house", icon: "mdi:home-cog-outline", c: "#94a3b8", title: "Aus Hauswerk übernommen",
        sum: "Anwesenheit, Urlaub, Feiertage, Sonnenstand, Wetter, Sturmgrenze und Böen-Sensor – gelten für alle Module", words: "anwesenheit urlaub sonne wetter feiertage hauswerk" },
    ];
    return rows;
  }

  _rwPop(id) {
    const p = this._settings;
    const { sw } = this._setHelpers(p);
    const s = this._rwStatus || {};
    const row = (k, title, sub, value, text, ctl) => this._setRow(k, title, sub, value, text, ctl);
    switch (id) {
      case "rwcovers":
        return { icon: "mdi:window-shutter-settings", c: "#0ea5e9", title: "Welche Rollläden?", sub: "Rollwerk",
          body: `<p class="muted">Gewählte Rollläden fährt Rollwerk nach ihrem Profil. Profil und Fensterkontakte stellst du danach je Rollladen ein. Gruppen wie „Alle Rollläden“ besser weglassen.</p>
            <div class="field"><span><ha-icon icon="mdi:window-shutter"></ha-icon> Rollläden</span>${this._picker("rw_covers", p.rw_covers || [])}</div>` };
      case "rwstorm":
        return { icon: "mdi:weather-windy-variant", c: "#ef4444", title: "Sturmschutz", sub: "Rollwerk · alle Rollläden",
          body: `<div class="wxrows">${row("rt0", "Sturmschutz", `hoch ab ${fmt(p.storm_kmh ?? 70, 0)} km/h Böen`, sw("rw_storm"), "Bei Sturm fahren die Rollläden hoch, damit der Behang nicht beschädigt wird, und bleiben oben, bis die Böen 15 Minuten lang unter 80 % der Grenze liegen. Je Rollladen abschaltbar.")}</div>
            <div class="rq-facts"><span style="--c:${s.storm ? "#ef4444" : "#22c55e"}"><ha-icon icon="mdi:weather-windy"></ha-icon>${s.gust != null ? `Böen jetzt ${fmt(s.gust, 0)} km/h` : "keine Windwerte"}</span>${s.storm ? `<span style="--c:#ef4444"><ha-icon icon="mdi:alert"></ha-icon>Sturmschutz aktiv</span>` : ""}</div>
            <p class="muted small"><ha-icon icon="mdi:home-cog-outline"></ha-icon>Sturmgrenze und Böen-Sensor stehen unter <button class="link inline" data-action="settings-go" data-sub="weather">Hauswerk › Wetter</button> – sie gelten für alle Module.</p>` };
      case "rwrecovery": {
        const { segs } = this._setHelpers(p);
        return { icon: "mdi:restart", c: "#64748b", title: "Nach Neustart", sub: "Rollwerk · alle Rollläden",
          body: `${segs("rw_recovery", [["never", "Nichts"], ["outage", "Verpasstes"], ["always", "Immer"]], "never")}
            <p class="muted small">„Nichts“: nach einem Neustart fährt Rollwerk erst beim nächsten Wechsel. „Verpasstes“: war Home Assistant während eines Wechsels aus (z. B. Stromausfall morgens), fährt Rollwerk das nach. „Immer“: nach jedem Neustart auf die aktuelle Sollstellung.</p>` };
      }
    }
    return { icon: "mdi:help", c: "#94a3b8", title: id, body: "" };
  }

  /** Empfohlene Werte für eine Fensterrichtung (auf 45° gerundet). */
  _rwSuggest(dir) {
    if (dir == null || dir === "") return null;
    const key = (Math.round(((Number(dir) % 360) + 360) % 360 / 45) * 45) % 360;
    const s = RW_SHADE_SUGGEST[key];
    return { ...s, dir: key, azimuth_start: (key - s.span + 360) % 360, azimuth_end: (key + s.span) % 360 };
  }

  /** Kompass: Fensterrichtung antippen; Sonnenschutz-Bereich und Sonne jetzt. */
  _rwCompass(p) {
    const cx = 110, cy = 110, R = 82;
    const pt = (deg, r) => [cx + r * Math.sin((deg * Math.PI) / 180), cy - r * Math.cos((deg * Math.PI) / 180)];
    const s0 = Number(p.azimuth_start ?? 95), s1 = Number(p.azimuth_end ?? 265);
    const span = (((s1 - s0) % 360) + 360) % 360;
    const [ax, ay] = pt(s0, R), [bx, by] = pt(s1, R);
    const sector = `<path d="M${cx},${cy} L${ax.toFixed(1)},${ay.toFixed(1)} A${R},${R} 0 ${span > 180 ? 1 : 0} 1 ${bx.toFixed(1)},${by.toFixed(1)} Z" class="cp-sec"/>`;
    const sun = this._rwStatus?.sun || {};
    const sunDot = sun.azimuth != null && sun.elevation > 0 ? (() => { const [x, y] = pt(sun.azimuth, R * (1 - Math.min(sun.elevation, 80) / 110)); return `<circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="9" class="cp-sun"/>`; })() : "";
    const dirs = [["N", 0], ["NO", 45], ["O", 90], ["SO", 135], ["S", 180], ["SW", 225], ["W", 270], ["NW", 315]];
    const btns = dirs.map(([l, d]) => { const [x, y] = pt(d, R + 16); const on = Number(p.window_dir) === d; return `<g class="cp-b ${on ? "on" : ""}" data-action="rwp-dir" data-v="${d}"><circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="15"/><text x="${x.toFixed(1)}" y="${(y + 4).toFixed(1)}">${l}</text></g>`; }).join("");
    const win = p.window_dir != null ? (() => { const [x, y] = pt(Number(p.window_dir), R - 6); return `<line x1="${cx}" y1="${cy}" x2="${x.toFixed(1)}" y2="${y.toFixed(1)}" class="cp-win"/>`; })() : "";
    return `<div class="compass"><svg viewBox="0 0 220 220" aria-label="Fensterrichtung">
      <circle cx="${cx}" cy="${cy}" r="${R}" class="cp-ring"/>${sector}${win}<rect x="${cx - 14}" y="${cy - 9}" width="28" height="18" rx="4" class="cp-house"/>${sunDot}${btns}</svg>
      <p class="muted small">${p.window_dir != null ? `Fenster zeigt nach <b>${this._rwDirName(p.window_dir)}</b> – Sonne zählt von ${fmt(s0, 0)}° bis ${fmt(s1, 0)}°.` : "Tippe an, wohin das Fenster zeigt."}${sun.azimuth != null && sun.elevation > 0 ? " ● Sonne jetzt." : ""}</p></div>`;
  }

  /** Profil bearbeiten: fünf Abschnitte, einfach oder mit „Experte“ alle Einstellungen der Cover Control Automation. */
  _rwpPop(pid, sec) {
    const d = this._pop.draft;
    const profiles = this._data.rollwerk?.profiles || {};
    if (!d.prof) {
      d.pid = pid || null;
      d.prof = clone(profiles[pid] || { ...(profiles.standard || Object.values(profiles)[0] || {}), name: "Neues Profil" });
    }
    const p = d.prof;
    const ex = this._expertOn("rollwerk");
    const dis = this._admin ? "" : "disabled";
    const S = this._hass.states;
    const st = this._rwStatus || {};
    const row = (k, title, sub, ctl, text) => text ? this._setRow(`rwp_${k}`, title, sub, ctl, text, true)
      : `<div class="wxr ctl"><div class="wxr-l"><b>${title}</b>${sub ? `<small>${sub}</small>` : ""}</div><div class="wxr-v">${ctl}</div></div>`;
    const num = (k, def, min, max, step, unit) => `<div class="unit"><input type="number" min="${min}" max="${max}" step="${step}" data-rwp="${k}" data-kind="num" value="${p[k] ?? ""}" placeholder="${def ?? "–"}" ${dis}><i>${unit}</i></div>`;
    const time = (k) => `<input type="time" data-rwp="${k}" data-kind="time" value="${esc(p[k] || RW_TIME_DEFAULTS[k] || "")}" ${dis}>`;
    const bool = (k) => `<label class="switch"><input type="checkbox" data-rwp="${k}" data-kind="bool" ${p[k] ? "checked" : ""} ${dis}><span></span></label>`;
    const feat = (f) => `<label class="switch"><input type="checkbox" data-action="rwp-feat" data-v="${f}" ${(p.features || []).includes(f) ? "checked" : ""} ${dis}><span></span></label>`;
    const text = (k) => `<input type="text" data-rwp="${k}" data-kind="text" value="${esc(p[k] || "")}" maxlength="60" ${dis}>`;
    const ent = (k, test, none = "keiner") => {
      const ids = Object.keys(S).filter((id) => test(id, S[id].attributes || {}) || id === p[k]).sort((a, b) => this._entityName(a).localeCompare(this._entityName(b), "de"));
      return `<select class="rwsel" data-rwp="${k}" data-kind="entity" ${dis}><option value="">${none}</option>${ids.map((id) => `<option value="${esc(id)}" ${p[k] === id ? "selected" : ""}>${esc(this._entityName(id))}</option>`).join("")}</select>`;
    };
    const dc = (cls, ...dom) => (id, a) => dom.some((x) => id.startsWith(`${x}.`)) && (!cls || a.device_class === cls || id.includes(cls));
    const bin = (id) => /^(binary_sensor|input_boolean|switch)\./.test(id);
    const chips = (k, opts) => `<div class="chips rwchips">${opts.map(([v, l, i]) => `<button class="chip ${(p[k] || []).includes(v) ? "on" : ""}" data-action="rwp-tog" data-k="${k}" data-v="${v}" ${dis}>${i ? `<ha-icon icon="${i}"></ha-icon>` : ""}${l}</button>`).join("")}</div>`;
    const choice = (k, opts, action = "rwp-set") => `<div class="segs small">${opts.map(([v, l, i]) => `<button class="seg ${String(k === "_mode" ? this._rwMode(p) : p[k] ?? "") === String(v) ? "on" : ""}" data-action="${action}" data-k="${k}" data-v="${v}" ${dis}>${i ? `<ha-icon icon="${i}"></ha-icon>` : ""}${l}</button>`).join("")}</div>`;
    const checks = (k, opts) => `<div class="rwchecks">${opts.map(([v, l]) => { const on = (p[k] || []).includes(v); return `<button class="rwck ${on ? "on" : ""}" data-action="rwp-tog" data-k="${k}" data-v="${v}" ${dis}><ha-icon icon="${on ? "mdi:checkbox-marked" : "mdi:checkbox-blank-outline"}"></ha-icon><span>${l}</span></button>`; }).join("")}</div>`;
    const lbl = (t) => `<div class="lbl">${t}</div>`;
    const note = (t, icon = "mdi:information-outline") => `<p class="muted small"><ha-icon icon="${icon}"></ha-icon>${t}</p>`;
    const exBox = (html) => (ex ? `<div class="rwex"><div class="rwex-h"><ha-icon icon="mdi:school-outline"></ha-icon>Experte</div>${html}</div>` : "");
    const has = (f) => (p.features || []).includes(f);
    const tok = (k, def, step, min, max, unit) => `<span class="tok"><button class="tok-b" data-action="rwp-step" data-k="${k}" data-d="${-step}" data-def="${def}" data-min="${min}" data-max="${max}" ${dis} aria-label="weniger">−</button><b>${fmt(p[k] ?? def, step < 1 ? 1 : 0)}${unit}</b><button class="tok-b" data-action="rwp-step" data-k="${k}" data-d="${step}" data-def="${def}" data-min="${min}" data-max="${max}" ${dis} aria-label="mehr">+</button></span>`;
    const meta = RW_SECTIONS.find(([x]) => x === sec) || RW_SECTIONS[0];
    const users = Object.entries(this._data.rollwerk?.covers || {}).filter(([, c]) => (c.profile || "standard") === (d.pid || "")).map(([id]) => this._entityName(id));
    let body = "";
    switch (sec) {
      case "tag": {
        const mode = this._rwMode(p);
        const win = (a, b) => (mode === "time" ? row(a, "Uhrzeit", "", time(a)) : `${row(a, "Frühestens", "", time(a))}${row(b, "Spätestens", "", time(b))}`);
        body = `${lbl("Wonach?")}${choice("_mode", [["time", "Uhrzeit", "mdi:clock-outline"], ["sun", "Mit der Sonne", "mdi:weather-sunset"], ...(ex || mode === "cal" ? [["cal", "Kalender", "mdi:calendar"]] : []), ...(ex || mode === "free" ? [["free", "Nur Sonne", "mdi:white-balance-sunny"]] : [])], "rwp-mode")}
          ${mode === "sun" ? note("Öffnet frühestens zur ersten Zeit, sobald die Sonne hoch genug steht – spätestens zur zweiten. Abends genauso andersherum.", "mdi:weather-sunset") : ""}
          <div class="rwstage"><div class="rwstage-h"><ha-icon icon="mdi:weather-sunset-up"></ha-icon><b>Morgens öffnen</b>${feat("up")}</div>
            ${has("up") ? `<p class="rwline">auf ${tok("pos_open", 100, 5, 0, 100, " %")}</p>
              ${mode !== "cal" && mode !== "free" ? `${lbl("Werktag")}<div class="wxrows">${win("up_early", "up_late")}</div>${lbl("Wochenende & Feiertag")}<div class="wxrows">${win("up_early_we", "up_late_we")}</div>` : ""}` : ""}</div>
          <div class="rwstage"><div class="rwstage-h"><ha-icon icon="mdi:weather-sunset-down"></ha-icon><b>Abends schließen</b>${feat("down")}</div>
            ${has("down") ? `
              <div class="wxrows">${row("two", "In zwei Stufen", "erst halb, später ganz zu", bool("close_stage1"))}</div>
              ${p.close_stage1 ? `
                <div class="rwsub"><div class="rwsub-h"><i>1</i><b>Stufe 1</b></div>
                  ${choice("stage1_trigger", [["azimuth", "Sonnenrichtung", "mdi:compass-outline"], ["elevation", "Sonnenhöhe", "mdi:weather-sunset"], ["time", "Uhrzeit", "mdi:clock-outline"]])}
                  <p class="rwline">${(p.stage1_trigger || "azimuth") === "azimuth" ? `sobald die Sonne ab ${tok("stage1_azimuth", 250, 5, 90, 360, "°")} steht <small class="muted">(${this._rwDirName(p.stage1_azimuth ?? 250)})</small>`
                    : p.stage1_trigger === "elevation" ? `sobald die Sonne unter ${tok("stage1_elevation", 10, 1, -10, 60, "°")} sinkt` : `um ${time("stage1_time")}`}
                    auf ${tok("pos_stage1", 50, 5, 0, 100, " %")}</p></div>
                <div class="rwsub"><div class="rwsub-h"><i>2</i><b>Stufe 2 – ganz zu</b><label class="switch"><input type="checkbox" data-rwp="close_stage2" data-kind="bool" ${p.close_stage2 !== false ? "checked" : ""} ${dis}><span></span></label></div>
                  ${p.close_stage2 !== false ? `<p class="rwline">zur spätesten Zeit auf ${tok("pos_close", 0, 5, 0, 100, " %")}</p>
                    ${mode !== "cal" ? `<div class="wxrows">${row("down_late", "Spätestens · vor Werktag", "", time("down_late"))}${row("down_late_we", "Spätestens · vor freiem Tag", "", time("down_late_we"))}</div>` : ""}`
                    : `<p class="muted small">Ohne Stufe 2 bleibt der Rollladen nachts auf Stufe 1 und öffnet morgens wieder.</p>`}</div>`
              : `<p class="rwline">auf ${tok("pos_close", 0, 5, 0, 100, " %")}</p>
                ${mode !== "cal" && mode !== "free" ? `${lbl("Vor Werktag")}<div class="wxrows">${win("down_early", "down_late")}</div>${lbl("Vor freiem Tag")}<div class="wxrows">${win("down_early_we", "down_late_we")}</div>` : ""}`}` : ""}</div>
          ${mode === "sun" || mode === "free" ? `${lbl("Sonnenhöhe")}<div class="wxrows">
            ${row("su", "Öffnen ab", "0° = Sonnenaufgang", num("sun_up", 0, -20, 60, 0.5, "°"), "Negativ = in der Dämmerung, z. B. −4°. Positiv = erst wenn die Sonne über Nachbarhäusern steht.")}
            ${p.close_stage1 ? "" : row("sd", "Schließen ab", "0° = Sonnenuntergang", num("sun_down", 0, -20, 60, 0.5, "°"))}</div>` : ""}
          ${mode === "cal" ? `<label class="field"><span><ha-icon icon="mdi:calendar"></ha-icon> Kalender</span>${ent("calendar", (id) => id.startsWith("calendar."), "–")}</label>
            <div class="wxrows">${row("co", "Termin fürs Öffnen", "Titel enthält", text("cal_open"), "Beginn = früheste, Ende = späteste Zeit.")}${row("cc", "Termin fürs Schließen", "Titel enthält", text("cal_close"))}</div>` : ""}
          ${note("Feiertage und Sonnenstand kommen aus Hauswerk › Einstellungen (Anwesenheit bzw. Wetter).", "mdi:home-cog-outline")}
          ${exBox(`${lbl("Helligkeit")}<div class="wxrows">${row("bf", "Helligkeit nutzen", "", feat("brightness"))}</div>
            ${has("brightness") ? `<label class="field"><span><ha-icon icon="mdi:brightness-5"></ha-icon> Helligkeitssensor</span>${ent("brightness_sensor", dc("illuminance", "sensor"))}</label>
            <div class="wxrows">${row("bu", "Öffnen ab", "", num("brightness_up", 0, 0, 200000, 10, "lx"))}${row("bd", "Schließen bis", "", num("brightness_down", 0, 0, 200000, 10, "lx"))}
              ${row("bh", "Spielraum", "", num("brightness_hyst", 0, 0, 10000, 10, "lx"))}${row("bt", "Mindestens so lange", "", num("brightness_duration", 30, 0, 3600, 5, "s"))}</div>` : ""}
            <div class="wxrows">${row("st", "Sonne mindestens so lange", "", num("sun_duration", 30, 0, 3600, 5, "s"))}</div>
            ${lbl("Sonne und Helligkeit verknüpfen")}${choice("bs_operator", [["or", "Eins reicht"], ["and", "Beide nötig"]])}
            <label class="field"><span><ha-icon icon="mdi:calendar-arrow-right"></ha-icon> Sensor „Arbeitstag morgen“ (fürs Schließen)</span>${ent("workday_tomorrow", (id) => id.startsWith("binary_sensor.") && /workday|arbeitstag/.test(id))}</label>`)}`;
        break;
      }
      case "shade": {
        const live = Object.entries(st.covers || {}).filter(([, c]) => c.profile === d.pid && c.shade_start);
        const sym = (v) => (v == null ? "–" : v ? "✓" : "✗");
        body = `<div class="wxrows">${row("sf", "Sonnenschutz", "tagsüber gegen Hitze und Blendung", feat("shading"))}</div>
          ${has("shading") ? `${lbl("Wohin zeigt das Fenster?")}${this._rwCompass(p)}
          ${(() => {
            const s = this._rwSuggest(p.window_dir);
            if (!s) return "";
            const keys = ["azimuth_start", "azimuth_end", "elevation_min", "elevation_max", "temp2_min", "pos_shading"];
            const same = keys.every((k) => Number(p[k]) === Number(s[k]));
            return `<div class="rwsug ${same ? "ok" : ""}"><div class="rwsug-h"><ha-icon icon="${same ? "mdi:check-decagram" : "mdi:lightbulb-on-outline"}"></ha-icon><b>Empfehlung für ${this._rwDirName(s.dir)}fenster</b></div>
              <p>${s.why}</p>
              <div class="rwsug-v"><span>Sonne ${s.azimuth_start}–${s.azimuth_end}°</span><span>Höhe ${s.elevation_min}–${s.elevation_max}°</span><span>ab ${s.temp2_min} °C außen</span><span>auf ${s.pos_shading} %</span></div>
              ${same ? `<small class="muted">Deine Einstellungen entsprechen der Empfehlung.</small>` : this._admin ? `<button class="secondary small" data-action="rwp-suggest"><ha-icon icon="mdi:auto-fix"></ha-icon>Empfehlung übernehmen</button>` : ""}</div>`;
          })()}
          ${(() => {
            const tok = (k, def, step, min, max, unit) => `<span class="tok"><button class="tok-b" data-action="rwp-step" data-k="${k}" data-d="${-step}" data-def="${def}" data-min="${min}" data-max="${max}" ${dis} aria-label="weniger">−</button><b>${fmt(p[k] ?? def, step < 1 ? 1 : 0)}${unit}</b><button class="tok-b" data-action="rwp-step" data-k="${k}" data-d="${step}" data-def="${def}" data-min="${min}" data-max="${max}" ${dis} aria-label="mehr">+</button></span>`;
            const dir = p.window_dir != null ? `<span class="tok txt">${this._rwDirName(p.window_dir)}</span>` : `<span class="tok txt warn">Richtung?</span>`;
            const sg = this._rwSuggest(p.window_dir);
            const hint = (k, unit) => (sg && Number(p[k]) !== Number(sg[k]) ? `<small class="rwhint">empfohlen ${sg[k]}${unit}</small>` : "");
            return `<div class="rwsent"><ha-icon icon="mdi:sun-thermometer-outline"></ha-icon><p>Beschatten, wenn die Sonne aufs Fenster nach ${dir} scheint, mindestens ${tok("elevation_min", 25, 5, 0, 80, "°")}${hint("elevation_min", "°")} hoch steht und es draußen wärmer als ${tok("temp2_min", 18, 1, 5, 40, " °C")}${hint("temp2_min", " °C")} ist. Der Rollladen fährt dann auf ${tok("pos_shading", 25, 5, 0, 100, " %")}${hint("pos_shading", " %")} – und wieder hoch, sobald eins davon nicht mehr stimmt.</p></div>`;
          })()}
          ${note("Außentemperatur aus Hauswerk › Wetter. Wartezeit 5 Minuten, damit kurze Sonne nichts auslöst.", "mdi:home-cog-outline")}
          ${live.length ? `${lbl("Jetzt")}<div class="evlist">${live.map(([id, c]) => `<div class="ev ${c.shading ? "live" : ""}"><ha-icon icon="${c.shading ? "mdi:sun-thermometer-outline" : "mdi:window-shutter"}"></ha-icon><span class="grow"><b>${esc(this._entityName(id))}</b><small>${RW_SHADE_CONDS.filter(([k]) => c.shade_start[k] != null).map(([k, l]) => `${l} ${sym(c.shade_start[k])}`).join(" · ")}</small></span>${c.shading ? `<em class="badge">AKTIV</em>` : ""}</div>`).join("")}</div>` : ""}
          ${exBox(`${lbl("Beschattung beginnt, wenn …")}<small class="muted">alle davon</small>${chips("shade_start_and", RW_SHADE_CONDS)}<small class="muted">eins davon</small>${chips("shade_start_or", RW_SHADE_CONDS)}
            ${lbl("Beschattung endet, wenn …")}<small class="muted">alle davon</small>${chips("shade_end_and", RW_SHADE_CONDS)}<small class="muted">eins davon</small>${chips("shade_end_or", RW_SHADE_CONDS)}
            ${note("Nicht messbare Bedingungen (kein Sensor) zählen nicht mit.")}
            <div class="wxrows">${row("az1", "Richtung von", "", num("azimuth_start", 95, 0, 360, 1, "°"))}${row("az2", "Richtung bis", "", num("azimuth_end", 265, 0, 360, 1, "°"))}
              ${row("el1", "Sonnenhöhe mindestens", "", num("elevation_min", 25, 0, 90, 1, "°"), "Tief stehende Sonne wird oft von Nachbarhäusern oder Bäumen verdeckt.")}${row("el2", "Sonnenhöhe höchstens", "", num("elevation_max", 90, 0, 90, 1, "°"))}
              ${row("t2h", "Spielraum außen", "", num("temp2_hyst", 0.2, 0, 5, 0.1, "°C"))}</div>
            <label class="field"><span><ha-icon icon="mdi:thermometer"></ha-icon> Eigener Außensensor (leer = Hauswerk › Wetter)</span>${ent("temp2_sensor", dc("temperature", "sensor"), "aus Hauswerk › Wetter")}</label>
            <label class="field"><span><ha-icon icon="mdi:home-thermometer-outline"></ha-icon> Temperatur innen (leer = Raumtemperatur aus Heizwerk)</span>${ent("temp1_sensor", dc("temperature", "sensor"), "aus dem Heizwerk-Raum")}</label>
            <div class="wxrows">${row("t1", "Innen ab", "", num("temp1_min", 18, 0, 40, 0.5, "°C"))}${row("t1h", "Spielraum innen", "", num("temp1_hyst", 0.2, 0, 5, 0.1, "°C"))}</div>
            <label class="field"><span><ha-icon icon="mdi:brightness-5"></ha-icon> Helligkeitssensor</span>${ent("shade_brightness_sensor", dc("illuminance", "sensor"))}</label>
            <div class="wxrows">${row("sb1", "Beginnt ab", "", num("shade_bright_start", 35000, 0, 200000, 100, "lx"))}${row("sb2", "Endet unter", "", num("shade_bright_end", 25000, 0, 200000, 100, "lx"))}
              ${row("fc", "Vorhersage-Höchstwert ab", "aus Hauswerk › Wetter", num("forecast_temp", "", -10, 45, 0.5, "°C"))}</div>
            <small class="muted">Wetterlage</small>${chips("weather_conditions", RW_WEATHER)}
            <label class="field"><span><ha-icon icon="mdi:toggle-switch-outline"></ha-icon> Eigene Bedingung (an = erfüllt)</span>${ent("shade_custom", bin)}</label>
            <div class="wxrows">${row("w1", "Warten vor Beginn", "", num("shade_wait_start", 300, 0, 7200, 30, "s"))}${row("w2", "Warten vor Ende", "", num("shade_wait_end", 300, 0, 7200, 30, "s"))}
              ${row("w3", "Sofort enden", "wenn die Sonne das Fenster verlässt", bool("shade_end_immediate"))}
              ${row("pa", "Andere Stellung", "wenn der Schalter an ist", num("pos_shading_alt", "", 0, 100, 1, "%"))}</div>
            <label class="field"><span><ha-icon icon="mdi:toggle-switch-outline"></ha-icon> Schalter für andere Stellung</span>${ent("shading_alt_entity", bin)}</label>`)}` : ""}`;
        break;
      }
      case "vent": {
        const mine = Object.entries(this._data.rollwerk?.covers || {}).filter(([, c]) => (c.profile || "standard") === (d.pid || ""));
        body = `${lbl("Tür ganz offen")}${choice("pos_lockout", [["", "Nicht herunterfahren"], ["30", "Höchstens 30 %"], ["50", "Höchstens 50 %"]], "rwp-lock")}
          ${note("So sperrt dich die Terrassentür nicht aus. Hochfahren geht immer.", "mdi:door-open")}
          <div class="wxrows">${row("vf", "Fenster gekippt: lüften", "Rollladen auf Lüftungsstellung", feat("ventilate"))}${has("ventilate") ? row("pv", "Lüftungsstellung", "", num("pos_ventilate", 30, 0, 100, 5, "%")) : ""}</div>
          ${lbl("Kontakte")}${mine.length ? `<div class="evlist">${mine.map(([id, c]) => `<div class="ev"><ha-icon icon="mdi:window-shutter"></ha-icon><span class="grow"><b>${esc(this._entityName(id))}</b><small>${(() => { const own = c.contact_open || c.contact_tilted; const k = own ? { open: [c.contact_open].filter(Boolean), tilted: [c.contact_tilted].filter(Boolean) } : c.contacts === "none" ? { open: [], tilted: [] } : this._rwRoomContacts(this._rwRoomFor(id));
              return [k.open.length ? `offen: ${k.open.map((e) => esc(this._entityName(e))).join(", ")}` : "", k.tilted.length ? `gekippt: ${k.tilted.map((e) => esc(this._entityName(e))).join(", ")}` : ""].filter(Boolean).join(" · ") + (!own && (k.open.length || k.tilted.length) ? " · aus Heizwerk" : "") || "kein Kontakt"; })()}</small></span><button class="link" data-action="pop-open" data-pop="rwc:${esc(id)}">ändern</button></div>`).join("")}</div>` : note("Noch kein Rollladen nutzt dieses Profil.")}
          ${exBox(`${lbl("Lüften")}${checks("vent_options", RW_VENT)}${lbl("Aussperrschutz auch bei gekipptem Fenster")}${checks("lockout_tilted", RW_LOCK_TILTED)}`)}`;
        break;
      }
      case "exc": {
        const manual = !(p.manual_block || []).length ? "next" : (p.manual_reset || []).includes("timeout") ? "hours" : "night";
        body = `${lbl("Wenn niemand zu Hause ist")}${choice("away_mode", [["normal", "Wie immer"], ["closed", "Tagsüber zu"], ["shade", "Beschattet"]])}
          <div class="rq-facts"><span style="--c:${st.away ? "#94a3b8" : "#22c55e"}"><ha-icon icon="${st.away ? "mdi:home-export-outline" : "mdi:home-account"}"></ha-icon>${st.away ? "Gerade niemand zu Hause" : "Jemand ist zu Hause"}</span>${st.vacation ? `<span style="--c:#34d399"><ha-icon icon="mdi:palm-tree"></ha-icon>Urlaub</span>` : ""}</div>
          <div class="wxrows">${row("vr", "Urlaub: Zeiten verschieben", "zufällig bis zu", num("vacation_random", 0, 0, 60, 5, "Min."), "Im Urlaub öffnet und schließt jeder Rollladen jeden Tag etwas anders – das Haus wirkt bewohnt.")}</div>
          ${note(`Wer zu Hause ist und wann Urlaub ist, stellst du einmal für alle Module ein: <button class="link inline" data-action="settings-go" data-sub="presence">Anwesenheit</button> · <button class="link inline" data-action="settings-go" data-sub="vacation">Urlaub</button>.`, "mdi:home-cog-outline")}
          ${lbl("Von Hand verstellt – Stellung bleibt …")}<div class="segs small">${[["next", "bis zum nächsten Wechsel"], ["night", "bis Mitternacht"], ["hours", "einige Stunden"]].map(([v, l]) => `<button class="seg ${manual === v ? "on" : ""}" data-action="rwp-man" data-v="${v}" ${dis}>${l}</button>`).join("")}</div>
          ${manual === "hours" ? `<div class="wxrows">${row("ro", "Wie lange", "", num("reset_timeout", 120, 5, 1440, 5, "Min."))}</div>` : ""}
          ${lbl("Schlafzimmer")}<label class="field"><span><ha-icon icon="mdi:bed-outline"></ha-icon> Schlaf-Schalter (an = schläft)</span>${ent("resident_sensor", bin)}</label>
          ${p.resident_sensor ? checks("resident_config", RW_RESIDENT) : note("Solange der Schalter an ist, öffnet der Rollladen morgens nicht – z. B. der Schlafmodus vom Handy.", "mdi:sleep")}
          ${exBox(`${lbl("Hand-Stellung bleibt bei …")}${checks("manual_block", RW_MANUAL)}${lbl("Zurücksetzen")}${checks("manual_reset", RW_RESET)}
            <div class="wxrows">${(p.manual_reset || []).includes("fixed") ? row("rt", "Uhrzeit", "", time("reset_time")) : ""}${(p.manual_reset || []).includes("in_position") ? row("rp", "In Stellung", "", num("reset_position", 100, 0, 100, 1, "%")) : ""}
              ${row("rr", "Danach gleich fahren", "auf die aktuelle Sollstellung", bool("manual_recover"))}</div>
            ${lbl("Erzwingen per Schalter")}${RW_FORCE.map(([k, l, i]) => `<label class="field"><span><ha-icon icon="${i}"></ha-icon> ${l}</span>${ent(k, bin)}</label>`).join("")}`)}`;
        break;
      }
      case "fine":
        body = `<div class="wxrows">${row("po", "Offen", "100 % = ganz offen", num("pos_open", 100, 0, 100, 1, "%"))}${row("pc", "Geschlossen", "z. B. 10 % für Lüftungsschlitze", num("pos_close", 0, 0, 100, 1, "%"))}${p.close_stage1 ? row("p1", "Abends Stufe 1", "", num("pos_stage1", 50, 0, 100, 1, "%")) : ""}${has("ventilate") ? row("pv2", "Lüften", "", num("pos_ventilate", 30, 0, 100, 1, "%")) : ""}${has("shading") ? row("ps2", "Beschattung", "", num("pos_shading", 25, 0, 100, 1, "%")) : ""}</div>
          ${exBox(`<div class="wxrows">${row("pt", "Toleranz", "", num("tolerance", 0, 0, 20, 1, "%"))}${row("pd", "Fahrzeit", "einmal ganz auf oder zu", num("drive_time", 90, 5, 300, 5, "s"))}
            ${row("df", "Verzögerung fest", "", num("delay_fix", 0, 0, 600, 1, "s"))}${row("dr", "Verzögerung zufällig bis", "", num("delay_random", 5, 0, 600, 1, "s"), "Verteilt die Fahrten, damit nicht alle Rollläden gleichzeitig funken.")}</div>
            ${lbl("Regeln im Detail")}${checks("behavior", RW_BEHAVIOR)}`)}
          ${d.pid ? note(users.length ? `Genutzt von: ${users.map(esc).join(", ")}` : "Noch kein Rollladen nutzt dieses Profil – zuordnen im Rollladen.", "mdi:window-shutter") : ""}`;
        break;
    }
    const tl = d.pid ? st.timelines?.[d.pid] : null;
    const isNew = !d.pid;
    return {
      icon: meta[2], c: meta[3], title: isNew ? "Neues Profil" : esc(p.name || ""), sub: `Profil · ${meta[1]}`,
      body: `${d.confirm ? (() => {
          const others = this._rwProfiles().filter((x) => x.id !== d.pid);
          const n = Object.values(this._data.rollwerk?.covers || {}).filter((c) => (c.profile || "standard") === d.pid).length;
          if (!d.replace) d.replace = others.find((x) => x.id === "standard")?.id || others[0]?.id;
          return `<div class="rwdel"><b><ha-icon icon="mdi:delete-alert-outline"></ha-icon>Profil „${esc(p.name || "")}“ löschen?</b>
            ${n ? `<label class="field"><span>${n} ${n === 1 ? "Rollladen nutzt" : "Rollläden nutzen"} dieses Profil und ${n === 1 ? "bekommt" : "bekommen"} dann:</span><select data-rwdel>${others.map((x) => `<option value="${esc(x.id)}" ${x.id === d.replace ? "selected" : ""}>${esc(x.name)}</option>`).join("")}</select></label>` : `<p class="muted small">Kein Rollladen nutzt dieses Profil.</p>`}
            <div class="rwdel-b"><button class="secondary" data-action="rwp-del-no">Behalten</button><button class="primary danger-bg" data-action="rwp-del"><ha-icon icon="mdi:delete-outline"></ha-icon>Löschen</button></div></div>`;
        })() : ""}<label class="field rwname"><span><ha-icon icon="mdi:form-textbox"></ha-icon> Name des Profils</span>${text("name").replace("<input ", `<input placeholder="z. B. Süd mit Hitze" `)}</label><div class="rwtop">${tl ? `<div class="grow">${this._rwDayBar(tl)}</div>` : `<span class="grow muted small">${isNew ? "Tagesleiste nach dem Anlegen" : ""}</span>`}
          <button class="rwexp ${ex ? "on" : ""}" data-action="rw-expert" title="Alle Einstellungen wie bei der Cover Control Automation"><ha-icon icon="mdi:school-outline"></ha-icon>Experte</button></div>
        <div class="rwsecs">${RW_SECTIONS.map(([x, t, i, c, f]) => `<button class="rwsec ${x === sec ? "on" : ""} ${f && !(p.features || []).includes(f) ? "off" : ""}" data-action="rwp-sec" data-sec="${x}" style="--c:${c}"><ha-icon icon="${i}"></ha-icon>${t}</button>`).join("")}</div>${body}`,
      foot: `${this._admin && d.pid && this._rwProfiles().length > 1 ? `<button class="icon boxed danger" data-action="rwp-del" title="Profil löschen" aria-label="Profil löschen"><ha-icon icon="mdi:delete-outline"></ha-icon></button>` : ""}
        <button class="secondary" data-action="pop-close">${this._admin ? "Abbrechen" : "Schließen"}</button>
        ${this._admin ? `<button class="primary" data-action="rwp-save"><ha-icon icon="mdi:content-save-outline"></ha-icon>${isNew ? "Anlegen" : "Speichern"}</button>` : ""}`,
    };
  }

  // ------------------------------------------------------------ Assistent „Rollladen hinzufügen“
  _cwizDraft() {
    return { step: 0, covers: [], contacts: {}, use: "wohnen", shade: true, temp: 24, mode: "sun", pick: null,
      prof: { window_dir: null, azimuth_start: 95, azimuth_end: 265 } };
  }

  _cwizOpen() {
    this._openPop("cwiz", this._cwizDraft());
  }

  /** Fenster- und Türkontakte im Bereich eines Rollladens: offen (Tür/Fenster) und gekippt (Name mit „kipp“/„tilt“). */
  _cwizContacts(coverId) {
    const S = this._hass.states;
    const area = this._hass.entities?.[coverId]?.area_id || this._hass.devices?.[this._hass.entities?.[coverId]?.device_id]?.area_id;
    const ids = area ? this._areaEntities(area) : [];
    const contacts = ids.filter((id) => id.startsWith("binary_sensor.") && ["door", "window", "opening", "garage_door"].includes(S[id]?.attributes?.device_class));
    const tilted = contacts.find((id) => /kipp|tilt/.test(`${id} ${S[id]?.attributes?.friendly_name || ""}`.toLowerCase()));
    const open = contacts.find((id) => id !== tilted && S[id]?.attributes?.device_class === "door") || contacts.find((id) => id !== tilted);
    return { all: contacts, open: open || null, tilted: tilted || null };
  }

  /** Passt ein vorhandenes Profil? Gleiche Richtung, gleiche Art (Schlafzimmer), gleicher Sonnenschutz. */
  _cwizMatch(d) {
    const sleep = d.use === "schlafen";
    return this._rwProfiles().find((p) => Number(p.window_dir) === Number(d.prof.window_dir) && !!p.resident_sensor === false
      && (p.features || []).includes("shading") === d.shade && (sleep ? /schlaf/i.test(p.name) : !/schlaf/i.test(p.name))) || null;
  }

  _cwizPop() {
    const d = this._pop.draft;
    const S = this._hass.states;
    const steps = ["Rollladen", "Richtung", "Fenster", "Raum", "Profil", "Fertig"];
    const name = (id) => esc(this._entityName(id));
    const bar = `<div class="wiz-bar">${steps.map((s, i) => `<button class="wiz-dot ${i === d.step ? "on" : i < d.step ? "done" : ""}" data-action="cwiz-go" data-i="${i}" ${i > d.step && !this._cwizOk(i - 1) ? "disabled" : ""}><i>${i < d.step ? "✓" : i + 1}</i><span>${s}</span></button>`).join("")}</div>`;
    const tick = (on, radio = false) => `<ha-icon icon="${radio ? (on ? "mdi:radiobox-marked" : "mdi:radiobox-blank") : on ? "mdi:checkbox-marked" : "mdi:checkbox-blank-outline"}"></ha-icon>`;
    let body = "";
    switch (d.step) {
      case 0: {
        const have = new Set(this._data.settings.rw_covers || []);
        const all = Object.keys(S).filter((id) => id.startsWith("cover.") && !have.has(id) && !(S[id].attributes?.entity_id || []).length);
        const groups = new Map();
        for (const id of all) {
          const a = this._areaOf(id) || "Ohne Bereich";
          if (!groups.has(a)) groups.set(a, []);
          groups.get(a).push(id);
        }
        body = `<p class="muted">Welche Rollläden sollen dazukommen? Mehrere gleichzeitig gehen auch – z. B. alle Fenster einer Seite, sie bekommen dann dasselbe Profil.</p>
          ${all.length ? [...groups.entries()].sort((a, b) => a[0].localeCompare(b[0], "de")).map(([a, ids]) => `<div class="lbl">${esc(a)}</div>${ids.map((id) => `<button class="wiz-dev ${d.covers.includes(id) ? "on" : ""}" data-action="cwiz-cover" data-id="${esc(id)}">${tick(d.covers.includes(id))}<span class="grow"><b>${name(id)}</b><small>${esc(this._fmtState(S[id]))}${S[id].attributes?.current_position != null ? ` · ${S[id].attributes.current_position} %` : ""}</small></span></button>`).join("")}`).join("")
            : `<p class="note"><ha-icon icon="mdi:check-all"></ha-icon>Alle Rollläden sind schon in Rollwerk.</p>`}`;
        break;
      }
      case 1:
        body = `<p class="muted">Wohin zeigt das Fenster${d.covers.length > 1 ? " (bei allen gewählten)" : ""}? Danach richtet sich der Sonnenschutz.</p>${this._rwCompass(d.prof)}
          <button class="wiz-dev ${d.prof.window_dir == null ? "on" : ""}" data-action="cwiz-nodir">${tick(d.prof.window_dir == null, true)}<span class="grow"><b>Weiß nicht / egal</b><small>ohne Sonnenschutz nach Richtung</small></span></button>`;
        break;
      case 2:
        body = `<p class="muted">Gibt es einen Kontakt am Fenster oder an der Tür? Dann sperrt dich der Rollladen nicht aus und lüftet bei gekipptem Fenster.</p>
          ${d.covers.map((cid) => {
            const f = this._cwizContacts(cid);
            const c = d.contacts[cid] || {};
            const opts = [...new Set([...f.all, c.open, c.tilted].filter(Boolean))];
            const sel = (k) => `<select data-cwiz="${esc(cid)}" data-k="${k}"><option value="">keiner</option>${Object.keys(S).filter((id) => id.startsWith("binary_sensor.") && (["door", "window", "opening"].includes(S[id].attributes?.device_class) || opts.includes(id))).sort((a, b) => (opts.includes(b) - opts.includes(a)) || this._entityName(a).localeCompare(this._entityName(b), "de")).map((id) => `<option value="${esc(id)}" ${c[k] === id ? "selected" : ""}>${name(id)}${this._areaOf(id) ? ` (${esc(this._areaOf(id))})` : ""}</option>`).join("")}</select>`;
            const room = this._rwRoomFor(cid, "");
            const inh = this._rwRoomContacts(room);
            if (c.inherit) return `<div class="cwiz-c"><b><ha-icon icon="mdi:window-shutter"></ha-icon>${name(cid)}</b>
              <div class="evlist">${[...inh.open.map((e) => [e, "ganz offen – nicht herunterfahren", "mdi:door-open"]), ...inh.tilted.map((e) => [e, "gekippt – lüften", "mdi:window-open-variant"])].map(([e, role, icon]) => `<div class="ev"><ha-icon icon="${icon}"></ha-icon><span class="grow"><b>${name(e)}</b><small>${role}</small></span></div>`).join("")}</div>
              <small class="muted"><ha-icon icon="mdi:home-thermometer-outline"></ha-icon> Aus Heizwerk › ${esc(room.name)} übernommen – auch die Raumtemperatur. <button class="link inline" data-action="cwiz-own" data-id="${esc(cid)}">Eigene wählen</button></small></div>`;
            return `<div class="cwiz-c"><b><ha-icon icon="mdi:window-shutter"></ha-icon>${name(cid)}</b>
              <label class="field"><span><ha-icon icon="mdi:door-open"></ha-icon> ganz offen (Tür/Fenster)</span>${sel("open")}</label>
              <label class="field"><span><ha-icon icon="mdi:window-open-variant"></ha-icon> gekippt</span>${sel("tilted")}</label>
              ${f.all.length ? `<small class="muted">${f.all.length} Kontakt${f.all.length > 1 ? "e" : ""} im selben Bereich gefunden${c.open || c.tilted ? " und vorausgewählt" : ""}.</small>` : ""}
              ${room && (inh.open.length || inh.tilted.length) ? `<small class="muted"> <button class="link inline" data-action="cwiz-inherit" data-id="${esc(cid)}">Doch aus Heizwerk › ${esc(room.name)} übernehmen</button></small>` : room ? `<small class="muted"> Im Heizwerk-Raum „${esc(room.name)}“ sind keine Fensterkontakte eingetragen.</small>` : ""}</div>`;
          }).join("")}`;
        break;
      case 3: {
        const uses = [["wohnen", "Wohnraum", "mdi:sofa-outline", "morgens auf, abends zu"], ["schlafen", "Schlafzimmer", "mdi:bed-outline", "später auf, früher zu, bleibt beim Ausschlafen zu"],
          ["kind", "Kinderzimmer", "mdi:teddy-bear", "früher zu"], ["neben", "Nebenraum", "mdi:door", "nur Sonnen- und Sturmschutz"]];
        body = `<p class="muted">Was für ein Raum ist das?</p>
          ${uses.map(([v, t, i, s]) => `<button class="wiz-type ${d.use === v ? "on" : ""}" data-action="cwiz-use" data-v="${v}"><ha-icon icon="${i}"></ha-icon><span><b>${t}</b><small>${s}</small></span></button>`).join("")}
          <div class="lbl">Öffnen und schließen</div>
          <div class="segs small">${[["sun", "Mit der Sonne", "mdi:weather-sunset"], ["time", "Nach Uhrzeit", "mdi:clock-outline"]].map(([v, l, i]) => `<button class="seg ${d.mode === v ? "on" : ""}" data-action="cwiz-mode" data-v="${v}"><ha-icon icon="${i}"></ha-icon>${l}</button>`).join("")}</div>
          <div class="wxrows"><div class="wxr"><div class="wxr-l"><b>Sonnenschutz</b><small>${d.prof.window_dir == null ? "braucht die Richtung aus Schritt 2" : `bei Sonne aus ${this._rwDirName(d.prof.window_dir)} – Werte nach Empfehlung`}</small></div>
            <div class="wxr-v"><label class="switch"><input type="checkbox" data-action="cwiz-shade" ${d.shade && d.prof.window_dir != null ? "checked" : ""} ${d.prof.window_dir == null ? "disabled" : ""}><span></span></label></div></div>
          ${d.shade && d.prof.window_dir != null ? `<div class="wxr"><div class="wxr-l"><b>Ab Außentemperatur</b></div><div class="wxr-v"><div class="wiz-temp"><button class="sbtn" data-action="cwiz-t" data-d="-1">−</button><b>${fmt(d.temp, 0)} °C</b><button class="sbtn" data-action="cwiz-t" data-d="1">+</button></div></div></div>` : ""}</div>`;
        break;
      }
      case 4: {
        const match = this._cwizMatch(d);
        if (d.pick == null) d.pick = match ? match.id : "new";
        const opt = (v, t, s) => `<button class="wiz-dev ${d.pick === v ? "on" : ""}" data-action="cwiz-pick" data-v="${esc(v)}">${tick(d.pick === v, true)}<span class="grow"><b>${t}</b><small>${s}</small></span></button>`;
        body = `<p class="muted">Rollläden mit gleichem Profil lassen sich später gemeinsam ändern.</p>
          ${opt("new", "Neues Profil", "aus deinen Antworten")}
          ${d.pick === "new" ? `<label class="field cwiz-name"><span><ha-icon icon="mdi:form-textbox"></ha-icon> Name des neuen Profils</span><input type="text" maxlength="60" data-cwizname value="${esc(d.name ?? this._cwizName(d, true))}" placeholder="${esc(this._cwizName(d, true))}"></label>` : ""}
          ${this._rwProfiles().map((p) => opt(p.id, `„${esc(p.name)}“${match?.id === p.id ? " – passt" : ""}`, esc(this._rwProfSum(p)))).join("")}`;
        break;
      }
      case 5: {
        const line = (icon, t, v) => `<div class="kv"><ha-icon icon="${icon}"></ha-icon><span>${t}</span><b>${v}</b></div>`;
        const cs = d.covers.filter((c) => d.contacts[c]?.open || d.contacts[c]?.tilted || d.contacts[c]?.inherit).length;
        const rooms = [...new Set(d.covers.map((c) => this._rwRoomFor(c, "")?.name).filter(Boolean))];
        body = `<div class="wiz-sum">
            ${line("mdi:window-shutter", "Rollläden", d.covers.map(name).join(", "))}
            ${line("mdi:compass-outline", "Fenster zeigt nach", d.prof.window_dir == null ? "–" : this._rwDirName(d.prof.window_dir))}
            ${line("mdi:home-thermometer-outline", "Raum aus Heizwerk", rooms.length ? rooms.map(esc).join(", ") : "–")}
            ${line("mdi:door-open", "Mit Kontakt", `${cs} von ${d.covers.length}`)}
            ${line("mdi:tune-variant", "Profil", d.pick === "new" ? `neu: „${esc(this._cwizName(d))}“` : `„${esc(this._rwProfName(d.pick))}“`)}
            ${d.pick === "new" ? line("mdi:sun-thermometer-outline", "Sonnenschutz", d.shade && d.prof.window_dir != null ? `ab ${fmt(d.temp, 0)} °C außen` : "aus") : ""}
          </div>${note2("Rollwerk fährt erst beim nächsten Wechsel (z. B. abends schließen) – nicht sofort nach dem Anlegen.")}`;
        break;
      }
    }
    function note2(t) { return `<p class="muted small"><ha-icon icon="mdi:information-outline"></ha-icon>${t}</p>`; }
    const last = d.step === steps.length - 1;
    return {
      icon: "mdi:auto-fix", c: "#0ea5e9", title: "Rollladen hinzufügen", sub: `Schritt ${d.step + 1} von ${steps.length} · ${steps[d.step]}`,
      body: bar + body,
      foot: `${d.step ? `<button class="secondary" data-action="cwiz-go" data-i="${d.step - 1}"><ha-icon icon="mdi:chevron-left"></ha-icon>Zurück</button>` : `<button class="secondary" data-action="pop-close">Abbrechen</button>`}
        ${last ? `<button class="primary" data-action="cwiz-save"><ha-icon icon="mdi:check"></ha-icon>Hinzufügen</button>`
          : `<button class="primary" data-action="cwiz-go" data-i="${d.step + 1}" ${this._cwizOk(d.step) ? "" : "disabled"}>Weiter<ha-icon icon="mdi:chevron-right"></ha-icon></button>`}`,
    };
  }

  _cwizOk(step) {
    const d = this._pop?.draft || {};
    return step === 0 ? d.covers?.length > 0 : true;
  }

  /** Name des neuen Profils: eingegeben, sonst aus Raum und Richtung vorgeschlagen. */
  _cwizName(d, suggest = false) {
    if (!suggest && String(d.name ?? "").trim()) return String(d.name).trim();
    const dir = d.prof.window_dir != null ? this._rwDirName(d.prof.window_dir) : "";
    const use = { schlafen: "Schlafzimmer", kind: "Kinderzimmer", neben: "Nebenraum" }[d.use] || "";
    return [use, dir].filter(Boolean).join(" ") || "Wohnraum";
  }

  /** Neues Profil aus den Antworten: Kopie von „Standard“, angepasst an Raum, Richtung und Sonnenschutz. */
  _cwizProfile(d) {
    const base = clone(this._data.rollwerk?.profiles?.standard || {});
    const f = new Set(["up", "down", "time", "ventilate"]);
    if (d.mode === "sun") f.add("sun");
    if (d.use === "neben") { f.delete("up"); f.delete("down"); }
    const shade = d.shade && d.prof.window_dir != null;
    if (shade) f.add("shading"); else f.delete("shading");
    const p = { ...base, name: this._cwizName(d), features: [...f], time_mode: "times" };
    if (d.prof.window_dir != null) Object.assign(p, { window_dir: d.prof.window_dir, azimuth_start: d.prof.azimuth_start, azimuth_end: d.prof.azimuth_end });
    const sg = this._rwSuggest(d.prof.window_dir);
    if (sg) Object.assign(p, { elevation_min: sg.elevation_min, elevation_max: sg.elevation_max, pos_shading: sg.pos_shading });
    if (shade) p.temp2_min = d.temp;
    if (d.use === "schlafen") Object.assign(p, { up_early: "07:30", up_late: "08:30", up_early_we: "09:00", up_late_we: "10:00", down_early: "19:00", down_late: "21:30", down_early_we: "19:30", down_late_we: "22:30" });
    if (d.use === "kind") Object.assign(p, { down_early: "17:30", down_late: "20:00", down_early_we: "18:00", down_late_we: "20:30" });
    if (d.mode === "time") for (const [a, b] of [["up_early", "up_late"], ["up_early_we", "up_late_we"], ["down_early", "down_late"], ["down_early_we", "down_late_we"]]) p[b] = p[a];
    return p;
  }

  async _cwizSave() {
    const d = this._pop.draft;
    let pid = d.pick;
    if (pid === "new") {
      const name = this._cwizName(d);
      if (this._rwProfiles().some((x) => x.name.toLowerCase() === name.toLowerCase())) {
        this._toast(`Ein Profil „${name}“ gibt es schon – bitte anders benennen oder das vorhandene wählen.`);
        d.step = 4;
        this._renderPop();
        return;
      }
      const res = await this._ws({ type: "hauswerk/rollwerk/profile/save", profile_id: null, profile: this._cwizProfile(d) });
      this._data.rollwerk.profiles = res.profiles;
      pid = res.profile_id;
    }
    const covers = [...new Set([...(this._data.settings.rw_covers || []), ...d.covers])];
    this._data.settings = await this._ws({ type: "hauswerk/heizen/settings/save", settings: { rw_covers: covers } });
    for (const cid of d.covers) {
      const c = d.contacts[cid] || {};
      const res = await this._ws({ type: "hauswerk/rollwerk/cover/save", entity_id: cid, cover: { profile: pid, contact_open: c.open || null, contact_tilted: c.tilted || null, auto: true, storm: true } });
      this._data.rollwerk.covers = res.covers;
    }
    const n = d.covers.length;
    this._closePop();
    this._renderMain();
    this._toast(n === 1 ? `${this._entityName(d.covers[0])} hinzugefügt` : `${n} Rollläden hinzugefügt`);
  }

  // ------------------------------------------------------------ Raum aus Heizwerk (wie im Backend)
  _rwAreaId(id) {
    const e = this._hass.entities?.[id];
    return e?.area_id || this._hass.devices?.[e?.device_id]?.area_id || null;
  }

  /** Heizwerk-Raum eines Rollladens: gewählt, sonst über den Bereich (Thermostat/Fenster im selben Bereich) oder den Namen. */
  _rwRoomFor(coverId, choice = this._data.rollwerk?.covers?.[coverId]?.room) {
    const rooms = this._data.rooms || {};
    if (choice === "none") return null;
    if (choice && rooms[choice]) return { ...rooms[choice], auto: false };
    const area = this._rwAreaId(coverId);
    const areaName = String(this._hass.areas?.[area]?.name || "").trim().toLowerCase();
    const hit = Object.values(rooms).find((r) => area && [...(r.climates || []), ...(r.windows || [])].some((e) => this._rwAreaId(e) === area))
      || Object.values(rooms).find((r) => areaName && String(r.name).trim().toLowerCase() === areaName);
    return hit ? { ...hit, auto: true } : null;
  }

  /** Fenster eines Heizwerk-Raums: Türen = ganz offen (Aussperrschutz), Fenster = gekippt (Lüften). */
  _rwRoomContacts(room) {
    const open = [], tilted = [];
    for (const e of room?.windows || []) {
      if (!/^(binary_sensor|input_boolean)\./.test(e)) continue;
      const st = this._hass.states[e];
      const txt = `${e} ${st?.attributes?.friendly_name || ""}`.toLowerCase();
      if (/kipp|tilt/.test(txt)) tilted.push(e);
      else if (["door", "garage_door"].includes(st?.attributes?.device_class) || /t(ü|ue)r|door/.test(txt)) open.push(e);
      else tilted.push(e);
    }
    return { open, tilted };
  }

  _rwcPop(entityId) {
    const d = this._pop.draft;
    if (!d.cfg) d.cfg = clone(this._data.rollwerk?.covers?.[entityId] || {});
    const c = d.cfg;
    const dis = this._admin ? "" : "disabled";
    const line = (label, sub, ctl) => `<div class="wxr"><div class="wxr-l"><b>${label}</b>${sub ? `<small>${sub}</small>` : ""}</div><div class="wxr-v">${ctl}</div></div>`;
    const tog = (k, def, label, sub) => line(label, sub, `<label class="switch"><input type="checkbox" data-rwc="${k}" ${(c[k] ?? def) ? "checked" : ""} ${dis}><span></span></label>`);
    const contacts = Object.keys(this._hass.states).filter((id) => /^(binary_sensor|input_boolean)\./.test(id) &&
      (["door", "window", "opening", "garage_door"].includes(this._hass.states[id].attributes?.device_class) || /t(ü|ue)r|door|fenster|window|kipp|tilt/.test(id)) || id === c.contact_open || id === c.contact_tilted)
      .sort((a, b) => this._entityName(a).localeCompare(this._entityName(b), "de"));
    const sel = (k) => `<select data-rwc="${k}" ${dis}><option value="">keiner</option>${contacts.map((id) => `<option value="${esc(id)}" ${c[k] === id ? "selected" : ""}>${esc(this._entityName(id))}</option>`).join("")}</select>`;
    const rs = this._rwStatus?.covers?.[entityId] || {};
    const pid = c.profile || "standard";
    const profiles = this._rwProfiles();
    const autoRoom = this._rwRoomFor(entityId, "");
    const room = this._rwRoomFor(entityId, c.room);
    const inh = this._rwRoomContacts(room);
    const cmode = c.contacts === "none" ? "none" : c.contact_open || c.contact_tilted || d.own || !room ? "own" : "heizwerk";
    return {
      icon: "mdi:window-shutter", c: "#0ea5e9", title: "Rollladen", sub: `${esc(this._entityName(entityId))}${rs.area ? ` · ${esc(rs.area)}` : ""}`,
      body: `
        <div class="wxrows">${tog("auto", true, "Automatik", "nach dem Profil fahren")}${tog("storm", true, "Sturmschutz", "bei Sturm hochfahren")}</div>
        <div class="field"><span><ha-icon icon="mdi:tune-variant"></ha-icon> Profil</span>
          <div class="segs small">${profiles.map((x) => `<button class="seg ${x.id === pid ? "on" : ""}" data-action="rwc-set" data-k="profile" data-v="${esc(x.id)}" ${dis}>${esc(x.name)}</button>`).join("")}</div></div>
        ${this._rwDayBar(this._rwStatus?.timelines?.[pid])}
        <p class="muted small"><ha-icon icon="mdi:information-outline"></ha-icon>${esc(this._rwProfSum({ id: pid, ...(this._data.rollwerk?.profiles?.[pid] || {}) }))} · <button class="link inline" data-action="pop-open" data-pop="rwp:${esc(pid)}:tag">Profil bearbeiten</button></p>
        <label class="field"><span><ha-icon icon="mdi:home-thermometer-outline"></ha-icon> Raum aus Heizwerk</span>
          <select data-rwc="room" ${dis}><option value="">${autoRoom ? `automatisch: ${esc(autoRoom.name)}` : "automatisch (keiner gefunden)"}</option>${Object.values(this._data.rooms || {}).sort((a, b) => a.name.localeCompare(b.name, "de")).map((r) => `<option value="${esc(r.id)}" ${c.room === r.id ? "selected" : ""}>${esc(r.name)}</option>`).join("")}<option value="none" ${c.room === "none" ? "selected" : ""}>keiner</option></select></label>
        <div class="lbl">Fenster- und Türkontakte</div>
        <div class="segs small">${[["heizwerk", "Aus Heizwerk", !room], ["own", "Eigene"], ["none", "Keine"]].map(([v, l, off]) => `<button class="seg ${cmode === v ? "on" : ""}" data-action="rwc-cmode" data-v="${v}" ${off || dis ? "disabled" : ""}>${l}</button>`).join("")}</div>
        ${cmode === "heizwerk" ? `<div class="evlist">${[...inh.open.map((e) => [e, "ganz offen – nicht herunterfahren", "mdi:door-open"]), ...inh.tilted.map((e) => [e, "gekippt – Lüftungsstellung", "mdi:window-open-variant"])].map(([e, role, icon]) => `<div class="ev"><ha-icon icon="${icon}"></ha-icon><span class="grow"><b>${esc(this._entityName(e))}</b><small>${role}</small></span></div>`).join("") || `<p class="muted small">Im Raum „${esc(room?.name || "")}“ sind keine Fensterkontakte eingetragen.</p>`}</div>
          <p class="muted small"><ha-icon icon="mdi:home-thermometer-outline"></ha-icon>Aus Heizwerk › ${esc(room?.name || "")}: Türen sperren das Herunterfahren, Fenster lüften. Neue Kontakte trägst du einmal im Raum ein – <button class="link inline" data-action="room-edit" data-id="${esc(room?.id || "")}" data-rtab="devices">Raum öffnen</button>. Die Raumtemperatur nutzt der Sonnenschutz („innen wärmer als“).</p>` : ""}
        ${cmode === "own" ? `<label class="field"><span><ha-icon icon="mdi:door-open"></ha-icon> Kontakt „ganz offen“ – Aussperrschutz</span>${sel("contact_open")}</label>
          <label class="field"><span><ha-icon icon="mdi:window-open-variant"></ha-icon> Kontakt „gekippt“ – Lüften</span>${sel("contact_tilted")}</label>
          <p class="muted small"><ha-icon icon="mdi:information-outline"></ha-icon>Nur nötig, wenn der Kontakt nicht schon im Heizwerk-Raum steht – z. B. eine Tür, die fürs Heizen keine Rolle spielt.</p>` : ""}
        ${cmode === "none" ? `<p class="muted small"><ha-icon icon="mdi:alert-outline"></ha-icon>Ohne Kontakt fährt der Rollladen auch bei offener Tür herunter.</p>` : ""}
        ${rs.reason ? `<div class="rq-facts"><span style="--c:#0ea5e9"><ha-icon icon="mdi:robot-outline"></ha-icon>${esc(rs.reason)}${rs.target != null ? ` → ${rs.target} %` : ""}</span>${rs.up ? `<span><ha-icon icon="mdi:weather-sunset-up"></ha-icon>${rs.up.join("–")}</span>` : ""}${rs.down ? `<span><ha-icon icon="mdi:weather-sunset-down"></ha-icon>${rs.down.join("–")}</span>` : ""}</div>` : ""}`,
      foot: `<button class="secondary" data-action="pop-close">${this._admin ? "Abbrechen" : "Schließen"}</button>
        ${this._admin ? `<button class="primary" data-action="rwc-save" data-id="${esc(entityId)}"><ha-icon icon="mdi:content-save-outline"></ha-icon>Speichern</button>` : ""}`,
    };
  }

  // ------------------------------------------------------------ Bericht
  _viewReport() {
    const rooms = this._rooms();
    const days = this._reportDays;
    const rep = this._report(days);
    const pills = `<div class="pills">${[7, 14, 30]
      .map((d) => `<button class="pill ${d === days ? "on" : ""}" data-action="report-days" data-days="${d}">${d} Tage</button>`)
      .join("")}</div>`;
    if (!rooms.length) return `${pills}<section class="card empty"><ha-icon icon="mdi:chart-bar"></ha-icon><h2>Noch keine Räume</h2></section>`;
    if (!rep) return `${pills}<section class="card"><div class="chart-empty"><div class="spinner"></div></div></section>`;
    const tot = this._sumRange(rep, 0, days);
    const row = (r) => {
      const rows = rep[r.id] || [];
      const sum = (k) => rows.reduce((a, x) => a + (x[k] || 0), 0);
      const temps = rows.map((x) => x.avg_temp).filter((t) => t != null);
      const avg = temps.length ? temps.reduce((a, b) => a + b, 0) / temps.length : null;
      return `<tr>
        <td><span class="rdot" style="background:${this._roomColor(r.id)}"></span>${esc(r.name)}<small>${TYPES[r.type].label}</small></td>
        <td>${fmt(sum("heat_min") / 60)} h</td><td>${fmt(sum("comfort_min") / 60)} h</td>
        <td>${int(sum("pause_min"))} Min.</td><td>${int(sum("openings"))}×</td>
        <td style="color:${tint(tempColor(avg))}">${fmt(avg)} °C</td></tr>`;
    };
    return `
      ${pills}
      <div class="kpis">
        ${this._kpi("#2dd4bf", "mdi:fire", "Geheizt", fmt(tot.heat / 60), "h", `Ø ${fmt(tot.heat / 60 / days)} h am Tag`)}
        ${this._kpi("#60a5fa", "mdi:sofa-outline", "Komfortzeit", fmt(tot.comfort / 60), "h", "Summe aller Räume")}
        ${this._kpi("#a78bfa", "mdi:window-open-variant", "Fensterpause", int(tot.pause), "Min.", "Thermostat abgesenkt")}
        ${this._kpi("#f472b6", "mdi:window-maximize", "Fenster geöffnet", int(tot.open), "×", `in ${days} Tagen`)}
      </div>
      <section class="card">
        ${this._sectionHead("mdi:fire", `Heizdauer pro Tag · ${days} Tage`)}
        ${this._stackChart(rep, days, "heat_min")}
      </section>
      <section class="card">
        ${this._sectionHead("mdi:window-open-variant", `Fensterpause pro Tag · ${days} Tage`)}
        ${this._stackChart(rep, days, "pause_min")}
      </section>
      ${(() => {
        const st = this._status?.rooms || {};
        const vr = rooms.filter((r) => st[r.id]?.air?.week?.count);
        if (!vr.length) return "";
        return `<section class="card">${this._sectionHead("mdi:weather-windy", "Lüften · 7 Tage", `<button class="link" data-action="tab" data-tab="vent">Lüften</button>`)}
          <div class="table-wrap"><table><thead><tr><th>Raum</th><th>gelüftet</th><th>Dauer</th><th>Feuchte</th><th>Wärme</th></tr></thead><tbody>
          ${vr.map((r) => { const wk = st[r.id].air.week; return `<tr><td><span class="rdot" style="background:${this._roomColor(r.id)}"></span>${esc(r.name)}</td><td>${wk.count}×</td><td>${wk.minutes} Min.</td><td>${wk.rh_drop != null ? `−${wk.rh_drop} %-Pkt.` : "–"}</td><td>${wk.kwh ? `ca. ${fmt(wk.kwh)} kWh` : "–"}</td></tr>`; }).join("")}
          </tbody></table></div><p class="muted small">Feuchte: Ø Rückgang je Lüftung. Wärme: grob geschätzt (ca. 20 W je Grad Unterschied, solange offen).</p></section>`;
      })()}
      ${this._powerReport(rooms, days)}
      ${this._valveHeat(rooms, rep, days)}
      <section class="card">
        ${this._sectionHead("mdi:table", "Räume im Vergleich")}
        <div class="table-wrap"><table>
          <thead><tr><th>Raum</th><th>Geheizt</th><th>Komfort</th><th>Pause</th><th>Fenster</th><th>Ø Raum</th></tr></thead>
          <tbody>${rooms.map(row).join("")}</tbody>
        </table></div>
        <p class="muted small">Geheizt: Minuten, in denen ein Thermostat „heizt“ meldet (ohne diese Angabe: Raum unter Soll).</p>
      </section>`;
  }

  /** Heizleistung je Raum: Urteil, Kennzahlen und Hinweise (Analyse aus dem Backend). */
  _powerReport(rooms, days) {
    const an = this._analysis?.[days] || {};
    const V = { good: ["Passt", "#22c55e", "mdi:check-circle-outline"], reserve: ["Reserve", "#0ea5e9", "mdi:arrow-down-bold-circle-outline"],
      tight: ["Knapp", "#f59e0b", "mdi:alert-circle-outline"], weak: ["Reicht nicht", "#ef4444", "mdi:fire-alert"],
      sensor: ["Messung prüfen", "#f97316", "mdi:thermometer-alert"], nodata: ["Zu wenig Daten", "#94a3b8", "mdi:timer-sand"] };
    const LV = { ok: ["mdi:check", "#22c55e"], info: ["mdi:information-outline", "#0ea5e9"], warn: ["mdi:alert-outline", "#ef4444"] };
    const list = rooms.map((r) => ({ r, a: an[r.id] })).filter((x) => x.a);
    if (!list.length) return "";
    const order = ["weak", "sensor", "tight", "good", "reserve", "nodata"];
    list.sort((x, y) => order.indexOf(x.a.verdict) - order.indexOf(y.a.verdict));
    const count = (v) => list.filter((x) => x.a.verdict === v).length;
    const bad = count("weak") + count("sensor");
    const head = bad ? `${bad} ${bad === 1 ? "Raum braucht" : "Räume brauchen"} Aufmerksamkeit` : count("tight") ? `${count("tight")} ${count("tight") === 1 ? "Raum ist" : "Räume sind"} knapp, sonst alles gut` : count("nodata") === list.length ? "Noch zu wenig Daten" : "Alle Räume werden gut warm";
    const fact = (label, val, hint = "") => (val == null ? "" : `<span class="pw-f"><small>${label}</small><b>${val}</b>${hint ? `<i>${hint}</i>` : ""}</span>`);
    const card = ({ r, a }) => {
      const [vl, vc, vi] = V[a.verdict] || V.nodata;
      const f = a.facts || {};
      return `<div class="pw-room" style="--c:${vc}">
        <div class="pw-h"><span class="rdot" style="background:${this._roomColor(r.id)}"></span><b>${esc(r.name)}</b><small>${r.type === "flaeche" ? "Fußbodenheizung" : "Heizkörper"}</small><span class="grow"></span><em class="pw-v"><ha-icon icon="${vi}"></ha-icon>${vl}</em></div>
        ${f.ok_pct != null ? `<div class="pw-bar" title="Komfort erreicht"><i style="width:${f.ok_pct}%"></i></div>` : ""}
        <div class="pw-fs">
          ${fact("Komfort erreicht", f.ok_pct != null ? `${f.ok_pct} %` : null)}
          ${fact("Ø zum Soll", f.dev != null ? `${f.dev > 0 ? "+" : ""}${fmt(f.dev)} °C` : null)}
          ${fact("Ø Ventil", f.valve != null ? `${f.valve} %` : null, f.full_pct ? `${f.full_pct} % ganz auf` : "")}
          ${fact("Aufheizen", f.rate != null ? `${fmt(f.rate, 1)} °C/h` : null)}
          ${fact("Überheizt", f.over_pct ? `${f.over_pct} %` : null)}
          ${fact("Frost / mild", f.ok_cold != null && f.ok_mild != null ? `${f.ok_cold} / ${f.ok_mild} %` : null)}
          ${fact("Kamin u. Ä.", f.fire_h ? `${fmt(f.fire_h, 1)} h` : null, f.fire_h ? "herausgerechnet" : "")}
        </div>
        <div class="pw-list">${(a.findings || []).map((x) => { const [i, c] = LV[x.level] || LV.info; return `<div class="pw-i"><ha-icon icon="${i}" style="color:${c}"></ha-icon><span><b>${esc(x.title)}</b><small>${esc(x.text)}</small></span></div>`; }).join("")}</div>
        ${this._admin && ["weak", "sensor", "tight"].includes(a.verdict) ? `<button class="link" data-action="room-edit" data-id="${r.id}"><ha-icon icon="mdi:cog-outline"></ha-icon>Raum einstellen</button>` : ""}
      </div>`;
    };
    return `<section class="card">
      ${this._sectionHead("mdi:radiator", `Heizleistung je Raum · ${days} Tage`)}
      <p class="pw-sum"><b>${head}</b><small>Komfort erreicht = Anteil der Komfortzeit, in der der Raum höchstens 0,5 °C unter Soll lag. Zusammen mit der Ventilöffnung zeigt das, ob die Heizung reicht, knapp ist oder Reserve hat.</small></p>
      <div class="pw-grid">${list.map(card).join("")}</div>
    </section>`;
  }

  /** Ventilöffnung je Raum und Stunde (Ø über die gewählten Tage) als Wärmekarte. */
  _valveHeat(rooms, rep, days) {
    const rowsOf = (id) => rep[id] || [];
    const hourAvg = (id) => Array.from({ length: 24 }, (_, h) => {
      const vals = rowsOf(id).map((x) => (x.valve_hours || [])[h]).filter((v) => v != null);
      return vals.length ? vals.reduce((a, b) => a + b, 0) / vals.length : null;
    });
    const withData = rooms.filter((r) => rowsOf(r.id).some((x) => x.valve_avg != null));
    if (!withData.length) return `<section class="card">${this._sectionHead("mdi:valve", "Ventilöffnung über den Tag")}<p class="muted small">Noch keine Werte – Hauswerk sammelt die Ventilöffnung ab jetzt minütlich (Thermostate, Ventil-Sensoren und Fußbodenheizung).</p></section>`;
    const color = (v) => v == null ? "var(--card2)" : `color-mix(in srgb, #f97316 ${Math.round(12 + v * 0.88)}%, var(--card2))`;
    const row = (r) => {
      const hs = hourAvg(r.id);
      const avgs = rowsOf(r.id).map((x) => x.valve_avg).filter((v) => v != null);
      const avg = avgs.length ? avgs.reduce((a, b) => a + b, 0) / avgs.length : null;
      return `<div class="vh-row"><span class="vh-name"><span class="rdot" style="background:${this._roomColor(r.id)}"></span>${esc(r.name)}<small>Ø ${avg != null ? `${fmt(avg, 0)} %` : "–"}</small></span>
        <div class="vh-cells">${hs.map((v, h) => `<i style="background:${color(v)}" title="${String(h).padStart(2, "0")}–${String(h + 1).padStart(2, "0")} Uhr: ${v == null ? "keine Werte" : `${fmt(v, 0)} %`}"></i>`).join("")}</div></div>`;
    };
    return `<section class="card">
      ${this._sectionHead("mdi:valve", `Ventilöffnung über den Tag · Ø ${days} Tage`)}
      <div class="vh">${withData.map(row).join("")}
        <div class="vh-row vh-axis"><span class="vh-name"></span><div class="vh-cells">${Array.from({ length: 24 }, (_, h) => `<b>${h % 6 === 0 ? h : ""}</b>`).join("")}</div></div>
      </div>
      <p class="muted small">Je dunkler, desto weiter offen. Räume, die schon vor Komfortbeginn lange voll offen sind, heizen zu spät vor; Räume mit wenig Öffnung brauchen kaum Wärme – dort lohnt eine niedrigere Komforttemperatur oder späteres Vorheizen.</p>
    </section>`;
  }

  // ------------------------------------------------------------ Einstellungen: eine flache Liste, Details im Pop-up
  _setHelpers(p) {
    const dis = this._admin ? "" : "disabled";
    return {
      dis,
      minutes: (key, def, min = 0, max = 240, step = 1, unit = "Min.") =>
        `<div class="unit"><input type="number" step="${step}" min="${min}" max="${max}" data-set="${key}" value="${p[key] ?? def}" ${dis}><i>${unit}</i></div>`,
      segs: (key, options, def) =>
        `<div class="segs small">${options
          .map(([v, l, icon]) => `<button class="seg ${String(p[key] || def) === String(v) ? "on" : ""}" data-action="set-seg" data-key="${key}" data-v="${v}" ${dis}>${icon ? `<ha-icon icon="${icon}"></ha-icon>` : ""}${l}</button>`)
          .join("")}</div>`,
      sw: (key) => `<label class="switch"><input type="checkbox" data-set="${key}" ${p[key] ? "checked" : ""} ${dis}><span></span></label>`,
      head: (icon, title) => `<div class="sub-h"><ha-icon icon="${icon}"></ha-icon>${title}</div>`,
    };
  }

  // ------------------------------------------------------------ Benachrichtigungen (Fenster)
  /** Kanäle eines Anlasses im Entwurf: eigene Auswahl oder die Standard-Kanäle. */
  _nkChannels(k, p = this._settings) {
    const own = (p.notify_routes || {})[k];
    return own && own.length ? [...own] : [...(p.notify_channels || [])];
  }

  /** Kanal für einen Anlass an/aus – gleich den Standard-Kanälen → keine eigene Auswahl. Leer → nur Protokoll. */
  _nkToggle(k, ch) {
    const p = this._settings;
    // Aus bzw. nur Protokoll: kein Kanal angehakt – ein Tipp schaltet mit diesem Kanal ein
    const cur = ["off", "log"].includes(p[`notify_${k}`]) ? [] : this._nkChannels(k);
    const i = cur.indexOf(ch);
    if (i >= 0) cur.splice(i, 1); else cur.push(ch);
    const def = p.notify_channels || [];
    const routes = { ...(p.notify_routes || {}) };
    if (!cur.length) { delete routes[k]; p[`notify_${k}`] = "log"; }
    else if (cur.length === def.length && cur.every((c) => def.includes(c))) delete routes[k];
    else routes[k] = cur;
    p.notify_routes = routes;
    if (cur.length && ["off", "log"].includes(p[`notify_${k}`])) p[`notify_${k}`] = "normal";
  }

  /** Alle Kanäle, die irgendwo genutzt werden (Standard, je Anlass, Zeiten, Bündeln). */
  _nkUsed(p = this._settings) {
    return [...new Set([...(p.notify_channels || []), ...Object.values(p.notify_routes || {}).flat(),
      ...Object.keys(p.notify_hours || {}), ...(p.notify_bundle || [])])];
  }

  _nkTemplate(t) {
    const p = this._settings;
    const S = this._hass?.states || {};
    const all = this._channels(this._nkUsed());
    const used = this._nkUsed();
    const apps = all.filter((c) => c.ok && c.group === "App");
    const appCh = used.filter((c) => apps.some((a) => a.id === c));
    const phones = appCh.length ? appCh : apps.map((c) => c.id);
    let voice = used.find((c) => c.startsWith("tts:") || c.startsWith("sat:"));
    if (!voice) {
      const tts = Object.keys(S).find((e) => e.startsWith("tts.") && S[e].state !== "unavailable");
      const players = Object.keys(S).filter((e) => e.startsWith("media_player.") && S[e].state !== "unavailable");
      const player = players.find((e) => /tab|tablet|fully|wand/.test(`${e} ${S[e].attributes?.friendly_name || ""}`.toLowerCase())) || players[0];
      const sat = Object.keys(S).find((e) => e.startsWith("assist_satellite.") && S[e].state !== "unavailable");
      voice = tts && player ? `tts:${tts}|${player}` : sat ? `sat:${sat}` : null;
    }
    const set = (k, v) => { p[`notify_${k}`] = v; };
    if (t === "important") {
      if (!phones.length) return this._toast("Keine Home-Assistant-App gefunden");
      p.notify_channels = phones;
      p.notify_routes = {};
      for (const k of NK_KINDS.map((x) => x.k)) set(k, ["frost", "storm", "offline", "cold", "cover"].includes(k) ? "important" : "log");
    } else if (t === "voice") {
      if (!voice) return this._toast("Keine Ansage möglich – kein Sprachdienst mit Lautsprecher gefunden");
      const routes = { ...(p.notify_routes || {}) };
      for (const k of ["window", "vent", "vent_done", "waste"]) { routes[k] = [voice]; set(k, "normal"); }
      p.notify_routes = routes;
      p.notify_hours = { ...(p.notify_hours || {}), [voice]: ["08:00", "21:00"] };
      p.notify_voice_away = true;
    } else if (t === "calm") {
      for (const k of NK_KINDS.map((x) => x.k)) set(k, ["frost", "storm"].includes(k) ? "normal" : "log");
    }
    this._toast("Vorlage übernommen – mit „Speichern“ übernehmen");
    this._refreshSettings();
  }

  _notifyPop(p, { minutes, segs, sw, head, dis }) {
    if (p.notify_channels == null) p.notify_channels = [...(p.notify_targets || []).map((t) => `svc:${t}`), ...(p.notify_ha ? ["ha"] : [])];
    for (const x of NK_KINDS) {
      const key = `notify_${x.k}`;
      if (p[key] === true || p[key] == null) p[key] = x.def;
      else if (p[key] === false) p[key] = "off";
    }
    const tab = this._nkTab || "what";
    const ns = this._status?.notify || {};
    const health = ns.health || {};
    const routes = p.notify_routes || {};
    const used = this._nkUsed(p);
    const info = new Map(this._channels(used).map((c) => [c.id, c]));
    const chInfo = (id) => info.get(id) || this._chInfo(id);
    const voiceOf = (ids) => ids.filter((c) => c.startsWith("tts:") || c.startsWith("sat:"));
    const hm = (iso) => new Date(iso).toLocaleString("de-DE", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" });
    const MODES_N = [["off", "Aus", "mdi:bell-off-outline"], ["log", "Protokoll", "mdi:text-box-outline"], ["normal", "Normal", "mdi:bell-outline"], ["important", "Wichtig", "mdi:bell-alert-outline"]];
    const MODE_TXT = { off: "aus", log: "nur Protokoll", normal: "normal", important: "wichtig" };
    const dot = (id) => { const h = health[id]; return `<i class="nk-dot ${h ? (h.ok ? "ok" : "bad") : ""}" title="${h ? (h.ok ? `zuletzt zugestellt ${hm(h.at)}` : `Fehler ${hm(h.at)}: ${esc(h.error || "")}`) : "noch nichts gesendet"}"></i>`; };
    const thr = {
      window: () => minutes("notify_window_min", 30, 5, 720, 5),
      offline: () => minutes("notify_offline_min", 15, 1, 720, 5),
      cover: () => minutes("notify_offline_min", 15, 1, 720, 5),
      battery: () => minutes("battery_low", 20, 5, 60, 5, "%"),
    };
    const sub = (x) => ({
      window: `ab ${p.notify_window_min ?? 30} Min.`, offline: `seit ${p.notify_offline_min ?? 15} Min.`, cover: `seit ${p.notify_offline_min ?? 15} Min.`,
      battery: `unter ${p.battery_low ?? 20} %`, frost: `unter ${fmt(p.cold_snap_temp ?? 0)} °C`,
      waste: p.waste_remind ? `Vorabend ab ${p.waste_remind}` : "Erinnerung unter Kalender aus",
    }[x.k] || x.sub);

    // ---------- Reiter „Anlässe“
    const preview = (x, chs) => {
      const voice = voiceOf(chs);
      return `<div class="nk-prev"><div class="nk-phone"><ha-icon icon="mdi:home-automation"></ha-icon><span class="grow"><b>${esc(x.ex[0])}</b><small>${esc(x.ex[1])}</small></span><em>jetzt</em></div>
        ${this._admin && chs.length ? `<div class="nk-pa">
          <button class="secondary small" data-action="nk-try" data-k="${x.k}" ${dis}><ha-icon icon="mdi:send-outline"></ha-icon>So senden</button>
          ${voice.length ? `<button class="secondary small" data-action="nk-try" data-k="${x.k}" data-voice="1" ${dis}><ha-icon icon="mdi:account-voice"></ha-icon>Probehören</button>` : ""}</div>` : ""}</div>`;
    };
    const kindRow = (x) => {
      const key = `notify_${x.k}`;
      const mode = p[key];
      const on = !["off"].includes(mode);
      const chs = this._nkChannels(x.k, p);
      const own = (routes[x.k] || []).length > 0;
      const open = this._nkOpen === x.k;
      const live = chs.filter((c) => !(p.notify_off || []).includes(c));
      const to = mode === "off" ? "aus" : mode === "log" ? "nur Protokoll" : !chs.length ? "kein Kanal"
        : !live.length ? "alle Empfänger pausiert" : live.map((c) => chInfo(c).label).join(", ") + (live.length < chs.length ? ` (+${chs.length - live.length} pausiert)` : "");
      return `<div class="nk-k ${open ? "open" : ""} ${on ? "" : "off"}">
        <div class="nk-h"><button class="nk-sum" data-action="nk-open" data-k="${x.k}" aria-expanded="${open}">
          <ha-icon icon="${x.icon}" style="color:${x.c}"></ha-icon><span class="grow"><b>${esc(x.title)}${mode === "important" ? ` <ha-icon class="nk-imp" icon="mdi:bell-alert" title="wichtig"></ha-icon>` : ""}</b><small>${esc(sub(x))} → ${esc(to)}${own ? " · eigene Kanäle" : ""}</small></span>
          <ha-icon class="nk-chev" icon="mdi:chevron-${open ? "up" : "down"}"></ha-icon></button>
          <label class="switch"><input type="checkbox" data-action="nk-onoff" data-k="${x.k}" ${on ? "checked" : ""} ${dis}><span></span></label></div>
        ${open ? `<div class="nk-body">
          <div class="nk-modes">${segs(key, MODES_N, x.def).replace('class="segs small"', 'class="segs small n4"')}</div>
          ${thr[x.k] ? `<label class="field narrow"><span>${x.k === "battery" ? "Grenze" : "Ab"}</span>${thr[x.k]()}</label>` : ""}
          <p class="muted small">${esc(x.text)}</p>
          ${!["off", "log"].includes(mode) ? `<label class="ch-own"><input type="checkbox" ${own ? "checked" : ""} data-action="ch-route" data-kind="${x.k}" data-on="${own ? "0" : "1"}" ${dis}> eigene Kanäle für diesen Anlass${own ? "" : ` <span class="muted">(sonst: ${esc((p.notify_channels || []).map((c) => chInfo(c).label).join(", ") || "–")})</span>`}</label>
            ${own ? this._chPicker(`route:${x.k}`, routes[x.k], { disabled: dis, test: false }) : ""}
            ${preview(x, chs)}` : ""}
        </div>` : ""}
      </div>`;
    };
    const groups = [...new Set(NK_KINDS.map((x) => x.g))];
    const apps = this._data.settings.kw_appliances || [];
    const appRow = `<div class="nk-k"><div class="nk-h"><button class="nk-sum" data-action="kw-dev-open"><ha-icon icon="mdi:washing-machine" style="color:#eab308"></ha-icon><span class="grow"><b>Gerät fertig</b><small>${apps.length ? apps.map((a) => `${esc(a.name || "Gerät")} → ${esc(appChannels(a).map((c) => chInfo(c).label).join(", ") || "kein Kanal")}`).join(" · ") : "Kein Gerät eingerichtet"} · je Gerät unter Kraftwerk › Geräte</small></span><ha-icon class="nk-chev" icon="mdi:chevron-right"></ha-icon></button></div></div>`;
    const wide = (this.offsetWidth || 0) >= 700;
    const view = wide ? this._nkView || "table" : "list";
    const cols = used;
    const table = `<div class="nk-tbl-w"><table class="nk-tbl"><thead><tr><th>Anlass</th><th>Art</th>${cols.map((c) => `<th class="${(p.notify_off || []).includes(c) ? "paused" : ""}" title="${esc(chInfo(c).sub || c)}${(p.notify_off || []).includes(c) ? " · pausiert" : ""}">${dot(c)}${esc(chInfo(c).label)}${(p.notify_off || []).includes(c) ? " ⏸" : ""}</th>`).join("")}</tr></thead><tbody>
      ${groups.map((g) => `<tr class="nk-tg"><td colspan="${cols.length + 2}">${g}</td></tr>${NK_KINDS.filter((x) => x.g === g).map((x) => {
        const mode = p[`notify_${x.k}`];
        const chs = this._nkChannels(x.k, p);
        const live = !["off", "log"].includes(mode);
        return `<tr><td><ha-icon icon="${x.icon}" style="color:${x.c}"></ha-icon>${esc(x.title)}</td>
          <td><select data-set="notify_${x.k}" ${dis}>${MODES_N.map(([v, l]) => `<option value="${v}" ${mode === v ? "selected" : ""}>${l}</option>`).join("")}</select></td>
          ${cols.map((c) => `<td><button class="nk-cell ${live && chs.includes(c) ? "on" : ""}" data-action="nk-cell" data-k="${x.k}" data-ch="${esc(c)}" aria-pressed="${live && chs.includes(c)}" ${dis} title="${esc(x.title)} → ${esc(chInfo(c).label)}"><ha-icon icon="mdi:check"></ha-icon></button></td>`).join("")}</tr>`;
      }).join("")}`).join("")}
    </tbody></table></div>`;
    const tplBar = `<div class="nk-tpl"><small>Vorlagen</small>
      <button class="pill" data-action="nk-tpl" data-t="important" ${dis}><ha-icon icon="mdi:cellphone-message"></ha-icon>Nur Wichtiges aufs Handy</button>
      <button class="pill" data-action="nk-tpl" data-t="voice" ${dis}><ha-icon icon="mdi:account-voice"></ha-icon>Ansagen tagsüber</button>
      <button class="pill" data-action="nk-tpl" data-t="calm" ${dis}><ha-icon icon="mdi:sleep"></ha-icon>Ruhig</button></div>`;
    const what = `${tplBar}
      ${wide ? `<div class="segs small nk-view"><button class="seg ${view === "list" ? "on" : ""}" data-action="nk-view" data-v="list"><ha-icon icon="mdi:format-list-bulleted"></ha-icon>Liste</button><button class="seg ${view === "table" ? "on" : ""}" data-action="nk-view" data-v="table"><ha-icon icon="mdi:table"></ha-icon>Tabelle</button></div>` : ""}
      ${view === "table" ? (cols.length ? table : `<p class="muted">Erst unter „Empfänger“ einen Kanal hinzufügen.</p>`) + `<p class="muted small">Haken = dieser Kanal bekommt den Anlass. Details (Grenzen, Vorschau) in der Liste.</p>`
        : [...groups, "Kraftwerk"].map((g) => `<div class="nk-g" style="--c:${NK_GROUPS[g][0]}"><div class="nk-gh"><span class="lg-logo">${modIcon(NK_GROUPS[g][1])}</span>${g}</div>${g === "Kraftwerk" ? appRow : NK_KINDS.filter((x) => x.g === g).map(kindRow).join("")}</div>`).join("")}`;

    // ---------- Reiter „Empfänger“
    const paused = new Set(p.notify_off || []);
    const failing = used.filter((c) => health[c] && !health[c].ok && !paused.has(c));
    const hours = p.notify_hours || {};
    const bundle = new Set(p.notify_bundle || []);
    const card = (id) => {
      const c = chInfo(id);
      const h = health[id];
      const kinds = NK_KINDS.filter((x) => !["off"].includes(p[`notify_${x.k}`]));
      const devs = apps.filter((a) => appChannels(a).includes(id));
      const win = hours[id];
      const voice = id.startsWith("tts:") || id.startsWith("sat:");
      const off = paused.has(id);
      return `<div class="nk-card ${c.ok ? "" : "bad"} ${off ? "paused" : ""}">
        <div class="nk-ch"><ha-icon icon="${NK_GICON[c.group] || "mdi:bell-outline"}"></ha-icon><span class="grow"><b>${esc(c.label)}</b><small>${esc(c.group)}${c.sub ? ` · ${esc(c.sub)}` : ""}</small></span>
          <label class="switch" title="${off ? "Empfänger pausiert – einschalten" : "Empfänger aktiv – pausieren"}"><input type="checkbox" data-action="nk-off" data-ch="${esc(id)}" ${off ? "" : "checked"} ${dis}><span></span></label></div>
        <div class="nk-hs">${off ? `<ha-icon icon="mdi:pause-circle-outline"></ha-icon>pausiert – bekommt nichts, Einstellungen bleiben` : `${dot(id)}${h ? (h.ok ? `zugestellt ${hm(h.at)}` : "Fehler") : c.ok ? "bereit" : "nicht erreichbar"}`}</div>
        ${h && !h.ok ? `<p class="nk-err"><ha-icon icon="mdi:alert-circle-outline"></ha-icon>${esc(h.error || "nicht zugestellt")} · ${hm(h.at)}</p>` : ""}
        <div class="pchips nk-kinds">${kinds.map((x) => { const on = p[`notify_${x.k}`] !== "log" && this._nkChannels(x.k, p).includes(id); return `<button class="pchip ${on ? "on" : ""}" data-action="nk-cell" data-k="${x.k}" data-ch="${esc(id)}" aria-pressed="${on}" ${dis}><i></i>${esc(x.title)}</button>`; }).join("")}
          ${devs.map((a) => `<span class="pchip on ro" title="unter Kraftwerk › Geräte"><i></i>${esc(a.name || "Gerät")} fertig</span>`).join("")}</div>
        <div class="nk-opts">
          <div class="nk-o"><span>Wann</span><div class="segs small"><button class="seg ${win ? "" : "on"}" data-action="nk-hours" data-ch="${esc(id)}" data-v="" ${dis}>Immer</button><button class="seg ${win ? "on" : ""}" data-action="nk-hours" data-ch="${esc(id)}" data-v="${voice ? "08:00-21:00" : "07:00-22:00"}" ${dis}>Zeitraum</button></div>
            ${win ? `<div class="nrow"><input type="time" data-nk-hours="${esc(id)}" data-i="0" value="${esc(win[0])}" ${dis}><span>–</span><input type="time" data-nk-hours="${esc(id)}" data-i="1" value="${esc(win[1])}" ${dis}></div><small class="muted">außerhalb nur Wichtiges</small>` : ""}</div>
          ${voice ? "" : `<label class="nk-o"><span>Bündeln<small>mehrere Meldungen binnen 5 Min. zu einer</small></span><span class="switch"><input type="checkbox" data-action="nk-bundle" data-ch="${esc(id)}" ${bundle.has(id) ? "checked" : ""} ${dis}><span></span></span></label>`}
        </div>
        <div class="nk-ca">
          ${this._admin ? `<button class="secondary small" data-action="ch-test1" data-ch="${esc(id)}"><ha-icon icon="mdi:send-outline"></ha-icon>Testen</button>` : ""}
          <button class="link" data-action="nk-remove" data-ch="${esc(id)}" ${dis}><ha-icon icon="mdi:close"></ha-icon>Entfernen</button>
        </div>
      </div>`;
    };
    const anyVoice = used.some((c) => c.startsWith("tts:") || c.startsWith("sat:"));
    const addOpen = !used.length || this._nkAdd;
    const nOff = used.filter((c) => paused.has(c)).length;
    const who = `
      <div class="nk-whohead"><span class="grow muted small">${used.length ? `${used.length - nOff} aktiv${nOff ? ` · ${nOff} pausiert` : ""}` : ""}</span>
        ${this._admin ? `<button class="secondary small" data-action="nk-add-open"><ha-icon icon="mdi:plus"></ha-icon>Kanal hinzufügen</button>` : ""}</div>
      ${failing.length ? `<div class="note warn"><ha-icon icon="mdi:alert-outline"></ha-icon><span class="grow">Nicht zugestellt: ${failing.map((c) => esc(chInfo(c).label)).join(", ")}</span>${this._admin ? `<button class="secondary small" data-action="ch-test1" data-ch="${esc(failing.join(","))}">Testen</button>` : ""}</div>` : ""}
      ${used.length ? `<div class="nk-cards">${used.map(card).join("")}</div>` : `<p class="muted">Noch kein Kanal gewählt – unten hinzufügen.</p>`}
      ${anyVoice ? `<div class="wxrows">${this._setRow("nva", "Ansagen nur, wenn jemand zu Hause ist", "sonst nur Wichtiges", sw("notify_voice_away"), "Ist niemand zu Hause (Hauswerk › Anwesenheit), sagt Hauswerk nichts an – außer bei „Wichtig“. Ruhezeit gilt für Ansagen immer.")}</div>` : ""}
      <section class="nk-addsec ${addOpen ? "open" : ""}" id="nk-add">
        <button class="nk-addh" data-action="nk-add-toggle" aria-expanded="${addOpen}"><ha-icon icon="mdi:plus-circle-outline"></ha-icon><span class="grow">Kanal hinzufügen · Standard-Kanäle</span><ha-icon icon="mdi:chevron-${addOpen ? "up" : "down"}"></ha-icon></button>
        ${addOpen ? `<p class="muted small">Alles, was in Home Assistant eingerichtet ist: App, Pushover, Telegram, E-Mail, Ansagen (Sprachdienst + Lautsprecher), Sprachassistenten, Anzeige am Tablet. Wählbar sind nur erreichbare Kanäle. Gewählte Kanäle sind die Standard-Kanäle – sie bekommen alle Anlässe ohne eigene Auswahl.</p>
        ${this._chPicker("default", p.notify_channels, { disabled: dis })}` : ""}</section>`;

    // ---------- Reiter „Ruhezeit & Verlauf“
    const ST = { sent: ["mdi:send-check-outline", C.ok, "gesendet"], held: ["mdi:sleep", C.cool, "zurückgehalten"], log: ["mdi:text-box-outline", C.rest, "nur Protokoll"] };
    const quiet = `
      <div class="nk-stats">
        <span style="--c:${C.ok}"><b>${ns.sent ?? 0}</b><small>gesendet heute</small></span>
        <span style="--c:${C.cool}"><b>${ns.held ?? 0}</b><small>zurückgehalten${ns.queued ? ` · ${ns.queued} wartet` : ""}</small></span>
        <span style="--c:${C.rest}"><b>${ns.log ?? 0}</b><small>nur Protokoll</small></span>
        <span style="--c:${(ns.failed ?? 0) ? C.alert : C.rest}"><b>${ns.failed ?? 0}</b><small>nicht zugestellt</small></span>
      </div>
      ${head("mdi:sleep", "Ruhezeit")}
      <div class="wxrows">
        ${this._setRow("quiet", "Nachts nicht stören", "Nachrichten danach senden, falls noch aktuell", sw("notify_quiet"),
          "In der Ruhezeit hält Hauswerk normale Nachrichten zurück und schickt sie danach – nur, wenn der Anlass noch besteht. Wichtige kommen sofort, Ansagen gar nicht. Eigene Zeiten je Kanal unter „Empfänger“.")}
        ${p.notify_quiet ? this._setRow("qtime", "Von – bis", "", `<div class="nrow"><input type="time" data-set="notify_quiet_from" value="${esc(p.notify_quiet_from || "22:00")}" ${dis}><span>–</span><input type="time" data-set="notify_quiet_to" value="${esc(p.notify_quiet_to || "07:00")}" ${dis}></div>`, "Auch über Mitternacht, z. B. 22:00 – 07:00.", true) : ""}
      </div>
      ${this._admin && (p.notify_channels || []).length ? `<button class="secondary small" data-action="ch-test" data-list="default"><ha-icon icon="mdi:send-outline"></ha-icon>Testnachricht an alle Standard-Kanäle</button>` : ""}
      ${head("mdi:history", "Zuletzt")}
      <div class="nk-hist">${(ns.last || []).map((h) => { const [i, c, l] = ST[h.state] || ST.log; return `<div class="nk-hr"><ha-icon icon="${i}" style="color:${c}"></ha-icon><span class="grow"><b>${esc(h.title)}</b><small>${esc(h.message)}</small><small class="muted">${esc(h.how || l)}</small></span><em>${new Date(h.at).toLocaleTimeString("de-DE", { hour: "2-digit", minute: "2-digit" })}</em></div>`; }).join("") || `<p class="muted small">Noch keine Nachricht.</p>`}</div>
      <button class="link" data-action="tab" data-tab="log"><ha-icon icon="mdi:text-box-search-outline"></ha-icon>Alle Nachrichten im Protokoll</button>`;

    const tabs = [["what", "mdi:bell-ring-outline", "Anlässe"], ["who", "mdi:account-multiple-outline", "Empfänger"], ["quiet", "mdi:sleep", "Ruhezeit & Verlauf"]];
    return {
      icon: "mdi:cellphone-message", c: "#0ea5e9", title: "Benachrichtigungen", sub: "Hauswerk · für Heizwerk, Rollwerk und Kraftwerk",
      body: `
        <div class="segs nk-tabs">${tabs.map(([id, i, l]) => `<button class="seg ${tab === id ? "on" : ""}" data-action="nk-tab" data-v="${id}"><ha-icon icon="${i}"></ha-icon>${l}${id === "who" && failing.length ? ` <em class="nk-badge">${failing.length}</em>` : ""}</button>`).join("")}</div>
        ${tab === "who" ? who : tab === "quiet" ? quiet : what}`,
    };
  }

  /** Anzeigename eines notify-Dienstes: mobile_app_pixel_8 → Pixel 8. */
  // ------------------------------------------------------------ Benachrichtigungskanäle (gemeinsam für alle Module)
  /** Alle nutzbaren Kanäle aus Home Assistant: Dienste (App, Pushover, Telegram, E-Mail …), notify-Entitäten,
   *  Sprachassistenten und die Mitteilung in Home Assistant. Ansagen (Sprachdienst + Lautsprecher) kommen dazu,
   *  sobald sie gewählt sind. ok = gerade erreichbar. */
  _channels(extra = []) {
    const S = this._hass?.states || {};
    const svc = Object.keys(this._hass?.services?.notify || {}).filter((x) => !["notify", "persistent_notification", "send_message"].includes(x));
    const out = new Map();
    const group = (t) => /pushover/.test(t) ? "Pushover" : /telegram/.test(t) ? "Telegram" : /smtp|e_?mail|gmail|mail/.test(t) ? "E-Mail"
      : /text_zu_sprache|tts|speak|alexa|echo|google_home|nest/.test(t) ? "Sprachausgabe" : /mobile_app/.test(t) ? "App" : null;
    for (const x of svc) out.set(`svc:${x}`, { id: `svc:${x}`, group: group(x) || "Weitere", label: this._notifyName(x), sub: `notify.${x}`, ok: true });
    for (const e of Object.keys(S).filter((k) => k.startsWith("notify."))) {
      const name = S[e].attributes?.friendly_name || e;
      const g = group(`${e} ${name}`.toLowerCase()) || (/overlay|bildschirm|display/i.test(name) ? "Bildschirm" : /csv|file|datei/i.test(e) ? "Weitere" : "App");
      out.set(`ent:${e}`, { id: `ent:${e}`, group: g, label: name, sub: e, ok: S[e].state !== "unavailable" });
    }
    for (const e of Object.keys(S).filter((k) => k.startsWith("assist_satellite.")))
      out.set(`sat:${e}`, { id: `sat:${e}`, group: "Sprachausgabe", label: S[e].attributes?.friendly_name || e, sub: "Sprachassistent", ok: S[e].state !== "unavailable" });
    out.set("ha", { id: "ha", group: "Home Assistant", label: "Mitteilung (Glocke)", sub: "Seitenleiste von Home Assistant", ok: true });
    for (const id of extra) if (!out.has(id)) out.set(id, this._chInfo(id));
    return [...out.values()];
  }

  _chInfo(id) {
    const S = this._hass?.states || {};
    if (id === "ha") return { id, group: "Home Assistant", label: "Mitteilung (Glocke)", sub: "", ok: true };
    const [kind, rest] = [id.slice(0, 3), id.slice(4)];
    if (kind === "tts") {
      const [tts, player] = rest.split("|");
      const ok = !!S[tts] && S[tts].state !== "unavailable" && !!S[player] && S[player].state !== "unavailable";
      return { id, group: "Sprachausgabe", label: `Ansage ${S[player]?.attributes?.friendly_name || player}`, sub: S[tts]?.attributes?.friendly_name || tts, ok };
    }
    if (kind === "svc") return { id, group: "Weitere", label: this._notifyName(rest), sub: `notify.${rest}`, ok: !!this._hass?.services?.notify?.[rest] };
    return { id, group: "Weitere", label: S[rest]?.attributes?.friendly_name || rest, sub: rest, ok: !!S[rest] && S[rest].state !== "unavailable" };
  }

  _chName(id) {
    return this._chInfo(id)?.label || id;
  }

  /** Kanal-Auswahl: Chips nach Art, nur erreichbare wählbar; Ansage mit Sprachdienst + Lautsprecher; Test. */
  _chPicker(list, selected, { test = true, disabled = "" } = {}) {
    const sel = new Set(selected || []);
    const all = this._channels([...sel]);
    const order = ["App", "Pushover", "Telegram", "E-Mail", "Sprachausgabe", "Bildschirm", "Weitere", "Home Assistant"];
    const groups = order.map((g) => [g, all.filter((c) => c.group === g)]).filter(([, l]) => l.length);
    const chip = (c) => `<button class="pchip ${sel.has(c.id) ? "on" : ""}" data-action="ch-toggle" data-list="${esc(list)}" data-ch="${esc(c.id)}" aria-pressed="${sel.has(c.id)}" title="${esc(c.sub || c.id)}" ${(!c.ok && !sel.has(c.id)) || disabled ? "disabled" : ""}><i></i>${esc(c.label)}${c.ok ? "" : " · nicht erreichbar"}</button>`;
    const S = this._hass?.states || {};
    const tts = Object.keys(S).filter((e) => e.startsWith("tts.") && S[e].state !== "unavailable");
    const players = Object.keys(S).filter((e) => e.startsWith("media_player.") && S[e].state !== "unavailable");
    const name = (e) => esc(S[e]?.attributes?.friendly_name || e);
    return `<div class="chpick" data-chlist="${esc(list)}">
      ${groups.map(([g, l]) => `<div class="chg"><small>${g}</small><div class="pchips">${l.map(chip).join("")}</div></div>`).join("")}
      ${tts.length && players.length ? `<div class="chg"><small>Ansage hinzufügen</small><div class="ch-tts">
        <select data-tts-engine>${tts.map((e) => `<option value="${e}">${name(e)}</option>`).join("")}</select>
        <select data-tts-player>${players.map((e) => `<option value="${e}">${name(e)}</option>`).join("")}</select>
        <button class="secondary small" data-action="ch-tts-add" data-list="${esc(list)}" ${disabled}><ha-icon icon="mdi:plus"></ha-icon>Ansage</button></div></div>` : ""}
      ${test && this._admin ? `<button class="secondary small" data-action="ch-test" data-list="${esc(list)}" ${sel.size ? "" : "disabled"}><ha-icon icon="mdi:send-outline"></ha-icon>Testnachricht an die Auswahl</button>` : ""}
    </div>`;
  }

  /** Liste hinter einer Kanal-Auswahl: Standard, je Anlass oder je Gerät (Entwurf im Fenster). */
  _chList(list) {
    if (list === "default") return this._settings.notify_channels || (this._settings.notify_channels = []);
    if (list.startsWith("route:")) {
      const k = list.slice(6);
      this._settings.notify_routes = { ...(this._settings.notify_routes || {}) };
      return this._settings.notify_routes[k] || (this._settings.notify_routes[k] = []);
    }
    if (list === "app") return this._pop.draft.notify || (this._pop.draft.notify = []);
    return [];
  }

  _chSet(list, values) {
    if (list === "default") this._settings.notify_channels = values;
    else if (list.startsWith("route:")) {
      const routes = { ...(this._settings.notify_routes || {}) };
      if (values.length) routes[list.slice(6)] = values; else delete routes[list.slice(6)];
      this._settings.notify_routes = routes;
    } else if (list === "app") this._pop.draft.notify = values;
    this._renderPop();
  }

  _notifyName(x) {
    const name = String(x).replace(/^mobile_app_/, "").replace(/_/g, " ");
    return name.charAt(0).toUpperCase() + name.slice(1);
  }

  _planList() {
    return Object.values(this._data.plans || {}).sort((a, b) => a.name.localeCompare(b.name, "de"));
  }

  /** Woher ein Raum seine Komfortzeiten bekommt, als Kurztext. */
  _planLabel(r) {
    if (r.schedule_entity) return `${r.schedule_entity.startsWith("calendar.") ? "Kalender" : "Zeitplan"} ${this._entityName(r.schedule_entity)}`;
    const plan = this._data.plans?.[r.plan_id];
    if (plan) return `Plan „${plan.name}“${plan.calendar ? " (Kalender)" : ""}`;
    return (r.schedule || []).length ? "eigener Plan" : "ohne Plan";
  }

  _leadFor(type, p = this._data.settings) {
    return type === "flaeche" ? p.lead_floor ?? 120 : p.lead_radiator ?? 15;
  }

  /** Einstellungen als Zeilen: scope "house" = Hauswerk (gilt für alle Module), "heat" = nur Heizwerk. */
  _settingRows(scope) {
    const p = this._data.settings;
    const s = this._status || {};
    const rooms = this._rooms();
    const plans = this._planList();
    const persons = (p.persons || []).length;
    const d = (iso) => new Date(iso).toLocaleDateString("de-DE", { day: "numeric", month: "short" });
    if (scope === "rw") return this._rwRows(p);
    if (scope === "kw") return this._kwRows(p);
    if (scope === "lw") return this._lwRows(p);
    if (scope === "house") {
      const vac = {
        off: "Nur von Hand",
        period: p.vacation_from && p.vacation_to ? `${d(p.vacation_from)} – ${d(p.vacation_to)}` : "Zeitraum – keiner eingetragen",
        calendar: p.vacation_calendar ? `Kalender ${this._entityName(p.vacation_calendar)}` : "Kalender – keiner gewählt",
      }[p.vacation_source || "period"];
      const n = this._widgets().length;
      const su = this._setupSteps(p).slice(1, -1);
      return [
        { g: "Haus", act: "setup-open", icon: "mdi:rocket-launch-outline", c: "#2dd4bf", title: "Einrichtung",
          sum: `Assistent für ganz Hauswerk · ${su.filter((x) => x.done).length} von ${su.length} Schritten erledigt`, words: "assistent einrichten ersteinrichtung start schritte" },
        { g: "Haus", id: "presence", icon: "mdi:home-account", c: "#34d399", title: "Anwesenheit",
          sum: persons ? `${persons} Person${persons > 1 ? "en" : ""} · abwesend nach ${p.away_delay} Min.${p.arrive_delay ? ` · zu Hause nach ${p.arrive_delay} Min.` : ""}` : "Noch keine Personen gewählt",
          warn: !persons, words: "personen abwesend heimweg nähe entfernung gäste" },
        { g: "Haus", id: "calendars", icon: "mdi:calendar-multiple", c: "#38bdf8", title: "Kalender",
          sum: [p.workday_calendar || p.workday_entity ? `Arbeitstage: ${this._entityName(p.workday_calendar || p.workday_entity)}${(s.free_days || []).length ? ` · nächster freier Werktag ${new Date(s.free_days[0]).toLocaleDateString("de-DE", { weekday: "short", day: "numeric", month: "numeric" })}` : ""}` : "Arbeitstage – keiner gewählt",
            (p.waste_calendars || []).length ? (s.waste?.[0] ? `Müll: ${s.waste[0].type} ${new Date(s.waste[0].date).toLocaleDateString("de-DE", { weekday: "short", day: "numeric", month: "numeric" })}` : "Müllabholung") : "",
            p.main_calendar ? `Standard: ${this._entityName(p.main_calendar)}` : (p.calendars || []).length ? `${p.calendars.length} Termin-Kalender` : "", p.vacation_source === "calendar" && p.vacation_calendar ? "Urlaub per Kalender" : ""].filter(Boolean).join(" · "),
          warn: !!s.workday_calendar_error, words: "kalender feiertag arbeitstag workday wochenende brückentag termine müll abfall familie urlaub" },
        { g: "Haus", id: "vacation", icon: "mdi:palm-tree", c: "#34d399", title: "Urlaub", sum: vac, on: s.vacation, words: "kalender zeitraum stichwort ferien reise" },
        { g: "Haus", id: "weather", icon: "mdi:weather-partly-cloudy", c: "#60a5fa", title: "Wetter",
          sum: `${p.weather_entity ? this._entityName(p.weather_entity) : "Wetter automatisch"}${p.outside_sensor ? ` · Außen: ${this._entityName(p.outside_sensor)}` : ""} · Kälte < ${fmt(p.cold_snap_temp ?? 0)} °C · Sturm ab ${fmt(p.storm_kmh ?? 70, 0)} km/h`,
          warn: this._wxAlerts().length > 0, words: "wetter außentemperatur sensor prognose sonne kälteeinbruch sturm frost heizgrenze" },
        { g: "Haus", id: "notify", icon: "mdi:cellphone-message", c: "#0ea5e9", title: "Benachrichtigungen",
          sum: (p.notify_channels || []).length
            ? `${(p.notify_channels || []).map((x) => this._chName(x)).join(", ")}${p.notify_quiet ? ` · Ruhezeit ${p.notify_quiet_from || "22:00"}–${p.notify_quiet_to || "07:00"}` : ""}`
            : "Noch keine App gewählt – Nachrichten nur im Protokoll",
          words: "handy app nachricht push benachrichtigung fenster batterie frost ruhezeit thermostat" },
        { g: "Darstellung", id: "look", icon: "mdi:palette-outline", c: "#a78bfa", title: "Darstellung",
          sum: `${{ auto: "Wie Home Assistant", sun: "Nach Sonnenstand", light: "Hell", dark: "Dunkel" }[p.look_theme || "auto"]} · Akzent ${(ACCENTS.find(([v]) => v === (p.look_accent || null)) || [0, "eigene Farbe"])[1]} · Hintergrund ${{ pattern: "Muster", daytime: "Tageszeit", plain: "schlicht" }[p.look_background || "pattern"]}`,
          words: "design farbe akzent hell dunkel hintergrund tageszeit himmel uhr uhrzeit wetter kopfzeile größe tablet" },
        { g: "Darstellung", act: "legend-open", icon: "mdi:help-circle-outline", c: "#64748b", title: "Symbole & Farben",
          sum: "Was die Zeichen und Farben in Heizwerk, Rollwerk, Kraftwerk und Lichtwerk bedeuten – mit Suche (am Computer auch Taste „?“)", words: "symbole farben legende zeichen bedeutung hilfe erklärung icon" },
        { g: "Darstellung", start: true, icon: "mdi:view-dashboard-edit-outline", c: "#2dd4bf", title: "Widgets der Startseite",
          sum: `${n} Widget${n === 1 ? "" : "s"} · für alle Benutzer gleich`, words: "start dashboard widget übersicht anpassen" },
        ...MODULES.map((m) => ({ g: "Module", go: m.views.find((v) => ["settings", "shutset", "kwset", "lightset"].includes(v)) || m.views[0], icon: `logo:${m.logo}`,
          c: { rollwerk: "#0ea5e9", kraftwerk: "#f59e0b", lichtwerk: "#6366f1" }[m.id] || "#fb923c", title: m.name,
          sum: m.id === "lichtwerk" ? `${(p.lw_lights || []).length} Lichter · ${Object.keys(this._data.lichtwerk?.profiles || {}).length} Profile` : m.id === "rollwerk" ? `${(p.rw_covers || []).length} Rollläden · ${Object.keys(this._data.rollwerk?.profiles || {}).length} Profile`
            : m.id === "kraftwerk" ? (this._kwConfigured(p) ? [(p.kw_solar || []).length ? "Solar" : "", p.kw_grid ? "Netz" : "", p.kw_battery ? "Batterie" : "", (p.kw_consumers || []).length ? `${p.kw_consumers.length} Verbraucher` : ""].filter(Boolean).join(" · ") : "Noch nicht eingerichtet")
            : `${rooms.length} ${rooms.length === 1 ? "Raum" : "Räume"} · Heizpläne, Vorheizen, Saison und mehr`,
          words: { lichtwerk: "lichtwerk licht lampe leuchte smart light module", rollwerk: "rollwerk rollladen rollo module", kraftwerk: "kraftwerk energie strom solar pv netz batterie module" }[m.id] || "heizen heizung räume module" })),
        ...COMING.map((m) => ({ g: "Module", soon: true, icon: m.icon, c: "#94a3b8", title: m.name, sum: "Kommt später", words: `${m.name.toLowerCase()} module` })),
        { g: "System", go: "log", icon: "mdi:text-box-search-outline", c: "#64748b", title: "Protokoll",
          sum: "Was wann warum entschieden wurde · 14 Tage", words: "protokoll log verlauf ereignisse warum debug" },
        (() => {
          const rd = s.radio || {};
          return { g: "System", id: "radio", x: true, icon: "mdi:access-point-network", c: rd.busy ? "#f97316" : "#64748b", title: "Funk-Auslastung",
            sum: rd.level != null ? `${fmt(rd.level, 0)} % · ${rd.busy ? "ausgelastet – Hauswerk drosselt" : `drosselt ab ${fmt(rd.limit ?? 70, 0)} %`} · ${s.commands_hour ?? 0} Befehle/Std.`
              : (rd.entities || []).length ? "Sensor gerade ohne Wert" : "Kein Duty-Cycle-Sensor gefunden",
            warn: !!rd.busy, words: "funk duty cycle homematic ccu auslastung befehle drosseln" };
        })(),
        { g: "System", id: "access", icon: "mdi:shield-account-outline", c: "#94a3b8", title: "Berechtigungen",
          sum: p.allow_users ? "Alle Benutzer dürfen ändern" : "Nur Administratoren dürfen ändern", words: "admin benutzer rechte tablet speichern" },
      ];
    }
    const season = {
      off: "Immer Heizperiode",
      auto: `Sommerpause ab ${fmt(p.summer_temp ?? 16)} °C außen`,
      entity: `Nach ${p.season_entity ? this._entityName(p.season_entity) : "Entität"}`,
      on: "Sommerpause von Hand an",
    }[p.summer_mode || "off"];
    const pre = { smart: "Lernend", fixed: `Feste Zeit · ${this._leadFor("heizkoerper")} / ${this._leadFor("flaeche")} Min.`, off: "Aus" }[p.preheat_mode || "fixed"] + (p.preheat_weather && (p.preheat_mode || "fixed") !== "off" ? " · nach Wetter" : "");
    const hum = rooms.filter((r) => r.humidity_sensor).length;
    const own = rooms.filter((r) => r.preheat_mode).length;
    const shared = rooms.filter((r) => !r.schedule_entity && this._data.plans?.[r.plan_id]).length;
    const away = p.away_action === "off" ? "Thermostate aus" : p.away_mode === "offset" ? `${fmt(p.away_offset)} °C kühler` : `höchstens ${fmt(p.away_temp)} °C`;
    const rows = [
      { g: "Hauswerk", go: "house", icon: "mdi:home-cog-outline", c: "#2dd4bf", title: "Zentrale Einstellungen",
        sum: "Anwesenheit, Urlaub, Wetter, Benachrichtigungen und Berechtigungen gelten für alle Module", words: "anwesenheit urlaub wetter personen berechtigungen zentral" },
      { g: "Heizen", id: "absence", icon: "mdi:home-export-outline", c: "#94a3b8", title: "Abwesenheit & Urlaub",
        sum: `Abwesend: ${away} · Urlaub: ${fmt(p.vacation_temp)} °C${Number(p.long_away_days) > 0 ? ` · nach ${p.long_away_days} Tagen Frostschutz` : ""}`,
        on: s.vacation || s.away, words: "abwesend urlaub absenken temperatur frostschutz lange" },
      { g: "Heizen", id: "season", icon: s.summer ? "mdi:weather-sunny" : "mdi:snowflake-thermometer", c: "#facc15", title: "Saison", sum: season + (s.summer ? " · gerade Sommerpause" : ""), words: "sommer sommerpause heizperiode außentemperatur" },
      ...(s.hm_links?.available ? [{ g: "System", id: "hmlinks", icon: "mdi:link-variant", c: (s.hm_links.findings || []).some((f) => f.level === "warn") ? "#f97316" : "#0ea5e9", title: "Homematic-Verknüpfungen",
        sum: s.hm_links.at ? `${Object.values(s.hm_links.rooms || {}).reduce((n, r) => n + r.walls.length, 0)} Wandthermostate aus der CCU · ${(s.hm_links.findings || []).length ? `${s.hm_links.findings.length} Hinweis${s.hm_links.findings.length > 1 ? "e" : ""}` : "alles verknüpft"}` : "noch nicht gelesen",
        warn: (s.hm_links.findings || []).some((f) => f.level === "warn"), words: "homematic ccu direktverknüpfung verknüpfung link peers wandthermostat heizkörper fensterkontakt fußbodenheizung kanal" }] : []),
      { g: "Heizen", id: "plans", icon: "mdi:calendar-clock", c: "#60a5fa", title: "Heizpläne",
        sum: plans.length ? `${plans.length} gemeinsame${plans.length === 1 ? "r Plan" : " Pläne"} · ${shared} von ${rooms.length} Räumen nutzen sie` : "Noch kein gemeinsamer Plan", go: "plans", words: "zeitplan komfortzeit kalender import vorlage" },
      { g: "Heizen", id: "preheat", icon: "mdi:clock-fast", c: "#fb923c", title: "Vorheizen", sum: pre + (own ? ` · ${own} ${own > 1 ? "Räume" : "Raum"} mit eigener Einstellung` : ""), words: "lernen lernend fest aus vorlauf aufheizen" },
      { g: "Heizen", id: "vent", icon: "mdi:weather-windy", c: "#22d3ee", title: "Lüften & Schimmelschutz",
        sum: Number(p.vent_rh ?? 65) > 0 ? `Hinweis ab ${p.vent_rh ?? 65} % Luftfeuchte · ${hum} ${hum === 1 ? "Raum" : "Räume"} mit Feuchtesensor` : "Aus",
        words: "lüften feucht schimmel taupunkt bad dusche luftfeuchte" },
      (() => {
        const dm = s.demand;
        const label = { low: p.demand_action === "off" ? "aus – kein Raum braucht Wärme" : `abgesenkt auf ${fmt(p.demand_low ?? 17)} °C`, raise: "angehoben fürs Vorheizen", normal: "normal – Räume brauchen Wärme" };
        return { g: "Heizen", id: "demand", x: true, icon: "mdi:water-boiler", c: dm?.state === "low" ? "#22c55e" : "#f97316", title: "Wärmeanforderung",
          sum: p.demand_entity ? `${this._entityName(p.demand_entity)} · ${dm?.error ? "nicht erreichbar" : label[dm?.state || "normal"]}` : "Aus – Wärmeerzeuger läuft unabhängig",
          words: "vaillant kessel therme wärmepumpe heizung bedarf absenken vorlauf energie sparen" };
      })(),
      { g: "Heizen", id: "protect", icon: "mdi:snowflake-thermometer", c: "#38bdf8", title: "Frostschutz", sum: `${fmt(p.frost_temp)} °C bei offenem Fenster und in der Sommerpause`, words: "fenster frost" },
      { g: "Heizen", id: "boost", icon: "mdi:rocket-launch-outline", c: "#f43f5e", title: "Boost", sum: `${p.boost_minutes || 30} Min. volle Leistung`, words: "boost schnell" },
      { g: "Heizen", id: "liming", icon: "mdi:water-sync", c: "#38bdf8", title: "Entkalkungsschutz",
        sum: p.liming ? `${["Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag", "Sonntag"][p.liming_day ?? 0]}, ${p.liming_time || "10:00"} Uhr · ${p.liming_minutes || 5} Min.` : "Aus", words: "ventil entkalken festsitzen" },
      { g: "Heizen", id: "calibration", x: true, icon: "mdi:tune-vertical-variant", c: "#a78bfa", title: "Kalibrierung", sum: `Offset höchstens alle ${p.calibration_interval || 10} Min. anpassen`, words: "offset kalibrieren batterie" },
      ...rooms.map((r) => ({ g: "Räume", room: r, icon: roomIcon(r), c: this._roomColor(r.id), title: r.name,
        sum: `${TYPES[r.type].label} · ${(r.climates || []).length}× Thermostat · ${this._planLabel(r)}`, off: r.enabled === false, words: "raum thermostat" })),
    ];
    if (!rooms.length) rows.push({ g: "Räume", newRoom: true, icon: "mdi:plus", c: "#2dd4bf", title: "Raum anlegen", sum: "Thermostate, Fenster und Sensoren zuordnen", words: "raum neu" });
    return rows;
  }

  // ------------------------------------------------------------ Protokoll (Hauswerk › Einstellungen › Protokoll)
  /** Einträge laden und neue live empfangen (einmal je geöffnetem Panel). */
  _logInit() {
    if (this._log) return;
    this._log = { loading: true, entries: [] };
    this._hass
      .callWS({ type: "hauswerk/log/get" })
      .then((r) => {
        this._log = { entries: r.entries || [], days: r.days || 14, live: false, at: Date.now() };
        this._logUnsub = this._hass.connection.subscribeMessage(
          (e) => {
            this._log.entries.push(e);
            this._log.at = Date.now();
            if (this._tab === "log") this._renderLogList();
          },
          { type: "hauswerk/log/subscribe" }
        );
        this._logUnsub.then(() => {
          this._log.live = true;
          if (this._tab === "log") this._renderLogList();
        }).catch(() => {});
        if (this._tab === "log") this._renderMain();
      })
      .catch((err) => {
        this._log = { error: err?.message || "Protokoll nicht verfügbar", entries: [] };
        if (this._tab === "log") this._renderMain();
      });
  }

  /** Eingeschaltete Kategorien (je Gerät gemerkt). */
  _logCats() {
    if (!this._logCatSet) {
      let list = null;
      try {
        list = JSON.parse(localStorage.getItem("hauswerk.protokoll.kategorien") || "null");
      } catch (e) {
        list = null;
      }
      this._logCatSet = new Set(Array.isArray(list) ? list : Object.keys(LOG_CATS).filter((k) => !LOG_CATS[k].off));
      // neue Kategorien (z. B. „Rollläden“) bei gemerkter Auswahl einmal dazunehmen
      let known = null;
      try {
        known = JSON.parse(localStorage.getItem("hauswerk.protokoll.bekannt") || "null");
      } catch (e) {
        known = null;
      }
      if (Array.isArray(list)) for (const k of Object.keys(LOG_CATS)) if (!LOG_CATS[k].off && !(known || ["presence", "season", "target", "window", "manual", "health", "command", "settings", "notify"]).includes(k)) this._logCatSet.add(k);
      try {
        localStorage.setItem("hauswerk.protokoll.bekannt", JSON.stringify(Object.keys(LOG_CATS)));
      } catch (e) {
        /* ohne Speicher */
      }
    }
    return this._logCatSet;
  }

  _viewLog() {
    this._logInit();
    const L = this._log || {};
    const cats = this._logCats();
    const rooms = this._rooms();
    const sel = this._logRoom || "";
    const back = `<button class="link back" data-action="tab" data-tab="house"><ha-icon icon="mdi:chevron-left"></ha-icon>Einstellungen</button>`;
    return `
      ${back}
      <section class="card lg">
        <div class="lg-head">
          <span class="lg-ic"><ha-icon icon="mdi:text-box-search-outline"></ha-icon></span>
          <div class="grow"><h2>Protokoll</h2><small>Was wann warum entschieden wurde · ${L.days || 14} Tage</small></div>
          <span class="lg-live ${L.live ? "on" : ""}" id="lg-live">${this._logLiveHtml()}</span>
        </div>
        <div class="lg-chips">${[["", "Alles", "mdi:home-outline", "#94a3b8"], ["heizwerk", "Heizwerk & Haus", "logo:heizen", "#fb923c"], ["rollwerk", "Rollwerk", "logo:rollwerk", "#0ea5e9"], ["kraftwerk", "Kraftwerk", "logo:kraftwerk", "#f59e0b"], ["lichtwerk", "Lichtwerk", "logo:lichtwerk", "#6366f1"]]
          .map(([id, name, icon, c]) => `<button class="lg-cat lg-mod ${(this._logMod || "") === id ? "on" : ""}" style="--c:${c}" data-action="log-mod" data-id="${id}">${String(icon).startsWith("logo:") ? `<span class="lg-logo">${modIcon(icon)}</span>` : `<ha-icon icon="${icon}"></ha-icon>`}${name}</button>`)
          .join("")}</div>
        <div class="lg-chips">${[["", "Alle Räume", "#94a3b8"], ...rooms.map((r) => [r.id, r.name, this._roomColor(r.id)])]
          .map(([id, name, c]) => `<button class="lg-room ${sel === id ? "on" : ""}" style="--c:${c}" data-action="log-room" data-id="${id}"><i></i>${esc(name)}</button>`)
          .join("")}</div>
        <div class="lg-chips">${Object.entries(LOG_CATS)
          .map(([k, d]) => `<button class="lg-cat ${cats.has(k) ? "on" : ""}" style="--c:${d.c}" data-action="log-cat" data-k="${k}" aria-pressed="${cats.has(k)}"><ha-icon icon="${d.icon}"></ha-icon>${d.name}</button>`)
          .join("")}</div>
        <div class="search lg-search"><ha-icon icon="mdi:magnify"></ha-icon><input type="search" data-action="log-search" placeholder="Suchen … (z. B. Fenster, Boost, Offset)" value="${esc(this._logQuery || "")}" autocomplete="off"></div>
        <div id="log-list">${this._logList()}</div>
      </section>`;
  }

  _logLiveHtml() {
    const L = this._log || {};
    const time = L.at ? new Date(L.at).toLocaleTimeString("de-DE") : "";
    return `<i></i>${L.live ? "live" : L.error ? "getrennt" : "verbinde …"}${time ? ` · ${time}` : ""}`;
  }

  /** Nur Liste und Live-Anzeige neu zeichnen (Suchfeld behält den Fokus). */
  _renderLogList() {
    const list = this.shadowRoot.getElementById("log-list");
    if (list) list.innerHTML = this._logList();
    const live = this.shadowRoot.getElementById("lg-live");
    if (live) {
      live.innerHTML = this._logLiveHtml();
      live.classList.toggle("on", !!this._log?.live);
    }
  }

  _logList() {
    const L = this._log || {};
    if (L.loading) return `<div class="chart-empty"><div class="spinner"></div></div>`;
    if (L.error) return `<p class="note warn"><ha-icon icon="mdi:alert-outline"></ha-icon>${esc(L.error)}</p>`;
    const cats = this._logCats();
    const room = this._logRoom || "";
    const q = (this._logQuery || "").toLowerCase().trim();
    const rooms = this._data.rooms || {};
    const roomName = (e) => rooms[e.room]?.name || e.rn || "";
    const hits = [];
    for (let i = L.entries.length - 1; i >= 0; i--) {
      const e = L.entries[i];
      if (!cats.has(e.cat) && LOG_CATS[e.cat]) continue;
      if (room && e.room !== room) continue;
      if (["rollwerk", "kraftwerk", "lichtwerk"].includes(this._logMod) && e.mod !== this._logMod) continue;
      if (this._logMod === "heizwerk" && ["rollwerk", "kraftwerk", "lichtwerk"].includes(e.mod)) continue;
      if (q && !`${e.title} ${e.why || ""} ${roomName(e)} ${LOG_CATS[e.cat]?.name || ""}`.toLowerCase().includes(q)) continue;
      hits.push(e);
    }
    if (!hits.length)
      return `<section class="empty small"><ha-icon icon="mdi:text-box-remove-outline"></ha-icon><p>${L.entries.length ? "Keine Einträge für diese Auswahl." : "Noch keine Einträge – ab jetzt protokolliert Hauswerk jede Entscheidung."}</p></section>`;
    const limit = this._logLimit || 200;
    const today = new Date().toDateString();
    const yesterday = new Date(Date.now() - 864e5).toDateString();
    let html = "";
    let lastDay = null;
    for (const e of hits.slice(0, limit)) {
      const d = new Date(e.ts * 1000);
      const ds = d.toDateString();
      if (ds !== lastDay) {
        lastDay = ds;
        html += `<div class="lg-day">${ds === today ? "Heute" : ds === yesterday ? "Gestern" : d.toLocaleDateString("de-DE", { weekday: "long", day: "numeric", month: "long" })}</div>`;
      }
      const def = LOG_CATS[e.cat] || { icon: "mdi:information-outline", c: "#94a3b8" };
      const rn = roomName(e);
      const rc = rooms[e.room] ? this._roomColor(e.room) : "#94a3b8";
      const lead = ["settings", "command", "health"].includes(e.cat) ? "Details" : "Warum";
      html += `
        <div class="lg-row">
          <time>${d.toLocaleTimeString("de-DE", { hour: "2-digit", minute: "2-digit" })}</time>
          <span class="lg-i" style="--c:${def.c}" title="${esc(def.name || "")}"><ha-icon icon="${def.icon}"></ha-icon></span>
          <div class="lg-b">
            <div class="lg-t">${e.mod === "rollwerk" ? `<span class="lg-badge" style="--c:#0ea5e9">Rollwerk</span>` : e.mod === "lichtwerk" ? `<span class="lg-badge" style="--c:#6366f1">Lichtwerk</span>` : ""}${rn ? `<span class="lg-badge" style="--c:${rc}">${esc(rn)}</span>` : ""}<b>${esc(e.title)}</b></div>
            ${e.why ? `<p><b>${lead}:</b> ${esc(e.why)}</p>` : ""}
          </div>
        </div>`;
    }
    if (hits.length > limit) html += `<button class="secondary wide lg-more" data-action="log-more">Ältere anzeigen (${hits.length - limit} weitere)</button>`;
    return html;
  }

  /** Einstellungen des Moduls Heizwerk. */
  _viewSettings() {
    return this._settingsPage("heat");
  }

  /** Zentrale Hauswerk-Einstellungen: gelten für alle Module. */
  _viewHouse() {
    return this._settingsPage("house");
  }

  _settingsPage(scope) {
    const intro = scope === "house"
      ? `<p class="muted small setintro"><ha-icon icon="mdi:home-cog-outline"></ha-icon>Diese Einstellungen gelten für ganz Hauswerk und alle Module. Was nur das Heizen betrifft, steht unter <button class="link inline" data-action="tab" data-tab="settings">Heizwerk › Einstellungen</button>.</p>`
      : "";
    return `
      ${intro}
      ${this._expertCard(scope)}
      <div class="setsearch search"><ha-icon icon="mdi:magnify"></ha-icon><input type="search" data-action="set-search" placeholder="Einstellung suchen …" value="${esc(this._setQuery || "")}" autocomplete="off"></div>
      <div id="set-list">${this._settingsList(scope)}</div>`;
  }

  /** Haken „Experteneinstellungen“ oben in den Einstellungen jedes Moduls. */
  _expertCard(scope) {
    const mod = EXPERT_MOD[scope];
    if (!mod) return "";
    const on = this._expertOn(mod);
    const name = { haus: "Hauswerk", heizen: "Heizwerk", rollwerk: "Rollwerk", kraftwerk: "Kraftwerk" }[mod];
    const what = { haus: "Funk-Auslastung", heizen: "Wärmeanforderung, Kalibrierung und im Raum: Regelung im Detail, Fenster-Feinheiten", rollwerk: "Nach Neustart und im Profil alle Einstellungen der Cover Control Automation", kraftwerk: "getrennte Einspeisung und Vorzeichen umdrehen" }[mod];
    return `<button class="xcard ${on ? "on" : ""}" data-action="expert-mod" data-mod="${mod}" role="switch" aria-checked="${on}">
      <span class="xc-box" aria-hidden="true">${on ? "✓" : ""}</span>
      <span class="grow"><b>Experteneinstellungen</b><small>${on ? `Alle Einstellungen von ${name} sichtbar` : `Blendet ein: ${what}`}</small></span>
      <ha-icon class="xc-ic" icon="mdi:school-outline"></ha-icon></button>`;
  }

  _settingsList(scope = this._tab === "house" ? "house" : this._tab === "shutset" ? "rw" : this._tab === "kwset" ? "kw" : this._tab === "lightset" ? "lw" : "heat") {
    const q = (this._setQuery || "").toLowerCase().trim();
    const ex = this._expertOn(EXPERT_MOD[scope] || "haus");
    const rows = this._settingRows(scope).filter((r) => (!r.x || ex) && (!q || `${r.g} ${r.title} ${r.sum} ${r.words}`.toLowerCase().includes(q)));
    if (!rows.length) return `<section class="card empty small"><p>Nichts gefunden für „${esc(q)}“.</p></section>`;
    const row = (r) => {
      const attrs = r.soon
        ? "disabled"
        : r.room
          ? `data-action="room-edit" data-id="${r.room.id}" ${this._admin ? "" : "disabled"}`
          : r.newRoom
            ? `data-action="room-new" ${this._admin ? "" : "disabled"}`
            : r.start
              ? `data-action="start-edit" ${this._admin ? "" : "disabled"}`
              : r.act
                ? `data-action="${r.act}"`
                : r.go
                ? `data-action="tab" data-tab="${r.go}"`
                : `data-action="pop-open" data-pop="${r.id}"`;
      return `
        <button class="srow ${r.warn ? "warn" : ""} ${r.off || r.soon ? "off" : ""}" ${attrs}>
          <span class="sr-ic ${String(r.icon).startsWith("logo:") ? "logo" : ""}" style="--c:${r.c}">${modIcon(r.icon)}</span>
          <span class="sr-t"><b>${esc(r.title)}${r.on ? ` <em class="badge ok">AKTIV</em>` : ""}${r.off ? ` <em class="badge">${r.offTxt || "AUTOMATIK AUS"}</em>` : ""}${r.soon ? ` <em class="badge">BALD</em>` : ""}</b><small>${esc(r.sum)}</small></span>
          ${r.soon ? "" : `<ha-icon class="sr-go" icon="mdi:chevron-right"></ha-icon>`}
        </button>`;
    };
    return [...new Set(rows.map((r) => r.g))]
      .map(
        (g) => `
        <section class="card sgroup">
          <div class="sg-h">${g}${g === "Räume" && this._admin && this._rooms().length ? `<span class="grow"></span><button class="link" data-action="room-new"><ha-icon icon="mdi:plus"></ha-icon>Raum</button>` : ""}</div>
          ${rows.filter((r) => r.g === g).map(row).join("")}
        </section>`
      )
      .join("");
  }

  // ------------------------------------------------------------ Einrichtung (Assistent für ganz Hauswerk)
  /** Schritte der Einrichtung mit Stand: erledigt, optional. */
  _setupSteps(p = this._data.settings) {
    const covers = (p.rw_covers || []).length;
    return [
      { id: "start", name: "Los geht's", icon: "mdi:hand-wave-outline" },
      { id: "persons", name: "Personen", icon: "mdi:account-group-outline", done: (p.persons || []).length > 0 },
      { id: "weather", name: "Wetter", icon: "mdi:weather-partly-cloudy", done: !!(p.weather_entity || p.outside_sensor || Object.keys(this._hass.states).some((e) => e.startsWith("weather."))) },
      { id: "rooms", name: "Räume", icon: "logo:heizen", done: this._rooms().length > 0 },
      { id: "covers", name: "Rollläden", icon: "logo:rollwerk", done: covers > 0, optional: true },
      { id: "energy", name: "Energie", icon: "logo:kraftwerk", done: this._kwConfigured(p), optional: true },
      { id: "done", name: "Fertig", icon: "mdi:flag-checkered" },
    ];
  }

  _setupOpen(step = 0) {
    this._setupBack = { step };
    this._openPop("setup", { step });
  }

  /** Geänderte Einstellungen der Einrichtung speichern (Personen, Wetter, Kraftwerk). */
  async _setupSave() {
    if (!this._settings) return true;
    const keys = ["persons", "weather_entity", "outside_sensor", "kw_solar", "kw_grid", "kw_battery", "kw_battery_soc", "kw_home"];
    const diff = {};
    for (const k of keys) if (JSON.stringify(this._settings[k] ?? null) !== JSON.stringify(this._data.settings[k] ?? null)) diff[k] = this._settings[k] ?? null;
    if (!Object.keys(diff).length) return true;
    try {
      this._data.settings = await this._ws({ type: "hauswerk/heizen/settings/save", settings: diff });
      this._settings = { ...clone(this._data.settings), ...this._settings };
      return true;
    } catch (err) {
      return false;
    }
  }

  /** Bereiche aus Home Assistant mit Thermostat, die noch kein Raum sind. */
  _setupAreas() {
    const used = new Set(this._rooms().flatMap((r) => r.climates || []));
    return Object.values(this._hass.areas || {})
      .map((a) => ({ id: a.area_id, name: a.name, climates: this._areaEntities(a.area_id).filter((e) => e.startsWith("climate.") && !used.has(e)) }))
      .filter((a) => a.climates.length)
      .sort((a, b) => a.name.localeCompare(b.name, "de"));
  }

  _setupPop() {
    const d = this._pop.draft;
    const p = this._settings;
    const steps = this._setupSteps(p);
    const st = steps[d.step];
    const S = this._hass.states;
    const bar = `<div class="wiz-bar">${steps.map((x, i) => `<button class="wiz-dot ${i === d.step ? "on" : x.done ? "done" : ""}" data-action="setup-go" data-i="${i}"><i>${x.done && i !== d.step ? "✓" : i + 1}</i><span>${x.name}</span></button>`).join("")}</div>`;
    const lead = (t) => `<p class="wiz-lead">${t}</p>`;
    let body = "";
    switch (st.id) {
      case "start":
        body = `${lead("In wenigen Schritten ist Hauswerk bereit: wer hier wohnt, woher das Wetter kommt, welche Räume geheizt werden – und auf Wunsch Rollläden und Energie. Alles lässt sich später ändern; jeder Schritt kann übersprungen werden.")}
          <div class="setup-list">${steps.slice(1, -1).map((x, i) => `<button class="srow" data-action="setup-go" data-i="${i + 1}">
            <span class="sr-ic ${String(x.icon).startsWith("logo:") ? "logo" : ""}" style="--c:${x.done ? "#22c55e" : "#94a3b8"}">${modIcon(x.icon)}</span>
            <span class="sr-t"><b>${x.name}${x.optional ? ` <em class="badge">OPTIONAL</em>` : ""}</b><small>${x.done ? "erledigt" : "noch offen"}</small></span>
            <ha-icon class="sr-go" icon="${x.done ? "mdi:check-circle" : "mdi:chevron-right"}" style="${x.done ? "color:#22c55e" : ""}"></ha-icon></button>`).join("")}</div>`;
        break;
      case "persons": {
        const all = Object.keys(S).filter((e) => e.startsWith("person.")).sort();
        const chosen = new Set(p.persons || []);
        const people = new Map(this._people(all).map((x) => [x.id, x]));
        body = `${lead("Wer wohnt hier? Hauswerk weiß dann, wann niemand zu Hause ist – Heizwerk senkt ab, Rollwerk kann tagsüber zu bleiben.")}
          ${all.length ? `<div class="pchips left">${all.map((id) => { const x = people.get(id); return `<button class="pchip ${chosen.has(id) ? "on" : ""} ${x?.home ? "home" : ""}" data-action="person-toggle" data-id="${esc(id)}" aria-pressed="${chosen.has(id)}"><i></i>${esc(x?.name || this._entityName(id))} · ${esc(!x ? "" : x.home ? "da" : x.distTxt || x.where || "")}</button>`; }).join("")}</div>`
            : `<p class="muted">In Home Assistant gibt es noch keine Personen. Lege sie unter Einstellungen › Personen an – oder später unter Hauswerk › Anwesenheit.</p>`}
          ${all.length && !chosen.size ? `<button class="link" data-action="setup-all-persons"><ha-icon icon="mdi:check-all"></ha-icon>Alle wählen</button>` : ""}
          <p class="muted small">Gäste, Wartezeiten und Heimweg stellst du später unter <b>Hauswerk › Anwesenheit</b> ein.</p>`;
        break;
      }
      case "weather": {
        const ws = Object.keys(S).filter((e) => e.startsWith("weather.")).sort();
        const cur = p.weather_entity || ws[0] || null;
        const w = cur && S[cur];
        body = `${lead("Das Wetter brauchen Vorheizen, Frostschutz, Sonnenschutz und Sturmschutz.")}
          ${ws.length ? `<div class="lbl">Wetterdienst</div><div class="pchips left">${ws.map((id) => `<button class="pchip ${cur === id ? "on" : ""}" data-action="setup-weather" data-id="${esc(id)}"><i></i>${esc(this._entityName(id))}${S[id]?.attributes?.temperature != null ? ` · ${fmt(S[id].attributes.temperature, 1)} °C` : ""}</button>`).join("")}</div>`
            : `<p class="muted">Kein Wetterdienst gefunden. Füge in Home Assistant z. B. „Met.no“ oder „DWD“ hinzu.</p>`}
          ${w ? `<div class="rq-facts"><span style="--c:#60a5fa"><ha-icon icon="mdi:weather-partly-cloudy"></ha-icon>${esc(w.state)} · ${fmt(w.attributes?.temperature, 1)} °C</span></div>` : ""}
          <div class="field"><span><ha-icon icon="mdi:thermometer"></ha-icon> Eigener Außensensor (optional, genauer als der Wetterdienst)</span>${this._picker("outside_sensor", p.outside_sensor)}</div>`;
        break;
      }
      case "rooms": {
        const rooms = this._rooms();
        const areas = this._setupAreas();
        body = `${lead("Heizwerk regelt jeden Raum einzeln. Der Raum-Assistent findet Thermostate, Fenster und Sensoren im Bereich und schlägt Temperaturen und Heizzeiten vor.")}
          ${rooms.length ? `<div class="lbl">Schon angelegt</div><div class="pchips left">${rooms.map((r) => `<span class="pchip on static"><i></i>${esc(r.name)}</span>`).join("")}</div>` : ""}
          ${areas.length ? `<div class="lbl">Bereiche mit Thermostat – noch kein Raum</div><div class="setup-list">${areas.map((a) => `<button class="srow" data-action="setup-room" data-area="${esc(a.id)}">
            <span class="sr-ic" style="--c:#fb923c"><ha-icon icon="mdi:plus"></ha-icon></span><span class="sr-t"><b>${esc(a.name)}</b><small>${a.climates.map((e) => esc(this._entityName(e))).join(", ")}</small></span><ha-icon class="sr-go" icon="mdi:chevron-right"></ha-icon></button>`).join("")}</div>` : ""}
          <button class="secondary" data-action="setup-room"><ha-icon icon="mdi:plus"></ha-icon>${rooms.length ? "Weiteren Raum anlegen" : "Raum anlegen"}</button>
          ${!areas.length && !rooms.length ? `<p class="muted small">Tipp: Ordne Thermostate in Home Assistant einem Bereich zu – dann findet der Assistent sie von selbst.</p>` : ""}`;
        break;
      }
      case "covers": {
        const have = new Set(p.rw_covers || []);
        const free = Object.keys(S).filter((e) => e.startsWith("cover.") && !have.has(e));
        body = `${lead("Rollwerk fährt Rollläden morgens auf, abends zu, beschattet bei Sonne und lüftet bei gekipptem Fenster – Fensterkontakte kommen aus Heizwerk.")}
          <div class="rq-facts"><span style="--c:#0ea5e9"><ha-icon icon="mdi:window-shutter"></ha-icon>${have.size} eingerichtet</span>${free.length ? `<span style="--c:#94a3b8"><ha-icon icon="mdi:window-shutter-open"></ha-icon>${free.length} weitere in Home Assistant</span>` : ""}</div>
          ${free.length ? `<button class="secondary" data-action="setup-covers"><ha-icon icon="mdi:plus"></ha-icon>Rollläden hinzufügen</button>` : `<p class="muted small">${have.size ? "Alle Rollläden aus Home Assistant sind eingerichtet." : "In Home Assistant gibt es keine Rollläden (cover.*) – diesen Schritt einfach überspringen."}</p>`}`;
        break;
      }
      case "energy": {
        const sug = this._kwSuggest();
        const P = this._kwPrefs();
        const fl = this._kwFlow(p);
        const found = [["kw_solar", "Solar"], ["kw_grid", "Netz"], ["kw_battery", "Batterie"]].filter(([k]) => (Array.isArray(sug[k]) ? sug[k].length : sug[k]));
        body = `${lead("Kraftwerk zeigt live, woher dein Strom kommt – Solar, Netz, Batterie – und wie autark du heute warst.")}
          ${this._kwConfigured(p) ? `<div class="rq-facts">${fl.has.solar ? `<span style="--c:#f59e0b"><ha-icon icon="mdi:solar-power-variant"></ha-icon>Solar ${this._kwFmt(fl.solar)}</span>` : ""}${fl.has.grid ? `<span style="--c:#8b5cf6"><ha-icon icon="mdi:transmission-tower"></ha-icon>Netz ${this._kwFmt(fl.grid, true)}</span>` : ""}<span style="--c:#0ea5e9"><ha-icon icon="mdi:home-lightning-bolt-outline"></ha-icon>Haus ${this._kwFmt(fl.home)}</span></div>`
            : found.length ? `<p>Gefunden: <b>${found.map(([, l]) => l).join(", ")}</b>.</p><button class="secondary" data-action="kw-take" data-k="all"><ha-icon icon="mdi:auto-fix"></ha-icon>Erkannte Sensoren übernehmen</button>`
              : `<p class="muted">Keine Leistungs-Sensoren (W/kW) gefunden. Ohne PV-Anlage oder Stromzähler-Anbindung diesen Schritt überspringen.</p>`}
          <button class="link" data-action="setup-kw"><ha-icon icon="mdi:tune-variant"></ha-icon>Im Einzelnen prüfen</button>
          <p class="muted small">${!P ? "Energie-Dashboard wird gelesen …" : P.ok ? "Tageswerte und Preise kommen aus dem Energie-Dashboard von Home Assistant ✓" : "Für Tageswerte, Autarkie und Kosten im Energie-Dashboard von Home Assistant Netz und Solar eintragen."}</p>`;
        break;
      }
      case "done": {
        const open = steps.filter((x) => x.done === false && !x.optional);
        body = `<div class="setup-done"><ha-icon icon="${open.length ? "mdi:progress-check" : "mdi:check-decagram"}"></ha-icon>
          <h2>${open.length ? "Fast fertig" : "Hauswerk ist eingerichtet"}</h2>
          <p>${open.length ? `Noch offen: ${open.map((x) => x.name).join(", ")}. Du kannst jederzeit unter Hauswerk › Einstellungen › Einrichtung weitermachen.` : "Die Startseite zeigt jetzt alles Wichtige. Unter „Anpassen“ wählst du Widgets – und oben findet die Lupe jede Einstellung."}</p></div>
          <div class="setup-list">${steps.slice(1, -1).map((x) => `<div class="srow static"><span class="sr-ic ${String(x.icon).startsWith("logo:") ? "logo" : ""}" style="--c:${x.done ? "#22c55e" : "#94a3b8"}">${modIcon(x.icon)}</span>
            <span class="sr-t"><b>${x.name}</b><small>${x.done ? "erledigt" : x.optional ? "übersprungen" : "noch offen"}</small></span><ha-icon class="sr-go" icon="${x.done ? "mdi:check-circle" : "mdi:circle-outline"}" style="${x.done ? "color:#22c55e" : ""}"></ha-icon></div>`).join("")}</div>`;
        break;
      }
    }
    const last = d.step === steps.length - 1;
    return {
      icon: "mdi:rocket-launch-outline", c: "#2dd4bf", title: "Hauswerk einrichten", sub: `Schritt ${d.step + 1} von ${steps.length} · ${st.name}`,
      body: `${bar}${body}`,
      foot: `${d.step ? `<button class="secondary" data-action="setup-go" data-i="${d.step - 1}">Zurück</button>` : `<button class="secondary" data-action="setup-close">Später</button>`}
        ${last ? `<button class="primary" data-action="setup-close"><ha-icon icon="mdi:check"></ha-icon>Fertig</button>`
          : `<button class="primary" data-action="setup-go" data-i="${d.step + 1}">${st.optional && !st.done ? "Überspringen" : "Weiter"}<ha-icon icon="mdi:chevron-right"></ha-icon></button>`}`,
    };
  }

  // ------------------------------------------------------------ Suche über alles
  /** Für die Suche: klein, ohne Umlaute und Satzzeichen. */
  _gsNorm(text) {
    return String(text || "").toLowerCase().replace(/ä/g, "a").replace(/ö/g, "o").replace(/ü/g, "u").replace(/ß/g, "ss").replace(/[^a-z0-9.%° ]+/g, " ");
  }

  /** Alles, was sich finden lässt – je Eintrag Gruppe, Symbol, Titel, Unterzeile, Suchtext und Ziel (data-Attribute). */
  _gsItems() {
    const out = [];
    const add = (g, icon, c, title, sub, words, attrs) => out.push({ g, icon, c, title, sub, hay: `${title} ${sub} ${words || ""}`, attrs });
    const a = (action, data = {}) => `data-action="${action}" data-gs="1" ${Object.entries(data).map(([k, v]) => `data-${k}="${esc(v)}"`).join(" ")}`;
    // Seiten
    add("Seiten", "mdi:view-dashboard-outline", "#2dd4bf", "Start", "Übersicht mit Widgets", "dashboard startseite home", a("tab", { tab: "start" }));
    for (const m of MODULES) for (const v of SUB_VIEWS.filter((x) => m.views.includes(x.id) && x.slug)) add("Seiten", `logo:${m.logo}`, "#94a3b8", `${m.name} › ${v.name}`, "", m.id, a("tab", { tab: v.id }));
    add("Seiten", "mdi:cog-outline", "#64748b", "Hauswerk › Einstellungen", "für alle Module", "zahnrad", a("tab", { tab: "house" }));
    add("Seiten", "mdi:text-box-search-outline", "#64748b", "Protokoll", "was wann warum entschieden wurde", "log verlauf", a("tab", { tab: "log" }));
    // Räume und ihre Geräte
    for (const r of this._rooms()) {
      add("Räume", "mdi:door", this._roomColor(r.id), r.name, `${r.type === "flaeche" ? "Fußbodenheizung" : "Heizkörper"} · Komfort ${fmt(r.comfort, 1)} °C`, "raum zimmer", a("room-page", { id: r.id }));
      const ents = [...(r.climates || []), ...(r.windows || []), r.temp_sensor, r.humidity_sensor, ...(r.extra || [])].filter(Boolean);
      for (const id of ents) add("Geräte", this._hass.states[id]?.attributes?.icon || (id.startsWith("climate.") ? "mdi:thermostat" : id.startsWith("binary_sensor.") ? "mdi:window-closed-variant" : "mdi:eye-outline"),
        "#94a3b8", this._entityName(id), `${r.name} · ${id}`, id, a("room-page", { id: r.id }));
    }
    // Heizpläne
    for (const [pid, p] of Object.entries(this._data.plans || {})) add("Heizpläne", "mdi:calendar-clock", "#f59e0b", p.name || pid, "gemeinsamer Heizplan", "plan zeiten", a("plan-sel", { kind: "plan", id: pid }));
    // Rollwerk
    if (this._data.rollwerk) {
      for (const c of this._rwCovers()) add("Rollläden", "mdi:window-shutter", "#0ea5e9", this._entityName(c.id), `${this._rwProfName(c.cfg.profile || "standard")}${c.rs.reason ? ` · ${c.rs.reason}` : ""}`, `rollladen rollo ${c.id}`, a("pop-open", { pop: `rwc:${c.id}` }));
      for (const p of this._rwProfiles()) add("Profile", "mdi:tune-variant", "#0ea5e9", p.name, "Rollwerk-Profil", "profil rollwerk", a("pop-open", { pop: `rwp:${p.id}:tag` }));
    }
    // Lichtwerk
    if (this._data.lichtwerk) {
      for (const l of this._lwLights()) add("Licht", "mdi:lightbulb-outline", "#6366f1", this._lwName(l), `${this._lwProfName(l.cfg.profile)}${l.ls.cause ? ` · ${l.ls.cause}` : ""}`, `licht lampe leuchte ${l.id} ${l.ls.area || ""}`, a("pop-open", { pop: `lwbri:${l.id}` }));
      for (const p of this._lwProfiles()) add("Profile", "mdi:tune-variant", "#6366f1", p.name, "Lichtwerk-Profil", "profil lichtwerk licht", a("pop-open", { pop: `lwp:${p.id}:on` }));
    }
    // Kraftwerk
    const kp = this._data.settings;
    for (const id of kp.kw_consumers || []) add("Geräte", this._kwConsIcon(id, kp), "#0ea5e9", this._kwConsName(id, kp), `Verbraucher · ${this._kwFmt(this._kwW(id))}`, `kraftwerk strom ${id}`, a("pop-open", { pop: "kwcons" }));
    // Einstellungen aller Module
    const scopes = [["house", "Hauswerk"], ["heat", "Heizwerk"], ...(this._data.rollwerk ? [["rw", "Rollwerk"]] : []), ["kw", "Kraftwerk"], ...(this._data.lichtwerk ? [["lw", "Lichtwerk"]] : [])];
    for (const [scope, label] of scopes) {
      let rows = [];
      try {
        rows = this._settingRows(scope);
      } catch (err) {
        this._fail(`Suche › Einstellungen ${label}`, err);
      }
      for (const r of rows) {
        if (r.soon || r.room || r.start) continue;
        const attrs = r.newRoom ? a("room-new") : r.act ? a(r.act) : r.go ? a("tab", { tab: r.go }) : a("pop-open", { pop: r.id });
        add(`Einstellungen · ${label}`, r.icon, r.c, r.title, r.sum, `${r.g} ${r.words || ""} einstellung`, attrs);
      }
    }
    return out;
  }

  _gsList(q) {
    const words = this._gsNorm(q).split(/\s+/).filter(Boolean);
    if (!words.length) {
      const recent = [["mdi:door", "Räume", "overview"], ["mdi:window-shutter", "Rollläden", "shutters"], ["mdi:lightbulb-group-outline", "Licht", "lights"], ["mdi:transmission-tower", "Energiefluss", "kwflow"], ["mdi:chart-box-outline", "Bericht", "report"]];
      return `<p class="muted small">Tippe, um zu suchen. Auf dem Computer öffnet <kbd>/</kbd> die Suche.</p>
        <div class="gs-quick">${recent.map(([i, l, t]) => `<button class="chip" data-action="tab" data-tab="${t}" data-gs="1"><ha-icon icon="${i}"></ha-icon>${l}</button>`).join("")}</div>`;
    }
    const scored = [];
    for (const it of this._gsItems()) {
      const title = this._gsNorm(it.title), hay = this._gsNorm(it.hay);
      if (!words.every((w) => hay.includes(w))) continue;
      let score = 0;
      for (const w of words) score += title.startsWith(w) ? 6 : new RegExp(`\\b${w.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}`).test(title) ? 4 : title.includes(w) ? 2 : 0;
      score += { Räume: 3, Seiten: 2 }[it.g] || 0;
      scored.push({ ...it, score });
    }
    scored.sort((x, y) => y.score - x.score);
    const groups = new Map();
    for (const it of scored) {
      if (!groups.has(it.g)) groups.set(it.g, []);
      if (groups.get(it.g).length < 6) groups.get(it.g).push(it);
    }
    // Gruppe mit dem besten Treffer zuerst
    const order = [...groups.keys()].sort((x, y) => Math.max(...groups.get(y).map((i) => i.score)) - Math.max(...groups.get(x).map((i) => i.score)));
    const row = (it) => `<button class="srow" ${it.attrs}>
        <span class="sr-ic ${String(it.icon).startsWith("logo:") ? "logo" : ""}" style="--c:${it.c}">${modIcon(it.icon)}</span>
        <span class="sr-t"><b>${esc(it.title)}</b>${it.sub ? `<small>${esc(it.sub)}</small>` : ""}</span><ha-icon class="sr-go" icon="mdi:chevron-right"></ha-icon></button>`;
    const log = `<button class="srow" data-action="gs-log" data-gs="1" data-q="${esc(q.trim())}"><span class="sr-ic" style="--c:#64748b"><ha-icon icon="mdi:text-box-search-outline"></ha-icon></span>
        <span class="sr-t"><b>„${esc(q.trim())}“ im Protokoll suchen</b><small>14 Tage: Entscheidungen, Fahrten, Änderungen</small></span><ha-icon class="sr-go" icon="mdi:chevron-right"></ha-icon></button>`;
    return `${scored.length ? order.map((g) => `<div class="gs-g"><div class="lbl">${esc(g)}</div>${groups.get(g).map(row).join("")}</div>`).join("") : `<p class="muted">Nichts gefunden für „${esc(q.trim())}“.</p>`}
      <div class="gs-g"><div class="lbl">Protokoll</div>${log}</div>`;
  }

  // ------------------------------------------------------------ Pop-ups
  _openPop(id, draft = {}) {
    this._settings = clone(this._data.settings);
    this._pop = { id, draft };
    this._renderPop();
  }

  _closePop() {
    const was = this._pop?.id;
    this._pop = null;
    this._settings = null;
    this._renderPop();
    if (was === "setup") this._setupBack = null;
    // aus der Einrichtung gestartet (Raum, Rollläden, Energie): danach dorthin zurück
    if (this._setupBack && was && was !== "setup")
      setTimeout(() => {
        if (!this._pop && !this._dialog && this._setupBack) this._openPop("setup", { step: this._setupBack.step });
      }, 60);
  }

  /** Pop-up schließen, ohne zur Einrichtung zurückzuspringen (es folgt gleich ein anderes). */
  _closePopQuiet() {
    this._pop = null;
    this._settings = null;
    this._renderPop();
  }

  /** Nach einer Änderung an Einstellungen neu zeichnen: das offene Pop-up, sonst die Seite. */
  _refreshSettings() {
    if (this._pop) this._renderPop();
    else this._renderMain();
  }

  _renderPop() {
    const host = this.shadowRoot.getElementById("pop");
    if (!host) return;
    // Darstellung: Änderungen sofort als Vorschau zeigen, beim Abbrechen wieder die gespeicherten
    this._applyLook(this._pop?.id === "look" ? this._settings : null);
    if (!this._pop) {
      host.innerHTML = "";
      return;
    }
    const scroll = host.querySelector(".sheet-body")?.scrollTop || 0;
    let def;
    try {
      def = this._popDef(this._pop.id);
    } catch (err) {
      def = { icon: "mdi:alert-circle-outline", c: "#ef4444", title: "Fehler", sub: "Dieses Fenster kann nicht angezeigt werden",
        body: this._failCard(`Das Fenster „${this._pop.id}“`, err), foot: `<button class="secondary" data-action="pop-close">Schließen</button>` };
    }
    const foot =
      def.foot ??
      `<button class="secondary" data-action="pop-close">${this._admin ? "Abbrechen" : "Schließen"}</button>
       ${this._admin ? `<button class="primary" data-action="pop-save"><ha-icon icon="mdi:content-save-outline"></ha-icon>Speichern</button>` : ""}`;
    host.innerHTML = `
      <div class="backdrop" data-action="pop-close"></div>
      <div class="sheet pop" role="dialog" aria-label="${esc(def.title)}">
        <div class="sheet-head">
          <span class="sr-ic big" style="--c:${def.c}"><ha-icon icon="${def.icon}"></ha-icon></span>
          <div class="grow"><h2>${def.title}</h2>${def.sub ? `<div class="muted">${def.sub}</div>` : ""}</div>
          <button class="icon boxed" data-action="pop-close" title="Schließen"><ha-icon icon="mdi:close"></ha-icon></button>
        </div>
        <div class="sheet-body">${this._admin || def.open ? "" : `<p class="note warn"><ha-icon icon="mdi:lock-outline"></ha-icon>Nur ansehen: Ändern dürfen Administratoren – oder alle, wenn ein Admin es unter „Berechtigungen“ freigibt.</p>`}${def.body}</div>
        <div class="sheet-foot">${foot}</div>
      </div>`;
    const body = host.querySelector(".sheet-body");
    if (body && this._pop.keep) body.scrollTop = scroll;
    this._pop.keep = true;
  }

  _popDef(id) {
    if (id === "rwiz") return this._wizPop();
    if (id === "cwiz") {
      if (!this._pop.draft.covers) Object.assign(this._pop.draft, this._cwizDraft());
      return this._cwizPop();
    }
    if (String(id).startsWith("rwc:")) return this._rwcPop(id.slice(4));
    if (String(id).startsWith("rwpos:")) return this._rwPosPop(id.slice(6));
    if (String(id).startsWith("kwapp:")) return this._kwAppPop(id.slice(6));
    if (String(id).startsWith("lwp:")) { const [, pid, sec] = String(id).split(":"); return this._lwpPop(pid, LW_SECTIONS.some(([x]) => x === sec) ? sec : "on"); }
    if (String(id).startsWith("lwbri:") || String(id).startsWith("lwl:") || String(id).startsWith("lwroom:") || LW_POPS.includes(id)) return this._lwPop(id);
    if (RW_POPS.includes(id)) return this._rwPop(id);
    if (KW_POPS.includes(id)) return this._kwPop(id);
    if (id === "setup") return this._setupPop();
    if (id === "search")
      return { icon: "mdi:magnify", c: "#2dd4bf", title: "Suchen", sub: "Seiten, Räume, Geräte, Rollläden, Profile, Einstellungen und Protokoll",
        body: `<div class="search gs-in"><ha-icon icon="mdi:magnify"></ha-icon><input type="search" data-action="g-search" placeholder="z. B. Bad, Urlaub, Batterie, Wallbox …" value="${esc(this._pop.draft.q || "")}" autocomplete="off" enterkeyhint="go"></div>
          <div id="gs-list">${this._gsList(this._pop.draft.q || "")}</div>`, foot: `<button class="secondary" data-action="pop-close">Schließen</button>` };
    if (id === "errtext")
      return { icon: "mdi:content-copy", c: "#64748b", title: "Diagnose", sub: "Text markieren und kopieren",
        body: `<textarea class="hw-errtext" readonly rows="12">${esc(this._pop.draft.text || this._failText())}</textarea>`, foot: `<button class="secondary" data-action="pop-close">Schließen</button>` };
    if (String(id).startsWith("rwp:")) { const [, pid, sec] = String(id).split(":"); return this._rwpPop(pid, RW_SECTIONS.some(([x]) => x === sec) ? sec : "tag"); }
    const p = this._settings;
    const s = this._status || {};
    const { minutes, segs, sw, head, dis } = this._setHelpers(p);
    const rooms = this._rooms();
    const st = s.rooms || {};
    const date = (iso, time = false) =>
      new Date(iso).toLocaleString("de-DE", time ? { weekday: "short", day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" } : { weekday: "short", day: "numeric", month: "short" });
    switch (id) {
      case "presence": {
        const S = this._hass.states;
        const st = this._status || {};
        const persons = [...new Set(Object.keys(S).filter((e) => e.startsWith("person.")).concat(p.persons || []))];
        const chosen = new Set(p.persons || []);
        const zones = Object.keys(S).filter((e) => e.startsWith("zone.")).sort((a, b) => (a === "zone.home" ? -1 : b === "zone.home" ? 1 : a.localeCompare(b)));
        const people = new Map(this._people(persons, p.home_zone || "zone.home").map((x) => [x.id, x]));
        const state = st.vacation
          ? ["mdi:palm-tree", "Urlaub", "#34d399"]
          : p.presence_force === "away"
            ? ["mdi:home-export-outline", "Abwesend – von Hand", "#94a3b8"]
            : st.away
              ? ["mdi:home-export-outline", "Niemand da", "#94a3b8"]
              : st.approaching
                ? ["mdi:home-import-outline", "Jemand kommt heim", "#14b8a6"]
                : ["mdi:home-account", (p.persons || []).length ? "Jemand da" : "Keine Personen gewählt", (p.persons || []).length ? "#14b8a6" : "#f59e0b"];
        const chip = (id) => {
          const x = people.get(id);
          const txt = !x ? "fehlt" : x.home ? "da" : x.distTxt || x.where;
          return `<button class="pchip ${chosen.has(id) ? "on" : ""} ${x?.home ? "home" : ""}" data-action="person-toggle" data-id="${esc(id)}" aria-pressed="${chosen.has(id)}" ${dis}><i></i>${esc(x?.name || this._entityName(id))} · ${esc(txt)}</button>`;
        };
        const step = (key, def) =>
          `<div class="mstep"><button data-action="min-step" data-key="${key}" data-d="-5" aria-label="5 Minuten weniger" ${dis}>−</button><b>${p[key] ?? def} min</b><button data-action="min-step" data-key="${key}" data-d="5" aria-label="5 Minuten mehr" ${dis}>+</button></div>`;
        const row = (k, title, sub, value, text, ctl) => this._setRow(k, title, sub, value, text, ctl);
        return {
          icon: "mdi:home-account", c: "#8b5cf6", title: "Anwesenheit", sub: "Hauswerk · gilt für alle Module",
          body: `
            <span class="pstate" style="--c:${state[2]}"><ha-icon icon="${state[0]}"></ha-icon>${state[1]}</span>
            <div class="wxsrcs">
              <div class="wxsrc">${row("who", "Wer wohnt hier?", "Tippen zum Aus- und Abwählen", `<div class="pchips">${persons.map(chip).join("") || `<span class="muted small">Keine Personen in Home Assistant</span>`}</div>`,
                "Gewählte Personen zählen, sobald sie in der Wohnung sind (über die Ortung ihres Handys in Home Assistant). Sind alle weg, gilt das Haus nach der Wartezeit als abwesend. Ohne gewählte Personen gibt es kein automatisches „Abwesend“. Über „Hinzufügen“ wählst du auch Handys oder Tracker (device_tracker) direkt; „Neue Person“ legt eine Person in Home Assistant an.", true)}
              <div class="wxr-pk">${this._picker("person_add", p.persons || [])}
                ${this._data.user_admin ? (this._newPerson != null ? `
                <div class="newp"><input type="text" maxlength="40" data-newp placeholder="Name, z. B. Julia" value="${esc(this._newPerson)}"><button class="primary small" data-action="person-create"><ha-icon icon="mdi:account-plus-outline"></ha-icon>Anlegen</button><button class="link tiny" data-action="person-new">Abbrechen</button></div>
                <p class="muted small">Legt die Person in Home Assistant an. Damit Hauswerk sie orten kann, ordnest du ihr danach unter Einstellungen › Personen ihr Handy zu.</p>`
                : `<button class="pk-add" data-action="person-new"><ha-icon icon="mdi:account-plus-outline"></ha-icon>Neue Person in Home Assistant anlegen</button>`) : ""}</div></div>
            </div>
            <div class="wxrows">
              ${row("zone", "Wohnung (Zone)", "wo „zu Hause“ ist", `<select data-set="home_zone" ${dis}>${zones.map((z) => `<option value="${esc(z)}" ${(p.home_zone || "zone.home") === z ? "selected" : ""}>${esc(z === "zone.home" && this._entityName(z) === z ? "Home (Zuhause)" : this._entityName(z))}</option>`).join("")}</select>`,
                "Die Zone aus Home Assistant, in der eine Person als zu Hause gilt – meist „Home“. Abstände rechnet Hauswerk zur Mitte dieser Zone.", true)}
              ${row("delay", "Absenken nach", "damit kurze Wege nichts auslösen", step("away_delay", 10),
                "Erst wenn alle gewählten Personen so lange weg sind, gilt das Haus als abwesend. Was dann passiert, legt jedes Modul fest – fürs Heizen unter Heizwerk › Abwesenheit & Urlaub.")}
              ${row("arrive", "Zu Hause nach", "nach dem Heimkommen", step("arrive_delay", 0),
                "So lange nach dem Heimkommen bleibt es noch bei „abwesend“ – z. B. damit ein kurzer Zwischenstopp nicht gleich alles hochheizt. 0 = sofort.")}
              ${row("vac", "Urlaub", "von Hand – bleibt an, bis du ihn ausschaltest", sw("vacation"),
                "Schaltet Urlaub für alle Module. Automatisch per Zeitraum oder Kalender: Hauswerk › Einstellungen › Urlaub.")}
              ${row("guest", "Gäste da", "nicht absenken, auch wenn alle Bewohner weg sind", sw("guest"),
                "Solange Gäste da sind, gilt das Haus nie als abwesend – auch wenn alle gewählten Personen unterwegs sind.")}
            </div>
            <p class="muted small"><ha-icon icon="mdi:calendar-star"></ha-icon>Feiertage und Arbeitstage stehen jetzt unter <button class="link inline" data-action="settings-go" data-sub="calendars">Hauswerk › Kalender</button>.</p>
            ${head("mdi:map-marker-radius-outline", "Auf dem Heimweg")}
            <div class="wxrows">
              ${row("near", "Näher als", "und auf dem Weg nach Hause = schon zu Hause (0 = aus)", `<div class="unit"><input type="number" step="50" min="0" max="50000" data-set="proximity_m" value="${Math.round(p.proximity_m ?? 0)}" ${dis}><i>m</i></div>`,
                "Kommt eine Person näher und ist schon näher als dieser Abstand, gilt das Haus als bewohnt – Heizwerk heizt dann schon vor. Wer in der Nähe ist, aber nicht näher kommt (z. B. Arbeit oder Einkauf um die Ecke), zählt nicht: Sonst würde die Abwesenheit nie greifen. Die Richtung kommt aus dem Bewegungs-Sensor der Integration „Nähe“; ohne ihn zählt, ob der Abstand in den letzten 15 Minuten kleiner wurde.", true)}
            </div>
            <div class="field"><span>Entfernungs-Sensoren (optional, z. B. aus der Integration „Nähe“)</span>${this._picker("proximity_sensors", p.proximity_sensors || [])}</div>
            <p class="muted small"><ha-icon icon="mdi:information-outline"></ha-icon>Party und Eco schaltest du in der Hausmodus-Leiste auf der Startseite. Präsenzmelder einzelner Räume stehen am Raum unter „Geräte“.</p>`,
        };
      }

      case "absence":
        return {
          icon: "mdi:home-export-outline", c: "#94a3b8", title: "Abwesenheit & Urlaub", sub: "Heizwerk · was die Heizung tut, wenn niemand da ist",
          body: `
            <p class="muted small"><ha-icon icon="mdi:home-cog-outline"></ha-icon>Wer zu Hause ist und wann Urlaub ist, stellst du zentral ein: <button class="link inline" data-action="settings-go" data-sub="presence">Anwesenheit</button> · <button class="link inline" data-action="settings-go" data-sub="vacation">Urlaub</button></p>
            ${head("mdi:home-export-outline", "Wenn niemand da ist")}
            <div class="field">${segs("away_action", [["lower", "Absenken", "mdi:thermometer-chevron-down"], ["off", "Thermostate aus", "mdi:power"]], "lower")}</div>
            ${(p.away_action || "lower") === "lower" ? `
            <div class="field">${segs("away_mode", [["temp", "Auf höchstens …", "mdi:thermometer"], ["offset", "Um … kühler", "mdi:arrow-down-thin"]], "temp")}</div>
            ${(p.away_mode || "temp") === "offset"
              ? `<label class="field narrow"><span>Absenkung</span><div class="unit"><input type="number" step="0.5" min="0" max="10" data-set="away_offset" value="${p.away_offset ?? 2}" ${dis}><i>°C</i></div></label>`
              : `<div class="field"><span>Höchstens</span>${this._stepper("set", "away_temp", p.away_temp)}</div>`}` : ""}
            <label class="field narrow"><span><ha-icon icon="mdi:snowflake-thermometer"></ha-icon> Frostschutz, wenn so lange niemand da war (0 = nie)</span><div class="unit"><input type="number" step="1" min="0" max="60" data-set="long_away_days" value="${p.long_away_days ?? 0}" ${dis}><i>Tage</i></div></label>
            ${head("mdi:palm-tree", "Im Urlaub")}
            <div class="field"><span>Temperatur im Urlaub (alle Räume)</span>${this._stepper("set", "vacation_temp", p.vacation_temp)}</div>`,
        };

      case "calendars": {
        const st = this._status || {};
        const saved = this._data.settings;
        const row = (k, title, sub, value, text, ctl) => this._setRow(k, title, sub, value, text, ctl);
        const dd = (iso) => new Date(iso).toLocaleDateString("de-DE", { weekday: "short", day: "numeric", month: "numeric" });
        const free = saved.workday_calendar === p.workday_calendar && saved.workday_entity === p.workday_entity ? st.free_days || [] : null;
        const fc = p.workday_calendar && /forecast|morgen|tomorrow/i.test(`${p.workday_calendar} ${this._entityName(p.workday_calendar)}`);
        const wdOn = !!(p.workday_calendar || p.workday_entity);
        const vac = { off: "nur von Hand", period: "per Zeitraum", calendar: p.vacation_calendar ? `aus ${this._entityName(p.vacation_calendar)}` : "per Kalender – keiner gewählt" }[p.vacation_source || "period"];
        return {
          icon: "mdi:calendar-multiple", c: "#38bdf8", title: "Kalender", sub: "Hauswerk · gilt für alle Module",
          body: `
            ${head("mdi:calendar-check-outline", "Arbeitstage & Feiertage")}
            <div class="wxsrcs">
              <div class="wxsrc">${row("wdcal", "Arbeitstage-Kalender", "von der Integration „Arbeitstag“ (Workday)", "",
                "Der Kalender der Integration „Arbeitstag“ hat für jeden Arbeitstag einen Termin. Fehlt an einem Werktag der Termin (Feiertag, Brückentag …), gelten die Zeiten des Wochenendes: in Heizwerk für alle Heizpläne – auch schon in der Vorschau für morgen –, in Rollwerk fürs Öffnen und abends fürs Schließen (morgen frei?). Anders als der Sensor kennt der Kalender auch die nächsten Tage. Den Kalender ohne Versatz wählen (nicht „Forecast“/„morgen“).", true)}
              <div class="wxr-pk">${this._picker("workday_calendar", p.workday_calendar ? [p.workday_calendar] : [])}</div></div>
            </div>
            ${fc ? `<p class="note warn"><ha-icon icon="mdi:alert-outline"></ha-icon>Das scheint der Kalender mit Versatz („Forecast“) zu sein – dann wären alle Tage um einen verschoben. Besser den Kalender ohne Versatz wählen.</p>` : ""}
            ${st.workday_calendar_error && free ? `<p class="note warn"><ha-icon icon="mdi:alert-outline"></ha-icon>Kalender nicht lesbar: ${esc(st.workday_calendar_error)} – bis dahin gilt der Sensor.</p>` : ""}
            ${wdOn ? `<div class="field"><span>An freien Werktagen wie am</span>${segs("workday_as", [["5", "Samstag", "mdi:calendar-weekend"], ["6", "Sonntag", "mdi:calendar-weekend-outline"]], "6")}</div>` : ""}
            ${free ? `<div class="lbl">Freie Werktage · nächste 2 Wochen</div>
            <div class="evlist">${free.length ? free.map((d) => `<div class="ev ${d === new Date().toLocaleDateString("sv-SE") ? "live" : ""}"><ha-icon icon="mdi:calendar-star"></ha-icon><span class="grow"><b>${dd(d)}</b><small>Zeiten wie am ${Number(p.workday_as ?? 6) === 5 ? "Samstag" : "Sonntag"}</small></span>${d === new Date().toLocaleDateString("sv-SE") ? `<em class="badge ok">HEUTE</em>` : ""}</div>`).join("") : `<p class="muted small">${wdOn ? "Keine – alle Werktage sind Arbeitstage." : "Ohne Arbeitstage-Kalender gelten Feiertage wie normale Werktage."}</p>`}</div>`
              : `<p class="muted small"><ha-icon icon="mdi:information-outline"></ha-icon>Nach dem Speichern zeigt Hauswerk hier die freien Werktage.</p>`}
            <details class="role-help" ${p.workday_entity && !p.workday_calendar ? "open" : ""}><summary>Ohne Kalender: Arbeitstag-Sensor (kennt nur heute)</summary>
              <div class="wxr-pk">${this._picker("workday_entity", p.workday_entity ? [p.workday_entity] : [])}</div>
              <p class="muted small">Gilt, wenn kein Kalender gewählt oder er nicht lesbar ist. Damit weiß Hauswerk erst am Feiertag selbst, dass frei ist.</p></details>
            ${head("mdi:palm-tree", "Urlaub")}
            <button class="srow" data-action="settings-go" data-sub="vacation"><span class="sr-ic" style="--c:#34d399"><ha-icon icon="mdi:palm-tree"></ha-icon></span><span class="sr-t"><b>Urlaub automatisch</b><small>${esc(vac)}</small></span><ha-icon class="sr-go" icon="mdi:chevron-right"></ha-icon></button>
            ${head("mdi:trash-can-outline", "Müllabholung")}
            <div class="wxsrcs">
              <div class="wxsrc">${row("waste", "Abfuhr-Kalender", "z. B. Waste Collection Schedule", "",
                "Kalender mit den Abholterminen – je Abfallart ein Termin (Restabfall, Bio, Papier, Gelbe Tonne …). Hauswerk erinnert am Vorabend, zeigt die Abholung im Bildschirmschoner, unter der Glocke und in den Widgets „Termine“ und „Nächste Ereignisse“ – mit eigenem Symbol und eigener Farbe je Abfallart.", true)}
              <div class="wxr-pk">${this._picker("waste_calendars", p.waste_calendars || [])}</div></div>
            </div>
            ${(p.waste_calendars || []).length ? `
            <div class="field"><span>Erinnern am Vorabend ab</span>${segs("waste_remind", [["null", "Aus"], ["17:00", "17 Uhr"], ["18:00", "18 Uhr"], ["19:00", "19 Uhr"], ["20:00", "20 Uhr"]], "null")}</div>
            <p class="muted small">Ab dann steht „Morgen Müllabfuhr“ unter der Glocke und groß im Bildschirmschoner – bis zur Abholung am nächsten Vormittag (10 Uhr).</p>
            ${p.waste_remind ? `<div class="field"><span>Nachricht aufs Handy am Vorabend</span>${segs("notify_waste", [["off", "Aus", "mdi:bell-off-outline"], ["log", "Protokoll", "mdi:text-box-outline"], ["normal", "Normal", "mdi:bell-outline"], ["important", "Wichtig", "mdi:bell-alert-outline"]], "off").replace('class="segs small"', 'class="segs small n4"')}</div>
            <p class="muted small">An die Geräte unter <button class="link inline" data-action="settings-go" data-sub="notify">Benachrichtigungen</button>, einmal je Abholtag.</p>` : ""}
            ${(st.waste_types || []).length ? `<div class="field"><span>Anzeigen</span><div class="pchips">${st.waste_types.map((t) => { const on = !(p.waste_hidden || []).some((h) => h.toLowerCase() === t.toLowerCase()); const [ic, c] = this._calIcon(t); return `<button class="pchip ${on ? "on" : ""}" data-action="waste-hide" data-t="${esc(t)}" aria-pressed="${on}" ${dis} style="--c:${c}"><ha-icon icon="${ic}"></ha-icon>${esc(t)}</button>`; }).join("")}</div></div>
            <p class="muted small">Abgewählte Abfallarten (z. B. Sperrmüll nur auf Anmeldung) zeigt und meldet Hauswerk nicht.</p>` : ""}
            ${st.waste_error ? `<p class="note warn"><ha-icon icon="mdi:alert-outline"></ha-icon>Nicht lesbar: ${esc(st.waste_error)}</p>` : ""}
            ${(st.waste || []).length ? `<div class="lbl">Nächste Abholungen</div><div class="evlist">${st.waste.slice(0, 6).map((e) => { const [ic, c] = this._calIcon(e.type); const today = e.date === new Date().toLocaleDateString("sv-SE"); return `<div class="ev ${st.waste_due?.date === e.date ? "live" : ""}"><ha-icon icon="${ic}" style="color:${c}"></ha-icon><span class="grow"><b>${esc(e.type)}</b><small>${today ? "heute" : dd(e.date)}</small></span></div>`; }).join("")}</div>` : `<p class="muted small">In den nächsten zwei Wochen keine Abholung${JSON.stringify(saved.waste_calendars || []) === JSON.stringify(p.waste_calendars || []) ? "" : " – nach dem Speichern erscheinen sie hier"}.</p>`}` : ""}
            ${head("mdi:calendar-text-outline", "Termine")}
            <div class="wxsrcs">
              <div class="wxsrc">${row("maincal", "Standard-Kalender", "z. B. Familie", "",
                "Der wichtigste Kalender des Haushalts: Seine Termine stehen in Bildschirmschoner und Widgets zuerst.", true)}
              <div class="wxr-pk">${this._picker("main_calendar", p.main_calendar ? [p.main_calendar] : [])}</div></div>
            </div>
            <div class="field"><span>Weitere Kalender (z. B. Schule, Geburtstage)</span>${this._picker("calendars", (p.calendars || []).filter((c) => c !== p.main_calendar))}</div>
            <p class="muted small">Alle Termine erscheinen im Bildschirmschoner des Tablets und in den Widgets „Termine“ und „Nächste Ereignisse“ (dort je Widget auch eigene Kalender wählbar).</p>
            <p class="muted small"><ha-icon icon="mdi:window-shutter"></ha-icon>Rollwerk-Profile können weiterhin eigene Kalender für Fahrzeiten und einen eigenen Sensor „Arbeitstag morgen“ haben – ohne gilt dieser Arbeitstage-Kalender.</p>`,
        };
      }

      case "vacation": {
        const src = p.vacation_source || "period";
        const saved = this._data.settings;
        const events = src === "calendar" && saved.vacation_calendar === p.vacation_calendar && saved.vacation_keywords === p.vacation_keywords ? s.vacation_events || [] : null;
        return {
          icon: "mdi:palm-tree", c: "#34d399", title: "Urlaub", sub: "Hauswerk · gilt für alle Module",
          body: `
            <div class="field"><span>Urlaub automatisch erkennen</span>${segs("vacation_source", [["off", "Aus", "mdi:close-circle-outline"], ["period", "Zeitraum", "mdi:calendar-range"], ["calendar", "HA-Kalender", "mdi:calendar-search"]], "period")}</div>
            ${src === "period" ? `
            <div class="row2">
              <label class="field"><span><ha-icon icon="mdi:calendar-start"></ha-icon> Von</span><input type="date" data-set="vacation_from" value="${esc(p.vacation_from || "")}" ${dis}></label>
              <label class="field"><span><ha-icon icon="mdi:calendar-end"></ha-icon> Bis</span><input type="date" data-set="vacation_to" value="${esc(p.vacation_to || "")}" ${dis}></label>
            </div>` : ""}
            ${src === "calendar" ? `
            <div class="field"><span><ha-icon icon="mdi:calendar"></ha-icon> Kalender</span>${this._picker("vacation_calendar", p.vacation_calendar ? [p.vacation_calendar] : [])}</div>
            <label class="field"><span><ha-icon icon="mdi:text-search"></ha-icon> Stichworte im Termin-Titel (mit Komma getrennt, leer = jeder Termin)</span>
              <input type="text" maxlength="200" data-set="vacation_keywords" value="${esc(p.vacation_keywords ?? "")}" placeholder="Urlaub, Ferien" ${dis}></label>
            <p class="muted small">Läuft ein passender Termin, ist Urlaub – auch ganztägige und mehrtägige Termine. Hauswerk schaut alle 5 Minuten nach.</p>
            ${s.vacation_calendar_error && events ? `<p class="note warn"><ha-icon icon="mdi:alert-outline"></ha-icon>Kalender nicht lesbar: ${esc(s.vacation_calendar_error)}</p>` : ""}
            ${events ? `
            <div class="lbl">Gefundene Termine</div>
            <div class="evlist">${events.length ? events.map((e) => `
              <div class="ev ${new Date(e.start) <= new Date() ? "live" : ""}"><ha-icon icon="${new Date(e.start) <= new Date() ? "mdi:palm-tree" : "mdi:calendar-blank-outline"}"></ha-icon>
                <span class="grow"><b>${esc(e.summary || "Termin")}</b><small>${date(e.start)} – ${date(new Date(e.end).getTime() - 1)}</small></span>${new Date(e.start) <= new Date() ? `<em class="badge ok">JETZT</em>` : ""}</div>`).join("") : `<p class="muted small">In den nächsten 4 Monaten kein passender Termin.</p>`}</div>`
            : `<p class="muted small"><ha-icon icon="mdi:information-outline"></ha-icon>Nach dem Speichern zeigt Hauswerk hier die gefundenen Termine.</p>`}` : ""}
            ${src === "off" ? `<p class="muted small">Urlaub nur von Hand.</p>` : ""}
            <p class="muted small"><ha-icon icon="mdi:gesture-tap"></ha-icon>Von Hand geht es immer: „Urlaub“ in der Hausmodus-Leiste oder <code>switch.hauswerk_urlaub</code> für Automationen.</p>
            <p class="muted small"><ha-icon icon="mdi:radiator"></ha-icon>Die Temperatur im Urlaub stellst du unter <button class="link inline" data-action="settings-go" data-sub="absence">Heizwerk › Abwesenheit & Urlaub</button> ein.</p>`,
        };
      }

      case "season":
        return {
          icon: "mdi:weather-sunny", c: "#facc15", title: "Saison", sub: "Heizperiode oder Sommerpause – für alle Räume",
          body: `
            <p class="muted">In der Sommerpause bleiben die Thermostate aus. Zurück in den Heizbetrieb geht es 1 °C unter der Schwelle.</p>
            <div class="field"><span>Sommerpause</span>${segs("summer_mode", [["off", "Nie", "mdi:close-circle-outline"], ["auto", "Nach Außentemperatur", "mdi:thermometer-auto"], ["entity", "Nach Entität", "mdi:toggle-switch-outline"], ["on", "Jetzt an", "mdi:weather-sunny"]], "off")}</div>
            ${p.summer_mode === "auto" ? `
            <div class="row2">
              <div class="field"><span>Außentemperatur</span>${this._picker("outside_sensor", p.outside_sensor ? [p.outside_sensor] : [])}</div>
              <div class="field"><span>Sommerpause ab</span>${this._stepper("set", "summer_temp", p.summer_temp ?? 16)}</div>
            </div>
            <div class="field"><span>Entscheiden nach</span>${segs("summer_basis", [["now", "Temperatur jetzt", "mdi:thermometer"], ["day", "Tagesmittel (24 h)", "mdi:calendar-today"], ["days3", "Mittel 3 Tage", "mdi:calendar-range"]], "day")}</div>
            <p class="muted small">${(p.summer_basis || "day") === "now"
              ? "Zählt der Wert genau in diesem Moment, kann die Saison an milden Nachmittagen kurz wechseln – und das wöchentliche Entkalken hängt am Zufall."
              : `Ein ${(p.summer_basis || "day") === "days3" ? "Mittel über 3 Tage" : "Tagesmittel"} ist ruhiger: einzelne warme Stunden oder kalte Morgen ändern die Saison nicht.${this._status?.outside_mean != null ? ` Gerade: <b>${fmt(this._status.outside_mean)} °C</b> im Mittel.` : " Bis genug Werte gesammelt sind (ca. 6 Stunden), gilt die Temperatur jetzt."}`} Danach richtet sich auch das Entkalken im Sommer.</p>` : ""}
            ${p.summer_mode === "entity" ? `
            <div class="field"><span>Heizperiode (an = heizen, aus = Sommerpause)</span>${this._picker("season_entity", p.season_entity ? [p.season_entity] : [])}</div>` : ""}
            ${["auto", "entity"].includes(p.summer_mode) ? `
            <div class="field"><span>Wenn ${p.summer_mode === "auto" ? "der Außensensor" : "die Entität"} nicht verfügbar ist</span>${segs("summer_fallback", [["keep", "Zustand halten", "mdi:pause-circle-outline"], ["heat", "Heizen", "mdi:fire"], ["summer", "Sommerpause", "mdi:weather-sunny"]], "keep")}</div>` : ""}
            ${p.summer_mode && p.summer_mode !== "off" ? `
            <div class="field"><span>Thermostate in der Sommerpause</span>${segs("summer_action", [["off", "Ausschalten", "mdi:power"], ["frost", "Frostschutz", "mdi:snowflake"]], "off")}</div>` : ""}`,
        };

      case "preheat": {
        const mode = p.preheat_mode || "fixed";
        const own = rooms.filter((r) => r.preheat_mode);
        const label = { smart: "lernend", fixed: "feste Zeit", off: "aus" };
        return {
          icon: "mdi:clock-fast", c: "#fb923c", title: "Vorheizen", sub: "Für alle Räume – je Raum änderbar",
          body: `
            <p class="muted">Damit ein Raum zu Beginn der Komfortzeit schon warm ist, heizt Heizwerk vorher los.</p>
            <div class="field">${segs("preheat_mode", [["smart", "Lernen", "mdi:brain"], ["fixed", "Feste Zeit", "mdi:timer-outline"], ["off", "Aus", "mdi:timer-off-outline"]], "fixed")}</div>
            ${mode === "fixed" ? `
            <div class="row2">
              <label class="field"><span><ha-icon icon="mdi:radiator"></ha-icon> Heizkörper</span>${minutes("lead_radiator", 15, 0, 600, 5)}</label>
              <label class="field"><span><ha-icon icon="mdi:heating-coil"></ha-icon> Flächenheizung</span>${minutes("lead_floor", 120, 0, 600, 5)}</label>
            </div>
            <p class="muted small">So viele Minuten vor Beginn der Komfortzeit geht es los. Fußbodenheizungen brauchen deutlich länger.</p>` : ""}
            ${mode === "smart" ? `
            <p class="muted small"><ha-icon icon="mdi:information-outline"></ha-icon>Heizwerk misst bei jedem Aufheizen, wie viele Grad pro Stunde ein Raum schafft, und startet so früh, dass er pünktlich warm ist – mit 15 % Reserve. Höchstens ${this._data.defaults.heizkoerper.preheat_max} Min. (Heizkörper) bzw. ${this._data.defaults.flaeche.preheat_max} Min. (Fläche) vorher; je Raum änderbar.</p>
            <div class="lbl">Gelernt</div>
            <div class="evlist">${rooms.map((r) => {
              const rs = st[r.id] || {};
              return `<div class="ev"><ha-icon icon="${esc(roomIcon(r))}"></ha-icon><span class="grow"><b>${esc(r.name)}</b><small>${rs.heat_rate ? `${fmt(rs.heat_rate)} °C/h${rs.learned ? " · gelernt" : " · Startwert"}` : "noch nichts gemessen"}</small></span>
                ${rs.learned && this._admin ? `<button class="link tiny" data-action="preheat-reset" data-id="${r.id}"><ha-icon icon="mdi:restore"></ha-icon>neu lernen</button>` : ""}</div>`;
            }).join("") || `<p class="muted small">Noch keine Räume.</p>`}</div>` : ""}
            ${mode === "off" ? `<p class="muted small">Räume heizen erst zu Beginn der Komfortzeit los.</p>` : ""}
            ${mode !== "off" ? `
            ${head("mdi:weather-snowy", "Nach Wetter")}
            <label class="check"><span><b>Vorlauf nach Außentemperatur anpassen</b><small>Bei Kälte früher, an milden Tagen später. Bezug sind 5 °C draußen: je Grad kälter 4 % mehr Vorlauf, je Grad wärmer 4 % weniger (höchstens 0,6- bis 1,8-fach).${mode === "smart" ? " Gelernte Werte rechnet Heizwerk auf 5 °C um, damit kalte und milde Tage vergleichbar sind." : ""}</small></span>${sw("preheat_weather")}</label>
            ${(() => {
              const f = Object.values(st)[0]?.preheat_factor;
              const out = s.outside_temp;
              return this._data.settings.preheat_weather && f ? `<p class="muted small"><ha-icon icon="mdi:thermometer"></ha-icon>Gerade ${fmt(f, 2)}-facher Vorlauf${out != null ? ` bei ${fmt(out)} °C außen` : ""}${mode === "fixed" ? ` – Heizkörper ${Math.round(this._leadFor("heizkoerper") * f)} Min., Fläche ${Math.round(this._leadFor("flaeche") * f)} Min` : ""}.</p>` : "";
            })()}` : ""}
            ${own.length ? `<p class="muted small"><ha-icon icon="mdi:home-edit-outline"></ha-icon>Eigene Einstellung: ${own.map((r) => `${esc(r.name)} (${label[r.preheat_mode]})`).join(", ")} – änderbar am Raum unter „Vorheizen & Fenster“.</p>` : ""}`,
        };
      }

      case "rq": {
        const d = this._pop.draft;
        const room = this._data.rooms[d.id] || {};
        const rs = st[d.id] || {};
        const mode = rs.mode || "aus";
        const m = MODE[mode] || MODE.aus;
        const dv = this._devIndicators(room);
        const until = rs.override_until ? new Date(rs.override_until).toLocaleTimeString("de-DE", { hour: "2-digit", minute: "2-digit" }) : null;
        const blocked = { aus: "Die Automatik ist aus – Heizwerk stellt nichts ein.", fenster: "Fenster offen – die Fensterpause geht vor, die Änderung gilt danach.", sommer: "Sommerpause – die Änderung gilt erst in der Heizperiode.", entkalken: "Gerade läuft der Entkalkungsschutz." }[mode];
        const next = rs.next_change != null ? new Date(Date.now() + rs.next_change * 60000).toLocaleTimeString("de-DE", { hour: "2-digit", minute: "2-digit" }) : null;
        const durs = [["", next ? `bis ${next}` : "bis Planwechsel"], ["1", "1 h"], ["2", "2 h"], ["4", "4 h"], ["8", "8 h"]];
        const facts = [
          [m.i, rs.mode_label || "Automatik aus", m.c],
          ["mdi:thermometer", `Jetzt ${fmt(rs.room_temp)} °C`, "var(--muted)"],
          ["mdi:target", `Soll ${fmt(rs.target)} °C`, tint(tempColor(rs.target))],
          ...(rs.humidity != null ? [["mdi:water-percent", `${fmt(rs.humidity, 0)} %`, "var(--muted)"]] : []),
          ...(dv.valve != null ? [["mdi:valve", `Ventil ${fmt(dv.valve, 0)} %`, dv.valve > 0 ? "#fb923c" : "var(--muted)"]] : []),
          ...(dv.floor?.on ? [["mdi:heating-coil", `${dv.floor.label} heizt`, "#f97316"]] : []),
          ...(rs.assist ? [["mdi:radiator", rs.assist.on ? "Heizkörper hilft nach" : "Heizkörper zu", rs.assist.on ? "#f97316" : "#64748b"]] : []),
          ...(rs.windows_open ? [["mdi:window-open-variant", "Fenster offen", "#22d3ee"]] : []),
          ...(this._fireChip(rs) ? [[this._fireChip(rs)[0], { on: "Kamin an", maybe: "Wärmer ohne Heizung", after: "Nachwärme" }[rs.fireplace.state], this._fireChip(rs)[2]]] : []),
        ];
        const fp = rs.fireplace || {};
        const fireBtn = room.fireplace && !(fp.state === "on" && fp.source === "signal")
          ? `<button class="qbtn ${fp.manual ? "hot" : ""}" data-action="rq-fire" data-id="${room.id}" data-on="${fp.manual ? "0" : "1"}"><ha-icon icon="mdi:fireplace${fp.manual ? "-off" : ""}"></ha-icon>Kamin ${fp.manual ? "aus" : "an"}</button>` : "";
        const auto = room.enabled !== false;
        return {
          icon: roomIcon(room), c: this._roomColor(room.id), title: esc(room.name || "Raum"), sub: "Manuell ändern", open: true,
          body: `
            <div class="rq-facts">${facts.map(([i, txt, c]) => `<span style="--c:${c}"><ha-icon icon="${i}"></ha-icon>${esc(txt)}</span>`).join("")}</div>
            ${blocked ? `<p class="note"><ha-icon icon="mdi:information-outline"></ha-icon>${blocked}</p>` : ""}
            ${rs.cause ? `<div class="rq-why"><ha-icon icon="mdi:help-circle-outline"></ha-icon><span><b>Warum ${rs.target != null ? `${fmt(rs.target)} °C` : "dieser Zustand"}?</b><small>${esc(rs.cause)}</small>${rs.plan_label && !String(rs.cause).includes(rs.plan_label) ? `<small class="muted">Heizplan: ${esc(rs.plan_label)} · ${fmt(rs.plan_target)} °C</small>` : ""}</span></div>` : ""}
            ${this._fireChip(rs) ? `<p class="muted small"><ha-icon icon="mdi:fireplace"></ha-icon>${esc(this._fireChip(rs)[3])}${fp.manual && fp.until ? ` Endet von selbst um ${new Date(fp.until).toLocaleTimeString("de-DE", { hour: "2-digit", minute: "2-digit" })}.` : ""}</p>` : ""}
            ${(mode === "manuell" || mode === "boost") && until ? `<div class="room-note ${mode === "boost" ? "boost" : ""}"><ha-icon icon="${mode === "boost" ? "mdi:rocket-launch-outline" : "mdi:hand-back-right-outline"}"></ha-icon>${mode === "boost" ? "Boost" : "Manuell"} bis ${until}<span class="grow"></span><button class="link" data-action="ovr-reset" data-id="${room.id}">Zurück zum Plan</button></div>` : ""}
            <div class="rq-temp">
              <small>Gewünschte Temperatur</small>
              ${this._stepper("rq", room.id, d.temp)}
              <div class="rq-quick">
                <button class="pill ${d.temp === room.comfort ? "on" : ""}" data-action="rq-temp" data-t="${room.comfort ?? 21}"><ha-icon icon="mdi:sofa-outline"></ha-icon>Komfort ${fmt(room.comfort ?? 21)} °C</button>
                <button class="pill ${d.temp === room.eco ? "on" : ""}" data-action="rq-temp" data-t="${room.eco ?? 18}"><ha-icon icon="mdi:leaf"></ha-icon>Eco ${fmt(room.eco ?? 18)} °C</button>
              </div>
            </div>
            <div class="lbl">Wie lange?</div>
            <div class="segs small rq-dur">${durs.map(([h, l]) => `<button class="seg ${String(d.hours ?? "") === h ? "on" : ""}" data-action="rq-dur" data-h="${h}">${l}</button>`).join("")}</div>
            <div class="rq-more">
              ${(room.climates || []).length && !["aus", "fenster", "entkalken"].includes(mode) ? `<button class="qbtn hot" data-action="rq-boost" data-id="${room.id}"><ha-icon icon="mdi:rocket-launch-outline"></ha-icon>Boost ${this._data.settings.boost_minutes || 30} Min.</button>` : ""}
              ${fireBtn}
              <button class="qbtn" data-action="room-page" data-id="${room.id}" data-hint="1"><ha-icon icon="mdi:chart-line"></ha-icon>Raumseite</button>
              ${this._admin ? `<button class="qbtn" data-action="plan-open" data-id="${room.id}" data-hint="1"><ha-icon icon="mdi:calendar-clock"></ha-icon>Heizplan</button>
              <button class="qbtn" data-action="room-auto" data-id="${room.id}" data-hint="1"><ha-icon icon="${auto ? "mdi:robot-off-outline" : "mdi:robot-outline"}"></ha-icon>Automatik ${auto ? "aus" : "an"}</button>` : ""}
            </div>`,
          foot: `<button class="secondary" data-action="pop-close">Abbrechen</button>
                 <button class="primary" data-action="rq-apply"><ha-icon icon="mdi:check"></ha-icon>Übernehmen</button>`,
        };
      }

      case "legend": {
        const d = this._pop.draft || {};
        const groups = [...new Set(LEGEND.map((x) => x[0]))];
        const order = d.first && groups.includes(d.first) ? [d.first, ...groups.filter((g) => g !== d.first)] : groups;
        const q = String(d.q || "").toLowerCase().trim();
        const hit = (x) => !q || `${x[3]} ${x[4]}`.toLowerCase().includes(q);
        const row = ([, icon, c, name, text, label]) => `<div class="lg-r"><span class="si lg-s" style="--c:${c}"><ha-icon icon="${icon}"></ha-icon>${label ? esc(label) : ""}</span><span class="grow"><b>${esc(name)}</b><small>${esc(text)}</small></span></div>`;
        const list = order.map((g) => [g, LEGEND.filter((x) => x[0] === g && hit(x))]).filter(([, l]) => l.length);
        return {
          icon: "mdi:help-circle-outline", c: "#64748b", title: "Symbole & Farben", sub: "Was die Zeichen in Hauswerk bedeuten",
          body: `
            <div class="lg-colors">${COLOR_LEGEND.map(([c, n, t]) => `<span class="lg-c" style="--c:${c}"><i></i><b>${n}</b><small>${t}</small></span>`).join("")}</div>
            <input class="lg-q" type="search" placeholder="Symbol suchen, z. B. Kamin" value="${esc(d.q || "")}" data-legend-q>
            ${list.map(([g, l]) => `<div class="lbl">${g}</div><div class="lg-list">${l.map(row).join("")}</div>`).join("") || `<p class="muted">Nichts gefunden.</p>`}
            <p class="muted small"><ha-icon icon="mdi:gesture-tap"></ha-icon>Einzelne Symbole erklären sich auch selbst: am Computer mit der Maus darauf zeigen, am Handy und Tablet die Kachel antippen.</p>`,
          foot: `<button class="primary" data-action="pop-close">Verstanden</button>`,
        };
      }

      case "hmlinks": {
        const L = s.hm_links || {};
        const KI = { trv: "mdi:radiator", window: "mdi:window-closed-variant", fal: "mdi:heating-coil", wall: "mdi:thermostat", other: "mdi:link-variant" };
        const rooms = Object.entries(L.rooms || {}).map(([id, info]) => [this._data.rooms[id], info]).filter(([r]) => r).sort((a, b) => a[0].name.localeCompare(b[0].name, "de"));
        const peer = (x) => `<span class="hl-p ${x.in_room ? "" : "out"}" title="${esc(x.model || "")}${x.in_room ? "" : " · nicht in diesem Raum eingetragen"}"><ha-icon icon="${KI[x.kind] || KI.other}"></ha-icon>${esc(x.name)}${x.kind === "fal" && x.channels.length ? ` · Kanal ${x.channels.join(", ")}` : ""}</span>`;
        return {
          icon: "mdi:link-variant", c: "#0ea5e9", title: "Homematic-Verknüpfungen", sub: `Heizwerk · Direktverknüpfungen aus der CCU${L.at ? ` · gelesen ${new Date(L.at).toLocaleString("de-DE", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" })}` : ""}`,
          body: `
            <p class="muted small">Was die CCU direkt verknüpft hat, arbeitet ohne Home Assistant. Heizwerk liest das (nur lesen, alle 6 Stunden) und nutzt es: Heizkörper, die mit dem Wandthermostat verknüpft sind, folgen ihm – Hauswerk stellt dann nur das Wandthermostat. Ist ein Fensterkontakt direkt verknüpft, senkt die CCU beim Lüften selbst ab und Hauswerk sendet nichts (spart Funk).</p>
            ${L.error ? `<p class="note warn"><ha-icon icon="mdi:alert-outline"></ha-icon>${esc(L.error)}</p>` : ""}
            ${(L.findings || []).length ? `<div class="lbl">Hinweise</div><div class="evlist">${L.findings.map((f) => `<div class="ev"><ha-icon icon="mdi:link-variant-off" style="color:${f.level === "warn" ? "#f97316" : "#0ea5e9"}"></ha-icon><span class="grow"><b>${esc(f.text.split(" – ")[0])}</b><small>${esc([f.room ? this._data.rooms?.[f.room]?.name : "", f.text.split(" – ")[1] || ""].filter(Boolean).join(" · "))}</small></span></div>`).join("")}</div>` : ""}
            <div class="lbl">Je Raum</div>
            <div class="hl-list">${rooms.map(([r, info]) => `<div class="hl-room"><b>${esc(r.name)}</b>${info.walls.map((w) => `<div class="hl-w"><span class="hl-wn"><ha-icon icon="mdi:thermostat"></ha-icon>${esc(this._entityName(w.entity))}</span><ha-icon class="hl-arrow" icon="mdi:arrow-right"></ha-icon><span class="hl-ps">${w.peers.length ? w.peers.map(peer).join("") : `<em class="hl-none">keine Verknüpfung</em>`}</span></div>`).join("")}
              ${info.windows_ccu.length ? `<small class="muted"><ha-icon icon="mdi:window-open-variant"></ha-icon>Fensterpause macht die CCU${r.window_ccu === false ? " – im Raum abgeschaltet, Hauswerk macht sie selbst" : ""}</small>` : ""}</div>`).join("") || `<p class="muted">Noch nichts gelesen – „Neu lesen“ tippen.</p>`}</div>`,
          foot: `<button class="secondary" data-action="pop-close">Schließen</button>${this._admin ? `<button class="primary" data-action="hmlinks-refresh"><ha-icon icon="mdi:refresh"></ha-icon>Neu lesen</button>` : ""}`,
        };
      }

      case "radio": {
        const rd = this._status?.radio || {};
        const ids = rd.entities || [];
        const val = (id) => {
          const x = this._hass.states[id];
          return !x || ["unavailable", "unknown"].includes(x.state) ? "nicht erreichbar" : `${fmt(Number(x.state), 1)} %`;
        };
        const blocked = Object.values(this._status?.rooms || {}).flatMap((x) => x.duty_blocked || []);
        return {
          icon: "mdi:access-point-network", c: "#64748b", title: "Funk-Auslastung", sub: "Hauswerk · Duty Cycle, z. B. Homematic IP",
          body: `
            <div class="rq-facts">
              <span style="--c:${rd.busy ? "#f97316" : "#22c55e"}"><ha-icon icon="mdi:access-point"></ha-icon>${rd.level != null ? `Jetzt ${fmt(rd.level, 0)} %` : "kein Wert"}</span>
              <span style="--c:${rd.busy ? "#f97316" : "#22c55e"}"><ha-icon icon="${rd.busy ? "mdi:speedometer-slow" : "mdi:check"}"></ha-icon>${rd.busy ? "ausgelastet – gedrosselt" : "frei"}</span>
              <span style="--c:#64748b"><ha-icon icon="mdi:send-outline"></ha-icon>${this._status?.commands_hour ?? 0} Befehle in der letzten Stunde</span>
            </div>
            <p class="muted">Funkzentralen wie die Homematic-CCU dürfen nur begrenzt senden (Duty Cycle, 1 % der Zeit). Bei 100 % nimmt sie keine Befehle mehr an – Thermostate bleiben dann auf dem alten Wert. Ab der Grenze schickt Hauswerk nur noch Wechsel der Betriebsart (z. B. Fenster auf, Komfort beginnt) und Änderungen ab 1 °C, höchstens alle 15 Minuten je Thermostat, und lässt Ventil- und Kalibrier-Befehle weg. Meldet ein einzelnes Gerät „Duty Cycle erreicht“, bekommt es solange keine Befehle.</p>
            <label class="field narrow"><span><ha-icon icon="mdi:speedometer"></ha-icon> Drosseln ab</span>${minutes("radio_limit", 70, 30, 95, 5, "%")}</label>
            <div class="lbl">${(p.radio_entities || []).length ? "Gewählte Sensoren" : "Automatisch gefunden"} (höchster Wert zählt)</div>
            <div class="evlist">${ids.map((id) => `<div class="wrow"><ha-icon icon="mdi:access-point"></ha-icon><span class="grow"><b>${esc(this._entityName(id))}</b><small>${esc(id)}</small></span><em class="${id === rd.entity && rd.busy ? "bad" : ""}">${val(id)}</em></div>`).join("") || `<p class="muted small">Kein Sensor mit „duty_cycle“ gefunden – ohne Sensor drosselt Hauswerk nicht.</p>`}</div>
            ${blocked.length ? `<p class="muted small"><ha-icon icon="mdi:alert-outline"></ha-icon>Gerade gesperrt: ${blocked.map((x) => esc(this._entityName(x))).join(", ")}</p>` : ""}
            <div class="field"><span>Sensoren selbst wählen (leer = automatisch)</span>${this._picker("radio_entities", p.radio_entities || [])}</div>`,
        };
      }

      case "notify":
        return this._notifyPop(p, { minutes, segs, sw, head, dis });

      case "vent": {
        const withHum = rooms.filter((r) => r.humidity_sensor);
        return {
          icon: "mdi:weather-windy", c: "#22d3ee", title: "Lüften & Schimmelschutz", sub: "Heizwerk · rechnet mit absoluter Feuchte und Taupunkt",
          body: `
            <p class="muted">Ist es drinnen feucht und die Luft draußen trockener, erscheint unter der Glocke „Jetzt lüften“. Verglichen wird die Wassermenge in der Luft (g/m³) – kalte Winterluft ist fast immer trockener, schwüle Sommerluft oft nicht.</p>
            <label class="field narrow"><span><ha-icon icon="mdi:water-percent"></ha-icon> Hinweis ab Luftfeuchte (0 = aus)</span>${minutes("vent_rh", 65, 0, 95, 5, "%")}</label>
            <p class="muted small">Gilt für Wohnräume. Bäder lüften ab 70 %, Schlaf- und Kinderzimmer ab 60 % – je Raum änderbar (Raum › Geräte › Lüften).</p>
            <div class="lbl">Dauer & Ende</div>
            <p class="muted small">Empfohlen wird kurzes Stoßlüften nach Außentemperatur: unter 0 °C 5 Min., bis 10 °C 10 Min., bis 15 °C 15 Min., darüber 25 Min. Ist das Fenster offen, läuft in der Raumkachel ein Countdown; ist genug gelüftet (Zeit um, Feuchte deutlich gesunken oder Raum 3 °C kühler), kommt „Fenster schließen“.</p>
            <label class="field narrow"><span><ha-icon icon="mdi:window-open-variant"></ha-icon> „Kippen kostet Wärme“ nach</span>${minutes("vent_long_min", 30, 5, 240, 5)}</label>
            <div class="lbl">Anlässe</div>
            <div class="field"><span><ha-icon icon="mdi:weather-sunset-up"></ha-icon> Morgens lüften (Schlaf- und Kinderzimmer) ab</span>${segs("vent_morning", [["null", "Aus"], ["06:30", "6:30"], ["07:00", "7:00"], ["07:30", "7:30"], ["08:00", "8:00"]], "null")}</div>
            <label class="field narrow"><span><ha-icon icon="mdi:molecule-co2"></ha-icon> Lüften ab CO₂ (0 = aus)</span>${minutes("vent_co2", 1000, 0, 5000, 100, "ppm")}</label>
            <div class="wxrows">${this._setRow("vcool", "Sommer: kühlen", "„Fenster auf“, wenn draußen kühler – „zu“, wenn wärmer", sw("vent_cool"), "In der Sommerpause: Ist es drinnen ab 23 °C und draußen mindestens 2 °C kühler, empfiehlt Heizwerk das Fenster zu öffnen. Wird es draußen wärmer als drinnen, kommt „Fenster schließen“. Zusammen mit dem Sonnenschutz von Rollwerk bleibt es so tagsüber kühler.")}</div>
            <p class="muted small"><ha-icon icon="mdi:water-alert-outline"></ha-icon>Steigt die Feuchte schnell (Duschen, Kochen), kommt „Jetzt lüften“ für eine halbe Stunde. Die Schimmel-Ampel schätzt die Feuchte an der kühlsten Stelle der Außenwand (Temperaturfaktor 0,7): ab 70 % gelb, ab 80 % rot.</p>
            <div class="lbl">Nachrichten aufs Handy</div>
            <div class="field"><span>Lüften empfohlen</span>${segs("notify_vent", [["off", "Aus"], ["log", "Protokoll"], ["normal", "Normal"], ["important", "Wichtig"]], "off")}</div>
            <div class="field"><span>Genug gelüftet – Fenster schließen</span>${segs("notify_vent_done", [["off", "Aus"], ["log", "Protokoll"], ["normal", "Normal"], ["important", "Wichtig"]], "normal")}</div>
            <button class="link" data-action="tab" data-tab="vent"><ha-icon icon="mdi:weather-windy"></ha-icon>Zur Seite Lüften</button>
            <div class="lbl">Räume mit Feuchtesensor</div>
            <div class="evlist">${withHum.map((r) => {
              const rs = st[r.id] || {};
              return `<div class="ev ${rs.vent ? "live" : ""}"><ha-icon icon="${rs.vent ? "mdi:weather-windy" : "mdi:water-percent"}"></ha-icon><span class="grow"><b>${esc(r.name)}</b><small>${rs.humidity != null ? `${fmt(rs.humidity, 0)} %` : "–"}${rs.vent ? ` · jetzt lüften · Taupunkt ${fmt(rs.vent.dew_point)} °C` : ""}${r.shower_boost ? ` · nach dem Duschen ${r.shower_boost} Min. nachheizen` : ""}</small></span>${rs.vent ? `<em class="badge ok">LÜFTEN</em>` : ""}</div>`;
            }).join("") || `<p class="muted small">Noch kein Raum hat einen Feuchtesensor – am Raum unter „Geräte“ zuordnen.</p>`}</div>
            <p class="muted small"><ha-icon icon="mdi:shower-head"></ha-icon>Nach dem Duschen nachheizen stellst du am Raum unter „Geräte“ ein (braucht einen Feuchtesensor).</p>`,
        };
      }

      case "demand": {
        const dm = this._status?.demand || {};
        const ent = p.demand_entity;
        const zst = ent ? this._hass.states[ent] : null;
        const need = dm.need || [];
        const stLabel = !ent ? "aus" : dm.error ? "nicht erreichbar" : dm.state === "low" ? (p.demand_action === "off" ? "aus – kein Raum braucht Wärme" : "abgesenkt") : dm.state === "raise" ? "angehoben fürs Vorheizen" : "normal";
        const roomsV = rooms.map((r) => ({ r, v: st[r.id]?.valve_all, m: st[r.id]?.mode })).filter((x) => x.v != null || ["vorheizen", "boost"].includes(x.m));
        return {
          icon: "mdi:water-boiler", c: "#f97316", title: "Wärmeanforderung", sub: "Heizwerk · Wärmeerzeuger nach Bedarf der Räume",
          body: `
            <p class="muted">Aus den Ventilöffnungen aller Räume weiß Hauswerk, ob überhaupt Wärme gebraucht wird. Braucht <b>kein</b> Raum Wärme, senkt es den Wärmeerzeuger (z. B. die Zone der Vaillant-Anlage) ab oder schaltet ihn aus – sobald ein Raum wieder Wärme braucht, kommt sofort der alte Wert zurück. Beim Vorheizen kann es ihn anheben. Warmwasser ist davon nicht betroffen.</p>
            <div class="field"><span><ha-icon icon="mdi:water-boiler"></ha-icon> Wärmeerzeuger (Klima-Entität, leer = aus)</span>${this._picker("demand_entity", ent ? [ent] : [])}</div>
            ${ent ? `
            <div class="rq-facts">
              <span style="--c:${dm.state === "low" ? "#22c55e" : "#f97316"}"><ha-icon icon="mdi:water-boiler"></ha-icon>Jetzt: ${esc(stLabel)}</span>
              ${zst ? `<span style="--c:#64748b"><ha-icon icon="mdi:thermometer"></ha-icon>Soll ${fmt(Number(zst.attributes.temperature))} °C · ${esc(this._fmtState(zst))}</span>` : ""}
              ${dm.orig_temp != null ? `<span style="--c:#64748b"><ha-icon icon="mdi:restore"></ha-icon>normal ${fmt(dm.orig_temp)} °C</span>` : ""}
            </div>
            <label class="field"><span>Wenn kein Raum Wärme braucht</span>${segs("demand_action", [["lower", "Absenken", "mdi:thermometer-chevron-down"], ["off", "Ausschalten", "mdi:power"]], "lower")}</label>
            ${(p.demand_action || "lower") === "lower" ? `<label class="field narrow"><span><ha-icon icon="mdi:thermometer-low"></ha-icon> Absenken auf</span>${minutes("demand_low", 17, 5, 25, 0.5, "°C")}</label>` : ""}
            <label class="field narrow"><span><ha-icon icon="mdi:valve"></ha-icon> Ein Raum braucht Wärme ab Ventilöffnung</span>${minutes("demand_valve", 15, 1, 80, 1, "%")}</label>
            <label class="field narrow"><span><ha-icon icon="mdi:timer-sand"></ha-icon> Erst absenken nach</span>${minutes("demand_hold", 20, 5, 180, 5)}</label>
            <label class="field narrow"><span><ha-icon icon="mdi:clock-fast"></ha-icon> Beim Vorheizen anheben um (0 = nein)</span>${minutes("demand_preheat", 0, 0, 5, 0.5, "°C")}</label>
            <div class="lbl">Räume gerade</div>
            <div class="evlist">${roomsV.map(({ r, v, m }) => {
              const hot = ["vorheizen", "boost"].includes(m) || (v ?? 0) >= Number(p.demand_valve ?? 15);
              return `<div class="ev ${hot ? "live" : ""}"><ha-icon icon="${hot ? "mdi:fire" : "mdi:valve-closed"}"></ha-icon><span class="grow"><b>${esc(r.name)}</b><small>${v != null ? `Ventil ${fmt(v, 0)} %` : "ohne Ventilwert"}${["vorheizen", "boost"].includes(m) ? ` · ${MODE[m]?.label || m}` : ""}</small></span>${hot ? `<em class="badge">BRAUCHT WÄRME</em>` : ""}</div>`;
            }).join("") || `<p class="muted small">Kein Raum meldet eine Ventilöffnung – dann entscheidet die Raumtemperatur.</p>`}</div>
            <p class="muted small"><ha-icon icon="mdi:alert-outline"></ha-icon>Bitte vorsichtig einstellen: Absenken wirkt über die Heizkurve auf die Vorlauftemperatur. Bei Vaillant (myVaillant) setzt Hauswerk dafür eine zeitlich begrenzte Temperatur-Schnellwahl und erneuert sie bei Bedarf alle 30 Min. Alles steht im Protokoll unter „Ziel & Heizung“.</p>` : ""}`,
        };
      }

      case "protect":
        return {
          icon: "mdi:snowflake-thermometer", c: "#38bdf8", title: "Frostschutz",
          body: `
            <p class="muted">Diese Temperatur bekommen Thermostate bei offenem Fenster und in der Sommerpause (wenn sie nicht ausgeschaltet werden). Wann die Fensterpause beginnt, stellst du je Raum ein.</p>
            <div class="field narrow">${this._stepper("set", "frost_temp", p.frost_temp)}</div>`,
        };

      case "boost":
        return {
          icon: "mdi:rocket-launch-outline", c: "#f43f5e", title: "Boost",
          body: `
            <p class="muted">Der <ha-icon icon="mdi:rocket-launch-outline"></ha-icon>-Knopf auf einer Raumkarte dreht die Thermostate des Raums für eine Weile ganz auf.</p>
            <label class="field narrow"><span>Dauer</span>${minutes("boost_minutes", 30, 5, 240, 5)}</label>`,
        };

      case "liming":
        return {
          icon: "mdi:water-sync", c: "#38bdf8", title: "Entkalkungsschutz",
          body: `
            <label class="check"><span><b>Einmal pro Woche alle Ventile öffnen</b><small>Damit sie über den Sommer nicht festsitzen.</small></span>${sw("liming")}</label>
            ${p.liming ? `
            <div class="row3">
              <label class="field"><span>Tag</span><select data-set="liming_day" ${dis}>${["Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag", "Sonntag"]
                .map((d, i) => `<option value="${i}" ${Number(p.liming_day ?? 0) === i ? "selected" : ""}>${d}</option>`)
                .join("")}</select></label>
              <label class="field"><span>Uhrzeit</span><input type="time" data-set="liming_time" value="${esc(p.liming_time || "10:00")}" ${dis}></label>
              <label class="field"><span>Dauer</span>${minutes("liming_minutes", 5, 1, 60)}</label>
            </div>
            <label class="check"><span><b>Auch in der Heizperiode</b><small>Sonst nur in der Sommerpause (oder immer, wenn keine Sommerpause genutzt wird).</small></span>${sw("liming_winter")}</label>` : ""}`,
        };

      case "hints": {
        const h = this._hints();
        const row = (x) => this._hintRow(x);
        const warn = h.filter((x) => x.lvl === "warn"), info = h.filter((x) => x.lvl === "info");
        return {
          icon: h.length ? "mdi:bell-badge-outline" : "mdi:bell-check-outline", c: warn.length ? "#f59e0b" : "#34d399", title: "Hinweise",
          sub: h.length ? `${warn.length} zu beheben · ${info.length} zur Info` : "Alles in Ordnung",
          body: h.length
            ? `${warn.length ? `<div class="lbl">Bitte beheben</div><div class="hints">${warn.map(row).join("")}</div>` : ""}
               ${info.length ? `<div class="lbl" style="margin-top:14px">Gut zu wissen</div><div class="hints">${info.map(row).join("")}</div>` : ""}`
            : `<div class="wok"><ha-icon icon="mdi:check-circle-outline"></ha-icon>Keine Hinweise – alles läuft.</div>`,
          foot: `<button class="secondary" data-action="pop-close">Schließen</button>`,
        };
      }

      case "widget-add": {
        const have = new Set(this._widgets().map((w) => w.type));
        const dr = this._pop.draft || {};
        const preview = (k, d) => {
          const size = dr.size || d.size || "m";
          return `<div class="wprev">
            <div class="segs small">${[["s", "Klein"], ["m", "Mittel"], ["l", "Groß"]].map(([v, l]) => `<button class="seg ${size === v ? "on" : ""}" data-action="w-pick-size" data-v="${v}">${l}</button>`).join("")}</div>
            <div class="wgrid wprev-g">${this._widget({ id: "vorschau", type: k, size, title: null, entities: [] }, -1, false, 0)}</div>
            ${d.config ? `<p class="muted small"><ha-icon icon="mdi:information-outline"></ha-icon>Nach dem Hinzufügen wählst du, was es zeigen soll.</p>` : ""}
            <button class="primary" data-action="w-add" data-type="${k}" data-size="${size}"><ha-icon icon="mdi:plus"></ha-icon>${have.has(k) ? "Noch einmal hinzufügen" : "Hinzufügen"}</button>
          </div>`;
        };
        return {
          icon: "mdi:widgets-outline", c: "#2dd4bf", title: "Widget hinzufügen", sub: "Antippen für eine Vorschau mit deinen Daten",
          body: `<div class="wcat">${Object.entries(WIDGETS)
            .map(([k, d]) => `
              <button class="wcat-i ${dr.sel === k ? "on" : ""}" data-action="w-pick" data-type="${k}" style="--c:${d.c}" aria-expanded="${dr.sel === k}">
                <span class="sr-ic"><ha-icon icon="${d.icon}"></ha-icon></span>
                <span class="sr-t"><b>${d.name}${have.has(k) ? ` <em class="badge">SCHON DA</em>` : ""}</b><small class="wrap">${d.text}</small></span>
                <ha-icon class="sr-go" icon="${dr.sel === k ? "mdi:chevron-up" : "mdi:chevron-down"}"></ha-icon>
              </button>${dr.sel === k ? preview(k, d) : ""}`)
            .join("")}</div>`,
          foot: `<button class="secondary" data-action="pop-close">Schließen</button>`,
        };
      }

      case "widget": {
        const dr = this._pop.draft;
        const w = this._widgets()[dr.i] || {};
        const def = WIDGETS[w.type] || {};
        return {
          icon: def.icon || "mdi:widgets-outline", c: def.c || "#2dd4bf", title: `Widget „${def.name || ""}“`,
          body: `
            <label class="field"><span>Titel (leer = „${def.name || ""}“)</span><input type="text" maxlength="40" data-pop="title" value="${esc(dr.title)}" placeholder="${esc(def.name || "")}"></label>
            <div class="field"><span>Größe</span>
              <div class="segs small">${[["s", "Klein", "mdi:square-small"], ["m", "Mittel", "mdi:square-outline"], ["l", "Groß", "mdi:rectangle-outline"]]
                .map(([v, l, i]) => `<button class="seg ${dr.size === v ? "on" : ""}" data-action="w-size" data-v="${v}"><ha-icon icon="${i}"></ha-icon>${l}</button>`)
                .join("")}</div>
              <small class="muted">${{ s: "Klein: nur das Wichtigste auf einen Blick.", m: "Mittel: mit Kennzahlen bzw. Liste.", l: "Groß: volle Breite mit allen Einzelheiten." }[dr.size] || ""}</small></div>
            ${def.forecast ? `
            <div class="field"><span>Zeitraum</span>
              <div class="segs small">${[["hourly", "Nächste Stunden", "mdi:clock-outline"], ["daily", "Nächste Tage", "mdi:calendar-week"]]
                .map(([v, l, i]) => `<button class="seg ${(dr.mode || "hourly") === v ? "on" : ""}" data-action="w-mode" data-v="${v}"><ha-icon icon="${i}"></ha-icon>${l}</button>`)
                .join("")}</div></div>
            <div class="field"><span>Wetter-Entität (leer = wie unter Einstellungen › Wetter)</span>${this._picker("w_weather", dr.w_weather ? [dr.w_weather] : [])}</div>
            <p class="muted small">Kann die Entität keine Stunden-Prognose, zeigt das Widget die Tage (und umgekehrt).</p>` : ""}
            ${def.cal ? `
            <div class="field"><span>Kalender${w.type === "events" ? " (optional)" : ""} – z. B. Müllabfuhr, Familie</span>${this._picker("w_calendars", dr.w_calendars || [])}</div>
            <p class="muted small">Leer = die Kalender unter Darstellung › Tabletmodus. Müll-Termine bekommen ein passendes Symbol (Rest, Bio, Papier, Gelb, Glas).</p>` : def.config ? `
            <div class="field"><span>${w.type === "shortcuts" ? "Knöpfe: Szenen, Skripte, Schalter, Lichter …" : "Sensoren und andere Entitäten"}</span>${this._picker("w_entities", dr.w_entities || [])}</div>
            <p class="muted small">${w.type === "shortcuts" ? "Ein Tipp schaltet um bzw. startet Skript oder Szene. Es gelten die Rechte des angemeldeten Benutzers." : "Zeigt den aktuellen Wert mit Einheit."}</p>` : ""}`,
          foot: `<button class="secondary" data-action="pop-close">Abbrechen</button><button class="primary" data-action="w-save"><ha-icon icon="mdi:content-save-outline"></ha-icon>Speichern</button>`,
        };
      }

      case "weather": {
        const S = this._hass.states;
        const weathers = Object.keys(S).filter((e) => e.startsWith("weather.")).sort();
        const wid = p.weather_entity || weathers[0];
        const w = wid ? S[wid] : null;
        const a = w?.attributes || {};
        const sunId = p.sun_entity || "sun.sun";
        const sun = S[sunId];
        const sa = sun?.attributes || {};
        const label = (WEATHER[w?.state] || [null, w?.state || "–"])[1];
        const own = p.outside_sensor && S[p.outside_sensor] ? parseFloat(S[p.outside_sensor].state) : null;
        const tNow = own ?? a.temperature;
        const hhmm = (iso) => (iso ? new Date(iso).toLocaleTimeString("de-DE", { hour: "2-digit", minute: "2-digit" }) : "–");
        const unit = a.wind_speed_unit || "km/h";
        const help = this._help || {};
        const row = (key, title, sub, value, text, ctl = false) => `
          <div class="wxr ${ctl ? "ctl" : ""}">
            <div class="wxr-l"><b>${title}<button class="qm ${help[key] ? "on" : ""}" data-action="help" data-k="${key}" aria-label="Erklärung zu ${title}">?</button></b>${sub ? `<small>${sub}</small>` : ""}${help[key] ? `<p class="wxr-h">${text}</p>` : ""}</div>
            <div class="wxr-v">${value}</div>
          </div>`;
        const num = (key, def, min, max, step, u) =>
          `<div class="unit"><input type="number" step="${step}" min="${min}" max="${max}" data-set="${key}" value="${p[key] ?? def}" ${dis}><i>${u}</i></div>`;
        const alerts = this._wxAlerts();
        return {
          icon: "mdi:weather-partly-cloudy", c: "#60a5fa", title: "Wetter", sub: "Hauswerk · für Startseite, Widgets und alle Module",
          body: `
            <div class="wxsrcs">
              <div class="wxsrc">${row("src", "Wetterquelle", p.weather_entity ? "gewählt" : weathers.length ? `automatisch: ${esc(this._entityName(weathers[0]))}` : "keine gefunden", "",
                "Die Wetter-Entität (z. B. OpenWeatherMap, Met.no) liefert Wetterlage, Vorhersage, Wind und Luftfeuchte. Leer = die erste gefundene.")}
              <div class="wxr-pk">${this._picker("weather_entity", p.weather_entity ? [p.weather_entity] : [])}</div></div>
              <div class="wxsrc">${row("out", "Außentemperatur von", p.outside_sensor ? "eigene Wetterstation statt Wetterdienst" : "leer = vom Wetterdienst", "",
                "Ein eigener Temperatursensor misst meist genauer als der Wetterdienst. Die Vorhersage kommt weiterhin vom Wetterdienst. Heizwerk nutzt ihn auch für die Sommerpause nach Außentemperatur.")}
              <div class="wxr-pk">${this._picker("outside_sensor", p.outside_sensor ? [p.outside_sensor] : [])}</div></div>
              <div class="wxsrc">${row("sunsrc", "Sonnenstand", sun ? "für Tageszeit, Sonnenauf- und -untergang" : "nicht gefunden – Integration „Sonne“ hinzufügen", "",
                "Die Entität der Home-Assistant-Integration „Sonne“ (meist sun.sun). Hauswerk nutzt sie für die Darstellung nach Tageszeit, Sonnenauf- und -untergang und für die Rollläden (Rollwerk).")}
              <div class="wxr-pk">${this._picker("sun_entity", [p.sun_entity || (S["sun.sun"] ? "sun.sun" : null)].filter(Boolean))}</div></div>
              <div class="wxsrc">${row("windsrc", "Böen von", p.wind_sensor ? "eigener Windsensor" : "leer = vom Wetterdienst", "",
                "Ein eigener Wind- oder Böen-Sensor (z. B. Wetterstation auf dem Dach). Rollwerk nutzt ihn für den Sturmschutz der Rollläden.")}
              <div class="wxr-pk">${this._picker("wind_sensor", p.wind_sensor ? [p.wind_sensor] : [])}</div></div>
            </div>
            ${head("mdi:clock-outline", "Jetzt")}
            ${w ? `
            <div class="wxrows">
              ${row("now", "Aktuell", a.apparent_temperature != null ? `gefühlt ${fmt(a.apparent_temperature)} °C` : own != null ? "Temperatur von der eigenen Station" : "", `${esc(label)} · ${fmt(tNow)} °C`,
                "Wetterlage laut Wetterdienst, Temperatur von der eigenen Station (falls gewählt). „Gefühlt“ berücksichtigt Wind und Feuchte.")}
              ${row("hum", "Feuchte", "", a.humidity != null ? `${fmt(a.humidity, 0)} %` : "–", "Relative Luftfeuchte draußen laut Wetterdienst.")}
              ${row("wind", "Wind", a.wind_gust_speed != null ? `Böen ${fmt(a.wind_gust_speed)} ${esc(unit)}` : "", a.wind_speed != null ? `${fmt(a.wind_speed)} ${esc(unit)}` : "–",
                "Mittlere Windgeschwindigkeit laut Wetterdienst; Böen, falls der Dienst sie liefert.")}
              ${row("sun", "Sonne", sun ? `Höhe ${fmt(sa.elevation)}°` : `${esc(sunId)} fehlt`, sun ? (sun.state === "above_horizon" ? "über dem Horizont" : "unter dem Horizont") : "–",
                "Aus der Home-Assistant-Integration „Sonne“ (oben unter „Sonnenstand“ wählbar). Hauswerk nutzt sie für die Darstellung nach Tageszeit und für die Rollläden (Rollwerk).")}
              ${row("rise", "Sonnenaufgang", "nächster Sonnenaufgang", hhmm(sa.next_rising), "Nächster Sonnenaufgang laut Sonnenstand-Entität.")}
              ${row("set", "Sonnenuntergang", "nächster Sonnenuntergang", hhmm(sa.next_setting), "Nächster Sonnenuntergang laut Sonnenstand-Entität.")}
            </div>` : `<p class="note warn"><ha-icon icon="mdi:weather-cloudy-alert"></ha-icon>Keine Wetter-Entität gefunden – z. B. die Integration „Met.no“ oder „OpenWeatherMap“ einrichten.</p>`}
            ${head("mdi:alert-outline", "Grenzwerte")}
            <div class="wxrows">
              ${row("limit", "Heizgrenze", p.summer_mode === "auto" ? "darunter gilt die Heizsaison" : "nur bei Saison „Nach Außentemperatur“",
                `<button class="link" data-action="settings-go" data-sub="season">${fmt(p.summer_temp ?? 16)} °C</button>`,
                "Ab dieser Außentemperatur macht Heizwerk Sommerpause (1 °C Hysterese). Einstellbar unter Heizwerk › Einstellungen › Saison.")}
              ${row("cold", "Kälteeinbruch", "Vorhersage unter diesem Wert", num("cold_snap_temp", 0, -30, 25, 0.5, "°C"),
                "Sagt die Vorhersage der nächsten 3 Tage einen Tiefstwert unter dieser Grenze voraus, erscheint ein Hinweis unter der Glocke.", true)}
              ${row("storm", "Sturm", "Böen ab dieser Stärke", num("storm_kmh", 70, 20, 200, 5, "km/h"),
                "Erwartet die Vorhersage der nächsten 24 Stunden Böen (oder Wind) ab dieser Stärke, erscheint ein Hinweis unter der Glocke.", true)}
            </div>
            ${alerts.length ? `<div class="lbl">Gerade aktiv</div><div class="evlist">${alerts.map((x) => `<div class="ev live"><ha-icon icon="${x.icon}"></ha-icon><span class="grow"><b>${esc(x.text)}</b><small>${esc(x.sub)}</small></span></div>`).join("")}</div>` : ""}`,
        };
      }

      case "look": {
        const acc = p.look_accent || null;
        const known = ACCENTS.some(([v]) => v === acc);
        const bg = p.look_background || "pattern";
        const now = this._skyPhase();
        const size = this._lookSize();
        const bgText = {
          pattern: "Dezentes Muster je Bereich: Glut und aufsteigende Wärme bei Heizwerk, Punkte auf der Startseite.",
          daytime: "Die Kopfzeile folgt dem Sonnenstand (sun.sun, sonst der Uhrzeit): Nacht, Sonnenaufgang, Tag und Sonnenuntergang.",
          plain: "Ruhiger, einfarbiger Hintergrund – gut für Wand-Tablets.",
        }[bg];
        return {
          icon: "mdi:palette-outline", c: "#a78bfa", title: "Darstellung", sub: "Hauswerk · für alle Module und Benutzer",
          body: `
            ${head("mdi:theme-light-dark", "Design")}
            <div class="field">${segs("look_theme", [["auto", "Wie Home Assistant", "mdi:home-assistant"], ["sun", "Nach Sonnenstand", "mdi:weather-sunset"], ["light", "Hell", "mdi:white-balance-sunny"], ["dark", "Dunkel", "mdi:weather-night"]], "auto")}</div>
            ${head("mdi:palette-outline", "Akzentfarbe")}
            <div class="swatches">
              ${ACCENTS.map(([v, name, show]) => `<button class="sw ${acc === v ? "on" : ""}" style="--c:${show || v}" data-action="look-accent" data-v="${v || ""}" title="${name}" aria-label="${name}" ${dis}></button>`).join("")}
              <label class="sw custom ${known ? "" : "on"}" style="--c:${known ? "#94a3b8" : acc}" title="Eigene Farbe"><input type="color" data-look-color value="${known ? "#14b8a6" : acc}" aria-label="Eigene Farbe" ${dis}></label>
              <span class="muted small">Eigene</span>
            </div>
            ${head("mdi:image-filter-hdr", "Hintergrund")}
            <div class="field">${segs("look_background", [["pattern", "Muster", "mdi:texture-box"], ["daytime", "Tageszeit", "mdi:weather-sunset"], ["plain", "Schlicht", "mdi:square-rounded-outline"]], "pattern")}</div>
            <p class="muted small">${bgText}</p>
            ${bg === "daytime" ? `<div class="skies">${SKIES.map(([k, l]) => `<div class="skyc"><div class="sky ${k === now ? "on" : ""}" style="background:var(--sky-${k})">${k === now ? "<em>jetzt</em>" : ""}</div><small>${l}</small></div>`).join("")}</div>` : ""}
            ${head("mdi:page-layout-header", "Kopfzeile")}
            <label class="check"><span><b>Wetter anzeigen</b><small>Außentemperatur und Wetterlage oben rechts. Die Quelle stellst du unter Hauswerk › Wetter ein.</small></span>${sw("look_header_weather")}</label>
            <label class="check"><span><b>Uhrzeit anzeigen</b><small>Praktisch für Wand-Tablets. Auf dem Handy ausgeblendet.</small></span>${sw("look_header_clock")}</label>
            ${head("mdi:cellphone-cog", "Auf diesem Gerät")}
            <div class="field"><span>Größe</span><div class="segs small">${[["s", "Kompakt", "mdi:format-font-size-decrease"], ["m", "Normal", "mdi:format-size"], ["l", "Groß", "mdi:format-font-size-increase"]]
              .map(([v, l, i]) => `<button class="seg ${size === v ? "on" : ""}" data-action="look-size" data-v="${v}"><ha-icon icon="${i}"></ha-icon>${l}</button>`)
              .join("")}</div></div>
            <p class="muted small"><ha-icon icon="mdi:information-outline"></ha-icon>Die Größe gilt nur für dieses Gerät und sofort – z. B. größer auf dem Wand-Tablet, kompakter am Handy. Alles andere gilt nach dem Speichern für alle.</p>
            ${this._startBox()}
            ${this._tabletBox()}`,
        };
      }

      case "access":
        return {
          icon: "mdi:shield-account-outline", c: "#94a3b8", title: "Berechtigungen", sub: "Hauswerk · gilt für alle Module",
          body: `
            <p class="muted">Wer darf Einstellungen, Widgets, Räume und Heizpläne ändern? Temperatur ±, Boost und „Zurück zum Plan“ dürfen immer alle.</p>
            <label class="check"><span><b>Alle Benutzer dürfen ändern</b><small>Sinnvoll z. B. für ein Wand-Tablet mit eigenem Benutzer ohne Admin-Rechte.</small></span>
              <span class="switch"><input type="checkbox" data-set="allow_users" ${p.allow_users ? "checked" : ""} ${this._data.user_admin ? "" : "disabled"}><span></span></span></label>
            ${this._data.user_admin ? "" : `<p class="muted small"><ha-icon icon="mdi:lock-outline"></ha-icon>Das kann nur ein Administrator umstellen.</p>`}`,
        };

      case "calibration":
        return {
          icon: "mdi:tune-vertical-variant", c: "#a78bfa", title: "Kalibrierung",
          body: `
            <p class="muted">Gilt für Räume mit „Thermostat kalibrieren“: so oft wird der Offset am Gerät höchstens angepasst. Seltener schont die Batterien.</p>
            <label class="field narrow"><span>Höchstens alle</span>${minutes("calibration_interval", 10, 1, 120)}</label>`,
        };

      case "import": {
        const dr = this._pop.draft;
        const res = dr.result;
        return {
          icon: "mdi:calendar-import", c: "#60a5fa", title: "Aus Kalender importieren", sub: "Termine der nächsten 7 Tage werden Komfortzeiten",
          body: `
            <div class="field"><span><ha-icon icon="mdi:calendar"></ha-icon> Kalender</span>${this._picker("import_calendar", dr.import_calendar ? [dr.import_calendar] : [])}</div>
            <label class="field"><span><ha-icon icon="mdi:text-search"></ha-icon> Nur Termine mit diesen Wörtern (leer = alle)</span><input type="text" maxlength="200" data-pop="keyword" value="${esc(dr.keyword || "")}" placeholder="z. B. Homeoffice, Heizen"></label>
            <p class="muted small">Gleiche Uhrzeiten an mehreren Tagen werden zu einem Zeitfenster. Ganztägige Termine werden übersprungen. Danach kannst du alles wie gewohnt anpassen.</p>
            <button class="secondary wide" data-action="import-read" ${dr.import_calendar ? "" : "disabled"}><ha-icon icon="mdi:calendar-search"></ha-icon>Termine lesen</button>
            ${res ? `
            <div class="lbl" style="margin-top:16px">${res.length ? `${res.length} Zeitfenster gefunden` : "Keine passenden Termine gefunden"}</div>
            <div class="evlist">${res.map((b) => `<div class="ev"><ha-icon icon="mdi:clock-outline"></ha-icon><span class="grow"><b>${esc(b.start)} – ${esc(b.end)}</b><small>${b.days.map((d) => DAYS[d]).join(", ")}</small></span></div>`).join("")}</div>` : ""}`,
          foot: `<button class="secondary" data-action="pop-close">Abbrechen</button>
            ${res && res.length ? `<button class="secondary" data-action="import-apply" data-mode="append"><ha-icon icon="mdi:plus"></ha-icon>Hinzufügen</button>
            <button class="primary" data-action="import-apply" data-mode="replace"><ha-icon icon="mdi:swap-horizontal"></ha-icon>Ersetzen</button>` : ""}`,
        };
      }
    }
    return { icon: "mdi:cog", c: "#94a3b8", title: "Einstellung", body: "" };
  }
  // ------------------------------------------------------------ Raum-Dialog
  /** Experteneinstellungen je Modul ("haus", "heizen", "rollwerk", "kraftwerk"), gemerkt je Gerät. */
  _expertOn(mod = "heizen") {
    if (!this._expert || typeof this._expert !== "object") this._expert = {};
    if (this._expert[mod] == null) {
      try {
        const own = localStorage.getItem(`hauswerk.experte.${mod}`);
        // Früher galt ein Schalter für alles: Heizwerk und Rollwerk übernehmen ihn einmalig
        const old = ["heizen", "rollwerk"].includes(mod) ? localStorage.getItem("hauswerk.experte") ?? localStorage.getItem("heizwerk.experte") : null;
        this._expert[mod] = (own ?? old) === "1";
      } catch (e) {
        this._expert[mod] = false;
      }
    }
    return this._expert[mod];
  }

  _setExpert(mod, on) {
    this._expertOn(mod);
    this._expert[mod] = !!on;
    try {
      localStorage.setItem(`hauswerk.experte.${mod}`, on ? "1" : "0");
    } catch (err) {
      /* ohne Speicher: gilt bis zum Neuladen */
    }
  }

  // ------------------------------------------------------------ Raum-Assistent
  /** Entitäten eines Home-Assistant-Bereichs (direkt oder über das Gerät zugeordnet). */
  _areaEntities(areaId) {
    const E = this._hass.entities || {};
    const D = this._hass.devices || {};
    return Object.keys(this._hass.states).filter((id) => {
      const e = E[id];
      if (!e || e.hidden || e.entity_category) return false;
      return (e.area_id || D[e.device_id]?.area_id) === areaId;
    });
  }

  /** Was der Assistent in einem Bereich findet: Thermostate, Fenster, Sensoren, Fußbodenheizung. */
  _wizScan(areaId) {
    const used = new Set(this._rooms().flatMap((r) => r.climates || []));
    const ids = areaId ? this._areaEntities(areaId) : [];
    const S = this._hass.states;
    const dc = (id) => S[id]?.attributes?.device_class;
    const dom = (id) => id.split(".")[0];
    const climates = ids.filter((id) => dom(id) === "climate" && this._devType(id) !== "Wärmeerzeuger");
    return {
      climates,
      free: climates.filter((id) => !used.has(id)),
      windows: ids.filter((id) => dom(id) === "binary_sensor" && ["window", "door", "opening", "garage_door"].includes(dc(id))),
      temps: ids.filter((id) => dom(id) === "sensor" && dc(id) === "temperature"),
      hums: ids.filter((id) => dom(id) === "sensor" && dc(id) === "humidity"),
      floor: ids.filter((id) => this._devType(id) === "Fußbodenheizung"),
    };
  }

  _wizOpen() {
    this._openPop("rwiz", { step: 0, area: null, name: "", use: null, type: "heizkoerper", climates: [], assist: [], windows: [], temp: null, hum: null, show: [],
      comfort: 21, eco: 18, plan: this._planList()[0]?.id ? `plan:${this._planList()[0].id}` : "preset:berufstaetig", open: false });
  }

  /** Bereich gewählt: Name und gefundene Geräte übernehmen, Nutzung am Namen erraten. */
  _wizArea(areaId) {
    const d = this._pop.draft;
    const area = this._hass.areas?.[areaId];
    const f = this._wizScan(areaId);
    const name = area?.name || "";
    const use = WIZ_USES.find((u) => u.match.test(name.toLowerCase()));
    Object.assign(d, { area: areaId, name, climates: f.free.length ? f.free : f.climates, windows: f.windows, temp: f.temps[0] || null, hum: f.hums[0] || null, show: f.floor, assist: [] });
    if (f.floor.length) d.type = "flaeche";
    if (use) this._wizUse(use.id);
  }

  _wizUse(id) {
    const d = this._pop.draft;
    const u = WIZ_USES.find((x) => x.id === id);
    if (!u) return;
    Object.assign(d, { use: id, comfort: u.comfort, eco: u.eco });
    if (!d.plan?.startsWith("plan:")) d.plan = `preset:${u.plan}`;
  }

  _wizPop() {
    const d = this._pop.draft;
    const steps = ["Raum", "Nutzung", "Heizung", "Geräte", "Zeiten", "Fertig"];
    const S = this._hass.states;
    const name = (id) => esc(this._entityName(id));
    const bar = `<div class="wiz-bar">${steps.map((s, i) => `<button class="wiz-dot ${i === d.step ? "on" : i < d.step ? "done" : ""}" data-action="wiz-go" data-i="${i}" ${i > d.step && !this._wizOk(i - 1) ? "disabled" : ""}><i>${i < d.step ? "✓" : i + 1}</i><span>${s}</span></button>`).join("")}</div>`;
    const tick = (on) => `<ha-icon icon="${on ? "mdi:checkbox-marked" : "mdi:checkbox-blank-outline"}"></ha-icon>`;
    const devRow = (k, id, on, extra = "") => `<button class="wiz-dev ${on ? "on" : ""}" data-action="wiz-tog" data-k="${k}" data-id="${esc(id)}">${tick(on)}<span class="grow"><b>${esc(this._devType(id))}</b><small>${name(id)} · ${esc(this._fmtState(S[id]))}${this._areaOf(id) && !d.area ? ` · ${esc(this._areaOf(id))}` : ""}</small></span>${extra}</button>`;
    const radio = (k, id, label) => `<button class="wiz-dev ${d[k] === id ? "on" : ""}" data-action="wiz-one" data-k="${k}" data-id="${esc(id || "")}"><ha-icon icon="${d[k] === id ? "mdi:radiobox-marked" : "mdi:radiobox-blank"}"></ha-icon><span class="grow"><b>${label}</b>${id ? `<small>${name(id)}</small>` : ""}</span></button>`;
    let body = "";
    switch (d.step) {
      case 0: {
        const areas = Object.values(this._hass.areas || {}).sort((a, b) => a.name.localeCompare(b.name, "de"));
        const taken = new Set(this._rooms().map((r) => r.name.toLowerCase()));
        body = `<p class="muted">Welcher Raum soll geheizt werden? Wähle einen Bereich aus Home Assistant – Thermostate, Fenster und Sensoren darin sucht der Assistent dann selbst.</p>
          <div class="wiz-areas">${areas.map((a) => {
            const f = this._wizScan(a.area_id);
            const done = taken.has(a.name.toLowerCase()) || (f.climates.length && !f.free.length);
            return `<button class="wiz-area ${d.area === a.area_id ? "on" : ""} ${done ? "done" : ""}" data-action="wiz-area" data-id="${esc(a.area_id)}">
              <ha-icon icon="${a.icon || "mdi:door"}"></ha-icon><b>${esc(a.name)}</b>
              <small>${done ? "schon angelegt" : f.climates.length ? `${f.climates.length} Thermostat${f.climates.length > 1 ? "e" : ""}${f.windows.length ? ` · ${f.windows.length} Fenster` : ""}` : "kein Thermostat"}</small></button>`;
          }).join("")}</div>
          <label class="field"><span><ha-icon icon="mdi:form-textbox"></ha-icon> Name des Raums</span><input type="text" data-wiz="name" value="${esc(d.name)}" placeholder="z. B. Wohnzimmer" maxlength="40"></label>
          ${!areas.length ? `<p class="muted small">In Home Assistant sind keine Bereiche angelegt – dann einfach einen Namen eingeben, die Geräte wählst du im übernächsten Schritt.</p>` : ""}`;
        break;
      }
      case 1:
        body = `<p class="muted">Wofür wird <b>${esc(d.name)}</b> genutzt? Daraus schlägt der Assistent Temperaturen und Heizzeiten vor – ändern kannst du alles.</p>
          <div class="wiz-areas">${WIZ_USES.map((u) => `<button class="wiz-area ${d.use === u.id ? "on" : ""}" data-action="wiz-use" data-id="${u.id}"><ha-icon icon="${u.icon}"></ha-icon><b>${u.label}</b><small>${fmt(u.comfort)} / ${fmt(u.eco)} °C</small></button>`).join("")}</div>`;
        break;
      case 2: {
        const opt = (v, icon, t, s) => `<button class="wiz-type ${d.type === v ? "on" : ""}" data-action="wiz-type" data-v="${v}"><ha-icon icon="${icon}"></ha-icon><span><b>${t}</b><small>${s}</small></span></button>`;
        body = `<p class="muted">Wie wird ${esc(d.name)} beheizt?</p>
          ${opt("heizkoerper", "mdi:radiator", "Heizkörper", "reagiert schnell: kurze Vorheizzeit, Pause schon nach 1 Minute offenem Fenster")}
          ${opt("flaeche", "mdi:heating-coil", "Fußbodenheizung", "träge: lange Vorheizzeit, wenig Absenkung, Pause erst nach 15 Minuten offenem Fenster")}
          ${opt("misch", "mdi:home-thermometer", "Fußbodenheizung + Heizkörper", "Wandthermostat regelt die Fußbodenheizung, Heizkörper helfen nur bei Bedarf (Mischbetrieb)")}`;
        break;
      }
      case 3: {
        const f = this._wizScan(d.area);
        const used = new Set(this._rooms().flatMap((r) => r.climates || []));
        const other = Object.keys(S).filter((id) => id.startsWith("climate.") && !f.climates.includes(id) && !used.has(id) && this._devType(id) !== "Wärmeerzeuger")
          .sort((a, b) => this._entityName(a).localeCompare(this._entityName(b), "de"));
        const chosen = new Set(d.climates);
        const extra = d.climates.filter((id) => !f.climates.includes(id));
        const asst = (id) => d.type === "misch" && chosen.has(id) && this._thermoKind(id) !== "wall"
          ? `<em class="wiz-role ${d.assist.includes(id) ? "on" : ""}" data-action="wiz-assist" data-id="${esc(id)}">${d.assist.includes(id) ? "Zusatz" : "folgt Wand"}</em>` : "";
        const wins = Object.keys(S).filter((id) => id.startsWith("binary_sensor.") && ["window", "door", "opening"].includes(S[id].attributes?.device_class));
        const winOther = wins.filter((id) => !f.windows.includes(id) && d.windows.includes(id));
        body = `<div class="lbl">Thermostate</div>
          ${f.climates.length ? f.climates.map((id) => devRow("climates", id, chosen.has(id), asst(id))).join("") : `<p class="muted small">In ${esc(d.name || "diesem Bereich")} hat der Assistent kein Thermostat gefunden.</p>`}
          ${extra.map((id) => devRow("climates", id, true, asst(id))).join("")}
          ${other.length ? `<label class="field"><span><ha-icon icon="mdi:plus"></ha-icon> Anderes Thermostat hinzufügen</span><select data-wiz-add="climates"><option value="">wählen …</option>${other.filter((id) => !chosen.has(id)).map((id) => `<option value="${esc(id)}">${name(id)}${this._areaOf(id) ? ` (${esc(this._areaOf(id))})` : ""}</option>`).join("")}</select></label>` : ""}
          ${d.type === "misch" ? `<p class="muted small"><ha-icon icon="mdi:information-outline"></ha-icon>Tippe bei einem Heizkörper auf „folgt Wand“, um ihn zur <b>Zusatzheizung</b> zu machen (in der CCU vorher aus der Heizgruppe nehmen). Die anderen folgen weiter dem Wandthermostat.</p>` : ""}
          <div class="lbl">Fenster & Türen</div>
          ${f.windows.map((id) => devRow("windows", id, d.windows.includes(id))).join("")}${winOther.map((id) => devRow("windows", id, true)).join("")}
          ${!f.windows.length ? `<p class="muted small">Keine Kontakte im Bereich – ohne Kontakt erkennt Hauswerk offene Fenster am Temperatursturz.</p>` : ""}
          <label class="field"><span><ha-icon icon="mdi:plus"></ha-icon> Anderen Kontakt hinzufügen</span><select data-wiz-add="windows"><option value="">wählen …</option>${wins.filter((id) => !d.windows.includes(id)).map((id) => `<option value="${esc(id)}">${name(id)}${this._areaOf(id) ? ` (${esc(this._areaOf(id))})` : ""}</option>`).join("")}</select></label>
          ${f.temps.length ? `<div class="lbl">Raumtemperatur messen mit</div>${radio("temp", null, "dem Thermostat")}${f.temps.map((id) => radio("temp", id, this._devType(id))).join("")}` : ""}
          ${f.hums.length ? `<div class="lbl">Luftfeuchte</div>${radio("hum", null, "keine")}${f.hums.map((id) => radio("hum", id, this._devType(id))).join("")}` : ""}
          ${f.floor.length ? `<div class="lbl">Nur anzeigen</div>${f.floor.map((id) => devRow("show", id, d.show.includes(id))).join("")}` : ""}`;
        break;
      }
      case 4: {
        const plans = this._planList();
        const step = (k) => `<div class="wiz-temp"><button class="sbtn" data-action="wiz-t" data-k="${k}" data-d="-0.5">−</button><b>${fmt(d[k])} °C</b><button class="sbtn" data-action="wiz-t" data-k="${k}" data-d="0.5">+</button></div>`;
        const planBtn = (v, t, s) => `<button class="wiz-dev ${d.plan === v ? "on" : ""}" data-action="wiz-plan" data-v="${v}"><ha-icon icon="${d.plan === v ? "mdi:radiobox-marked" : "mdi:radiobox-blank"}"></ha-icon><span class="grow"><b>${t}</b><small>${s}</small></span></button>`;
        const blocks = (b) => b.map((x) => `${x.days.length === 7 ? "täglich" : x.days.length === 5 && x.days[0] === 0 ? "Mo–Fr" : x.days.length === 2 && x.days[0] === 5 ? "Sa–So" : x.days.map((i) => "MDMDFSS"[i]).join("")} ${x.start}–${x.end}`).join(" · ");
        body = `<div class="wxrows">
            <div class="wxr"><div class="wxr-l"><b>Komfort</b><small>wenn jemand im Raum ist</small></div><div class="wxr-v">${step("comfort")}</div></div>
            <div class="wxr"><div class="wxr-l"><b>Eco</b><small>nachts und tagsüber ohne Nutzung</small></div><div class="wxr-v">${step("eco")}</div></div>
          </div>
          <div class="lbl">Heizzeiten (Komfort)</div>
          ${plans.map((p) => planBtn(`plan:${p.id}`, `Plan „${esc(p.name)}“`, `gemeinsam mit anderen Räumen${p.calendar ? " · aus Kalender" : ""}`)).join("")}
          ${Object.entries(PLAN_PRESETS).map(([k, p]) => planBtn(`preset:${k}`, `Eigener Plan: ${esc(p.label)}`, blocks(p.blocks))).join("")}
          <p class="muted small">Die Zeiten kannst du danach unter <i>Heizpläne</i> genau einstellen.</p>`;
        break;
      }
      case 5: {
        const plan = d.plan.startsWith("plan:") ? `Plan „${esc(this._data.plans?.[d.plan.slice(5)]?.name || "")}“` : esc(PLAN_PRESETS[d.plan.slice(7)]?.label || "");
        const line = (icon, t, v) => `<div class="kv"><ha-icon icon="${icon}"></ha-icon><span>${t}</span><b>${v}</b></div>`;
        const warn = !d.climates.length;
        body = `<div class="wiz-sum">
            ${line("mdi:door", "Raum", esc(d.name))}
            ${line("mdi:radiator", "Heizung", { heizkoerper: "Heizkörper", flaeche: "Fußbodenheizung", misch: "Fußbodenheizung + Heizkörper" }[d.type])}
            ${line("mdi:thermostat", "Thermostate", d.climates.length ? `${d.climates.length}${d.assist.length ? ` (${d.assist.length} Zusatz)` : ""}` : "keins")}
            ${line("mdi:window-open-variant", "Fenster", d.windows.length || "keine")}
            ${line("mdi:thermometer", "Messen mit", d.temp ? name(d.temp) : "Thermostat")}
            ${line("mdi:sofa-outline", "Komfort / Eco", `${fmt(d.comfort)} / ${fmt(d.eco)} °C`)}
            ${line("mdi:calendar-clock", "Heizzeiten", plan)}
          </div>
          ${warn ? `<p class="note warn"><ha-icon icon="mdi:alert-outline"></ha-icon>Ohne Thermostat kann Heizwerk den Raum nicht regeln – du kannst es später unter <i>Geräte</i> eintragen.</p>` : ""}
          <button class="wiz-dev ${d.open ? "on" : ""}" data-action="wiz-open">${tick(d.open)}<span class="grow"><b>Danach alle Einstellungen öffnen</b><small>Vorheizen, Fenster, Regelung, Experte …</small></span></button>`;
        break;
      }
    }
    const last = d.step === steps.length - 1;
    return {
      icon: "mdi:auto-fix", c: "#fb923c", title: "Raum anlegen", sub: `Schritt ${d.step + 1} von ${steps.length} · ${steps[d.step]}`,
      body: bar + body,
      foot: `${d.step ? `<button class="secondary" data-action="wiz-go" data-i="${d.step - 1}"><ha-icon icon="mdi:chevron-left"></ha-icon>Zurück</button>` : `<button class="secondary" data-action="wiz-expert" title="Ohne Assistent: alle Felder auf einmal">Ohne Assistent</button>`}
        ${last ? `<button class="primary" data-action="wiz-save"><ha-icon icon="mdi:check"></ha-icon>Raum anlegen</button>`
          : `<button class="primary" data-action="wiz-go" data-i="${d.step + 1}" ${this._wizOk(d.step) ? "" : "disabled"}>Weiter<ha-icon icon="mdi:chevron-right"></ha-icon></button>`}`,
    };
  }

  /** Darf es nach diesem Schritt weitergehen? */
  _wizOk(step) {
    const d = this._pop?.draft || {};
    if (step === 0) return !!String(d.name || "").trim();
    if (step === 1) return !!d.use;
    return true;
  }

  /** Raum aus dem Assistenten bauen und speichern. */
  async _wizSave() {
    const d = this._pop.draft;
    const room = { name: d.name.trim(), type: d.type === "misch" ? "flaeche" : d.type, comfort: d.comfort, eco: Math.min(d.eco, d.comfort), climates: d.climates, windows: d.windows,
      enabled: true, allow_manual: true, schedule: [] };
    if (d.temp) room.temp_sensor = d.temp;
    if (d.hum) room.humidity_sensor = d.hum;
    if (d.use) room.use = d.use;
    if (d.show.length) room.show_entities = d.show;
    if (d.type === "misch" && d.assist.length) room.assist_entities = d.assist;
    if (d.plan.startsWith("plan:")) room.plan_id = d.plan.slice(5);
    else room.schedule = clone(PLAN_PRESETS[d.plan.slice(7)]?.blocks || PLAN_PRESETS.berufstaetig.blocks);
    const saved = await this._saveRoom(room);
    if (!saved) return;
    const open = d.open;
    this._closePop();
    this._toast(`${saved.name} angelegt`);
    if (open) this._openRoom(saved);
  }

  _openRoom(room) {
    this._dialog = {
      room: room
        ? clone(room)
        : { name: "", type: "heizkoerper", comfort: 21, eco: 18, climates: [], windows: [], schedule: clone(PLAN_PRESETS.berufstaetig.blocks), enabled: true, allow_manual: true },
      isNew: !room,
    };
    // Altes Gesamt-Schalter-Feld in die zwei neuen Schalter überführen
    const r = this._dialog.room;
    if (r.allow_manual === false) {
      r.manual_device = r.manual_device ?? false;
      r.manual_ui = r.manual_ui ?? false;
    }
    r.allow_manual = true;
    // Neuer Raum: erster gemeinsamer Plan, falls es einen gibt
    const plans = this._planList();
    if (!room && plans.length) {
      r.plan_id = plans[0].id;
      r.schedule = [];
    }
    this._dialog.schedSrc = r.schedule_entity ? "entity" : this._data.plans?.[r.plan_id] ? "plan" : "own";
    this._renderDialog();
  }

  _renderDialog() {
    try {
      this._renderDialogInner();
    } catch (err) {
      const host = this.shadowRoot.getElementById("dialog");
      if (host) host.innerHTML = `<div class="backdrop" data-action="dialog-close"></div><div class="sheet pop"><div class="sheet-body">${this._failCard("Der Raum-Dialog", err)}</div>
        <div class="sheet-foot"><button class="secondary" data-action="dialog-close">Schließen</button></div></div>`;
    }
  }

  _renderDialogInner() {
    const host = this.shadowRoot.getElementById("dialog");
    if (!this._dialog) {
      host.innerHTML = "";
      return;
    }
    const scroll = host.querySelector(".sheet-body")?.scrollTop || 0;
    const r = this._dialog.room;
    const d = this._data.defaults[r.type];
    const tab = this._dialog.tab || "basis";
    const num = (key, unit, step, extra = "") =>
      `<div class="unit"><input type="number" step="${step}" data-room="${key}" value="${r[key] ?? ""}" placeholder="${d[key] ?? 0}" ${extra}><i>${unit}</i></div>`;
    const check = (key, icon, title, text, { on = !!r[key], disabled = false } = {}) =>
      `<label class="check"><ha-icon class="ck-ic" icon="${icon}"></ha-icon><span><b>${title}</b><small>${text}</small></span>
        <span class="switch"><input type="checkbox" data-room="${key}" ${on ? "checked" : ""} ${disabled ? "disabled" : ""}><span></span></span></label>`;
    const segs = (action, current, options) =>
      `<div class="segs small">${options
        .map(([v, l, icon]) => `<button class="seg ${current === v ? "on" : ""}" data-action="${action}" data-v="${v}">${icon ? `<ha-icon icon="${icon}"></ha-icon>` : ""}${l}</button>`)
        .join("")}</div>`;
    const hint = `<p class="muted small"><ha-icon icon="mdi:lightbulb-on-outline"></ha-icon>Leere Felder nutzen die Werte für ${TYPES[r.type].label} (grau).</p>`;
    const guessed = roomIcon({ ...r, icon: null });
    // Experten-Einstellungen nur auf Wunsch (gemerkt je Gerät)
    const ex = this._expertOn("heizen");
    const expertHint = (keys) => {
      const n = keys.filter((k) => r[k] != null && r[k] !== "" && r[k] !== false && !(Array.isArray(r[k]) && !r[k].length)).length;
      return `<button class="xhint" data-action="expert"><ha-icon icon="mdi:school-outline"></ha-icon><span>${n ? `${n} Experten-Einstellung${n > 1 ? "en" : ""} aktiv` : "Weitere Einstellungen für Experten"}</span><span class="grow"></span>Anzeigen<ha-icon icon="mdi:chevron-right"></ha-icon></button>`;
    };

    // Reiter mit Punkt, sobald dort etwas eingerichtet ist
    const TABS_D = [
      ["basis", "mdi:home-edit-outline", "Raum", false],
      ["devices", "mdi:thermostat", "Geräte", !!r.presence_sensor || !!(r.show_entities || []).length],
      ["window", "mdi:clock-fast", "Vorheizen & Fenster", !!r.window_detect || ["window_delay", "resume_delay", "lead_min", "max_setback", "pause_mode", "preheat_mode", "preheat_max"].some((k) => r[k] != null && r[k] !== "") || r.min_instead_of_off],
      ["control", "mdi:tune-variant", "Regelung", !!(r.compensation || r.calibration || r.valve_control || r.comfort_entity || r.eco_entity || Number(r.off_above) > 0 || Number(r.aggressive_range) > 0)],
    ];

    const views = {
      basis: () => `
        <label class="field"><span>Name</span><input type="text" maxlength="60" data-room="name" value="${esc(r.name)}" placeholder="z. B. Wohnzimmer"></label>
        <div class="field"><span>Symbol</span>
          <div class="icons">
            <button class="ic-pick ${!r.icon ? "on" : ""}" data-action="room-icon" data-v="" title="Automatisch aus dem Namen"><ha-icon icon="${guessed}"></ha-icon><em>Auto</em></button>
            ${ROOM_ICON_CHOICES.map((i) => `<button class="ic-pick ${r.icon === i ? "on" : ""}" data-action="room-icon" data-v="${i}" title="${i.replace("mdi:", "")}"><ha-icon icon="${i}"></ha-icon></button>`).join("")}
          </div>
        </div>
        <div class="field"><span>Heizungsart</span>
          <div class="types">
            ${Object.entries(TYPES)
              .map(([k, t]) => `
              <button class="type ${r.type === k ? "on" : ""}" data-action="room-type" data-type="${k}">
                <ha-icon icon="${t.icon}"></ha-icon><b>${t.label}</b><small>${t.text}</small>
              </button>`)
              .join("")}
          </div>
        </div>
        <div class="row2">
          <div class="field"><span><ha-icon icon="mdi:sofa-outline"></ha-icon> Komfort</span>${this._stepper("dlg", "comfort", r.comfort)}</div>
          <div class="field"><span><ha-icon icon="mdi:leaf"></ha-icon> Eco</span>${this._stepper("dlg", "eco", r.eco)}</div>
        </div>
        ${this._schedField(r, segs)}
        ${check("enabled", "mdi:robot-outline", "Automatik aktiv", "Aus: Heizwerk lässt die Thermostate dieses Raums in Ruhe.", { on: r.enabled !== false })}`,

      devices: () => `
        <div class="field"><span><ha-icon icon="mdi:thermostat"></ha-icon> Thermostate – Heizwerk stellt diese ein (z. B. das Wandthermostat)</span>${this._picker("climates", r.climates || [])}</div>
        ${(r.climates || []).length > 1 ? this._rolesBlock(r) : ""}
        <div class="field"><span><ha-icon icon="mdi:eye-outline"></ha-icon> Weitere Geräte – nur anzeigen</span>${this._picker("show_entities", r.show_entities || [])}</div>
        <p class="muted small"><ha-icon icon="mdi:information-outline"></ha-icon>Z. B. Heizkörper-Thermostat oder Stellantrieb der Fußbodenheizung: Heizwerk zeigt Ventilöffnung und Werte an der Raumkarte und auf der Raumseite, stellt aber nichts daran ein.</p>
        <div class="field"><span><ha-icon icon="mdi:window-closed-variant"></ha-icon> Fenster- und Türkontakte</span>${this._picker("windows", r.windows || [])}</div>
        <div class="row2">
          <div class="field"><span><ha-icon icon="mdi:thermometer"></ha-icon> Raumtemperatur</span>${this._picker("temp_sensor", r.temp_sensor ? [r.temp_sensor] : [])}</div>
          <div class="field"><span><ha-icon icon="mdi:water-percent"></ha-icon> Luftfeuchte</span>${this._picker("humidity_sensor", r.humidity_sensor ? [r.humidity_sensor] : [])}</div>
        </div>
        <p class="muted small"><ha-icon icon="mdi:information-outline"></ha-icon>Raumtemperatur und Luftfeuchte sind optional. Ohne Raumsensor nutzt Heizwerk den Messwert der Thermostate.</p>
        ${r.humidity_sensor ? `
        <div class="sub-h"><ha-icon icon="mdi:shower-head"></ha-icon>Nach dem Duschen</div>
        <div class="row2">
          <label class="field"><span>Nachheizen (0 = aus)</span><div class="unit"><input type="number" step="5" min="0" max="120" data-room="shower_boost" value="${r.shower_boost ?? ""}" placeholder="0"><i>Min.</i></div></label>
          <label class="field"><span>wenn die Luftfeuchte steigt um</span><div class="unit"><input type="number" step="1" min="3" max="40" data-room="shower_rise" value="${r.shower_rise ?? ""}" placeholder="10"><i>%-Punkte in 15 Min.</i></div></label>
        </div>
        <p class="muted small">Steigt die Feuchte so schnell (Duschen, Baden), heizt Heizwerk den Raum für diese Zeit auf Komfort – damit Wände und Handtücher trocknen. Höchstens einmal pro Stunde.</p>` : ""}
        <div class="sub-h"><ha-icon icon="mdi:weather-windy"></ha-icon>Lüften</div>
        <div class="row2">
          <label class="field"><span>Raumart</span><select data-room="use">${[["", "– aus dem Namen –"], ...WIZ_USES.map((u) => [u.id, u.label])].map(([v, l]) => `<option value="${v}" ${String(r.use || "") === v ? "selected" : ""}>${esc(l)}</option>`).join("")}</select></label>
          <label class="field"><span>Lüften ab Luftfeuchte</span><div class="unit"><input type="number" step="1" min="40" max="90" data-room="vent_rh" value="${r.vent_rh ?? ""}" placeholder="${fmt(this._ventLimitOf(r), 0)}"><i>%</i></div></label>
        </div>
        <div class="row2">
          <label class="field"><span>Morgens lüften</span><select data-room="vent_morning">${[["", "Automatisch (Schlaf-/Kinderzimmer)"], ["1", "Ja"], ["0", "Nein"]].map(([v, l]) => `<option value="${v}" ${(r.vent_morning == null ? "" : r.vent_morning ? "1" : "0") === v ? "selected" : ""}>${l}</option>`).join("")}</select></label>
          <div class="field"><span><ha-icon icon="mdi:molecule-co2"></ha-icon> CO₂-Sensor <span class="muted small">· optional</span></span>${this._picker("co2_sensor", r.co2_sensor ? [r.co2_sensor] : [])}</div>
        </div>
        ${(() => {
          const info = this._status?.rooms?.[r.id]?.links;
          if (!info) return "";
          const KI = { trv: "mdi:radiator", window: "mdi:window-closed-variant", fal: "mdi:heating-coil", wall: "mdi:thermostat", other: "mdi:link-variant" };
          return `<div class="sub-h"><ha-icon icon="mdi:link-variant"></ha-icon>Direktverknüpfungen in der CCU</div>
            ${info.walls.map((w) => `<div class="hl-w"><span class="hl-wn"><ha-icon icon="mdi:thermostat"></ha-icon>${esc(this._entityName(w.entity))}</span><ha-icon class="hl-arrow" icon="mdi:arrow-right"></ha-icon><span class="hl-ps">${w.peers.length ? w.peers.map((x) => `<span class="hl-p ${x.in_room ? "" : "out"}" title="${esc(x.model || "")}"><ha-icon icon="${KI[x.kind] || KI.other}"></ha-icon>${esc(x.name)}${x.kind === "fal" && x.channels.length ? ` · Kanal ${x.channels.join(", ")}` : ""}</span>`).join("") : `<em class="hl-none">keine Verknüpfung</em>`}</span></div>`).join("")}
            ${info.unlinked_trvs.length ? `<p class="muted small"><ha-icon icon="mdi:link-variant-off"></ha-icon>Nicht mit dem Wandthermostat verknüpft: ${info.unlinked_trvs.map((e) => esc(this._entityName(e))).join(", ")} – Hauswerk stellt ${info.unlinked_trvs.length > 1 ? "sie" : "ihn"} selbst${(r.assist_entities || []).some((e) => info.unlinked_trvs.includes(e)) ? " (Zusatzheizung im Mischbetrieb)" : ""}.</p>` : ""}
            ${info.windows_ccu.length ? check("window_ccu", "mdi:window-open-variant", "Fensterpause der CCU überlassen", `${info.windows_ccu.map((e) => esc(this._entityName(e))).join(", ")} ${info.windows_ccu.length > 1 ? "sind" : "ist"} direkt mit dem Thermostat verknüpft – die CCU senkt beim Lüften selbst ab. Hauswerk zeigt die Pause dann nur an und sendet nichts (spart Funk). Aus: Hauswerk schickt die Fenster-Temperatur zusätzlich.`, { on: r.window_ccu !== false }) : ""}
            <p class="muted small">Gelesen aus der CCU (nur lesen) · Übersicht unter Heizwerk › Einstellungen › Homematic-Verknüpfungen.</p>`;
        })()}
        <div class="sub-h"><ha-icon icon="mdi:fireplace"></ha-icon>Kamin</div>
        ${check("fireplace", "mdi:fireplace", "Kamin im Raum vorhanden", "Wird der Raum wärmer, ohne dass geheizt wird, rechnet Heizwerk mit einer zusätzlichen Wärmequelle: Diese Zeit zählt nicht für die Bewertung der Heizleistung und nicht fürs Lernen der Aufheizzeit.")}
        ${r.fireplace ? `
        <div class="field"><span><ha-icon icon="mdi:flash-outline"></ha-icon> Signal „Kamin in Betrieb“ <span class="muted small">· optional</span></span>${this._picker("fireplace_entity", r.fireplace_entity ? [r.fireplace_entity] : [])}</div>
        <p class="muted small">Ein vorhandener Kamin heißt nicht, dass er brennt. Ohne Signal sagt Heizwerk nur „wärmer ohne Heizung – vielleicht der Kamin“ (es kann auch Sonne, Kochen oder Besuch sein). Mit Signal ist es sicher: Schalter, Binärsensor oder Steckdose (an = brennt), Temperaturfühler am Ofen bzw. Rohr (ab 50 °C) oder Leistung eines Gebläses. Ohne Signal lässt sich „Kamin an“ auch von Hand angeben – Tipp auf die Raumkachel.</p>` : ""}
        <div class="sub-h"><ha-icon icon="mdi:motion-sensor"></ha-icon>Präsenzmelder im Raum <span class="muted small">· optional</span></div>
        <div class="field">${this._picker("presence_sensor", r.presence_sensor ? [r.presence_sensor] : [])}</div>
        ${r.presence_sensor ? `
        <div class="field"><span>Wann heizen</span>
          ${segs("presence-mode", r.presence_mode || "plan", [["plan", "In Komfortzeiten, wenn jemand da ist", "mdi:calendar-account-outline"], ["always", "Immer, sobald jemand da ist", "mdi:account-check-outline"]])}
        </div>
        <div class="row2">
          <label class="field"><span><ha-icon icon="mdi:account-arrow-right-outline"></ha-icon> Belegt nach</span>${num("presence_on", "Min.", 1, 'min="0" max="240"')}</label>
          <label class="field"><span><ha-icon icon="mdi:account-arrow-left-outline"></ha-icon> Leer nach</span>${num("presence_off", "Min.", 1, 'min="0" max="240"')}</label>
        </div>
        <div class="field"><span><ha-icon icon="mdi:calendar-clock"></ha-icon> Nur berücksichtigen, solange an (optional)</span>${this._picker("presence_schedule", r.presence_schedule ? [r.presence_schedule] : [])}</div>` : `<p class="muted small">Mit Präsenzmelder bleibt der Raum während der Komfortzeit auf Eco, solange niemand darin ist.</p>`}
        <p class="muted small"><ha-icon icon="mdi:home-account"></ha-icon>Wer zu Hause ist (Personen, Abwesend, Urlaub), gilt für das ganze Haus: Hauswerk › Einstellungen › Anwesenheit.</p>`,

      window: () => `
        ${hint}
        ${this._preheatSection(r, d, num, segs, ex)}
        <div class="sub-h"><ha-icon icon="mdi:window-open-variant"></ha-icon>Fenster</div>
        <div class="field"><span>Bei offenem Fenster</span>
          ${segs("pause-mode", r.pause_mode || "", [["", `Standard (${d.pause_mode === "off" ? "aus" : "Frostschutz"})`, "mdi:auto-mode"], ["frost", "Frostschutz", "mdi:snowflake"], ["off", "Ausschalten", "mdi:power"]])}
        </div>
        ${check("window_detect", "mdi:thermometer-chevron-down", "Fenster ohne Kontakt erkennen", "Fällt die Raumtemperatur in 5 Minuten stark, gilt das als offenes Fenster – Fensterpause für eine feste Zeit.")}
        ${r.window_detect ? `
        <div class="row2">
          <label class="field"><span><ha-icon icon="mdi:arrow-down-bold"></ha-icon> Temperatursturz ab</span><div class="unit"><input type="number" step="0.1" min="0.3" max="5" data-room="window_detect_drop" value="${r.window_detect_drop ?? ""}" placeholder="1,0"><i>°C in 5 Min.</i></div></label>
          <label class="field"><span><ha-icon icon="mdi:timer-sand"></ha-icon> Pause dann für</span><div class="unit"><input type="number" step="5" min="5" max="60" data-room="window_detect_min" value="${r.window_detect_min ?? ""}" placeholder="15"><i>Min.</i></div></label>
        </div>
        ${(r.windows || []).length ? `<p class="muted small"><ha-icon icon="mdi:information-outline"></ha-icon>Gilt zusätzlich zu den Fensterkontakten – z. B. für ein Fenster ohne Kontakt.</p>` : ""}` : ""}
        <div class="row2">
          <label class="field"><span><ha-icon icon="mdi:timer-sand"></ha-icon> Fensterpause nach</span>${num("window_delay", "s", 10, 'min="0" max="7200"')}</label>
          ${ex ? `<label class="field"><span><ha-icon icon="mdi:timer-play-outline"></ha-icon> Weiterheizen nach dem Schließen</span>${num("resume_delay", "s", 10, 'min="0" max="3600"')}</label>` : ""}
        </div>
        ${ex ? `
        <div class="sub-h"><ha-icon icon="mdi:school-outline"></ha-icon>Experte</div>
        <div class="row2">
          <label class="field"><span><ha-icon icon="mdi:arrow-collapse-down"></ha-icon> Höchstens absenken um</span>${num("max_setback", "°C", 0.5, 'min="0" max="15"')}</label>
          <label class="field"><span><ha-icon icon="mdi:window-open-variant"></ha-icon> Temperatur bei offenem Fenster</span><div class="unit"><input type="number" step="0.5" min="5" max="30" data-room="window_temp" value="${r.window_temp ?? ""}" placeholder="${fmt(this._data.settings.frost_temp)}"><i>°C</i></div></label>
        </div>
        ${check("min_instead_of_off", "mdi:thermometer-low", "Kleinste Temperatur statt Ausschalten", "Für Thermostate, die sich nicht zuverlässig aus- und wieder einschalten lassen.")}` : expertHint(["resume_delay", "max_setback", "window_temp", "min_instead_of_off"])}`,

      control: () => `
        ${check("manual_device", "mdi:hand-back-right-outline", "Am Gerät gedreht übernehmen", "Dreht jemand am Thermostat selbst, gilt der Wert bis zur nächsten Planänderung.", { on: r.allow_manual !== false && r.manual_device !== false })}
        ${check("manual_ui", "mdi:cellphone-cog", "In Home Assistant geändert übernehmen", "Ändert jemand das Thermostat in Home Assistant oder der App, gilt der Wert bis zur nächsten Planänderung.", { on: r.allow_manual !== false && r.manual_ui !== false })}
        ${r.type === "heizkoerper" ? check("compensation", "mdi:thermometer-plus", "Nach Raumsensor nachführen", "Misst das Thermostat am Heizkörper zu warm, wird der Sollwert um die Differenz (max. 4 °C) angehoben.", { disabled: !r.temp_sensor }) : ""}
        ${r.type === "heizkoerper" && !r.temp_sensor ? `<p class="muted small"><ha-icon icon="mdi:alert-circle-outline"></ha-icon>Nachführen braucht einen Raumsensor (Reiter Geräte).</p>` : ""}
        ${ex ? `
        <div class="sub-h"><ha-icon icon="mdi:school-outline"></ha-icon>Experte</div>
        ${hint}
        <div class="row2">
          <label class="field"><span><ha-icon icon="mdi:plus-minus-variant"></ha-icon> Fester Ausgleich am Thermostat</span>${num("target_offset", "°C", 0.5, 'min="-5" max="5"')}</label>
        </div>
        <p class="muted small"><ha-icon icon="mdi:information-outline"></ha-icon>Regelt ein Thermostat dauerhaft zu kalt, z. B. +1 °C: Heizwerk schickt dann 1 °C mehr als den Sollwert.</p>
        ${check("calibration", "mdi:tune-vertical-variant", "Thermostat kalibrieren", "Setzt den Temperatur-Offset am Gerät (number-Entität mit „calibration“ oder „offset“ im Namen), damit es wie der Raumsensor misst. Ersetzt das Nachführen.", { disabled: !r.temp_sensor })}
        ${r.calibration ? `<div class="field"><span>Offset-Entität (leer = automatisch suchen)</span>${this._picker("calibration_entities", r.calibration_entities || [])}</div>` : ""}
        ${check("valve_control", "mdi:valve", "Ventil direkt steuern", "Für Thermostate mit Ventil-Entität (number mit „valve“ oder „position“ im Namen): Öffnung nach Abstand zum Soll.")}
        ${r.valve_control ? `
        <div class="row2">
          <label class="field"><span>Ganz offen ab</span>${num("valve_diff", "°C unter Soll", 0.1, 'min="0.2" max="5"')}</label>
          <label class="field"><span>Höchstens öffnen</span>${num("valve_max", "%", 5, 'min="10" max="100"')}</label>
        </div>
        <div class="field"><span>Ventil-Entität (leer = automatisch suchen)</span>${this._picker("valve_entities", r.valve_entities || [])}</div>` : ""}
        <div class="sub-h"><ha-icon icon="mdi:chart-bell-curve-cumulative"></ha-icon>Feinregelung <span class="muted small">· 0 = aus</span></div>
        <div class="row3">
          <label class="field"><span><ha-icon icon="mdi:thermometer-check"></ha-icon> Aus ab Soll +</span>${num("off_above", "°C", 0.1, 'min="0" max="5"')}</label>
          <label class="field"><span><ha-icon icon="mdi:arrow-expand-vertical"></ha-icon> Übersteuern ab</span>${num("aggressive_range", "°C", 0.1, 'min="0" max="5"')}</label>
          <label class="field"><span><ha-icon icon="mdi:plus-minus-variant"></ha-icon> Übersteuern um</span>${num("aggressive_offset", "°C", 0.5, 'min="0" max="5"')}</label>
        </div>
        <p class="muted small">Übersteuern stellt das Thermostat höher bzw. tiefer, solange der Raum weit vom Soll entfernt ist – träge Thermostate reagieren so schneller.</p>
        <div class="sub-h"><ha-icon icon="mdi:tune-vertical"></ha-icon>Komfort und Eco aus Helfern</div>
        <p class="muted small">Eine Zahl-Entität (z. B. input_number) ersetzt den festen Wert, so lässt er sich per Automation oder Dashboard ändern.</p>
        <div class="row2">
          <div class="field"><span><ha-icon icon="mdi:sofa-outline"></ha-icon> Komfort aus</span>${this._picker("comfort_entity", r.comfort_entity ? [r.comfort_entity] : [])}</div>
          <div class="field"><span><ha-icon icon="mdi:leaf"></ha-icon> Eco aus</span>${this._picker("eco_entity", r.eco_entity ? [r.eco_entity] : [])}</div>
        </div>` : expertHint(["target_offset", "calibration", "valve_control", "off_above", "aggressive_range", "aggressive_offset", "comfort_entity", "eco_entity"])}`,
    };

    host.innerHTML = `
      <div class="backdrop" data-action="dialog-close"></div>
      <div class="sheet" role="dialog" aria-label="Raum">
        <div class="sheet-head">
          <span class="rr-ic big" style="--rc:${r.id ? this._roomColor(r.id) : "var(--accent)"}"><ha-icon icon="${esc(roomIcon(r))}"></ha-icon></span>
          <div class="grow"><h2>${esc(r.name || (this._dialog.isNew ? "Neuer Raum" : "Raum"))}</h2><div class="muted">${this._dialog.isNew ? "Neuer Raum" : "Raum bearbeiten"} · ${TYPES[r.type].label}</div></div>
          <button class="icon boxed" data-action="dialog-close" title="Schließen"><ha-icon icon="mdi:close"></ha-icon></button>
        </div>
        <nav class="dtabs">
          ${TABS_D.map(([id, icon, label, dot]) => `<button class="dtab ${tab === id ? "on" : ""}" data-action="dialog-tab" data-tab="${id}" title="${label}"><ha-icon icon="${icon}"></ha-icon><span>${label}</span>${dot ? "<i></i>" : ""}</button>`).join("")}
          <span class="grow"></span>
          <button class="xtog ${ex ? "on" : ""}" data-action="expert" title="Experten-Einstellungen ${ex ? "ausblenden" : "anzeigen"}"><ha-icon icon="mdi:school-outline"></ha-icon><span>Experte</span><i></i></button>
        </nav>
        <div class="sheet-body">${views[tab]()}</div>
        <div class="sheet-foot">
          ${this._dialog.isNew ? "" : `<button class="danger" data-action="room-delete" title="Raum löschen"><ha-icon icon="mdi:trash-can-outline"></ha-icon></button>`}
          <button class="secondary" data-action="dialog-close">Abbrechen</button>
          <button class="primary" data-action="room-save"><ha-icon icon="mdi:content-save-outline"></ha-icon>Speichern</button>
        </div>
      </div>`;
    const body = host.querySelector(".sheet-body");
    if (body && this._dialog.keepScroll) body.scrollTop = scroll;
    this._dialog.keepScroll = true;
    const name = host.querySelector('[data-room="name"]');
    if (this._dialog.isNew && name && !this._dialog.focused) {
      this._dialog.focused = true;
      setTimeout(() => name.focus(), 50);
    }
  }

  _preheatSection(r, d, num, segs, ex = true) {
    const global = this._data.settings.preheat_mode || "fixed";
    const label = { smart: "lernend", fixed: "feste Zeit", off: "aus" };
    const mode = r.preheat_mode || global;
    const st = r.id ? this._status?.rooms?.[r.id] || {} : {};
    const learned = st.learned;
    const rate = st.heat_rate;
    const example = rate ? Math.round((2 / rate) * 60 * 1.15 + 5) : null;
    return `
      <div class="sub-h"><ha-icon icon="mdi:clock-fast"></ha-icon>Vorheizen</div>
      <p class="muted small">Damit der Raum zu Beginn einer Komfortzeit schon warm ist, heizt Heizwerk vorher los.</p>
      <div class="field">
        ${segs("preheat-mode", r.preheat_mode || "", [["", `Wie alle Räume (${label[global]})`, "mdi:home-outline"], ["smart", "Lernen", "mdi:brain"], ["fixed", "Feste Zeit", "mdi:timer-outline"], ["off", "Aus", "mdi:timer-off-outline"]])}
      </div>
      ${mode === "smart" ? `
        <div class="row2">
          ${ex ? `<label class="field"><span><ha-icon icon="mdi:timer-alert-outline"></ha-icon> Höchstens vorher</span>${num("preheat_max", "Min.", 10, 'min="10" max="600"')}</label>` : ""}
          <div class="field"><span><ha-icon icon="mdi:speedometer"></ha-icon> Aufheizgeschwindigkeit</span>
            <div class="learn ${learned ? "ok" : ""}">
              <b>${rate ? `${fmt(rate)} °C/h` : "–"}</b>
              <small>${!r.id ? "wird nach dem Speichern gelernt" : learned ? `gelernt · 2 °C wärmer ≈ ${example} min` : `Startwert · lernt beim nächsten Aufheizen`}</small>
              ${learned && this._admin ? `<button class="link tiny" data-action="preheat-reset" data-id="${r.id}"><ha-icon icon="mdi:restore"></ha-icon>neu lernen</button>` : ""}
            </div>
          </div>
        </div>
        <p class="muted small"><ha-icon icon="mdi:information-outline"></ha-icon>Heizwerk misst bei jedem Aufheizen, wie viele Grad pro Stunde der Raum schafft, und rechnet daraus die Startzeit aus – mit 15 % Reserve.</p>` : ""}
      ${mode === "fixed" ? `
        <div class="row2">
          <label class="field"><span><ha-icon icon="mdi:timer-outline"></ha-icon> Vorheizen vor Komfortbeginn</span>
            <div class="unit"><input type="number" step="5" min="0" max="600" data-room="lead_min" value="${r.lead_min ?? ""}" placeholder="${this._leadFor(r.type)}"><i>Min.</i></div></label>
        </div>` : ""}
      ${mode === "off" ? `<p class="muted small">Der Raum heizt erst zu Beginn der Komfortzeit los.</p>` : ""}`;
  }

  /** Woher der Raum seine Komfortzeiten bekommt: gemeinsamer Plan, eigener Plan oder Home Assistant. */
  _schedField(r, segs) {
    const plans = this._planList();
    const src = this._dialog.schedSrc;
    return `
      <div class="field"><span><ha-icon icon="mdi:calendar-clock"></ha-icon> Heizplan</span>
        ${segs("sched-src", src, [["plan", "Gemeinsamer Plan", "mdi:calendar-multiple"], ["own", "Eigener Plan", "mdi:calendar-edit"], ["entity", "Aus Home Assistant", "mdi:home-assistant"]])}
      </div>
      ${src === "plan" ? (plans.length ? `
      <label class="field"><span>Plan</span>
        <select data-room="plan_id">${plans.map((p) => `<option value="${p.id}" ${r.plan_id === p.id ? "selected" : ""}>${esc(p.name)}</option>`).join("")}</select></label>
      <p class="muted small">Zeiten des Plans änderst du unter Heizpläne – sie gelten für alle Räume mit diesem Plan. Komfort und Eco bleiben die Werte dieses Raums.</p>`
        : `<p class="note warn"><ha-icon icon="mdi:calendar-alert"></ha-icon>Noch kein gemeinsamer Plan. Lege einen unter Heizpläne an – bis dahin nutzt der Raum seinen eigenen Plan.</p>`) : ""}
      ${src === "own" ? `<p class="muted small">Die Zeiten bearbeitest du unter Heizpläne › Räume › ${esc(r.name || "dieser Raum")}.</p>` : ""}
      ${src === "entity" ? `
      <div class="field"><span>Zeitplan oder Kalender (an bzw. Termin = Komfort, sonst Eco)</span>${this._picker("schedule_entity", r.schedule_entity ? [r.schedule_entity] : [])}</div>
      <p class="muted small">Bei einem Kalender heizt Heizwerk vor dem nächsten Termin vor.</p>` : ""}`;
  }
  // ------------------------------------------------------------ Entitätsauswahl
  _entityName(id) {
    return this._hass.states[id]?.attributes?.friendly_name || id;
  }

  /** Zustand der Entitätssuche je Feld: Reiter, Suchtext, Filter, aufgeklappt. */
  _pkState(field) {
    this._pk = this._pk || {};
    return (this._pk[field] = this._pk[field] || { tab: "suggest", q: "", dom: "", avail: false, open: false });
  }

  /** Raum einer Entität aus Home Assistant (der Entität selbst, sonst ihres Geräts). */
  _areaOf(id) {
    const ent = this._hass.entities?.[id];
    const areaId = ent?.area_id || (ent?.device_id ? this._hass.devices?.[ent.device_id]?.area_id : null);
    return areaId ? this._hass.areas?.[areaId]?.name || null : null;
  }

  /** An/aus eines Stellantriebs oder Heizkreises (switch, input_boolean, binary_sensor), sonst null. */
  _switchOf(id) {
    const d = id.split(".")[0];
    if (!["switch", "input_boolean", "binary_sensor"].includes(d)) return null;
    const st = this._hass?.states?.[id];
    if (!st || !["on", "off"].includes(st.state)) return null;
    return st.state === "on";
  }

  _floorLabel(room) {
    return room.type === "flaeche" ? "Fußbodenheizung" : "Stellantrieb";
  }

  /** Anzeige-Geräte eines Raums zusammengefasst: höchste Ventilöffnung und Fußbodenheizung an/aus. */
  _devIndicators(room) {
    const ids = [...(room.climates || []), ...(room.show_entities || [])];
    const valves = ids.map((id) => this._valveOf(id)).filter((v) => v != null);
    const sws = (room.show_entities || []).map((id) => [id, this._switchOf(id)]).filter(([, v]) => v != null);
    return {
      valve: valves.length ? Math.max(...valves) : null,
      valves: valves.length,
      floor: sws.length
        ? { on: sws.some(([, v]) => v), label: this._floorLabel(room), names: sws.map(([id, v]) => `${this._entityName(id)} ${v ? "an" : "aus"}`).join(", ") }
        : null,
    };
  }

  /** Art des Geräts als Überschrift, z. B. „Wandthermostat“, „Fensterkontakt“, „Fußbodenheizung“. */
  _devType(id) {
    const st = this._hass?.states?.[id];
    const dom = String(id).split(".")[0];
    const a = st?.attributes || {};
    const dc = a.device_class;
    const txt = `${id} ${a.friendly_name || ""}`.toLowerCase();
    if (dom === "climate" && /zone|circuit|heizkreis|vaillant|viessmann|buderus|kessel|therme|w(ä|ae)rmepumpe|heat_?pump|boiler/.test(txt)) return "Wärmeerzeuger";
    if (dom === "climate") {
      const k = this._thermoKind(id);
      return k === "wall" ? "Wandthermostat" : k === "trv" ? "Heizkörper-Thermostat" : "Thermostat";
    }
    if ((dom === "switch" || dom === "input_boolean") && /fu(ss|ß)boden|fbh|fl(ä|ae)chen|heizkreis|stellantrieb/.test(txt)) return "Fußbodenheizung";
    if (dom === "binary_sensor") {
      return { window: "Fensterkontakt", door: "Türkontakt", opening: "Öffnungskontakt", garage_door: "Garagentor", motion: "Bewegungsmelder",
        occupancy: "Präsenzmelder", presence: "Präsenzmelder", battery: "Batterie", moisture: "Wassermelder", smoke: "Rauchmelder" }[dc]
        || (/fenster|window/.test(txt) ? "Fensterkontakt" : /präsenz|presence|bewegung|motion/.test(txt) ? "Präsenzmelder" : "Melder");
    }
    if (dom === "sensor") {
      if (a.unit_of_measurement === "%" && /ventil|valve|st(ö|oe)(ß|ss)el|tappet|heating_demand|pi_heating/.test(txt)) return "Ventilöffnung";
      if (a.unit_of_measurement === "%" && /heating_power|heizleistung|_heating$/.test(txt)) return "Heizleistung";
      if (/duty_cycle/.test(txt)) return "Funk-Auslastung";
      return { temperature: "Temperatursensor", humidity: "Feuchtesensor", battery: "Batterie", distance: "Entfernung", power: "Leistung",
        energy: "Energie", illuminance: "Helligkeit", pressure: "Luftdruck", carbon_dioxide: "CO₂-Sensor" }[dc] || "Sensor";
    }
    return { switch: "Schalter", input_boolean: "Schalter-Helfer", input_number: "Zahl-Helfer", number: "Einstellwert", valve: "Ventil",
      cover: "Rollladen", light: "Licht", scene: "Szene", script: "Skript", weather: "Wetterdienst", person: "Person",
      device_tracker: "Handy / Tracker", calendar: "Kalender", schedule: "Zeitplan", zone: "Zone", sun: "Sonne", notify: "Benachrichtigung",
      fan: "Lüfter", humidifier: "Luftentfeuchter", media_player: "Medienspieler" }[dom] || DOMAIN_LABEL[dom] || "Gerät";
  }

  /** Wandthermostat („wall“), Heizkörper-Thermostat („trv“) oder unbekannt – nach Modell, sonst Name. */
  _thermoKind(id) {
    const st = this._hass?.states?.[id];
    // Modell aus dem Zustand, sonst aus dem Geräte-Register (Homematic, Bosch, tado, Netatmo, Danfoss, Aqara, AVM …)
    const dev = this._hass?.devices?.[this._hass?.entities?.[id]?.device_id];
    const model = String(st?.attributes?.model || dev?.model || "").toLowerCase();
    if (model) {
      if (TRV_MODELS.some((w) => model.includes(w))) return "trv";
      if (WALL_MODELS.some((w) => model.includes(w))) return "wall";
    }
    const txt = `${id} ${st?.attributes?.friendly_name || ""}`.toLowerCase();
    if (/wth|wandthermostat|wall_thermostat|wall thermostat|raumthermostat|room thermostat/.test(txt)) return "wall";
    if (/trv|heizk(ö|o|oe)rper|radiator|stellantrieb|ventil/.test(txt)) return "trv";
    return null;
  }

  /** Rolle der Thermostate eines Raums: stellt ein · folgt dem Wandthermostat · selbst · Zusatzheizung. */
  _rolesBlock(r) {
    const rs = this._status?.rooms?.[r.id] || {};
    const climates = r.climates || [];
    const hasWall = climates.some((id) => this._thermoKind(id) === "wall");
    const assist = new Set(r.assist_entities || []);
    const own = new Set(r.pair_exclude || []);
    const role = (id) => assist.has(id) ? "assist" : this._thermoKind(id) === "wall" ? "main"
      : !hasWall || r.pair_mode === "off" || own.has(id) ? "own" : "follow";
    const rows = climates.map((id) => {
      const ro = role(id);
      const kind = this._thermoKind(id);
      const v = this._valveOf(id);
      let state = "";
      if (ro === "follow") state = (rs.pair_broken || []).includes(id) ? "folgt nicht – Hauswerk stellt selbst" : (rs.followers || []).includes(id) ? "folgt ✓" : "";
      if (ro === "assist" && rs.assist) state = rs.assist.on ? "heizt mit" : "zu – Boden reicht";
      const sub = [this._entityName(id), state, v != null ? `Ventil ${fmt(v, 0)} %` : ""].filter(Boolean).join(" · ");
      const opts = [...(hasWall ? [["follow", "Folgt Wand", "mdi:link-variant"]] : []), ["own", "Selbst", "mdi:tune-variant"], ["assist", "Zusatz", "mdi:radiator"]];
      return `<div class="role">
        <div class="role-h"><ha-icon icon="${kind === "wall" ? "mdi:thermostat-box" : "mdi:radiator"}"></ha-icon><span class="grow"><b>${esc(this._devType(id))}</b><small>${esc(sub)}</small></span>
          ${ro === "main" ? `<em class="role-main">stellt ein</em>` : ""}</div>
        ${ro === "main" ? "" : `<div class="segs small ${hasWall ? "n3" : "n2"}">${opts.map(([k, l, i]) => `<button class="seg ${ro === k ? "on" : ""}" data-action="role-set" data-id="${esc(id)}" data-v="${k}"><ha-icon icon="${i}"></ha-icon>${l}</button>`).join("")}</div>`}
      </div>`;
    }).join("");
    const anyAssist = climates.some((id) => role(id) === "assist");
    return `<div class="field"><span><ha-icon icon="mdi:thermostat"></ha-icon> Rolle der Thermostate</span>
      <div class="roles">${rows}</div>
      ${anyAssist ? `<label class="field narrow"><span><ha-icon icon="mdi:thermometer-chevron-down"></ha-icon> Zusatz-Heizkörper helfen ab</span><div class="unit"><input type="number" step="0.1" min="0.2" max="3" data-room="assist_diff" value="${r.assist_diff ?? ""}" placeholder="0,5"><i>°C unter Soll</i></div></label>` : ""}
      <details class="role-help"><summary><ha-icon icon="mdi:help-circle-outline"></ha-icon> Was bedeuten die Rollen?</summary>
        <p><b>Folgt Wand</b> – in der CCU-Heizgruppe des Wandthermostats; Hauswerk stellt nur das Wandthermostat (spart Funk). Folgt er 15 Min. nicht, stellt Hauswerk ihn selbst.</p>
        <p><b>Selbst</b> – Hauswerk stellt ihn wie das Wandthermostat auf das Raum-Soll.</p>
        <p><b>Zusatz</b> – Mischbetrieb: zu, solange die Fußbodenheizung reicht; heizt mit ab X °C unter Soll, beim Vorheizen und Boost. In der CCU aus der Heizgruppe nehmen und auf „Manu“ stellen.</p>
      </details></div>`;
  }

  /** %-Sensoren für die Ventilöffnung am selben Gerät wie das Thermostat (Sensoren vor Zahlen-Entitäten). */
  _valveSiblings(id) {
    const reg = this._hass?.entities;
    if (!reg) return [];
    if (this._valveMapFor !== reg) {
      this._valveMapFor = reg;
      this._valveMap = {};
    }
    if (this._valveMap[id]) return this._valveMap[id];
    const dev = reg[id]?.device_id;
    let found = [];
    if (dev) {
      // Homematic „Ventilöffnungsgrad“, Bosch „Ventilstößel“ (valvetappet), Zigbee „pi_heating_demand“/„position“,
      // tado „Heizleistung“ (sensor.*_heating), Netatmo „heating_power_request“
      const words = /ventil|valve|stellung|st(ö|oe)(ß|ss)el|tappet|heating_demand|heizbedarf|pi_heating|heating_power|heizleistung|_heating$|position/i;
      const cands = Object.entries(reg)
        .map(([eid, e]) => ({ ...e, entity_id: eid }))
        .filter((e) => e.device_id === dev && e.entity_id !== id && !e.hidden && words.test(`${e.entity_id} ${e.name || ""} ${e.translation_key || ""}`));
      const ok = (e) => {
        const st = this._hass.states?.[e.entity_id];
        return st && st.attributes?.unit_of_measurement === "%" && !/max|min|limit|grenze|offset/i.test(e.entity_id);
      };
      found = cands.filter((e) => e.entity_id.startsWith("sensor.") && ok(e)).map((e) => e.entity_id);
      if (!found.length) found = cands.filter((e) => e.entity_id.startsWith("number.") && ok(e)).map((e) => e.entity_id);
    }
    this._valveMap[id] = found;
    return found;
  }

  /** Ventilöffnung in % einer Entität (Thermostat-Attribut, Ventil/Stellantrieb oder %-Sensor), sonst null. */
  _valveOf(id) {
    const st = this._hass?.states?.[id];
    if (!st || ["unavailable", "unknown"].includes(st.state)) return null;
    const a = st.attributes || {};
    const d = id.split(".")[0];
    const num = (v) => (v === null || v === undefined || v === "" || isNaN(Number(v)) ? null : Number(v));
    if (d === "climate") {
      for (const k of ["valve_position", "valve_opening", "valve_tappet", "pi_heating_demand", "heating_demand", "heating_power_request", "heating_power", "position", "valve"]) {
        if (num(a[k]) != null) return num(a[k]);
      }
      // Viele Thermostate (z. B. Homematic IP, Zigbee) melden die Ventilöffnung als eigenen Sensor am selben Gerät.
      const vals = this._valveSiblings(id).map((sid) => this._valveOf(sid)).filter((v) => v != null);
      return vals.length ? Math.max(...vals) : null;
    }
    if (d === "valve" || d === "cover") return num(a.current_position);
    if ((d === "sensor" || d === "number") && a.unit_of_measurement === "%" && a.device_class !== "battery" && a.device_class !== "humidity") return num(st.state);
    return null;
  }

  _fmtState(st) {
    if (!st) return "nicht gefunden";
    if (["unavailable", "unknown"].includes(st.state)) return "nicht erreichbar";
    const a = st.attributes || {};
    const domain = st.entity_id?.split(".")[0];
    if (domain === "climate") {
      const mode = { heat: "Heizen", off: "Aus", auto: "Auto", heat_cool: "Auto", cool: "Kühlen" }[st.state] || st.state;
      return a.current_temperature != null ? `${fmt(a.current_temperature)} °C · ${mode}` : mode;
    }
    if (domain === "binary_sensor" || domain === "input_boolean" || domain === "switch") {
      const on = st.state === "on";
      const dc = a.device_class;
      if (["window", "door", "opening", "garage_door"].includes(dc)) return on ? "offen" : "zu";
      if (["motion", "occupancy", "presence"].includes(dc)) return on ? "erkannt" : "frei";
      return on ? "an" : "aus";
    }
    if (domain === "person" || domain === "device_tracker") return st.state === "home" ? "zu Hause" : st.state === "not_home" ? "unterwegs" : st.state;
    const u = st.attributes.unit_of_measurement;
    const n = Number(st.state);
    return `${st.state !== "" && isFinite(n) ? n.toLocaleString("de-DE", { maximumFractionDigits: 2 }) : st.state}${u ? ` ${u}` : ""}`;
  }

  /** Auswahlfeld: gewählte Entitäten als Karten, darunter die Suche mit Vorschlägen, nach Raum und Filter. */
  _picker(field, selected) {
    // einzelne Entität oder Liste – beides annehmen
    selected = Array.isArray(selected) ? selected : selected ? [selected] : [];
    const cfg = PICKERS[field];
    const S = this._pkState(field);
    const open = this._admin && S.open;  // erst nach „Hinzufügen“ bzw. „Ändern“
    const cards = (cfg.noCards ? [] : selected)
      .map((id) => {
        const st = this._hass.states[id];
        const area = this._areaOf(id);
        return `
        <div class="pk-sel ${st ? "" : "missing"}">
          <button class="pk-sel-b" ${this._admin && !cfg.multi ? `data-action="pk-open" data-field="${field}" title="Ändern"` : "disabled"}>
            <b>${esc(this._devType(id))}</b><small>${esc(this._entityName(id))} · ${esc(this._fmtState(st))}${area ? ` · ${esc(area)}` : ""}</small>
          </button>
          ${this._admin ? `<button class="pk-x" data-action="pick-remove" data-field="${field}" data-id="${esc(id)}" title="Entfernen" aria-label="Entfernen"><ha-icon icon="mdi:close"></ha-icon></button>` : ""}
        </div>`;
      })
      .join("");
    const more = this._admin && !open
      ? `<button class="pk-add" data-action="pk-open" data-field="${field}"><ha-icon icon="${cfg.multi || !selected.length ? "mdi:plus" : "mdi:swap-horizontal"}"></ha-icon>${!selected.length ? "Hinzufügen" : cfg.multi ? "Weitere hinzufügen" : "Andere wählen"}</button>`
      : !this._admin && !selected.length ? `<div class="pk-none muted small">Nichts gewählt</div>` : "";
    const box = open
      ? `<div class="pk-box">
          <div class="search"><ha-icon icon="mdi:magnify"></ha-icon><input type="search" data-picker-input="${field}" placeholder="Suchen: Name, Raum, Entität …" value="${esc(S.q)}" autocomplete="off"></div>
          <div class="pk-tabs">${[["suggest", "Vorschläge"], ["area", "Nach Raum"], ["filter", "Filter"]]
            .map(([k, l]) => `<button class="${S.tab === k ? "on" : ""}" data-action="pk-tab" data-field="${field}" data-v="${k}">${l}</button>`)
            .join("")}</div>
          <div class="pk-body">${this._pickerList(field)}</div>
          <button class="link tiny pk-close" data-action="pk-open" data-field="${field}">${selected.length ? "Fertig" : "Abbrechen"}</button>
        </div>`
      : "";
    return `<div class="picker" data-picker="${field}">${cards}${more}${box}</div>`;
  }

  /** Kandidaten mit Bewertung: passt die Geräteklasse, der Name, der Raum? */
  _candidates(field, query) {
    const cfg = PICKERS[field];
    const S = this._pkState(field);
    const selected = this._pickerValue(field);
    const words = (query || "").toLowerCase().trim().split(/\s+/).filter(Boolean);
    const room = cfg.scope === "room" ? this._dialog?.room : null;
    const roomWords = (room?.name || "").toLowerCase().split(/[\s\-_.:]+/).filter((w) => w.length > 2);
    const hints = PICK_HINTS[field] || [];
    const classes = PICK_CLASSES[field] || [];
    const list = [];
    for (const [id, st] of Object.entries(this._hass.states)) {
      const domain = id.split(".")[0];
      if (!cfg.domains.includes(domain)) continue;
      const sel = selected.includes(id);
      if (sel && cfg.multi) continue;
      const a = st.attributes || {};
      const dc = a.device_class;
      const unit = a.unit_of_measurement;
      if (cfg.deviceClass) {
        const ok = dc === cfg.deviceClass || (cfg.deviceClass === "temperature" && ["°C", "°F"].includes(unit)) || (["humidity", "battery"].includes(cfg.deviceClass) && unit === "%")
          || (cfg.deviceClass === "power" && ["W", "kW", "MW"].includes(unit));
        if (!ok) continue;
      }
      const name = a.friendly_name || id;
      const area = this._areaOf(id);
      const hay = `${name} ${id} ${area || ""}`.toLowerCase();
      if (words.length && !words.every((w) => hay.includes(w))) continue;
      if (S.dom && S.dom !== domain && S.dom !== dc) continue;
      const bad = ["unavailable", "unknown"].includes(st.state);
      if (S.avail && bad && !sel) continue;
      let score = 35;
      const why = [];
      if (sel) why.push("jetzt gewählt");
      if (classes.includes(dc) || (field === "persons" && domain === "person")) score += 20;
      if (hints.some((h) => hay.includes(h))) {
        score += 15;
        why.push("Name passt");
      }
      if (roomWords.length && roomWords.some((w) => hay.includes(w))) {
        score += 20;
        why.push(area && roomWords.some((w) => area.toLowerCase().includes(w)) ? "Raum passt" : "passt zum Raum");
      }
      if (area) why.push(area);
      if (unit) why.push(unit);
      else if (dc) why.push(DC_LABEL[dc] || dc);
      if (bad) {
        score -= 25;
        why.push("nicht erreichbar");
      } else score += 5;
      if (sel) score += 10;
      list.push({ id, name, area, domain, dc, bad, sel, why, val: this._fmtState(st), score: Math.max(5, Math.min(99, score)) });
    }
    return list.sort((x, y) => y.sel - x.sel || y.score - x.score || x.name.localeCompare(y.name, "de"));
  }

  /** Inhalt des gewählten Reiters (wird beim Tippen allein neu gezeichnet, damit das Suchfeld den Fokus behält). */
  _pickerList(field) {
    const S = this._pkState(field);
    const cfg = PICKERS[field];
    const all = this._candidates(field, S.q);
    const card = (c) => `
      <div class="pk-card ${c.sel ? "sel" : ""}">
        <b>${esc(c.name)}</b><span class="pk-v">${esc(c.val)}</span>
        <small>${esc(c.id)}</small>
        <span class="pk-why"><em class="${c.score >= 75 ? "hi" : ""}">${c.score} %</em>${esc(c.why.join(" · "))}</span>
        ${c.sel ? `<span class="pk-ok">ist gewählt</span>` : `<button class="pk-pick" data-action="pick-add" data-field="${field}" data-id="${esc(c.id)}">Passt</button>`}
      </div>`;
    const row = (c) => `
      <div class="pk-row ${c.sel ? "sel" : ""} ${c.bad ? "bad" : ""}">
        <span class="grow"><b>${esc(c.name)}</b><small>${esc(c.id)}${c.area && S.tab !== "area" ? ` · ${esc(c.area)}` : ""}</small></span>
        <span class="pk-v">${esc(c.val)}</span>
        ${c.sel ? `<span class="pk-mini on">gewählt</span>` : `<button class="pk-mini" data-action="pick-add" data-field="${field}" data-id="${esc(c.id)}">Wählen</button>`}
      </div>`;
    if (!all.length) return `<div class="pk-empty">Nichts gefunden${S.q ? ` für „${esc(S.q)}“` : ""}${S.dom || S.avail ? " – Filter zurücksetzen?" : ""}.</div>`;
    if (S.tab === "area") {
      const groups = new Map();
      for (const c of all.slice(0, 150)) {
        const k = c.area || "";
        if (!groups.has(k)) groups.set(k, []);
        groups.get(k).push(c);
      }
      const keys = [...groups.keys()].sort((a, b) => (!a ? 1 : !b ? -1 : a.localeCompare(b, "de")));
      return `<div class="pk-scroll">${keys
        .map((k) => `<div class="pk-group">${esc(k || "Ohne Raum")} <span>${groups.get(k).length}</span></div>${groups.get(k).map(row).join("")}`)
        .join("")}</div>`;
    }
    if (S.tab === "filter") {
      const counts = {};
      for (const c of this._candidates(field, "")) if (c.dc) counts[c.dc] = (counts[c.dc] || 0) + 1;
      const opts = [
        ...(cfg.domains.length > 1 ? cfg.domains.map((d) => [d, DOMAIN_LABEL[d] || d]) : []),
        ...Object.entries(counts).sort((a, b) => b[1] - a[1]).slice(0, 8).map(([dc]) => [dc, DC_LABEL[dc] || dc]),
      ];
      return `
        <div class="pk-chips">
          ${opts.map(([v, l]) => `<button class="${S.dom === v ? "on" : ""}" data-action="pk-dom" data-field="${field}" data-v="${esc(v)}">${esc(l)}</button>`).join("")}
          <button class="${S.avail ? "on" : ""}" data-action="pk-avail" data-field="${field}">Nur erreichbare</button>
        </div>
        <div class="pk-scroll">${all.slice(0, 80).map(row).join("")}${all.length > 80 ? `<div class="pk-empty">… ${all.length - 80} weitere – Suche eingrenzen</div>` : ""}</div>`;
    }
    const top = all.slice(0, S.q ? 8 : 3);
    const rest = all.length - top.length;
    return `
      <div class="pk-list">${top.map(card).join("")}</div>
      ${rest > 0 ? `<div class="pk-foot">${rest} weitere passende · <button class="link" data-action="pk-tab" data-field="${field}" data-v="area">Nach Raum suchen</button> · <button class="link" data-action="pk-tab" data-field="${field}" data-v="filter">Filtern</button></div>` : ""}`;
  }

  /** Auswahlfeld an Ort und Stelle neu zeichnen. */
  _rerenderPicker(field) {
    const el = this.shadowRoot.querySelector(`[data-picker="${field}"]`);
    if (el) el.outerHTML = this._picker(field, this._pickerValue(field));
  }

  _pickerTarget(field) {
    const scope = PICKERS[field].scope;
    return scope === "room" ? this._dialog?.room : scope === "pop" ? this._pop?.draft : scope === "plan" ? this._plan : this._settings;
  }

  _pickerValue(field) {
    if (field === "person_add") return this._settings?.persons || [];
    if (field === "plan_calendar") return this._plan?.calendar ? [this._plan.calendar] : [];
    const target = this._pickerTarget(field);
    if (!target) return [];
    const v = target[field];
    return Array.isArray(v) ? v : v ? [v] : [];
  }

  _setPickerValue(field, values) {
    const cfg = PICKERS[field];
    if (field === "person_add") {
      this._settings.persons = values;
      this._refreshSettings();
      return;
    }
    const target = this._pickerTarget(field);
    target[field] = cfg.multi ? values : values[0] || null;
    if (["temp_sensor", "presence_sensor"].includes(field) && this._dialog) {
      this._renderDialog();
      return;
    }
    if (field === "plan_calendar") {
      this._plan.calendar = values[0] || null;
      this._plan.dirty = true;
      this._renderMain();
      return;
    }
    if (["kwa_power", "kwa_door", "kwa_status"].includes(field)) {
      if (field === "kwa_power" && values[0] && !String(this._pop.draft.name || "").trim()) this._pop.draft.name = APP_TYPES[this._pop.draft.type]?.label || "";
      this._renderPop();
      return;
    }
    if (["outside_sensor", "weather_entity", "sun_entity", "vacation_calendar", "import_calendar", "w_weather"].includes(field)) {
      this._refreshSettings();
      return;
    }
    this._rerenderPicker(field);
  }

  // ------------------------------------------------------------ Ereignisse
  _onInput(e, isChange = false) {
    const t = e.target;
    if (t.dataset.nkHours !== undefined && this._settings) {
      const h = { ...(this._settings.notify_hours || {}) };
      const cur = [...(h[t.dataset.nkHours] || ["08:00", "21:00"])];
      if (t.value) cur[Number(t.dataset.i)] = t.value;
      h[t.dataset.nkHours] = cur;
      this._settings.notify_hours = h;
      const bar = this.shadowRoot.getElementById("set-save");
      if (bar) bar.hidden = !this._settingsDirty();
      return;
    }
    if (t.dataset.legendQ !== undefined) {
      // Legende filtern, ohne neu zu zeichnen (Fokus und Tastatur bleiben)
      const q = t.value.toLowerCase().trim();
      if (this._pop?.draft) this._pop.draft.q = t.value;
      const box = t.closest(".sheet-body") || t.parentElement;
      box.querySelectorAll(".lg-list").forEach((list) => {
        let any = false;
        list.querySelectorAll(".lg-r").forEach((r) => { const on = !q || r.textContent.toLowerCase().includes(q); r.hidden = !on; any = any || on; });
        list.hidden = !any;
        if (list.previousElementSibling?.classList.contains("lbl")) list.previousElementSibling.hidden = !any;
      });
      return;
    }
    if (t.dataset.newp !== undefined) {
      this._newPerson = t.value;
      return;
    }
    if (t.dataset.pickerInput) {
      const field = t.dataset.pickerInput;
      this._pkState(field).q = t.value;
      const body = t.closest(".picker")?.querySelector(".pk-body");
      if (body) body.innerHTML = this._pickerList(field);
      return;
    }
    if (t.dataset.room && this._dialog) {
      const key = t.dataset.room;
      let v;
      if (t.type === "checkbox") v = t.checked;
      else if (t.type === "number") v = t.value === "" ? null : Number(t.value);
      else v = t.value;
      if (key === "plan_id" || key === "use") v = v || null;
      if (key === "vent_morning") v = v === "" ? null : v === "1";
      this._dialog.room[key] = v;
      if (["name", "valve_control", "calibration", "window_detect", "fireplace"].includes(key) && isChange) this._renderDialog();
      return;
    }
    if (t.dataset.action === "log-search") {
      this._logQuery = t.value;
      this._logLimit = 200;
      this._renderLogList();
      return;
    }
    if (t.dataset.action === "g-search" && this._pop?.id === "search") {
      this._pop.draft.q = t.value;
      const list = this.shadowRoot.getElementById("gs-list");
      if (list) list.innerHTML = this._gsList(t.value);
      return;
    }
    if (t.dataset.action === "set-search") {
      // nur die Liste neu zeichnen, damit das Suchfeld den Fokus behält
      this._setQuery = t.value;
      const list = this.shadowRoot.getElementById("set-list");
      if (list) list.innerHTML = this._settingsList();
      return;
    }
    if (t.dataset.kwappFlag && this._pop?.id?.startsWith("kwapp:")) {
      this._pop.draft[t.dataset.kwappFlag] = t.checked;
      return;
    }
    if (t.dataset.kwapp && this._pop?.id?.startsWith("kwapp:")) {
      this._pop.draft[t.dataset.kwapp] = t.value;
      if (isChange) this._renderPop();
      else { const b = this.shadowRoot.querySelector('#pop [data-action="kwapp-save"]'); if (b) b.disabled = !(this._pop.draft.kwa_power && t.value.trim()); }
      return;
    }
    if (t.dataset.kwname && this._pop?.id === "kwcons") {
      const p = this._settings;
      p.kw_names = { ...(p.kw_names || {}) };
      if (t.value.trim()) p.kw_names[t.dataset.kwname] = t.value;
      else delete p.kw_names[t.dataset.kwname];
      // nur das Symbol tauschen, damit das Feld den Fokus behält
      const ic = this.shadowRoot.querySelector(`[data-kwicon="${CSS.escape(t.dataset.kwname)}"]`);
      if (ic) ic.setAttribute("icon", this._kwConsIcon(t.dataset.kwname, p));
      return;
    }
    if (t.dataset.cwizname !== undefined && this._pop?.id === "cwiz") {
      this._pop.draft.name = t.value;
      return;
    }
    if (t.dataset.cwiz && this._pop?.id === "cwiz") {
      const c = (this._pop.draft.contacts[t.dataset.cwiz] ||= {});
      c[t.dataset.k] = t.value || null;
      return;
    }
    if (t.dataset.wiz && this._pop?.id === "rwiz") {
      this._pop.draft[t.dataset.wiz] = t.value;
      // Knopf „Weiter“ freigeben, ohne das Feld neu zu zeichnen (Fokus bleibt)
      const next = this.shadowRoot.querySelector('.sheet-foot [data-action="wiz-go"].primary');
      if (next) next.disabled = !this._wizOk(this._pop.draft.step);
      return;
    }
    if (t.dataset.wizAdd && this._pop?.id === "rwiz" && isChange && t.value) {
      const d = this._pop.draft;
      d[t.dataset.wizAdd] = [...new Set([...d[t.dataset.wizAdd], t.value])];
      this._renderPop();
      return;
    }
    if (t.hasAttribute?.("data-rwdel") && this._pop?.draft) {
      this._pop.draft.replace = t.value;
      return;
    }
    if (t.dataset.lwp && this._pop?.draft?.prof) {
      const k = t.dataset.lwp, kind = t.dataset.kind;
      this._pop.draft.prof[k] = kind === "bool" ? t.checked : kind === "num" ? (t.value === "" ? null : Number(t.value)) : t.value || null;
      if ((kind === "bool" || kind === "entity") && isChange) this._renderPop();
      return;
    }
    if (t.dataset.lwroom && this._pop?.draft?.ids) {
      this._pop.draft[t.dataset.lwroom] = t.type === "checkbox" ? t.checked : t.value;
      if (isChange) this._renderPop();
      return;
    }
    if (t.dataset.lwsc && this._pop?.draft?.prof) {
      const [i, k] = t.dataset.lwsc.split(":");
      const sc = (this._pop.draft.prof.scenes = (this._pop.draft.prof.scenes || []).map((x) => ({ ...x })));
      if (!sc[+i]) return;
      sc[+i][k] = ["brightness", "kelvin"].includes(k) ? (t.value === "" ? null : Number(t.value)) : t.value || null;
      if (isChange) this._renderPop();
      return;
    }
    if (t.dataset.lwl && this._pop?.draft?.cfg) {
      this._pop.draft.cfg[t.dataset.lwl] = t.type === "checkbox" ? t.checked : t.value || null;
      return;
    }
    if (t.dataset.lwbri !== undefined && this._pop?.draft) {
      this._pop.draft.v = Number(t.value);
      const v = this.shadowRoot.getElementById("lwbri-v");
      if (v) v.textContent = `${t.value} %`;
      const b = this.shadowRoot.querySelector('#pop [data-action="lw-bri-apply"]');
      if (b) b.lastChild.textContent = `${t.value} % übernehmen`;
      return;
    }
    if (t.dataset.rwp && this._pop?.draft?.prof) {
      const k = t.dataset.rwp, kind = t.dataset.kind;
      this._pop.draft.prof[k] = kind === "bool" ? t.checked : kind === "num" ? (t.value === "" ? null : Number(t.value)) : t.value || null;
      if ((kind === "bool" || kind === "entity") && isChange) this._renderPop();
      return;
    }
    if (t.dataset.rwc && this._pop?.draft?.cfg) {
      const k = t.dataset.rwc;
      this._pop.draft.cfg[k] = t.type === "checkbox" ? t.checked : t.type === "number" ? (t.value === "" ? null : Number(t.value)) : t.value || null;
      if (k === "room" && isChange) this._renderPop();
      if (t.type === "checkbox" && isChange) this._renderPop();
      return;
    }
    if (t.dataset.pop !== undefined && this._pop) {
      this._pop.draft[t.dataset.pop] = t.value;
      return;
    }
    if (t.dataset.plankw !== undefined && this._plan) {
      this._plan.keyword = t.value;
      this._plan.dirty = true;
      if (isChange) this._renderMain();
      return;
    }
    if (t.dataset.planname !== undefined && this._plan) {
      this._plan.name = t.value;
      this._plan.dirty = true;
      if (isChange) this._renderMain();
      return;
    }
    if (isChange && t.dataset.action === "room-plan") {
      const room = clone(this._data.rooms[t.dataset.id]);
      const old = this._data.plans?.[room.plan_id];
      room.plan_id = t.value || null;
      // Wechsel auf „Eigener Plan“ ohne eigene Zeiten: Zeiten des bisherigen Plans übernehmen
      if (!room.plan_id && old && !(room.schedule || []).length) room.schedule = clone(old.schedule || []);
      this._saveRoom(room).then((saved) => {
        if (!saved) return;
        this._selectPlan("room", room.id);
        this._renderMain();
        this._toast(room.plan_id ? `${room.name} nutzt jetzt „${this._data.plans[room.plan_id].name}“` : `${room.name} hat jetzt einen eigenen Plan`);
      });
      return;
    }
    if (t.dataset.plan && this._plan) {
      const i = Number(t.dataset.i);
      const b = this._plan.blocks[i];
      if (t.value) b[t.dataset.plan] = t.value;
      // Uhrzeit: nicht neu zeichnen (sonst schließt der Wähler am Handy und die Seite springt) –
      // außer beim Bestätigen, wenn sich dadurch Überschneidungen ändern
      const before = JSON.stringify(this._planConf || []);
      if (t.value && isChange && JSON.stringify(planConflicts(this._plan.blocks)) !== before) {
        this._plan.dirty = true;
        this._renderMain();
      } else if (t.value) this._planSoftUpdate(i);
      return;
    }
    if (t.dataset.lookColor !== undefined && this._settings) {
      this._settings.look_accent = t.value;
      if (isChange) this._renderPop();
      else this._applyLook(this._settings);
      return;
    }
    if (t.dataset.set && this._settings) {
      const key = t.dataset.set;
      if (t.type === "checkbox") this._settings[key] = t.checked;
      else if (t.type === "number") {
        if (t.value !== "") this._settings[key] = Number(t.value); // leer = alten Wert behalten
      } else this._settings[key] = t.value || null;
      // Andere Wetterquelle oder Zone: Werte im Pop-up sofort aktualisieren
      if (isChange && ["weather_entity", "outside_sensor", "home_zone"].includes(key)) this._refreshSettings();
      const bar = this.shadowRoot.getElementById("set-save");
      if (bar) bar.hidden = !this._settingsDirty();
      return;
    }
    if (isChange && t.dataset.action === "plan-preset" && t.value) {
      this._plan.blocks = clone(PLAN_PRESETS[t.value].blocks);
      this._plan.dirty = true;
      this._renderMain();
      return;
    }
    if (isChange && t.dataset.action === "hmode") {
      const key = t.dataset.key;
      this._ws({ type: "hauswerk/heizen/settings/save", settings: { [key]: t.checked } })
        .then((settings) => {
          this._data.settings = settings;
          if (this._settings) this._settings[key] = t.checked;
          this._renderMain();
        })
        .catch(() => this._renderMain());
      return;
    }
    if (isChange && t.dataset.action === "room-toggle") {
      const room = clone(this._data.rooms[t.dataset.id]);
      room.enabled = t.checked;
      this._saveRoom(room);
    }
  }

  async _onClick(e) {
    try {
      await this._onClickInner(e);
    } catch (err) {
      const a = e.target.closest?.("[data-action]")?.dataset.action || "?";
      this._fail(`Aktion „${a}“`, err);
      if (!err?.hwShown) this._toast(`Das hat nicht geklappt: ${err?.message || err}`);
    }
  }

  async _onClickInner(e) {
    const path = e.composedPath();
    // Tabletmodus: Bildschirmschoner weckt nur auf, nach dem Wischen kein Klick
    if (path.some((n) => n.id === "saver")) {
      e.preventDefault();
      this._saverHide();
      return;
    }
    if (this._swiped && Date.now() - this._swiped < 400) return;
    if (!path.some((n) => n.classList?.contains("picker"))) {
      this.shadowRoot.querySelectorAll(".pick-list").forEach((l) => (l.hidden = true));
    }
    for (const d of this.shadowRoot.querySelectorAll("details.rmenu[open]")) if (!path.includes(d) || e.target.closest?.(".rm-pop [data-action]")) d.open = false;
    const el = e.target.closest?.("[data-action]");
    if (!el) return;
    const a = el.dataset.action;
    if (a === "room-quick" && path.some((n) => n.tagName === "DETAILS" || n.tagName === "SUMMARY" || n.tagName === "INPUT")) return;
    if (["room-toggle", "plan-preset", "adv", "hmode", "room-plan", "set-search", "log-search", "g-search"].includes(a)) {
      if (a === "adv" && this._dialog) setTimeout(() => (this._dialog.advanced = el.open), 0);
      return;
    }
    if (el.tagName === "BUTTON") e.preventDefault();
    // Sprung aus der Hinweis-Liste: Liste schließen, dann Ziel öffnen
    if (el.dataset.hint && this._pop) this._closePop();
    if (el.dataset.gs && this._pop?.id === "search") this._closePop();

    switch (a) {
      case "tab":
        this._setView(el.dataset.tab);
        break;
      case "menu":
        this.dispatchEvent(new CustomEvent("hass-toggle-menu", { bubbles: true, composed: true }));
        break;
      case "setup-hide":
        try {
          localStorage.setItem("hauswerk.einrichtung.aus", "1");
        } catch (err) {
          /* ohne Speicher: bis zum Neuladen */
        }
        this._renderMain();
        this._toast("Ausgeblendet – die Einrichtung findest du unter Hauswerk › Einstellungen");
        break;
      case "setup-open":
        this._setupOpen(0);
        break;
      case "setup-go": {
        const i = Number(el.dataset.i);
        if (!(await this._setupSave())) break;
        this._pop.draft.step = Math.max(0, Math.min(this._setupSteps().length - 1, i));
        this._setupBack = { step: this._pop.draft.step };
        if (this._setupSteps()[this._pop.draft.step].id === "energy") this._kwPrefs();
        this._renderPop();
        this.shadowRoot.querySelector("#pop .sheet-body")?.scrollTo?.(0, 0);
        break;
      }
      case "setup-close":
        await this._setupSave();
        this._setupBack = null;
        this._closePop();
        this._renderMain();
        break;
      case "setup-all-persons":
        this._settings.persons = Object.keys(this._hass.states).filter((e) => e.startsWith("person."));
        this._renderPop();
        break;
      case "setup-weather":
        this._settings.weather_entity = el.dataset.id;
        this._renderPop();
        break;
      case "setup-room":
        if (!(await this._setupSave())) break;
        this._closePopQuiet();
        this._wizOpen();
        if (el.dataset.area) {
          this._wizArea(el.dataset.area);
          this._pop.draft.step = 1;
          this._renderPop();
        }
        break;
      case "setup-covers":
        if (!(await this._setupSave())) break;
        this._closePopQuiet();
        this._cwizOpen();
        break;
      case "setup-kw":
        if (!(await this._setupSave())) break;
        this._closePopQuiet();
        this._openPop("kwdetect");
        break;
      case "search-open":
        this._openPop("search", { q: "" });
        setTimeout(() => this.shadowRoot.querySelector("#pop [data-action=g-search]")?.focus(), 30);
        break;
      case "gs-log":
        this._logQuery = el.dataset.q || "";
        this._logMod = "";
        this._setView("log");
        break;
      case "room-open":
      case "room-page":
        this._roomId = el.dataset.id;
        this._setView("room");
        break;
      case "presence": {
        const m = el.dataset.mode;
        const patch = { vacation: m === "urlaub", presence_force: m === "abwesend" ? "away" : null };
        const settings = await this._ws({ type: "hauswerk/heizen/settings/save", settings: patch });
        this._data.settings = settings;
        break;
      }
      case "step":
        await this._step(el.dataset.kind, el.dataset.key, Number(el.dataset.delta));
        break;
      case "blk-comfort":
        this._plan.blocks[Number(el.dataset.i)].temp = null;
        this._plan.dirty = true;
        this._renderMain();
        break;
      case "room-new":
        this._wizOpen();
        break;
      case "wiz-go": {
        const i = Number(el.dataset.i);
        if (i > this._pop.draft.step && !this._wizOk(this._pop.draft.step)) return;
        this._pop.draft.step = i;
        this._pop.keep = false;
        this._renderPop();
        break;
      }
      case "wiz-area":
        this._wizArea(el.dataset.id);
        this._renderPop();
        break;
      case "wiz-use":
        this._wizUse(el.dataset.id);
        this._pop.draft.step = 2;
        this._pop.keep = false;
        this._renderPop();
        break;
      case "wiz-type":
        this._pop.draft.type = el.dataset.v;
        if (el.dataset.v !== "misch") this._pop.draft.assist = [];
        this._renderPop();
        break;
      case "wiz-tog": {
        const d = this._pop.draft, k = el.dataset.k, id = el.dataset.id;
        d[k] = d[k].includes(id) ? d[k].filter((x) => x !== id) : [...d[k], id];
        if (k === "climates") d.assist = d.assist.filter((x) => d.climates.includes(x));
        this._renderPop();
        break;
      }
      case "wiz-assist": {
        e.stopPropagation?.();
        const d = this._pop.draft, id = el.dataset.id;
        d.assist = d.assist.includes(id) ? d.assist.filter((x) => x !== id) : [...d.assist, id];
        this._renderPop();
        break;
      }
      case "wiz-one":
        this._pop.draft[el.dataset.k] = el.dataset.id || null;
        this._renderPop();
        break;
      case "wiz-t": {
        const d = this._pop.draft;
        d[el.dataset.k] = Math.max(5, Math.min(30, Math.round((d[el.dataset.k] + Number(el.dataset.d)) * 2) / 2));
        this._renderPop();
        break;
      }
      case "wiz-plan":
        this._pop.draft.plan = el.dataset.v;
        this._renderPop();
        break;
      case "wiz-open":
        this._pop.draft.open = !this._pop.draft.open;
        this._renderPop();
        break;
      case "wiz-expert":
        this._closePop();
        this._openRoom(null);
        break;
      case "wiz-save":
        await this._wizSave();
        break;
      case "cwiz-open":
        this._cwizOpen();
        break;
      case "cwiz-go": {
        const i = Number(el.dataset.i);
        const d = this._pop.draft;
        if (i > d.step && !this._cwizOk(d.step)) return;
        if (d.step === 0 && i > 0) {
          // Kontakte im Bereich vorschlagen (nur für neu gewählte Rollläden)
          for (const cid of d.covers) {
            if (d.contacts[cid]) continue;
            const room = this._rwRoomFor(cid, "");
            const inh = this._rwRoomContacts(room);
            if (room && (inh.open.length || inh.tilted.length)) d.contacts[cid] = { inherit: true, room: room.id };
            else { const f = this._cwizContacts(cid); d.contacts[cid] = { open: f.open, tilted: f.tilted, room: room?.id || null }; }
          }
        }
        if (i === 4) d.pick = null;
        d.step = i;
        this._pop.keep = false;
        this._renderPop();
        break;
      }
      case "cwiz-cover": {
        const d = this._pop.draft, id = el.dataset.id;
        d.covers = d.covers.includes(id) ? d.covers.filter((x) => x !== id) : [...d.covers, id];
        this._renderPop();
        break;
      }
      case "cwiz-own": {
        const cid = el.dataset.id;
        const f = this._cwizContacts(cid);
        this._pop.draft.contacts[cid] = { open: f.open, tilted: f.tilted };
        this._renderPop();
        break;
      }
      case "cwiz-inherit":
        this._pop.draft.contacts[el.dataset.id] = { inherit: true };
        this._renderPop();
        break;
      case "cwiz-nodir":
        Object.assign(this._pop.draft.prof, { window_dir: null, azimuth_start: 95, azimuth_end: 265 });
        this._renderPop();
        break;
      case "cwiz-use":
        this._pop.draft.use = el.dataset.v;
        this._renderPop();
        break;
      case "cwiz-mode":
        this._pop.draft.mode = el.dataset.v;
        this._renderPop();
        break;
      case "cwiz-shade":
        this._pop.draft.shade = el.checked;
        this._renderPop();
        break;
      case "cwiz-t":
        this._pop.draft.temp = Math.max(15, Math.min(35, this._pop.draft.temp + Number(el.dataset.d)));
        this._renderPop();
        break;
      case "cwiz-pick":
        this._pop.draft.pick = el.dataset.v;
        this._renderPop();
        break;
      case "cwiz-save":
        await this._cwizSave();
        break;
      case "rwp-step": {
        const pr = this._pop.draft.prof, k = el.dataset.k;
        const v = Number(pr[k] ?? el.dataset.def) + Number(el.dataset.d);
        pr[k] = Math.max(Number(el.dataset.min), Math.min(Number(el.dataset.max), Math.round(v * 2) / 2));
        this._renderPop();
        break;
      }
      case "room-edit":
        if (this._pop) this._closePop();
        this._openRoom(this._data.rooms[el.dataset.id]);
        if (el.dataset.rtab && this._dialog) {
          this._dialog.tab = el.dataset.rtab;
          this._renderDialog();
        }
        break;
      case "expert":
        this._setExpert("heizen", !this._expertOn("heizen"));
        this._renderDialog();
        break;
      case "expert-mod": {
        const mod = el.dataset.mod;
        this._setExpert(mod, !this._expertOn(mod));
        this._setQuery = this._setQuery || "";
        this._renderMain();
        break;
      }
      case "hints-open":
        this._openPop("hints");
        break;
      case "plan-open":
        if (this._plan?.dirty && !confirm("Ungespeicherte Änderungen am Heizplan verwerfen?")) break;
        this._selectPlan("room", el.dataset.id);
        this._plan.dirty = false;
        this._setView("plans");
        break;
      case "plan-sel":
        if (this._plan?.dirty && !confirm("Ungespeicherte Änderungen verwerfen?")) return;
        this._selectPlan(el.dataset.kind, el.dataset.id);
        if (this._tab !== "plans") this._setView("plans");
        else this._renderMain();
        break;
      case "w-edit":
        this._wEdit = !this._wEdit;
        this._renderMain();
        break;
      case "w-add-open":
        this._openPop("widget-add");
        break;
      case "w-pick":
        this._pop.draft = { ...(this._pop.draft || {}), sel: this._pop.draft?.sel === el.dataset.type ? null : el.dataset.type, size: null };
        this._renderPop();
        if (this._pop.draft.sel) this.shadowRoot.querySelector(".wprev")?.scrollIntoView({ block: "nearest", behavior: "smooth" });
        break;
      case "w-pick-size":
        this._pop.draft.size = el.dataset.v;
        this._renderPop();
        break;
      case "w-add": {
        const def = WIDGETS[el.dataset.type];
        const list = clone(this._widgets());
        const w = { id: Math.random().toString(16).slice(2, 10), type: el.dataset.type, size: el.dataset.size || def.size || "m", title: null, entities: [] };
        list.push(w);
        this._wEdit = true;
        await this._saveWidgets(list);
        if (def.config && !def.cal) this._openPop("widget", { i: list.length - 1, title: "", size: w.size, w_entities: [], w_calendars: [] });
        else this._closePop();
        this._toast(`Widget „${def.name}“ hinzugefügt`);
        break;
      }
      case "w-move": {
        const list = clone(this._widgets());
        const i = Number(el.dataset.i), j = i + Number(el.dataset.d);
        if (j < 0 || j >= list.length) break;
        [list[i], list[j]] = [list[j], list[i]];
        await this._saveWidgets(list);
        break;
      }
      case "w-del": {
        const list = clone(this._widgets());
        const w = list[Number(el.dataset.i)];
        if (!confirm(`Widget „${w.title || WIDGETS[w.type]?.name}“ entfernen?`)) break;
        list.splice(Number(el.dataset.i), 1);
        await this._saveWidgets(list);
        break;
      }
      case "w-sugg": {
        const list = clone(this._widgets());
        list[Number(el.dataset.i)].entities = el.dataset.ids.split(",").filter(Boolean);
        await this._saveWidgets(list);
        break;
      }
      case "w-conf": {
        const w = this._widgets()[Number(el.dataset.i)];
        this._openPop("widget", { i: Number(el.dataset.i), title: w.title || "", size: this._wSize(w), w_entities: [...(w.entities || [])], w_calendars: [...(w.entities || [])], w_weather: w.type === "forecast" ? (w.entities || [])[0] || null : null, mode: w.mode || "hourly" });
        break;
      }
      case "w-mode":
        this._pop.draft.mode = el.dataset.v;
        this._renderPop();
        break;
      case "w-size":
        this._pop.draft.size = el.dataset.v;
        this._renderPop();
        break;
      case "w-save": {
        const dr = this._pop.draft;
        const list = clone(this._widgets());
        const isFc = list[dr.i].type === "forecast";
        const isCal = !!WIDGETS[list[dr.i].type]?.cal;
        Object.assign(list[dr.i], { title: dr.title.trim() || null, size: dr.size, entities: isFc ? (dr.w_weather ? [dr.w_weather] : []) : isCal ? dr.w_calendars || [] : dr.w_entities || [] });
        if (isFc) list[dr.i].mode = dr.mode || "hourly";
        await this._saveWidgets(list);
        this._closePop();
        break;
      }
      case "w-sc": {
        const id = el.dataset.e;
        const d = id.split(".")[0];
        const [dom, svc] = { script: ["script", "turn_on"], scene: ["scene", "turn_on"], button: ["button", "press"], input_button: ["input_button", "press"], lock: [ "lock", this._hass.states[id]?.state === "locked" ? "unlock" : "lock"] }[d] || ["homeassistant", "toggle"];
        try {
          await this._hass.callService(dom, svc, { entity_id: id });
          this._toast(`${this._entityName(id)}: ${svc === "toggle" ? "umgeschaltet" : "ausgeführt"}`);
        } catch (err) {
          this._toast(err.message || "Aktion fehlgeschlagen");
        }
        setTimeout(() => this._tab === "start" && this._renderMain(), 700);
        break;
      }
      case "rw-view":
        this._rwv = el.dataset.v;
        try {
          localStorage.setItem("hauswerk.rollansicht", this._rwv);
        } catch (err) {
          /* ohne Speicher: gilt bis zum Neuladen */
        }
        if (this._tFit) delete this._tFit.shutters;
        this._renderMain();
        break;
      case "room-view":
        this._view = el.dataset.v;
        try {
          localStorage.setItem("hauswerk.raumansicht", this._view);
        } catch (err) {
          /* ohne Speicher: gilt bis zum Neuladen */
        }
        this._renderMain();
        break;
      case "plan-src":
        this._plan.cal = el.dataset.v === "cal";
        this._plan.dirty = true;
        this._renderMain();
        break;
      case "plan-new":
        if (this._plan?.dirty && !confirm("Ungespeicherte Änderungen verwerfen?")) return;
        this._plan = { kind: "plan", id: null, name: "Neuer Plan", blocks: clone(PLAN_PRESETS.berufstaetig.blocks), dirty: true, day: this._plan?.day ?? (new Date().getDay() + 6) % 7, cal: false, calendar: null, keyword: "" };
        this._renderMain();
        break;
      case "plan-delete": {
        const using = this._planRooms(this._plan.id);
        if (!confirm(`Plan „${this._plan.name}“ löschen?${using.length ? `\n\n${using.map((r) => r.name).join(", ")} behalten die Zeiten als eigenen Plan.` : ""}`)) break;
        const res = await this._ws({ type: "hauswerk/heizen/plan/delete", plan_id: this._plan.id });
        this._data.rooms = res.rooms;
        this._data.plans = res.plans;
        this._plan = null;
        this._renderMain();
        this._toast("Plan gelöscht");
        break;
      }
      case "plan-own": {
        // Raum bekommt eine eigene Kopie des gemeinsamen Plans
        const room = clone(this._data.rooms[el.dataset.id]);
        room.schedule = clone(this._data.plans[room.plan_id]?.schedule || []);
        room.plan_id = null;
        if (await this._saveRoom(room)) {
          this._selectPlan("room", room.id);
          this._renderMain();
          this._toast(`${room.name} hat jetzt einen eigenen Plan`);
        }
        break;
      }
      case "plan-promote": {
        // Eigenen Plan eines Raums als gemeinsamen Plan speichern und dem Raum zuordnen
        const room = clone(this._data.rooms[this._plan.id]);
        const plan = await this._ws({ type: "hauswerk/heizen/plan/save", plan: { name: `Plan ${room.name}`, schedule: this._plan.blocks.filter((b) => b.days.length) } });
        this._data.plans = { ...(this._data.plans || {}), [plan.id]: plan };
        room.plan_id = plan.id;
        if (await this._saveRoom(room)) {
          this._selectPlan("plan", plan.id);
          this._renderMain();
          this._toast(`Gemeinsamer Plan „${plan.name}“ angelegt`);
        }
        break;
      }
      case "import-open":
        this._openPop("import", { import_calendar: null, keyword: "", result: null });
        break;
      case "import-read": {
        const dr = this._pop.draft;
        try {
          const res = await this._ws({ type: "hauswerk/heizen/calendar/import", entity_id: dr.import_calendar, keyword: dr.keyword || null, days: 7 });
          dr.result = res.blocks || [];
        } catch (err) {
          dr.result = null;
        }
        this._renderPop();
        break;
      }
      case "import-apply": {
        const blocks = this._pop.draft.result || [];
        this._plan.blocks = el.dataset.mode === "replace" ? clone(blocks) : [...this._plan.blocks, ...clone(blocks)];
        this._plan.dirty = true;
        this._closePop();
        this._renderMain();
        this._toast(`${blocks.length} Zeitfenster übernommen – bitte prüfen und speichern`);
        break;
      }
      case "pop-open":
        this._openPop(el.dataset.pop);
        break;
      case "pop-close":
        this._closePop();
        break;
      case "pop-save": {
        const p = this._settings;
        if (p.vacation_from && p.vacation_to && p.vacation_from > p.vacation_to) {
          this._toast("Der Urlaub endet vor seinem Beginn.");
          return;
        }
        // Nur Geändertes schicken: alte, inzwischen ungültige Werte blockieren so nicht das Speichern
        const old = this._data.settings;
        const diff = Object.fromEntries(Object.entries(p).filter(([k, v]) => JSON.stringify(v ?? null) !== JSON.stringify(old[k] ?? null)));
        if (Object.keys(diff).length) this._data.settings = await this._ws({ type: "hauswerk/heizen/settings/save", settings: diff });
        this._closePop();
        this._renderMain();
        this._toast("Gespeichert");
        break;
      }
      case "dialog-close":
        this._dialog = null;
        this._renderDialog();
        break;
      case "room-type":
        this._dialog.room.type = el.dataset.type;
        if (el.dataset.type === "flaeche") this._dialog.room.compensation = null;
        this._renderDialog();
        break;
      case "pause-mode":
        this._dialog.room.pause_mode = el.dataset.v || null;
        this._renderDialog();
        break;
      case "room-auto": {
        const room = clone(this._data.rooms[el.dataset.id]);
        room.enabled = room.enabled === false;
        if (await this._saveRoom(room)) this._toast(`${room.name}: Automatik ${room.enabled ? "an" : "aus"}`);
        break;
      }
      case "dialog-tab":
        this._dialog.tab = el.dataset.tab;
        this._dialog.keepScroll = false;
        this._renderDialog();
        break;
      case "room-icon":
        this._dialog.room.icon = el.dataset.v || null;
        this._renderDialog();
        break;
      case "sched-src":
        this._dialog.schedSrc = el.dataset.v;
        if (el.dataset.v !== "entity") this._dialog.room.schedule_entity = null;
        if (el.dataset.v !== "plan") this._dialog.room.plan_id = null;
        else if (!this._data.plans?.[this._dialog.room.plan_id]) this._dialog.room.plan_id = this._planList()[0]?.id || null;
        this._renderDialog();
        break;
      case "preheat-mode":
        this._dialog.room.preheat_mode = el.dataset.v || null;
        this._renderDialog();
        break;
      case "preheat-reset":
        if (!confirm("Gelernte Aufheizgeschwindigkeit vergessen und neu lernen?")) break;
        await this._ws({ type: "hauswerk/heizen/preheat/reset", room_id: el.dataset.id });
        if (this._status?.rooms?.[el.dataset.id]) this._status.rooms[el.dataset.id].learned = false;
        this._renderDialog();
        if (this._pop) this._renderPop();
        this._toast("Wird beim nächsten Aufheizen neu gelernt");
        break;
      case "role-set": {
        const room = this._dialog.room;
        const id = el.dataset.id;
        const assist = new Set(room.assist_entities || []);
        // „Alle selbst stellen“ von früher in einzelne Rollen umrechnen
        const own = new Set(room.pair_mode === "off"
          ? (room.climates || []).filter((c) => this._thermoKind(c) !== "wall" && !assist.has(c)) : room.pair_exclude || []);
        room.pair_mode = null;
        assist.delete(id);
        own.delete(id);
        if (el.dataset.v === "assist") assist.add(id);
        if (el.dataset.v === "own") own.add(id);
        room.assist_entities = [...assist];
        room.pair_exclude = [...own];
        this._renderDialog();
        break;
      }
      case "presence-mode":
        this._dialog.room.presence_mode = el.dataset.v;
        this._renderDialog();
        break;
      case "room-save":
        await this._saveDialog();
        break;
      case "room-delete":
        if (confirm(`Raum „${this._dialog.room.name}“ löschen? Heizplan und Bericht des Raums gehen verloren.`)) {
          const id = this._dialog.room.id;
          await this._ws({ type: "hauswerk/heizen/room/delete", room_id: id });
          delete this._data.rooms[id];
          this._dialog = null;
          this._renderDialog();
          this._renderMain();
        }
        break;
      case "pk-open": {
        const S = this._pkState(el.dataset.field);
        S.open = !S.open;
        this._rerenderPicker(el.dataset.field);
        if (S.open) this.shadowRoot.querySelector(`[data-picker-input="${el.dataset.field}"]`)?.focus();
        break;
      }
      case "pk-tab":
        this._pkState(el.dataset.field).tab = el.dataset.v;
        this._rerenderPicker(el.dataset.field);
        break;
      case "pk-dom": {
        const S = this._pkState(el.dataset.field);
        S.dom = S.dom === el.dataset.v ? "" : el.dataset.v;
        this._rerenderPicker(el.dataset.field);
        break;
      }
      case "pk-avail":
        this._pkState(el.dataset.field).avail = !this._pkState(el.dataset.field).avail;
        this._rerenderPicker(el.dataset.field);
        break;
      case "pick-add": {
        const field = el.dataset.field;
        // Nach der Wahl: Auswahl zuklappen (auch bei mehreren – „Weitere hinzufügen“ öffnet sie wieder), Suche zurücksetzen
        const S = this._pkState(field);
        S.q = "";
        S.open = false;
        const values = PICKERS[field].multi ? [...this._pickerValue(field), el.dataset.id] : [el.dataset.id];
        this._setPickerValue(field, values);
        break;
      }
      case "pick-remove": {
        const field = el.dataset.field;
        this._setPickerValue(field, this._pickerValue(field).filter((id) => id !== el.dataset.id));
        break;
      }
      case "ovr-reset":
        await this._ws({ type: "hauswerk/heizen/override", room_id: el.dataset.id, temp: null });
        if (this._pop?.id === "rq") this._closePop();
        break;
      case "room-quick": {
        const s = this._status?.rooms?.[el.dataset.id] || {};
        const room = this._data.rooms[el.dataset.id];
        if (!room) break;
        this._openPop("rq", { id: room.id, temp: s.target ?? room.comfort ?? 21, hours: null });
        break;
      }
      case "rq-dur":
        this._pop.draft.hours = el.dataset.h === "" ? null : Number(el.dataset.h);
        this._renderPop();
        break;
      case "rq-temp":
        this._pop.draft.temp = Number(el.dataset.t);
        this._renderPop();
        break;
      case "rq-apply": {
        const d = this._pop.draft;
        const name = this._data.rooms[d.id]?.name || "";
        await this._ws({ type: "hauswerk/heizen/override", room_id: d.id, temp: d.temp, hours: d.hours });
        this._closePop();
        this._toast(`${name}: ${fmt(d.temp)} °C ${d.hours ? `für ${d.hours} h` : "bis zum nächsten Planwechsel"}`);
        break;
      }
      case "nk-tab":
        this._nkTab = el.dataset.v;
        this._nkAdd = false;
        this._nkOpen = null;
        this._renderPop();
        break;
      case "nk-open":
        this._nkOpen = this._nkOpen === el.dataset.k ? null : el.dataset.k;
        this._renderPop();
        break;
      case "nk-view":
        this._nkView = el.dataset.v;
        this._renderPop();
        break;
      case "nk-onoff": {
        const k = `notify_${el.dataset.k}`;
        const def = NK_KINDS.find((x) => x.k === el.dataset.k)?.def;
        this._nkLast = this._nkLast || {};
        if (this._settings[k] !== "off") { this._nkLast[k] = this._settings[k]; this._settings[k] = "off"; }
        else this._settings[k] = this._nkLast[k] || (def === "off" ? "normal" : def);
        this._refreshSettings();
        break;
      }
      case "nk-cell":
        this._nkToggle(el.dataset.k, el.dataset.ch);
        this._refreshSettings();
        break;
      case "nk-tpl":
        this._nkTemplate(el.dataset.t);
        break;
      case "nk-hours": {
        const h = { ...(this._settings.notify_hours || {}) };
        if (el.dataset.v) h[el.dataset.ch] = el.dataset.v.split("-"); else delete h[el.dataset.ch];
        this._settings.notify_hours = h;
        this._refreshSettings();
        break;
      }
      case "nk-bundle": {
        const b = new Set(this._settings.notify_bundle || []);
        if (b.has(el.dataset.ch)) b.delete(el.dataset.ch); else b.add(el.dataset.ch);
        this._settings.notify_bundle = [...b];
        this._refreshSettings();
        break;
      }
      case "nk-off": {
        const set = new Set(this._settings.notify_off || []);
        if (set.has(el.dataset.ch)) set.delete(el.dataset.ch); else set.add(el.dataset.ch);
        this._settings.notify_off = [...set];
        this._refreshSettings();
        break;
      }
      case "nk-add-open":
      case "nk-add-toggle": {
        this._nkAdd = a === "nk-add-open" ? true : !this._nkAdd;
        this._renderPop();
        if (this._nkAdd) requestAnimationFrame(() => this.shadowRoot.querySelector("#pop #nk-add")?.scrollIntoView({ behavior: "smooth", block: "start" }));
        break;
      }
      case "nk-remove": {
        const ch = el.dataset.ch;
        const p = this._settings;
        p.notify_off = (p.notify_off || []).filter((c) => c !== ch);
        p.notify_channels = (p.notify_channels || []).filter((c) => c !== ch);
        const routes = {};
        for (const [k, l] of Object.entries(p.notify_routes || {})) { const r = l.filter((c) => c !== ch); if (r.length) routes[k] = r; }
        p.notify_routes = routes;
        const h = { ...(p.notify_hours || {}) }; delete h[ch]; p.notify_hours = h;
        p.notify_bundle = (p.notify_bundle || []).filter((c) => c !== ch);
        this._refreshSettings();
        break;
      }
      case "nk-try": {
        const x = NK_KINDS.find((k) => k.k === el.dataset.k);
        let channels = this._nkChannels(x.k);
        if (el.dataset.voice) channels = channels.filter((c) => c.startsWith("tts:") || c.startsWith("sat:"));
        try {
          const res = await this._ws({ type: "hauswerk/notify/test", channels, title: x.ex[0], message: x.ex[1] });
          const bad = (res?.results || []).filter((r) => !r.ok);
          this._toast(bad.length ? `Nicht zugestellt: ${bad.map((r) => `${this._chName(r.channel)} (${r.error})`).join(", ")}` : el.dataset.voice ? "Ansage abgespielt" : `„${x.ex[0]}“ gesendet`);
        } catch (err) {
          this._toast(`Das hat nicht geklappt: ${err?.message || err}`);
        }
        break;
      }
      case "ch-test1": {
        const channels = el.dataset.ch.split(",");
        try {
          const res = await this._ws({ type: "hauswerk/notify/test", channels });
          const bad = (res?.results || []).filter((r) => !r.ok);
          this._toast(bad.length ? `Nicht zugestellt: ${bad.map((r) => `${this._chName(r.channel)} (${r.error})`).join(", ")}` : "Testnachricht gesendet");
        } catch (err) {
          this._toast(`Das hat nicht geklappt: ${err?.message || err}`);
        }
        break;
      }
      case "kw-dev-open":
        this._closePop();
        this._setView("kwdev");
        break;
      case "legend-open":
        this._openPop("legend", { first: el.dataset.first || "", q: "" });
        break;
      case "rq-fire": {
        const on = el.dataset.on === "1";
        await this._ws({ type: "hauswerk/heizen/fireplace", room_id: el.dataset.id, on });
        this._closePop();
        this._toast(on ? "Kamin an – zählt nicht für die Heizleistung (längstens 8 Std.)" : "Kamin aus");
        break;
      }
      case "rq-boost":
        await this._ws({ type: "hauswerk/heizen/override", room_id: el.dataset.id, boost: true });
        this._closePop();
        this._toast(`Boost für ${this._data.settings.boost_minutes || 30} Minuten`);
        break;
      case "boost":
        await this._ws({ type: "hauswerk/heizen/override", room_id: el.dataset.id, boost: true });
        this._toast(`Boost für ${this._data.settings.boost_minutes || 30} Minuten`);
        break;
      case "plan-preview":
        this._plan.day = Number(el.dataset.day);
        this._renderMain();
        break;
      case "plan-day": {
        const b = this._plan.blocks[Number(el.dataset.i)];
        const day = Number(el.dataset.day);
        b.days = b.days.includes(day) ? b.days.filter((x) => x !== day) : [...b.days, day].sort();
        this._plan.dirty = true;
        this._renderMain();
        break;
      }
      case "plan-days":
        this._plan.blocks[Number(el.dataset.i)].days = el.dataset.set.split(",").map(Number);
        this._plan.dirty = true;
        this._renderMain();
        break;
      case "plan-copy": {
        const i = Number(el.dataset.i);
        this._plan.blocks.splice(i + 1, 0, clone(this._plan.blocks[i]));
        this._plan.dirty = true;
        this._renderMain();
        break;
      }
      case "plan-add": {
        // freies Zeitfenster vorschlagen, damit nichts überschneidet
        const tries = [["06:00", "08:00"], ["17:00", "21:00"], ["12:00", "14:00"], ["08:00", "10:00"], ["21:00", "23:00"], ["14:00", "17:00"], ["10:00", "12:00"], ["22:00", "24:00"], ["04:00", "06:00"], ["00:00", "02:00"]];
        let nb = null;
        for (const days of [[0, 1, 2, 3, 4], [5, 6], [0, 1, 2, 3, 4, 5, 6]]) {
          for (const [a, e] of tries) {
            const cand = { days, start: a, end: e, temp: null };
            if (!planConflicts([...this._plan.blocks, cand]).length) { nb = cand; break; }
          }
          if (nb) break;
        }
        this._plan.blocks.push(nb || { days: [0, 1, 2, 3, 4], start: "06:00", end: "08:00", temp: null });
        this._plan.dirty = true;
        this._renderMain();
        break;
      }
      case "blk-kind": {
        const b = this._plan.blocks[Number(el.dataset.i)];
        if (el.dataset.v === "eco") { b.kind = "eco"; b.temp = null; } else delete b.kind;
        this._plan.dirty = true;
        this._renderMain();
        break;
      }
      case "plan-resolve": {
        const win = Number(el.dataset.win);
        const before = this._plan.blocks.length;
        this._plan.blocks = planResolve(this._plan.blocks, win);
        this._plan.dirty = true;
        this._renderMain();
        this._toast(`Zeitfenster ${win + 1} hat Vorrang – ${this._plan.blocks.length > before ? "andere Zeitfenster geteilt bzw. gekürzt" : "andere Zeitfenster gekürzt"}`);
        break;
      }
      case "plan-del":
        this._plan.blocks.splice(Number(el.dataset.i), 1);
        this._plan.dirty = true;
        this._renderMain();
        break;
      case "plan-revert":
        if (this._plan.id) this._selectPlan(this._plan.kind, this._plan.id);
        else this._plan = null;
        this._renderMain();
        break;
      case "plan-save": {
        const P = this._plan;
        const blocks = P.blocks.filter((b) => b.days.length);
        const pc = planConflicts(blocks);
        if (pc.length) {
          this._toast(`Nicht gespeichert: ${pc[0].text}`);
          return;
        }
        if (P.kind === "plan") {
          if (!P.name.trim()) {
            this._toast("Bitte einen Namen für den Plan eingeben.");
            return;
          }
          if (P.cal && !P.calendar) {
            this._toast("Bitte einen Kalender wählen.");
            return;
          }
          const saved = await this._ws({ type: "hauswerk/heizen/plan/save", plan: { id: P.id, name: P.name, schedule: blocks, calendar: P.cal ? P.calendar : null, keyword: P.cal ? P.keyword || null : null } });
          this._data.plans = { ...(this._data.plans || {}), [saved.id]: saved };
          this._selectPlan("plan", saved.id);
          this._renderMain();
          this._toast(P.id ? "Plan gespeichert" : "Plan angelegt – jetzt im Raum auswählen");
        } else {
          const room = { ...clone(this._data.rooms[P.id]), schedule: blocks };
          if (await this._saveRoom(room)) {
            this._selectPlan("room", room.id);
            this._renderMain();
            this._toast("Heizplan gespeichert");
          }
        }
        break;
      }
      case "lwlinks-refresh": {
        const res = await this._ws({ type: "hauswerk/lichtwerk/links/refresh" });
        if (res && this._lwStatus) this._lwStatus.links = res;
        this._renderPop();
        this._toast("Verknüpfungen aus der CCU gelesen");
        break;
      }
      case "hmlinks-refresh": {
        const res = await this._ws({ type: "hauswerk/heizen/links/refresh" });
        if (res && this._status) this._status.hm_links = res;
        this._renderPop();
        this._toast("Verknüpfungen aus der CCU gelesen");
        break;
      }
      case "settings-go":
        // zentrale Pop-ups unter Hauswerk-Einstellungen, alle anderen unter Heizwerk › Einstellungen
        this._setView(HOUSE_POPS.includes(el.dataset.sub) ? "house" : LW_POPS.includes(el.dataset.sub) ? "lightset" : RW_POPS.includes(el.dataset.sub) || el.dataset.sub?.startsWith("rwc:") || el.dataset.sub?.startsWith("rwp:") ? "shutset" : "settings");
        if (el.dataset.sub) this._openPop(el.dataset.sub);
        break;
      case "person-new":
        this._newPerson = this._newPerson == null ? "" : null;
        this._renderPop();
        if (this._newPerson != null) this.shadowRoot.querySelector("[data-newp]")?.focus();
        break;
      case "person-create": {
        const name = (this._newPerson || "").trim();
        if (!name) {
          this._toast("Bitte einen Namen eingeben");
          break;
        }
        try {
          await this._hass.callWS({ type: "person/create", name });
        } catch (err) {
          this._toast(`Person nicht angelegt: ${err.message || err}`);
          break;
        }
        // Die neue Entität (person.…) erscheint kurz danach in Home Assistant
        let id = null;
        for (let i = 0; i < 20 && !id; i++) {
          id = Object.keys(this._hass.states).find((e) => e.startsWith("person.") && this._hass.states[e].attributes.friendly_name === name);
          if (!id) await new Promise((res) => setTimeout(res, 150));
        }
        if (id) this._settings.persons = [...new Set([...(this._settings.persons || []), id])];
        this._newPerson = null;
        this._refreshSettings();
        this._toast(id ? `${name} angelegt und ausgewählt` : `${name} angelegt – erscheint gleich in der Liste`);
        break;
      }
      case "notify-toggle": {
        const list = new Set(this._settings.notify_targets || []);
        if (list.has(el.dataset.id)) list.delete(el.dataset.id);
        else list.add(el.dataset.id);
        this._settings.notify_targets = [...list];
        this._refreshSettings();
        break;
      }
      case "notify-test":
        await this._ws({ type: "hauswerk/notify/test" });
        this._toast("Testnachricht gesendet");
        break;
      case "ch-toggle": {
        const cur = [...this._chList(el.dataset.list)];
        const i = cur.indexOf(el.dataset.ch);
        if (i >= 0) cur.splice(i, 1); else cur.push(el.dataset.ch);
        this._chSet(el.dataset.list, cur);
        break;
      }
      case "ch-tts-add": {
        const box = el.closest(".ch-tts");
        const id = `tts:${box.querySelector("[data-tts-engine]").value}|${box.querySelector("[data-tts-player]").value}`;
        const cur = [...this._chList(el.dataset.list)];
        if (!cur.includes(id)) cur.push(id);
        this._chSet(el.dataset.list, cur);
        break;
      }
      case "ch-route": {
        const k = el.dataset.kind;
        if (el.dataset.on === "1") this._chSet(`route:${k}`, [...(this._settings.notify_channels || [])]);
        else this._chSet(`route:${k}`, []);
        break;
      }
      case "ch-test": {
        const channels = [...this._chList(el.dataset.list)];
        try {
          const res = await this._ws({ type: "hauswerk/notify/test", channels });
          const bad = (res?.results || []).filter((r) => !r.ok);
          this._toast(bad.length ? `Nicht zugestellt: ${bad.map((r) => `${this._chName(r.channel)} (${r.error})`).join(", ")}` : `Testnachricht an ${channels.map((c) => this._chName(c)).join(", ")} gesendet`);
        } catch (err) {
          this._toast(`Das hat nicht geklappt: ${err?.message || err}`);
        }
        break;
      }
      case "person-toggle": {
        const list = new Set(this._settings.persons || []);
        if (list.has(el.dataset.id)) list.delete(el.dataset.id);
        else list.add(el.dataset.id);
        this._settings.persons = [...list];
        this._refreshSettings();
        break;
      }
      case "min-step": {
        const k = el.dataset.key;
        this._settings[k] = Math.min(240, Math.max(0, Number(this._settings[k] ?? 0) + Number(el.dataset.d)));
        this._refreshSettings();
        break;
      }
      case "help":
        this._help = { ...(this._help || {}), [el.dataset.k]: !this._help?.[el.dataset.k] };
        this._renderPop();
        break;
      case "log-mod":
        this._logMod = el.dataset.id || "";
        this._logLimit = 200;
        this._renderMain();
        break;
      case "err-copy": {
        const text = this._failText();
        try {
          await navigator.clipboard.writeText(text);
          this._toast("Diagnose kopiert");
        } catch (err) {
          // Zwischenablage gesperrt (z. B. in der App): Text zum Markieren zeigen
          this._openPop("errtext", { text });
        }
        break;
      }
      case "err-reload":
        location.reload();
        break;
      case "kw-log":
        this._logMod = "kraftwerk";
        this._logRoom = "";
        this._setView("log");
        break;
      case "kw-range":
        this._kwRange = el.dataset.v;
        this._renderMain();
        break;
      case "kw-energy":
        history.pushState(null, "", "/config/energy");
        window.dispatchEvent(new CustomEvent("location-changed", { detail: { replace: false } }));
        break;
      case "kw-take": {
        const sug = this._kwSuggest();
        const keys = el.dataset.k === "all" ? ["kw_solar", "kw_grid", "kw_battery", "kw_battery_soc", "kw_home"] : [el.dataset.k];
        for (const k of keys) {
          const v = sug[k];
          if (Array.isArray(v) ? v.length : v) this._settings[k] = Array.isArray(v) ? [...v] : v;
        }
        this._renderPop();
        break;
      }
      case "lw-cmd": {
        const ids = el.dataset.ids.split(",").filter(Boolean);
        await this._ws({ type: "hauswerk/lichtwerk/command", entity_ids: ids, action: el.dataset.a });
        if (this._pop?.id?.startsWith("lwbri:")) this._closePop();
        break;
      }
      case "lw-auto": {
        const on = el.dataset.on === "1";
        const res = await this._ws({ type: "hauswerk/lichtwerk/light/save", entity_id: el.dataset.id, light: { auto: on } });
        this._data.lichtwerk.lights = res.lights;
        if (this._pop?.id?.startsWith("lwbri:")) this._renderPop();
        this._renderMain();
        this._toast(on ? "Profil aktiv – Lichtwerk schaltet wieder" : "Profil an dieser Leuchte aus");
        break;
      }
      case "lw-pre": {
        const v = el.dataset.v;
        await this._ws(v === "off" ? { type: "hauswerk/lichtwerk/command", entity_ids: [el.dataset.ids], action: "off" }
          : { type: "hauswerk/lichtwerk/command", entity_ids: [el.dataset.ids], action: "on", brightness: Math.max(1, Math.min(100, Number(v))) });
        this._closePop();
        break;
      }
      case "lw-bri-apply":
        await this._ws({ type: "hauswerk/lichtwerk/command", entity_ids: [el.dataset.ids], action: "on", brightness: Number(this._pop.draft.v) });
        this._closePop();
        break;
      case "lwsc-add": {
        const pr = this._pop.draft.prof;
        const sc = (pr.scenes || []).slice();
        const last = sc.length ? hm(sc[sc.length - 1].from || "00:00") : 300;
        sc.push({ from: t2(Math.min(1425, last + 180)), name: "", brightness: pr.brightness ?? 80, kelvin: null });
        pr.scenes = sc;
        pr.scenes_on = true;
        this._renderPop();
        break;
      }
      case "lwsc-del":
        this._pop.draft.prof.scenes = (this._pop.draft.prof.scenes || []).filter((_, i) => i !== +el.dataset.i);
        this._renderPop();
        break;
      case "lwsc-preset":
        Object.assign(this._pop.draft.prof, { scenes: LW_SCENES.map((x) => ({ ...x })), scenes_on: true });
        this._renderPop();
        break;
      case "lw-room-save": {
        const d = this._pop.draft;
        let res = null;
        for (const id of d.ids) res = await this._ws({ type: "hauswerk/lichtwerk/light/save", entity_id: id, light: { profile: d.profile, auto: d.auto } });
        if (res?.lights) this._data.lichtwerk.lights = res.lights;
        if (res?.settings) this._data.settings = res.settings;
        this._closePop();
        this._renderMain();
        this._toast("Gespeichert");
        break;
      }
      case "lw-view":
        try { localStorage.setItem("hauswerk_lw_view", el.dataset.v); } catch (err) { /* ohne Speicher */ }
        this._renderMain();
        break;
      case "lw-log":
        this._logMod = "lichtwerk";
        this._logRoom = "";
        this._setView("log");
        break;
      case "lw-auto-off": {
        const res = await this._ws({ type: "hauswerk/lichtwerk/automation/off", entity_id: el.dataset.id });
        this._data.lichtwerk.automations = res.automations;
        this._renderPop();
        this._toast("Automation abgeschaltet");
        break;
      }
      case "lwl-save": {
        const cfg = this._pop.draft.cfg;
        const res = await this._ws({ type: "hauswerk/lichtwerk/light/save", entity_id: el.dataset.id, light: { profile: cfg.profile || "standard", auto: cfg.auto !== false, name: cfg.name || null, watt: cfg.watt === "" || cfg.watt == null ? null : Number(cfg.watt) } });
        this._data.lichtwerk.lights = res.lights;
        this._data.settings = res.settings;
        this._closePop();
        this._renderMain();
        this._toast("Gespeichert");
        break;
      }
      case "lwl-remove": {
        const res = await this._ws({ type: "hauswerk/lichtwerk/light/remove", entity_id: el.dataset.id });
        this._data.lichtwerk.lights = res.lights;
        this._data.settings = res.settings;
        this._closePop();
        this._renderMain();
        this._toast("Aus Lichtwerk entfernt");
        break;
      }
      case "lwadd-tog": {
        const d = this._pop.draft;
        d.pick = d.pick.includes(el.dataset.id) ? d.pick.filter((x) => x !== el.dataset.id) : [...d.pick, el.dataset.id];
        this._renderPop();
        break;
      }
      case "lwadd-prof":
        this._pop.draft.prof = el.dataset.v;
        this._renderPop();
        break;
      case "lwadd-save": {
        const d = this._pop.draft;
        let pid = d.prof || "standard";
        if (pid.startsWith("new:")) {
          const pre = LW_PRESETS[pid.slice(4)];
          const base = this._data.lichtwerk.profiles?.standard || {};
          const res = await this._ws({ type: "hauswerk/lichtwerk/profile/save", profile_id: null, profile: { ...base, ...pre.prof, name: pre.name, motion: pre.prof.motion ?? [] } });
          this._data.lichtwerk.profiles = res.profiles;
          pid = res.profile_id;
        }
        let res = null;
        for (const eid of d.pick) res = await this._ws({ type: "hauswerk/lichtwerk/light/save", entity_id: eid, light: { profile: pid, auto: true } });
        if (res) { this._data.lichtwerk.lights = res.lights; this._data.settings = res.settings; }
        this._closePop();
        this._setView("lights");
        this._toast(`${d.pick.length} ${d.pick.length === 1 ? "Licht" : "Lichter"} hinzugefügt – Profil „${this._lwProfName(pid)}“`);
        break;
      }
      case "lwp-sec": {
        const [, pid] = this._pop.id.split(":");
        this._pop.id = `lwp:${pid}:${el.dataset.sec}`;
        this._pop.keep = false;
        this._renderPop();
        break;
      }
      case "lwp-set":
        this._pop.draft.prof[el.dataset.k] = el.dataset.v;
        this._renderPop();
        break;
      case "lwp-tog": {
        const p = this._pop.draft.prof, k = el.dataset.k;
        const v = k === "days" ? Number(el.dataset.v) : el.dataset.v;
        const cur = [...(p[k] ?? (k === "days" ? [0, 1, 2, 3, 4, 5, 6] : []))];
        p[k] = cur.includes(v) ? cur.filter((x) => x !== v) : [...cur, v].sort((a, b) => (typeof a === "number" ? a - b : 0));
        this._renderPop();
        break;
      }
      case "lwp-preset": {
        const pre = LW_PRESETS[el.dataset.v];
        Object.assign(this._pop.draft.prof, pre.prof, { name: pre.name });
        this._renderPop();
        break;
      }
      case "lwp-save": {
        const d = this._pop.draft;
        d.prof.name = String(d.prof.name || "").trim();
        if (!d.prof.name) { this._toast("Bitte einen Namen eingeben."); return; }
        if (this._lwProfiles().some((x) => x.id !== d.pid && x.name.toLowerCase() === d.prof.name.toLowerCase())) { this._toast(`Ein Profil „${d.prof.name}“ gibt es schon.`); return; }
        const res = await this._ws({ type: "hauswerk/lichtwerk/profile/save", profile_id: d.pid, profile: d.prof });
        this._data.lichtwerk.profiles = res.profiles;
        this._closePop();
        this._renderMain();
        this._toast(d.pid ? "Gespeichert" : "Profil angelegt");
        break;
      }
      case "lwp-del": {
        const d = this._pop.draft;
        if (!d.confirm) { d.confirm = true; this._pop.keep = false; this._renderPop(); return; }
        const res = await this._ws({ type: "hauswerk/lichtwerk/profile/delete", profile_id: d.pid, replace_with: this._lwProfiles().find((x) => x.id !== d.pid)?.id || null });
        this._data.lichtwerk.profiles = res.profiles;
        this._data.lichtwerk.lights = res.lights;
        this._closePop();
        this._renderMain();
        this._toast("Profil gelöscht");
        break;
      }
      case "lwp-del-no":
        this._pop.draft.confirm = false;
        this._renderPop();
        break;
      case "rw-log":
        this._logMod = "rollwerk";
        this._logRoom = "";
        this._setView("log");
        break;
      case "log-room":
        this._logRoom = el.dataset.id || "";
        this._logLimit = 200;
        this._renderMain();
        break;
      case "log-cat": {
        const cats = this._logCats();
        if (cats.has(el.dataset.k)) cats.delete(el.dataset.k);
        else cats.add(el.dataset.k);
        try {
          localStorage.setItem("hauswerk.protokoll.kategorien", JSON.stringify([...cats]));
        } catch (err) {
          /* ohne Speicher: gilt bis zum Neuladen */
        }
        this._logLimit = 200;
        this._renderMain();
        break;
      }
      case "log-more":
        this._logLimit = (this._logLimit || 200) + 300;
        this._renderLogList();
        break;
      case "look-accent":
        this._settings.look_accent = el.dataset.v || null;
        this._renderPop();
        break;
      case "look-size":
        try {
          localStorage.setItem("hauswerk.groesse", el.dataset.v);
        } catch (err) {
          /* ohne Speicher: gilt bis zum Neuladen */
        }
        this.setAttribute("size", el.dataset.v);
        this._renderPop();
        break;
      case "start-edit":
        this._wEdit = true;
        this._setView("start");
        break;
      case "tpage":
        this._tabletGo(Number(el.dataset.i));
        break;
      case "tablet-toggle":
        this._tablet = !this._tablet;
        this._tabletSet(null, this._tablet ? "1" : "0");
        this._tabletApply();
        this._renderPop();
        this._renderMain();
        break;
      case "tstart": {
        const own = el.dataset.v === "own";
        const cur = this._widgets();
        this._data.settings = await this._ws({ type: "hauswerk/heizen/settings/save", settings: { start_widgets_tablet: own ? cur.map((w) => ({ ...w })) : null } });
        this._tFit = {};
        this._renderMain();
        break;
      }
      case "tablet-opt":
        this._tabletSet(el.dataset.k, el.dataset.v);
        if (el.dataset.k === "sidebar") this._tabletSidebar(el.dataset.v === "1");
        if (el.dataset.k === "theme") this._applyLook(this._pop?.id === "look" ? this._settings : null);
        this._lastAct = Date.now();
        this._renderPop();
        break;
      case "saver-test":
        this._closePopQuiet();
        this._saverShow();
        break;
      case "rw-cmd":
        if (this._pop?.id?.startsWith("rwpos:")) this._pop.draft = {};
        await this._ws({ type: "hauswerk/rollwerk/command", entity_ids: el.dataset.ids.split(",").filter(Boolean), action: el.dataset.a });
        break;
      case "rwpos-go":
        await this._rwPosGo(el.dataset.id, Number(el.dataset.v));
        break;
      case "rwc-set":
        this._pop.draft.cfg[el.dataset.k] = el.dataset.v || null;
        this._renderPop();
        break;
      case "rwp-tog": {
        const pr = this._pop.draft.prof, k = el.dataset.k, v = el.dataset.v;
        const list = new Set(pr[k] || []);
        if (list.has(v)) list.delete(v); else list.add(v);
        pr[k] = [...list];
        this._renderPop();
        break;
      }
      case "rwp-set":
        this._pop.draft.prof[el.dataset.k] = el.dataset.v;
        this._renderPop();
        break;
      case "rwp-feat": {
        const pr = this._pop.draft.prof;
        const f = new Set(pr.features || []);
        if (el.type === "checkbox" ? !el.checked : f.has(el.dataset.v) && el.tagName !== "BUTTON") f.delete(el.dataset.v);
        else f.add(el.dataset.v);
        pr.features = [...f];
        this._renderPop();
        break;
      }
      case "rwp-mode": {
        const pr = this._pop.draft.prof;
        const f = new Set(pr.features || []);
        const v = el.dataset.v;
        f.delete("sun");
        if (v === "free") f.delete("time"); else f.add("time");
        if (v === "sun" || v === "free") f.add("sun");
        if (v === "time" || v === "cal") f.delete("brightness");
        pr.time_mode = v === "cal" ? "calendar" : "times";
        if (v === "time") for (const [a, b] of [["up_early", "up_late"], ["up_early_we", "up_late_we"], ["down_early", "down_late"], ["down_early_we", "down_late_we"]]) pr[b] = pr[a];
        pr.features = [...f];
        this._renderPop();
        break;
      }
      case "rwp-dir": {
        const d = this._pop.draft;
        const pr = d.prof;
        const first = pr.window_dir == null;
        const s = this._rwSuggest(Number(el.dataset.v));
        pr.window_dir = s.dir;
        pr.azimuth_start = s.azimuth_start;
        pr.azimuth_end = s.azimuth_end;
        // erste Wahl der Richtung: Empfehlung gleich übernehmen (im Assistenten immer)
        if (first || d.covers) Object.assign(pr, { elevation_min: s.elevation_min, elevation_max: s.elevation_max, temp2_min: s.temp2_min, pos_shading: s.pos_shading });
        if (d.covers) d.temp = s.temp2_min;
        this._renderPop();
        break;
      }
      case "rwp-suggest": {
        const pr = this._pop.draft.prof;
        const s = this._rwSuggest(pr.window_dir);
        if (s) Object.assign(pr, { azimuth_start: s.azimuth_start, azimuth_end: s.azimuth_end, elevation_min: s.elevation_min, elevation_max: s.elevation_max, temp2_min: s.temp2_min, pos_shading: s.pos_shading });
        if (s?.dir === 0) pr.features = (pr.features || []).filter((f) => f !== "shading");
        this._renderPop();
        this._toast(s?.dir === 0 ? "Empfehlung übernommen – Sonnenschutz für Nordfenster aus" : "Empfehlung übernommen – noch speichern");
        break;
      }
      case "rwp-lock":
        this._pop.draft.prof.pos_lockout = el.dataset.v === "" ? null : Number(el.dataset.v);
        if (el.dataset.v !== "") this._pop.draft.prof.features = [...new Set([...(this._pop.draft.prof.features || []), "ventilate"])];
        this._renderPop();
        break;
      case "rwp-man": {
        const pr = this._pop.draft.prof;
        const v = el.dataset.v;
        pr.manual_block = v === "next" ? [] : ["opening", "closing", "shading", "ventilation"];
        pr.manual_reset = v === "night" ? ["fixed"] : v === "hours" ? ["timeout"] : [];
        if (v === "night") pr.reset_time = "00:01";
        if (v === "hours" && !(pr.reset_timeout > 5)) pr.reset_timeout = 120;
        this._renderPop();
        break;
      }
      case "rw-expert":
        this._setExpert("rollwerk", !this._expertOn("rollwerk"));
        this._renderPop();
        break;
      case "rwp-del-no":
        this._pop.draft.confirm = false;
        this._renderPop();
        break;
      case "rwp-sec": {
        const [, pid] = this._pop.id.split(":");
        this._pop.id = `rwp:${pid}:${el.dataset.sec}`;
        this._pop.keep = false;
        this._renderPop();
        break;
      }
      case "rwp-save": {
        const d = this._pop.draft;
        d.prof.name = String(d.prof.name || "").trim();
        if (!d.prof.name) { this._toast("Bitte einen Namen eingeben."); return; }
        if (this._rwProfiles().some((x) => x.id !== d.pid && x.name.toLowerCase() === d.prof.name.toLowerCase())) { this._toast(`Ein Profil „${d.prof.name}“ gibt es schon.`); return; }
        const res = await this._ws({ type: "hauswerk/rollwerk/profile/save", profile_id: d.pid, profile: d.prof });
        this._data.rollwerk.profiles = res.profiles;
        this._closePop();
        this._renderMain();
        this._toast(d.pid ? "Gespeichert" : "Profil angelegt");
        break;
      }
      case "rwp-del": {
        const d = this._pop.draft;
        if (!d.confirm) { d.confirm = true; this._pop.keep = false; this._renderPop(); return; }
        const res = await this._ws({ type: "hauswerk/rollwerk/profile/delete", profile_id: d.pid, replace_with: d.replace || null });
        this._data.rollwerk.profiles = res.profiles;
        this._data.rollwerk.covers = res.covers;
        this._closePop();
        this._renderMain();
        this._toast("Profil gelöscht");
        break;
      }
      case "rwc-cmode": {
        const d = this._pop.draft, v = el.dataset.v;
        d.own = v === "own";
        d.cfg.contacts = v === "none" ? "none" : null;
        if (v !== "own") Object.assign(d.cfg, { contact_open: null, contact_tilted: null });
        this._renderPop();
        break;
      }
      case "rwc-save": {
        const res = await this._ws({ type: "hauswerk/rollwerk/cover/save", entity_id: el.dataset.id, cover: this._pop.draft.cfg });
        this._data.rollwerk.covers = res.covers;
        if (res.profiles) this._data.rollwerk.profiles = res.profiles;
        this._closePop();
        this._renderMain();
        this._toast("Gespeichert");
        break;
      }
      case "set-seg":
        this._settings[el.dataset.key] = el.dataset.v === "null" ? null : el.dataset.v;
        this._refreshSettings();
        break;
      case "kwapp-type":
        this._pop.draft.type = el.dataset.v;
        this._renderPop();
        break;
      case "kwapp-pick":
        this._pop.draft.kwa_power = el.dataset.id;
        if (!String(this._pop.draft.name || "").trim()) this._pop.draft.name = APP_TYPES[this._pop.draft.type]?.label || "";
        this._renderPop();
        break;
      case "kwapp-notify": {
        const set = new Set(this._pop.draft.notify || []);
        if (set.has(el.dataset.id)) set.delete(el.dataset.id); else set.add(el.dataset.id);
        this._pop.draft.notify = [...set];
        this._renderPop();
        break;
      }
      case "kwapp-flag":
        this._pop.draft[el.dataset.k] = !this._pop.draft[el.dataset.k];
        this._renderPop();
        break;
      case "kwapp-save":
        this._kwAppSave();
        break;
      case "kwapp-del":
        this._kwAppSave(true);
        break;
      case "app-act":
        this._appAct(el.dataset.id, el.dataset.a);
        break;
      case "dash-create":
        this._dashCreate();
        break;
      case "dp-set":
        this._dpSet(el.dataset.scope, el.dataset.on === "1");
        break;
      case "waste-hide": {
        const t = el.dataset.t;
        const hidden = new Set(this._settings.waste_hidden || []);
        if (hidden.has(t)) hidden.delete(t); else hidden.add(t);
        this._settings.waste_hidden = [...hidden];
        this._refreshSettings();
        break;
      }
      case "report-days":
        this._reportDays = Number(el.dataset.days);
        this._renderMain();
        break;
    }
  }

  async _step(kind, key, delta) {
    if (kind === "dlg") {
      const r = this._dialog.room;
      r[key] = clampT((r[key] ?? 20) + delta);
      this._renderDialog();
    } else if (kind === "blk") {
      const room = this._planRef();
      const b = this._plan.blocks[Number(key)];
      b.temp = clampT((b.temp ?? room.comfort) + delta);
      this._plan.dirty = true;
      this._renderMain();
    } else if (kind === "set") {
      this._settings[key] = clampT((this._settings[key] ?? 17) + delta);
      this._refreshSettings();
    } else if (kind === "rq") {
      this._pop.draft.temp = clampT((this._pop.draft.temp ?? 20) + delta);
      this._renderPop();
    } else if (kind === "ovr") {
      const s = this._status?.rooms?.[key] || {};
      const base = s.target ?? this._data.rooms[key].comfort;
      const temp = clampT(base + delta);
      // sofort anzeigen, der Server bestätigt per Abo
      if (this._status?.rooms?.[key]) Object.assign(this._status.rooms[key], { target: temp, mode: "manuell", mode_label: "Manuell" });
      this._renderMain();
      await this._ws({ type: "hauswerk/heizen/override", room_id: key, temp });
    }
  }

  async _saveRoom(room) {
    try {
      const saved = await this._ws({ type: "hauswerk/heizen/room/save", room });
      this._data.rooms[saved.id] = saved;
      if (this._tab !== "plans") this._renderMain();
      return saved;
    } catch (e) {
      return null;
    }
  }

  async _saveDialog() {
    const r = this._dialog.room;
    if (!r.name || !r.name.trim()) {
      this._dialog.tab = "basis";
      this._renderDialog();
      this._toast("Bitte einen Namen eingeben.");
      return;
    }
    if (r.eco > r.comfort) {
      this._toast("Eco sollte nicht wärmer sein als Komfort.");
      return;
    }
    const saved = await this._saveRoom(r);
    if (saved) {
      this._dialog = null;
      this._renderDialog();
      this._renderMain();
    }
  }
}

/* Eigenes Zeichen: Flamme in einem Thermostat-Ring */
// Symbole der Module – gleiche Hausform wie das Hauswerk-Logo, eigene Farbe und eigenes Innenleben
// Behanghöhen im Pop-up „Höhe einstellen“ (fest, nicht aus den Profilen)
const RW_HEIGHTS = [["Offen", 100, "mdi:window-shutter-open"], ["Halb offen", 50, "mdi:window-shutter-settings"], ["Viertel offen", 25, "mdi:window-shutter-settings"], ["Geschlossen", 0, "mdi:window-shutter"]];
/** DOM abgleichen statt neu aufbauen: nur geänderte Knoten, Texte und Attribute anfassen. */
function morph(target, html) {
  const tpl = document.createElement("template");
  tpl.innerHTML = html;
  const active = target.getRootNode()?.activeElement;
  const attrs = (a, b) => {
    for (const { name } of [...a.attributes]) if (!b.hasAttribute(name) && !(name === "open" && a.tagName === "DETAILS")) a.removeAttribute(name);
    for (const { name, value } of [...b.attributes]) if (a.getAttribute(name) !== value) a.setAttribute(name, value);
  };
  const same = (a, b) => a.nodeType === b.nodeType && a.nodeName === b.nodeName && (a.nodeType !== 1 || (a.id === b.id && a.getAttribute("data-key") === b.getAttribute("data-key")));
  const kids = (a, b) => {
    const an = [...a.childNodes], bn = [...b.childNodes];
    bn.forEach((y, i) => {
      const x = an[i];
      if (!x) { a.appendChild(y); return; }
      if (!same(x, y)) { a.replaceChild(y, x); return; }
      if (x.nodeType !== 1) { if (x.data !== y.data) x.data = y.data; return; }
      if (x === active && ["INPUT", "TEXTAREA", "SELECT"].includes(x.tagName)) return;  // Eingabe nicht stören
      attrs(x, y);
      if (x.tagName === "INPUT") { if (x.value !== y.value) x.value = y.value; x.checked = y.checked; }
      if (x.tagName === "TEXTAREA" && x.value !== y.value) x.value = y.value;
      kids(x, y);
    });
    while (a.childNodes.length > bn.length) a.removeChild(a.lastChild);
  };
  kids(target, tpl.content);
}

const EXPERT_MOD = { house: "haus", heat: "heizen", rw: "rollwerk", kw: "kraftwerk" };
const LW_POPS = ["lwadd", "lwgeneral", "lwauto", "lwlinks"];
const LW_LK = { motion: "mdi:motion-sensor", button: "mdi:gesture-tap-button", other: "mdi:link-variant" };
const MODULE_LOGOS = {
  heizen: `<svg viewBox="0 0 48 48" aria-hidden="true">
  <defs><linearGradient id="hwlg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fdba74"/><stop offset="1" stop-color="#c2410c"/></linearGradient></defs>
  <rect width="48" height="48" rx="13" fill="url(#hwlg)"/>
  <path d="M10.5 23.5 24 11.5l13.5 12" fill="none" stroke="#fff" stroke-width="3.6" stroke-linecap="round" stroke-linejoin="round"/>
  <path d="M14.8 21.8V34.2a2.8 2.8 0 0 0 2.8 2.8h12.8a2.8 2.8 0 0 0 2.8-2.8V21.8" fill="none" stroke="#fff" stroke-width="3.6" stroke-linecap="round" stroke-linejoin="round"/>
  <rect x="18.6" y="22.6" width="3" height="10.8" rx="1.5" fill="#fff"/>
  <rect x="22.5" y="22.6" width="3" height="10.8" rx="1.5" fill="#fde68a"/>
  <rect x="26.4" y="22.6" width="3" height="10.8" rx="1.5" fill="#fff" opacity=".6"/>
</svg>`,
  rollwerk: `<svg viewBox="0 0 48 48" aria-hidden="true">
  <defs><linearGradient id="rwlg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#7dd3fc"/><stop offset="1" stop-color="#0369a1"/></linearGradient></defs>
  <rect width="48" height="48" rx="13" fill="url(#rwlg)"/>
  <path d="M10.5 23.5 24 11.5l13.5 12" fill="none" stroke="#fff" stroke-width="3.6" stroke-linecap="round" stroke-linejoin="round"/>
  <path d="M14.8 21.8V34.2a2.8 2.8 0 0 0 2.8 2.8h12.8a2.8 2.8 0 0 0 2.8-2.8V21.8" fill="none" stroke="#fff" stroke-width="3.6" stroke-linecap="round" stroke-linejoin="round"/>
  <rect x="18.6" y="22.6" width="10.8" height="3" rx="1.5" fill="#fff"/>
  <rect x="18.6" y="26.6" width="10.8" height="3" rx="1.5" fill="#fff" opacity=".6"/>
  <rect x="18.6" y="30.6" width="10.8" height="3" rx="1.5" fill="#fdba74"/>
</svg>`,
};
MODULE_LOGOS.kraftwerk = `<svg viewBox="0 0 48 48" aria-hidden="true">
  <defs><linearGradient id="kwlg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fde047"/><stop offset="1" stop-color="#d97706"/></linearGradient></defs>
  <rect width="48" height="48" rx="13" fill="url(#kwlg)"/>
  <path d="M10.5 23.5 24 11.5l13.5 12" fill="none" stroke="#fff" stroke-width="3.6" stroke-linecap="round" stroke-linejoin="round"/>
  <path d="M14.8 21.8V34.2a2.8 2.8 0 0 0 2.8 2.8h12.8a2.8 2.8 0 0 0 2.8-2.8V21.8" fill="none" stroke="#fff" stroke-width="3.6" stroke-linecap="round" stroke-linejoin="round"/>
  <path d="M25.6 20.5 19.8 29h4.4l-1.8 6.6 6-8.8h-4.5z" fill="#fff" stroke="#fff" stroke-width="1" stroke-linejoin="round"/>
</svg>`;
MODULE_LOGOS.lichtwerk = `<svg viewBox="0 0 48 48" aria-hidden="true">
  <defs><linearGradient id="lwlg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#a5b4fc"/><stop offset="1" stop-color="#4338ca"/></linearGradient></defs>
  <rect width="48" height="48" rx="13" fill="url(#lwlg)"/>
  <path d="M10.5 23.5 24 11.5l13.5 12" fill="none" stroke="#fff" stroke-width="3.6" stroke-linecap="round" stroke-linejoin="round"/>
  <path d="M14.8 21.8V34.2a2.8 2.8 0 0 0 2.8 2.8h12.8a2.8 2.8 0 0 0 2.8-2.8V21.8" fill="none" stroke="#fff" stroke-width="3.6" stroke-linecap="round" stroke-linejoin="round"/>
  <circle cx="24" cy="26.6" r="4.6" fill="#fde047"/>
  <rect x="21.9" y="31" width="4.2" height="2.6" rx="1" fill="#fff"/>
</svg>`;
/** ha-icon oder – bei „logo:<modul>“ – das eigene Symbol des Moduls. */
// Jede Kopie bekommt eigene IDs für den Farbverlauf: sonst bleibt sie leer, wenn die erste Kopie verborgen ist.
let logoNo = 0;
const modIcon = (icon) => {
  const svg = String(icon).startsWith("logo:") && MODULE_LOGOS[icon.slice(5)];
  if (!svg) return `<ha-icon icon="${icon}"></ha-icon>`;
  const n = ++logoNo;
  return `<span class="mlogo">${svg.replace(/id="(\w+)"/g, `id="$1${n}"`).replace(/url\(#(\w+)\)/g, `url(#$1${n})`)}</span>`;
};

const LOGO = `
<svg viewBox="0 0 48 48" aria-hidden="true">
  <defs><linearGradient id="lg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" style="stop-color:color-mix(in srgb, var(--accent) 75%, #fff)"/><stop offset="1" style="stop-color:color-mix(in srgb, var(--accent) 65%, #000)"/></linearGradient></defs>
  <rect width="48" height="48" rx="13" fill="url(#lg)"/>
  <path d="M10.5 23.5 24 11.5l13.5 12" fill="none" stroke="#fff" stroke-width="3.6" stroke-linecap="round" stroke-linejoin="round"/>
  <path d="M14.8 21.8V34.2a2.8 2.8 0 0 0 2.8 2.8h12.8a2.8 2.8 0 0 0 2.8-2.8V21.8" fill="none" stroke="#fff" stroke-width="3.6" stroke-linecap="round" stroke-linejoin="round"/>
  <rect x="18.6" y="22.8" width="4.6" height="4.6" rx="1.3" fill="#fdba74"/>
  <rect x="24.8" y="22.8" width="4.6" height="4.6" rx="1.3" fill="#fff"/>
  <rect x="18.6" y="29" width="4.6" height="4.6" rx="1.3" fill="#fff"/>
  <rect x="24.8" y="29" width="4.6" height="4.6" rx="1.3" fill="#fff" opacity=".55"/>
</svg>`;

const STYLE = `
/* Farben kommen aus dem Home-Assistant-Theme: hell oder dunkel wie dort eingestellt. */
:host {
  --text:var(--primary-text-color, #1f2328); --muted:var(--secondary-text-color, #5f6670);
  --bg:var(--primary-background-color, #f3f5f7); --card:var(--card-background-color, var(--ha-card-background, #fff));
  --card2:var(--secondary-background-color, #eceff2);
  --line:var(--divider-color, rgba(0,0,0,.1)); --line2:color-mix(in srgb, var(--text) 18%, transparent);
  --track:color-mix(in srgb, var(--text) 22%, transparent);
  --accent:#0f9488; --ink:#fff; --shade:38%; --shadow:0 8px 24px rgba(0,0,0,.10); --r:18px;
  display:block; min-height:100vh; background:var(--bg); color:var(--text);
  font-family:var(--paper-font-body1_-_font-family, Inter, "Segoe UI", Roboto, system-ui, sans-serif); -webkit-font-smoothing:antialiased;
}
:host([dark]) {
  --text:var(--primary-text-color, #f1f3f4); --muted:var(--secondary-text-color, #9aa0a6);
  --bg:var(--primary-background-color, #111315); --card:var(--card-background-color, var(--ha-card-background, #1b1d20));
  --card2:var(--secondary-background-color, #24272b); --line:var(--divider-color, rgba(255,255,255,.1));
  --accent:#2dd4bf; --ink:#04211d; --shade:0%; --shadow:0 10px 30px rgba(0,0,0,.45);
}
/* Hell/Dunkel anders als Home Assistant (z. B. Tablet im Dunkelmodus, Hauswerk auf Hell): eigene Farben statt der von HA */
:host([own]) { --text:#1f2328; --muted:#5f6670; --bg:#f3f5f7; --card:#fff; --card2:#eceff2; --line:rgba(0,0,0,.1); color-scheme:light; }
:host([own][dark]) { --text:#f1f3f4; --muted:#9aa0a6; --bg:#111315; --card:#1b1d20; --card2:#24272b; --line:rgba(255,255,255,.1); color-scheme:dark; }
* { box-sizing:border-box; scrollbar-color:var(--track) transparent; scrollbar-width:thin;
  --ct:color-mix(in srgb, var(--c, currentColor), var(--text) var(--shade));
  --rct:color-mix(in srgb, var(--rc, currentColor), var(--text) var(--shade)); }
ha-icon { --mdc-icon-size:18px; flex:none; }
button { font:inherit; color:inherit; }
.app { max-width:1180px; margin:0 auto; padding:16px 20px 40px; }
.grow { flex:1; }
.muted { color:var(--muted); }
.small { font-size:12px; }
code { background:var(--card2); padding:1px 6px; border-radius:6px; font-size:12px; }

/* Kopfleiste (fest oben) mit Modul-Reitern */
.top { position:sticky; top:0; z-index:6; padding:8px max(16px, calc((100% - 1180px) / 2 + 20px)) 0;
  background:linear-gradient(135deg, color-mix(in srgb, var(--accent) 20%, var(--bg)), color-mix(in srgb, #60a5fa 14%, var(--bg)));
  border-bottom:1px solid var(--line); }
.bar { display:flex; align-items:center; gap:12px; min-height:58px; }
.menu { all:unset; cursor:pointer; width:40px; height:40px; border-radius:50%; display:grid; place-items:center; flex:none; }
.menu ha-icon { --mdc-icon-size:24px; }
:host(:not([narrow])) .menu { display:none; }
:host([tablet]) .menu { display:grid !important; }
.brand svg { width:44px; height:44px; display:block; }
.ttl { display:flex; flex-direction:column; min-width:0; flex:1; line-height:1.2; }
.ttl small { font-size:10.5px; letter-spacing:.14em; font-weight:800; color:var(--accent); }
.ttl b { font-size:19px; font-weight:700; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.ttl span { font-size:12px; color:var(--muted); white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.hacts { display:flex; gap:8px; flex:none; }
.abtn { all:unset; cursor:pointer; display:inline-flex; align-items:center; gap:7px; padding:9px 15px; border-radius:99px; font-weight:600; font-size:14px;
  background:var(--card); border:1px solid var(--line); }
.abtn:hover { border-color:var(--line2); }
.abtn.active { border-color:var(--accent); color:var(--accent); }
.mtabs { display:flex; gap:10px; overflow-x:auto; padding:10px 0 12px; scrollbar-width:none; }
.mtabs::-webkit-scrollbar { display:none; }
.mtab { all:unset; cursor:pointer; flex:none; display:inline-flex; align-items:center; gap:10px; padding:9px 14px; border-radius:16px;
  background:var(--card); border:1px solid var(--line); }
.mtab > ha-icon { --mdc-icon-size:22px; color:var(--muted); }
.mtab .mt { display:flex; flex-direction:column; line-height:1.15; }
.mtab .mt small { font-size:10.5px; color:var(--muted); }
.mtab .mt b { font-size:15px; font-weight:600; }
.mtab:hover { border-color:var(--line2); }
.mtab.active { border-color:var(--accent); background:color-mix(in srgb, var(--accent) 12%, var(--card)); }
.mtab.active > ha-icon, .mtab.active .mt small { color:var(--accent); }
.mtab.soon { cursor:default; opacity:.45; border-style:dashed; }
.mtab.soon:hover { border-color:var(--line); }
.badge { font-style:normal; font-size:10px; font-weight:800; letter-spacing:.05em; padding:2px 8px; border-radius:99px; color:var(--muted); border:1px solid var(--line2); }
.badge.ok { --c:#fb923c; color:var(--ct); border-color:color-mix(in srgb, var(--c) 55%, transparent); background:color-mix(in srgb, var(--c) 12%, transparent); }
.badge.warn { --c:#06b6d4; color:var(--ct); border-color:color-mix(in srgb, var(--c) 55%, transparent); background:color-mix(in srgb, var(--c) 12%, transparent); }

/* Unterleiste im Modul Heizen */
.heatnav { display:flex; gap:4px; padding:4px; margin:0 0 16px; border-radius:16px; background:var(--card); border:1px solid var(--line); overflow-x:auto; scrollbar-width:none; }
.heatnav::-webkit-scrollbar { display:none; }
.hnav { all:unset; cursor:pointer; flex:1 0 auto; display:flex; align-items:center; justify-content:center; gap:8px; padding:10px 14px; border-radius:12px; font-weight:600; font-size:14px; color:var(--muted); white-space:nowrap; }
.hnav:hover { color:var(--text); background:var(--card2); }
.hnav.on { color:var(--text); background:color-mix(in srgb, var(--accent) 16%, var(--card)); box-shadow:inset 0 0 0 1px color-mix(in srgb, var(--accent) 45%, transparent); }
.hnav.on ha-icon { color:var(--accent); }
.hnav em { font-style:normal; font-size:11px; font-weight:700; padding:1px 7px; border-radius:99px; color:var(--muted); background:var(--card2); }
.hnav em.ok { --c:#fb923c; color:var(--ct); background:color-mix(in srgb, var(--c) 14%, transparent); }
.hnav em.warn { --c:#06b6d4; color:var(--ct); background:color-mix(in srgb, var(--c) 14%, transparent); }

/* Status-Chips */
.schips { display:flex; gap:10px; overflow-x:auto; padding:2px 0 14px; scrollbar-width:none; }
.schips::-webkit-scrollbar { display:none; }
.schip { all:unset; flex:none; display:inline-flex; align-items:center; gap:9px; padding:8px 15px 8px 12px; border-radius:99px; background:var(--card); border:1px solid var(--line); }
.schip > ha-icon { --mdc-icon-size:20px; color:var(--ct); }
.schip:not([style]) > ha-icon { color:var(--muted); }
.schip > span { display:flex; flex-direction:column; line-height:1.15; }
.schip b { font-size:13.5px; } .schip small { font-size:10.5px; color:var(--muted); }

/* Start */
.start .stit { display:flex; align-items:center; gap:8px; margin-bottom:10px; }
.start .stit ha-icon { --mdc-icon-size:20px; color:var(--accent); }
.hl { margin:0 0 4px; font-size:26px; font-weight:800; letter-spacing:-.01em; --c:#14b8a6; color:var(--ct); }
.hl.warn { --c:#f59e0b; }
.hsub { margin:0 0 16px; color:var(--muted); font-size:14px; }
.mtiles { display:grid; grid-template-columns:repeat(auto-fill, minmax(150px, 1fr)); gap:12px; }
.mtile { all:unset; cursor:pointer; display:flex; flex-direction:column; align-items:center; gap:6px; padding:18px 10px; border-radius:18px; text-align:center;
  background:color-mix(in srgb, var(--card2) 55%, var(--card)); border:1px solid var(--line); }
.mtile:hover { border-color:var(--line2); transform:translateY(-1px); }
.mtile.warn { --c:#f59e0b !important; background:color-mix(in srgb, #f59e0b 12%, var(--card)); border-color:color-mix(in srgb, #f59e0b 60%, transparent); }
.mico { width:46px; height:46px; border-radius:14px; display:grid; place-items:center; background:color-mix(in srgb, var(--c) 18%, transparent); color:var(--ct); }
.mico ha-icon { --mdc-icon-size:26px; }
.mtile b { font-size:15px; }
.mtile small { font-size:12.5px; color:var(--muted); }
.mtile small.g { --c:#14b8a6; color:var(--ct); font-weight:600; }
.gmini { display:grid; grid-template-columns:repeat(auto-fill, minmax(200px, 1fr)); gap:10px; }
.gm { all:unset; cursor:pointer; display:flex; flex-direction:column; gap:4px; padding:12px 14px; border-radius:14px; background:color-mix(in srgb, var(--card2) 55%, var(--card));
  border:1px solid var(--line); border-left:4px solid var(--acc); }
.gm:hover { border-color:var(--line2); border-left-color:var(--acc); }
.gh { display:flex; align-items:center; gap:7px; font-weight:600; font-size:14px; }
.gh ha-icon { --mdc-icon-size:18px; color:var(--muted); }
.gh .gn { flex:1; min-width:0; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.gh .gf { --c:#fb923c; color:var(--ct); }
.gt { font-size:26px; font-weight:800; letter-spacing:-.02em; }
.gt small { font-size:13px; font-weight:500; color:var(--muted); margin-left:2px; }
.gl { display:flex; align-items:center; gap:5px; font-size:12px; font-weight:600; color:var(--ct); }
.gl ha-icon { --mdc-icon-size:14px; }

/* Karten */
.card { background:var(--card); border:1px solid var(--line); border-radius:var(--r); padding:18px 20px; margin-bottom:14px; }
.shead { display:flex; align-items:center; gap:10px; margin-bottom:14px; }
.shead ha-icon { color:var(--accent); }
.shead h3 { margin:0; font-size:16px; font-weight:600; }
.shead.outer { margin:22px 2px 12px; }
.empty { text-align:center; padding:36px 20px; color:var(--muted); }
.empty ha-icon { --mdc-icon-size:46px; color:var(--accent); opacity:.8; }
.empty h2 { color:var(--text); margin:10px 0 6px; font-size:18px; }
.empty.small { padding:18px; }
.loading, .chart-empty { display:grid; place-items:center; padding:60px 0; }
.spinner { width:28px; height:28px; border-radius:50%; border:3px solid var(--line2); border-top-color:var(--accent); animation:spin 1s linear infinite; }
@keyframes spin { to { transform:rotate(360deg); } }

/* Banner */
.hero { color:#fff; position:relative; overflow:hidden; display:flex; align-items:center; gap:20px; padding:24px 28px; margin-bottom:14px; border-radius:22px;
  background:radial-gradient(120% 140% at 85% 0%, rgba(45,212,191,.55) 0%, rgba(45,212,191,0) 55%),
             linear-gradient(115deg, #0f5f63 0%, #11505a 40%, #0c3446 100%);
  box-shadow:0 10px 40px rgba(0,0,0,.35); }
.hero::after { content:""; position:absolute; inset:auto -10% -60% 30%; height:120%; background:radial-gradient(closest-side, rgba(255,255,255,.06), transparent); pointer-events:none; }
.hero-text { flex:1; min-width:0; position:relative; z-index:1; }
.hero-label { display:flex; gap:7px; align-items:center; font-size:14px; color:rgba(255,255,255,.85); }
.hero-big { font-size:64px; font-weight:800; letter-spacing:-.03em; line-height:1.05; margin-top:6px; }
.hero-big span { font-size:22px; font-weight:500; margin-left:6px; letter-spacing:0; }
.hero-date { color:rgba(255,255,255,.75); font-size:14px; margin-bottom:16px; }
.hero-chips { display:flex; gap:8px; flex-wrap:wrap; }
.hchip { display:inline-flex; align-items:center; gap:7px; padding:7px 13px; border-radius:99px; background:rgba(255,255,255,.12); backdrop-filter:blur(6px); font-size:13px; font-weight:500; }
.gauge { width:190px; flex:none; position:relative; z-index:1; }
.gauge svg { width:100%; display:block; }
.g-small { fill:rgba(255,255,255,.7); font-size:12px; }
.g-big { fill:#fff; font-size:26px; font-weight:800; }

/* Anwesenheit */
.segs { display:grid; grid-template-columns:repeat(3, 1fr); gap:10px; }
.seg { all:unset; cursor:pointer; display:flex; flex-direction:column; align-items:center; gap:6px; padding:14px 8px; border-radius:14px; border:1px solid var(--line2); color:var(--muted); font-weight:600; font-size:14px; text-align:center; }
.seg ha-icon { --mdc-icon-size:22px; }
.seg:hover { background:var(--card2); }
.seg.on { border-color:var(--accent); color:var(--text); background:color-mix(in srgb, var(--accent) 14%, var(--card)); }
.seg.on ha-icon { color:var(--accent); }
.seg[disabled] { cursor:default; }
.segs.small .seg { flex-direction:row; justify-content:center; padding:10px 8px; font-size:13px; }
.ptext { margin:14px 0 8px; color:var(--muted); line-height:1.5; }
.ptext b { color:var(--text); }
.links { display:flex; gap:20px; flex-wrap:wrap; }
.link { all:unset; cursor:pointer; display:inline-flex; align-items:center; gap:6px; color:var(--accent); font-weight:600; font-size:14px; }
.link:hover { filter:brightness(1.15); }
.link.tiny { font-size:12px; }
.tiny { font-size:12px; }

/* Kennzahlen */
.kpis { display:grid; grid-template-columns:repeat(4, 1fr); gap:12px; margin-bottom:14px; }
.kpi { position:relative; background:var(--card); border:1px solid var(--line); border-radius:16px; padding:14px 16px 14px 20px; overflow:hidden; }
.kpi::before { content:""; position:absolute; left:0; top:0; bottom:0; width:4px; background:var(--k); }
.kpi-l { display:flex; gap:7px; align-items:center; color:var(--muted); font-size:13px; }
.kpi-v { font-size:28px; font-weight:800; margin:6px 0 2px; letter-spacing:-.02em; }
.kpi-v span { font-size:14px; font-weight:500; color:var(--muted); margin-left:5px; letter-spacing:0; }
.kpi-s { font-size:12px; color:var(--muted); }

/* Diagramm */
.chart-wrap { position:relative; }
.chart { width:100%; height:240px; display:block; }
.gl { stroke:var(--line2); stroke-dasharray:4 6; }
.ax { fill:var(--muted); font-size:13px; }
.ax.today { fill:var(--text); font-weight:700; }
.chart-note { position:absolute; inset:0 0 30px 44px; display:grid; place-items:center; color:var(--muted); font-size:14px; }
.legend { display:flex; flex-wrap:wrap; gap:6px 16px; margin-top:12px; font-size:13px; color:var(--muted); }
.legend span { display:inline-flex; align-items:center; gap:6px; }
.legend i { width:10px; height:10px; border-radius:3px; }

/* Räume */
.rooms { display:grid; grid-template-columns:repeat(auto-fill, minmax(320px, 1fr)); gap:12px; }
.room { background:var(--card); border:1px solid var(--line); border-radius:var(--r); padding:16px 18px; position:relative; overflow:hidden; display:flex; flex-direction:column; }
.room::before { content:""; position:absolute; left:0; top:0; bottom:0; width:4px; background:var(--rc); }
.room-head { display:flex; align-items:center; gap:12px; }
.room-ic { width:40px; height:40px; border-radius:12px; display:grid; place-items:center; background:color-mix(in srgb, var(--rc) 18%, transparent); color:var(--rct); }
.room-ic { position:relative; flex:none; }
.room-ic > ha-icon { --mdc-icon-size:22px; }
.flame { position:absolute; right:-5px; bottom:-5px; width:20px; height:20px; border-radius:50%; display:grid; place-items:center; background:#fb923c; color:#fff; border:2px solid var(--card); }
.flame ha-icon { --mdc-icon-size:12px; }
.room-t small { display:inline-flex; align-items:center; gap:4px; }
.room-t small ha-icon { --mdc-icon-size:13px; }
.room.off { opacity:.62; }
.room.off .room-temp { color:var(--muted); }
.trend { display:inline-flex; align-items:center; gap:4px; margin-top:6px; font-size:12px; font-weight:600; color:var(--ct); }
.trend ha-icon { --mdc-icon-size:15px; }
.room-set small { display:inline-flex !important; align-items:center; gap:4px; }
.room-set small ha-icon { --mdc-icon-size:13px; }
.sis { display:flex; align-items:center; gap:4px; min-width:0; overflow:hidden; }
.room-foot { flex-wrap:nowrap !important; }
.si .t { white-space:nowrap; }
.si { display:inline-flex; align-items:center; gap:4px; height:28px; white-space:nowrap; padding:0 7px; border-radius:9px; color:var(--ct); font-size:12px; font-weight:600; background:color-mix(in srgb, var(--c) 10%, transparent); }
.si ha-icon { --mdc-icon-size:16px; }
.acts { display:flex; align-items:center; gap:2px; padding:2px; border-radius:12px; background:var(--card2); }
.acts .icon { width:32px; height:32px; }
.acts:empty { display:none; }
.icon.auto-on { color:var(--accent); }
.icon.auto-off { color:#f87171; background:color-mix(in srgb, #f87171 14%, transparent); }
.room.off .acts { opacity:1; }
.room-t { flex:1; min-width:0; }
/* Raumname nicht mitten im Wort umbrechen: lieber rutscht die Betriebsart in die nächste Zeile */
.room-head { flex-wrap:wrap; }
.room-head .room-t { min-width:min(8.5em, 60%); }
.room-t h4 { margin:0; font-size:16px; line-height:1.25; white-space:normal; overflow-wrap:break-word; hyphens:manual; }
.room-t small { color:var(--muted); font-size:12px; }
.mode { display:inline-flex; align-items:center; gap:5px; padding:4px 10px 4px 8px; border-radius:99px; font-size:12px; font-weight:600;
  color:var(--ct); background:color-mix(in srgb, var(--c) 15%, transparent); border:1px solid color-mix(in srgb, var(--c) 35%, transparent); white-space:nowrap; }
.mode ha-icon { --mdc-icon-size:15px; }
.room-body { display:flex; align-items:center; justify-content:space-between; gap:10px; margin:16px 0 12px; }
.room-now small, .room-set small { display:block; color:var(--muted); font-size:12px; margin-bottom:2px; }
.room-set { text-align:right; }
.room-temp { font-size:42px; font-weight:800; letter-spacing:-.03em; line-height:1; }
.room-temp span { font-size:16px; font-weight:500; color:var(--muted); margin-left:3px; }
.tgt { font-size:20px; }
.room-note { display:flex; align-items:center; gap:7px; font-size:13px; padding:8px 10px; border-radius:10px; background:color-mix(in srgb, #a78bfa 12%, transparent); margin-bottom:10px; }
.room-note.warn { background:color-mix(in srgb, #f59e0b 14%, transparent); }
.room-foot { display:flex; align-items:center; gap:10px; flex-wrap:wrap; border-top:1px solid var(--line); padding-top:12px; margin-top:auto; }
.dot-l { display:inline-flex; align-items:center; gap:6px; font-size:12px; font-weight:600; color:var(--ct); }
.dot-l i { width:8px; height:8px; border-radius:50%; background:var(--c); box-shadow:0 0 0 3px color-mix(in srgb, var(--c) 25%, transparent); }
.dot-l.plain { color:var(--muted); font-weight:500; }
.icon { all:unset; cursor:pointer; width:34px; height:34px; display:grid; place-items:center; border-radius:10px; color:var(--muted); }
.icon:hover { background:var(--card2); color:var(--text); }
.icon.boxed { border:1px solid var(--line2); }

/* Stepper */
.stepper { display:inline-flex; align-items:center; gap:10px; }
.stepper b { min-width:78px; text-align:center; font-size:22px; font-weight:800; letter-spacing:-.01em; }
.stepper.small b { min-width:64px; font-size:19px; }
.sbtn { all:unset; cursor:pointer; width:38px; height:38px; display:grid; place-items:center; border-radius:50%; border:1px solid var(--line2); font-size:20px; line-height:1; }
.stepper.small .sbtn { width:32px; height:32px; font-size:18px; }
.sbtn:hover { border-color:var(--accent); color:var(--accent); }

/* Schalter */
.switch { position:relative; display:inline-block; width:46px; height:26px; flex:none; }
.switch input { opacity:0; width:0; height:0; position:absolute; }
.switch > span { position:absolute; inset:0; border-radius:99px; background:var(--track); transition:.2s; cursor:pointer; }
.switch > span::after { content:""; position:absolute; width:20px; height:20px; left:3px; top:3px; border-radius:50%; background:#fff; transition:.2s; }
.switch input:checked + span { background:var(--accent); }
.switch input:checked + span::after { transform:translateX(20px); }
.switch input:disabled + span { opacity:.4; cursor:default; }

/* Pillen */
.pills { display:flex; gap:8px; flex-wrap:wrap; margin-bottom:14px; }
.pill { all:unset; cursor:pointer; display:inline-flex; align-items:center; gap:8px; padding:8px 14px; border-radius:99px; background:var(--card); border:1px solid var(--line); font-size:14px; font-weight:500; }
.pill i { width:8px; height:8px; border-radius:50%; background:var(--rc); }
.pill.on { border-color:var(--accent); background:color-mix(in srgb, var(--accent) 14%, var(--card)); }

/* Heizplan */
.plan-head { display:flex; justify-content:space-between; gap:12px; flex-wrap:wrap; margin-bottom:18px; }
.plan-head h2 { margin:0; font-size:22px; }
.plan-temps { display:flex; gap:8px; flex-wrap:wrap; align-items:flex-start; }
.tpill { padding:6px 12px; border-radius:99px; background:var(--card2); font-size:13px; color:var(--muted); }
.tpill b { color:var(--ct); margin-left:4px; }
.lbl { color:var(--muted); font-size:13px; margin:4px 0 8px; }
.daypills { display:flex; gap:6px; flex-wrap:wrap; margin-bottom:12px; }
.dp { all:unset; cursor:pointer; width:42px; height:36px; display:grid; place-items:center; border-radius:99px; border:1px solid var(--line2); font-size:14px; font-weight:600; color:var(--muted); }
.dp:hover { border-color:var(--accent); }
.dp.on { background:var(--accent); border-color:var(--accent); color:var(--ink); }
.dp[disabled] { cursor:default; }
.dbar { position:relative; height:22px; border-radius:99px; overflow:hidden; background:var(--card2); }
.dbar.mini { height:12px; }
.dseg { position:absolute; top:0; bottom:0; }
.dseg.eco { background:color-mix(in srgb, #60a5fa 38%, var(--card2)) !important; }
.dseg + .dseg { box-shadow:inset 2px 0 0 var(--card); }
.now { position:absolute; top:-3px; bottom:-3px; width:4px; margin-left:-2px; border-radius:2px; background:#fff; box-shadow:0 0 0 2px rgba(0,0,0,.45); }
.legend-line { display:flex; flex-wrap:wrap; gap:6px 16px; align-items:center; }
.legend-line span { display:inline-flex; align-items:center; gap:6px; }
.legend-line i { width:14px; height:8px; border-radius:4px; }
.dscale {display:flex; justify-content:space-between; color:var(--muted); font-size:12px; margin:6px 2px 4px; }
.week-mini { display:grid; gap:7px; margin-top:18px; padding-top:16px; border-top:1px solid var(--line); }
.wm-row { display:grid; grid-template-columns:28px 1fr; align-items:center; gap:8px; font-size:12px; color:var(--muted); }
.blocks { display:grid; gap:12px; }
.block { background:var(--card); border:1px solid var(--line); border-radius:var(--r); padding:16px 18px 16px 22px; position:relative; overflow:hidden; }
.block::before { content:""; position:absolute; left:0; top:0; bottom:0; width:4px; background:var(--tc); }
.block-top { display:flex; align-items:center; gap:14px; flex-wrap:wrap; margin-bottom:12px; }
.times { display:flex; align-items:center; gap:8px; flex-wrap:wrap; }
.dur { font-size:12px; color:var(--muted); padding:4px 10px; border-radius:99px; background:var(--card2); margin-left:4px; }
.block .dp { width:38px; height:32px; font-size:13px; }
.block .dp.on { background:color-mix(in srgb, var(--accent) 18%, transparent); color:var(--accent); border-color:color-mix(in srgb, var(--accent) 55%, transparent); }
.addbtn { all:unset; cursor:pointer; flex:1; display:flex; align-items:center; justify-content:center; gap:8px; padding:14px; border-radius:var(--r); border:1.5px dashed var(--line2); color:var(--accent); font-weight:600; font-size:14px; }
.addbtn:hover { border-color:var(--accent); background:color-mix(in srgb, var(--accent) 8%, transparent); }
.timebox { display:flex; align-items:center; gap:8px; padding:0 12px; border-radius:12px; border:1px solid var(--line2); background:var(--bg); }
.timebox input { all:unset; font-size:20px; font-weight:700; padding:9px 0; width:76px; color-scheme:dark; }
.timebox input::-webkit-calendar-picker-indicator { display:none; }
.timebox ha-icon { color:var(--muted); }
.block-temp { display:flex; align-items:center; gap:10px; flex:1; justify-content:flex-end; }
.quick { display:flex; gap:18px; flex-wrap:wrap; }
.plan-tools { display:flex; align-items:stretch; gap:12px; margin:12px 0 16px; flex-wrap:wrap; }
.plan-tools .ghost { border-radius:var(--r); padding:0 18px; }
.unit input { max-width:140px; }
.select-link { position:relative; }
.select-link select { position:absolute; inset:0; opacity:0; cursor:pointer; }
.savebar { position:sticky; bottom:12px; display:grid; grid-template-columns:1fr 1fr; gap:12px; margin-top:16px; z-index:4; }
.primary, .secondary, .danger { all:unset; cursor:pointer; display:inline-flex; align-items:center; justify-content:center; gap:8px; padding:13px 22px; border-radius:14px; font-weight:700; font-size:15px; text-align:center; }
.primary { background:var(--accent); color:var(--ink); }
.primary:hover { filter:brightness(1.08); }
.secondary { background:var(--card2); border:1px solid var(--line2); }
.danger { color:#f87171; border:1px solid color-mix(in srgb, #f87171 40%, transparent); padding:13px 16px; }
.primary[disabled], .secondary[disabled] { background:var(--card2); color:var(--muted); pointer-events:none; }
.savebar .primary, .savebar .secondary { box-shadow:var(--shadow); }

/* Bericht */
.table-wrap { overflow-x:auto; }
table { width:100%; border-collapse:collapse; font-size:14px; }
th { text-align:left; color:var(--muted); font-weight:500; font-size:12px; padding:0 10px 10px; border-bottom:1px solid var(--line); white-space:nowrap; }
td { padding:12px 10px; border-bottom:1px solid var(--line); white-space:nowrap; font-weight:600; }
td small { display:block; color:var(--muted); font-weight:400; font-size:12px; margin-left:18px; }
.rdot { display:inline-block; width:10px; height:10px; border-radius:50%; margin-right:8px; }

/* Formulare */
.field { display:flex; flex-direction:column; gap:7px; margin-bottom:16px; }
.field > span { font-size:13px; color:var(--muted); font-weight:500; }
.field.narrow { max-width:280px; }
.field > small { font-size:12px; }
.sub-h { display:flex; align-items:center; gap:8px; margin:22px 0 6px; padding-top:16px; border-top:1px solid var(--line); font-weight:700; font-size:14px; }
.sub-h ha-icon { color:var(--accent); }
.sub-h + p { margin-top:0; }
.sheet-body > .sub-h:first-of-type, .sheet-body > p:first-child + .sub-h { margin-top:4px; padding-top:0; border-top:none; }
.segs.small { grid-template-columns:repeat(auto-fit, minmax(130px, 1fr)); }
.savebar[hidden] { display:none; }
.subnav { display:flex; gap:6px; overflow-x:auto; scrollbar-width:none; margin-bottom:14px; padding-bottom:2px; }
.snav { all:unset; cursor:pointer; flex:none; display:inline-flex; align-items:center; gap:8px; padding:9px 14px; border-radius:12px; color:var(--muted); font-weight:600; font-size:14px; border:1px solid transparent; }
.snav:hover { color:var(--text); background:var(--card); }
.snav.on { color:var(--text); background:var(--card); border-color:var(--line2); }
.snav.on ha-icon { color:var(--accent); }
.snav em { font-style:normal; font-size:11px; font-weight:700; padding:1px 7px; border-radius:99px; background:color-mix(in srgb, var(--accent) 20%, transparent); color:var(--accent); }
.field > span ha-icon { --mdc-icon-size:14px; vertical-align:-2px; }
.seg ha-icon { --mdc-icon-size:18px; }
.rr-ic { width:36px; height:36px; border-radius:11px; display:grid; place-items:center; flex:none; background:color-mix(in srgb, var(--rc) 18%, transparent); color:var(--rct); }
.rrow small { display:inline-flex !important; align-items:center; gap:4px; }
.rrow small ha-icon { --mdc-icon-size:13px; }
.rrow.off { opacity:.55; }
.rr-extras { display:flex; gap:6px; color:var(--muted); }
.rr-extras ha-icon { --mdc-icon-size:17px; }
p ha-icon { --mdc-icon-size:16px; vertical-align:-3px; color:var(--accent); margin-right:6px; }
.presence { padding:14px; }
.heat-sub .presence { padding:0; }
.heat-sub { margin-top:18px; padding-top:16px; border-top:1px solid var(--line); }
.mnum { font-size:10.5px; font-weight:800; letter-spacing:.06em; text-transform:uppercase; color:var(--muted); padding:2px 8px; border-radius:99px; background:var(--card2); }
.pbar { display:flex; align-items:center; gap:10px; flex-wrap:wrap; }
.psegs { display:flex; flex:1 1 360px; padding:4px; gap:4px; border-radius:14px; background:var(--bg); border:1px solid var(--line); }
.pseg { all:unset; cursor:pointer; flex:1; display:flex; align-items:center; justify-content:center; gap:8px; padding:10px 12px; border-radius:11px; font-weight:600; font-size:14px; color:var(--muted); }
.pseg:hover { color:var(--text); }
.pseg.on { background:color-mix(in srgb, var(--accent) 18%, var(--card)); color:var(--text); box-shadow:inset 0 0 0 1px color-mix(in srgb, var(--accent) 50%, transparent); }
.pseg.on ha-icon { color:var(--accent); }
.pseg[disabled] { cursor:default; }
.ptoggles { display:flex; gap:8px; }
.ptoggle { position:relative; cursor:pointer; display:inline-flex; align-items:center; gap:7px; padding:10px 14px; border-radius:14px; border:1px solid var(--line2); color:var(--muted); font-weight:600; font-size:14px; }
.ptoggle input { position:absolute; opacity:0; pointer-events:none; }
.ptoggle:hover { color:var(--text); }
.ptoggle.on { --c:#d946ef; color:var(--ct); border-color:color-mix(in srgb, #e879f9 55%, transparent); background:color-mix(in srgb, #e879f9 12%, var(--card)); }
.presence .ptext { display:flex; align-items:center; gap:8px; margin:12px 4px 0; font-size:13px; }
.presence .ptext ha-icon { --mdc-icon-size:16px; flex:none; }
.link.inline { font-size:13px; }
.count { font-size:12px; font-weight:700; color:var(--muted); background:var(--card2); border-radius:99px; padding:2px 9px; }
.hchip.warn { background:rgba(250,204,21,.22); }
.hmodes { display:grid; grid-template-columns:1fr 1fr; gap:10px; margin:14px 0; }
.hmode { display:flex; align-items:center; gap:12px; padding:12px 14px; border-radius:14px; border:1px solid var(--line2); cursor:pointer; }
.hmode > ha-icon { --mdc-icon-size:22px; color:var(--muted); }
.hmode > span:first-of-type { flex:1; min-width:0; }
.hmode b { display:block; font-size:14px; }
.hmode small { display:block; color:var(--muted); font-size:12px; }
.hmode.on { border-color:#e879f9; background:color-mix(in srgb, #e879f9 10%, var(--card)); }
.hmode.on > ha-icon { color:#e879f9; }
.notes { display:flex; flex-wrap:wrap; gap:8px; margin:4px 0 6px; }
.note { display:inline-flex; align-items:center; gap:7px; padding:6px 12px; border-radius:99px; font-size:13px; font-weight:600; color:var(--ct); background:color-mix(in srgb, var(--c) 13%, transparent); border:1px solid color-mix(in srgb, var(--c) 30%, transparent); }
.room-note.pre { background:color-mix(in srgb, #fb923c 13%, transparent); }
.room-note small { color:var(--muted); font-size:12px; }
.learn { display:flex; flex-direction:column; gap:2px; padding:10px 13px; border-radius:12px; border:1px solid var(--line2); }
.learn b { font-size:18px; }
.learn small { font-size:12px; color:var(--muted); }
.learn.ok { border-color:color-mix(in srgb, var(--accent) 50%, transparent); }
.learn .link { align-self:flex-start; margin-top:4px; }
.tpill ha-icon { --mdc-icon-size:14px; vertical-align:-2px; margin-right:4px; }
.room-note.boost { background:color-mix(in srgb, #f43f5e 14%, transparent); }
.room-note.warmn { background:color-mix(in srgb, #f97316 13%, transparent); }
.icon.hot { color:#f43f5e; background:color-mix(in srgb, #f43f5e 14%, transparent); }
select { font:inherit; color:var(--text); background:var(--bg); border:1px solid var(--line2); border-radius:12px; padding:11px 13px; width:100%; color-scheme:dark; }
input[type=time] { font:inherit; color:var(--text); background:var(--bg); border:1px solid var(--line2); border-radius:12px; padding:10px 13px; width:100%; color-scheme:dark; }
.timebox input[type=time] { border:none; padding:9px 0; background:none; width:76px; font-size:20px; font-weight:700; box-shadow:none; }
input[type=text], input[type=number], input[type=date], input[type=search] { font:inherit; color:var(--text); background:var(--bg); border:1px solid var(--line2); border-radius:12px; padding:11px 13px; min-width:0; width:100%; color-scheme:dark; }
input:focus { outline:none; border-color:var(--accent); box-shadow:0 0 0 3px color-mix(in srgb, var(--accent) 25%, transparent); }
.unit { display:flex; align-items:center; gap:8px; }
.unit i { font-style:normal; color:var(--muted); font-size:13px; min-width:30px; }
.row2 { display:grid; grid-template-columns:1fr 1fr; gap:0 14px; }
.row3 { display:grid; grid-template-columns:1fr 1fr 1.2fr; gap:0 14px; }
.check { display:flex; align-items:center; gap:14px; justify-content:space-between; padding:12px 0; border-top:1px solid var(--line); cursor:pointer; }
.check b { display:block; font-size:14px; }
.check small { display:block; color:var(--muted); font-size:12px; margin-top:3px; line-height:1.4; }
.rlist { display:grid; }
.rrow { display:flex; align-items:center; gap:10px; padding:10px 0; border-top:1px solid var(--line); }
.rrow:first-child { border-top:none; }
.rrow small { display:block; color:var(--muted); font-size:12px; }

/* Rollwerk: Tagesleiste, Kompass, Experte */
.rwday { margin:2px 0 4px; }
.rwday-bar { position:relative; height:12px; border-radius:99px; background:color-mix(in srgb, #1e293b 55%, var(--card2)); overflow:hidden; }
.rwday.small .rwday-bar { height:11px; }
.rwday-bar i { position:absolute; top:0; bottom:0; }
.rwday-bar .d-day { background:color-mix(in srgb, #38bdf8 55%, var(--card2)); }
.rwday-bar .d-half { background:repeating-linear-gradient(135deg, #6366f1 0 4px, #818cf8 4px 8px); }
.rwday-lab span.s1 { color:#6366f1; font-weight:700; top:14px; }
.rwday-lab { height:30px !important; }
.rwstage { padding:12px; border:1px solid var(--line2); border-radius:16px; margin:10px 0; }
.rwstage-h { display:flex; align-items:center; gap:10px; }
.rwstage-h > ha-icon { color:#f59e0b; }
.rwstage-h b { flex:1; font-size:15px; }
.rwline { margin:10px 0 6px; line-height:2.2; }
.rwsub { margin-top:10px; padding:10px 12px; border-radius:14px; background:var(--card2); }
.rwsub-h { display:flex; align-items:center; gap:8px; margin-bottom:6px; }
.rwsub-h i { font-style:normal; width:22px; height:22px; border-radius:50%; display:grid; place-items:center; background:#6366f1; color:#fff; font-size:12px; font-weight:700; }
.rwsub-h b { flex:1; }
.rwday-bar .d-shade { background:repeating-linear-gradient(135deg, #f97316 0 4px, #fb923c 4px 8px); }
.rwday-bar .d-now { position:absolute; top:-2px; bottom:-2px; width:2px; background:var(--text); border-radius:2px; }
.rwday-lab { position:relative; height:16px; font-size:11px; color:var(--muted); }
.rwday-lab span { position:absolute; transform:translateX(-50%); white-space:nowrap; }
.rw-next { display:flex; flex-direction:column; gap:4px; margin:4px 0 2px; }
.rw-next small { display:flex; align-items:center; gap:5px; color:var(--muted); font-size:12px; }
.rw-next small ha-icon { --mdc-icon-size:14px; }
.rw-times { display:flex; gap:14px; flex-wrap:nowrap; }
.rw-t { display:flex; flex-direction:column; min-width:0; }
.rw-t small { display:flex; align-items:center; gap:3px; font-size:11px; color:var(--muted); white-space:nowrap; }
.rw-t small ha-icon { --mdc-icon-size:12px; }
.rw-t b { font-size:14px; font-variant-numeric:tabular-nums; white-space:nowrap; }
.rwtop { display:flex; align-items:center; gap:10px; margin-bottom:10px; }
.rwexp { flex:none; display:inline-flex; align-items:center; gap:5px; padding:6px 11px; border-radius:99px; border:1px solid var(--line2); background:var(--card2); color:var(--muted); font:inherit; font-size:12px; cursor:pointer; }
.rwexp.on { color:#fff; background:#8b5cf6; border-color:#8b5cf6; }
.rwex { margin-top:16px; padding:12px; border-radius:14px; border:1px dashed color-mix(in srgb, #8b5cf6 45%, transparent); background:color-mix(in srgb, #8b5cf6 5%, transparent); }
.rwex-h { display:flex; align-items:center; gap:6px; font-size:12px; font-weight:700; color:#8b5cf6; text-transform:uppercase; letter-spacing:.04em; margin-bottom:6px; }
.rwex-h ha-icon { --mdc-icon-size:16px; }
.compass { display:flex; flex-direction:column; align-items:center; gap:4px; margin:4px 0 10px; }
.compass svg { width:min(250px, 100%); height:auto; }
.cp-ring { fill:var(--card2); stroke:var(--line2); stroke-width:1.5; }
.cp-sec { fill:color-mix(in srgb, #f97316 28%, transparent); stroke:#f97316; stroke-width:1.5; }
.cp-win { stroke:#0ea5e9; stroke-width:5; stroke-linecap:round; }
.cp-house { fill:var(--card); stroke:var(--text); stroke-width:1.5; }
.cp-sun { fill:#facc15; stroke:#f59e0b; stroke-width:2; }
.cp-b { cursor:pointer; }
.cp-b circle { fill:var(--card); stroke:var(--line2); stroke-width:1.5; }
.cp-b text { font-size:11px; font-weight:700; text-anchor:middle; fill:var(--text); pointer-events:none; }
.cp-b.on circle { fill:#0ea5e9; stroke:#0ea5e9; }
.cp-b.on text { fill:#fff; }
.rwsent { display:flex; gap:10px; padding:12px 14px; border-radius:16px; background:color-mix(in srgb, #f97316 8%, var(--card2)); border:1px solid color-mix(in srgb, #f97316 25%, transparent); margin-bottom:6px; }
.rwsent > ha-icon { color:#f97316; flex:none; margin-top:4px; }
.rwsent p { margin:0; line-height:2.3; font-size:15px; }
.tok { display:inline-flex; align-items:center; gap:2px; vertical-align:middle; padding:1px 3px; border-radius:99px; background:var(--card); border:1px solid color-mix(in srgb, #f97316 45%, transparent); line-height:1.4; white-space:nowrap; }
.tok b { padding:0 4px; font-weight:700; color:#c2410c; }
.tok.txt { padding:2px 10px; font-weight:700; color:#0369a1; border-color:color-mix(in srgb, #0ea5e9 45%, transparent); }
.tok.warn { color:#b45309; }
.tok-b { all:unset; cursor:pointer; width:24px; height:24px; border-radius:50%; display:grid; place-items:center; font-weight:700; color:var(--muted); background:var(--card2); }
.tok-b:active { background:var(--line2); }
.cwiz-c { padding:12px; border:1px solid var(--line2); border-radius:14px; margin-bottom:10px; }
.cwiz-c > b { display:flex; align-items:center; gap:8px; margin-bottom:6px; }
.cwiz-c > b ha-icon { color:#0ea5e9; }
.cwiz-c select { width:100%; padding:10px 12px; border-radius:12px; border:1px solid var(--line2); background:var(--card); color:var(--text); font:inherit; }
/* Bericht: Heizleistung */
.pw-sum { display:flex; flex-direction:column; gap:3px; margin:0 0 12px; }
.pw-sum small { color:var(--muted); font-size:12px; }
.pw-grid { display:grid; grid-template-columns:repeat(auto-fill, minmax(300px, 1fr)); gap:10px; }
.pw-room { padding:12px 14px; border-radius:16px; border:1px solid var(--line2); border-left:4px solid var(--c); background:var(--card); display:flex; flex-direction:column; gap:8px; }
.pw-h { display:flex; align-items:center; gap:8px; flex-wrap:wrap; }
.pw-h small { color:var(--muted); font-size:12px; }
.pw-v { font-style:normal; display:inline-flex; align-items:center; gap:4px; padding:3px 10px; border-radius:99px; font-size:12px; font-weight:700; color:var(--c); background:color-mix(in srgb, var(--c) 13%, transparent); }
.pw-v ha-icon { --mdc-icon-size:16px; }
.pw-bar { height:6px; border-radius:99px; background:var(--card2); overflow:hidden; }
.pw-bar i { display:block; height:100%; background:var(--c); border-radius:99px; }
.pw-fs { display:flex; flex-wrap:wrap; gap:6px; }
.pw-f { display:flex; flex-direction:column; padding:6px 10px; border-radius:12px; background:var(--card2); min-width:84px; }
.pw-f small { font-size:11px; color:var(--muted); }
.pw-f b { font-size:15px; }
.pw-f i { font-style:normal; font-size:11px; color:#ef4444; }
.pw-list { display:flex; flex-direction:column; gap:6px; }
.pw-i { display:flex; gap:8px; align-items:flex-start; }
.pw-i ha-icon { --mdc-icon-size:18px; flex:none; margin-top:1px; }
.pw-i span { display:flex; flex-direction:column; gap:2px; }
.pw-i small { color:var(--muted); font-size:12.5px; line-height:1.45; }
/* Raum-Assistent */
.wiz-bar { display:flex; gap:4px; margin:-2px 0 16px; overflow-x:auto; scrollbar-width:none; }
.wiz-dot { flex:1; min-width:52px; display:flex; flex-direction:column; align-items:center; gap:4px; border:0; background:none; color:var(--muted); font:inherit; font-size:11px; cursor:pointer; padding:0; }
.wiz-dot i { font-style:normal; width:26px; height:26px; border-radius:50%; display:grid; place-items:center; background:var(--card2); border:1px solid var(--line2); font-weight:700; font-size:12px; }
.wiz-dot.on { color:var(--text); font-weight:600; }
.wiz-dot.on i { background:#fb923c; border-color:#fb923c; color:#fff; }
.wiz-dot.done i { background:color-mix(in srgb, #fb923c 18%, var(--card2)); color:#c2410c; border-color:color-mix(in srgb, #fb923c 40%, transparent); }
.wiz-dot:disabled { opacity:.45; cursor:default; }
.wiz-areas { display:grid; grid-template-columns:repeat(auto-fill, minmax(140px, 1fr)); gap:8px; margin:10px 0 14px; }
.wiz-area { display:flex; flex-direction:column; align-items:flex-start; gap:3px; text-align:left; padding:12px; border-radius:14px; border:1px solid var(--line2); background:var(--card2); color:var(--text); font:inherit; cursor:pointer; }
.wiz-area ha-icon { color:#fb923c; margin-bottom:2px; }
.wiz-area small { color:var(--muted); font-size:12px; }
.wiz-area.on { border-color:#fb923c; background:color-mix(in srgb, #fb923c 12%, var(--card2)); box-shadow:0 0 0 1px #fb923c inset; }
.wiz-area.done { opacity:.55; }
.wiz-type { width:100%; display:flex; align-items:flex-start; gap:12px; text-align:left; padding:14px; margin-bottom:8px; border-radius:14px; border:1px solid var(--line2); background:var(--card2); color:var(--text); font:inherit; cursor:pointer; }
.wiz-type ha-icon { color:#fb923c; flex:none; }
.wiz-type span { display:flex; flex-direction:column; gap:3px; }
.wiz-type small { color:var(--muted); }
.wiz-type.on { border-color:#fb923c; box-shadow:0 0 0 1px #fb923c inset; background:color-mix(in srgb, #fb923c 10%, var(--card2)); }
.wiz-dev { width:100%; display:flex; align-items:center; gap:10px; text-align:left; padding:10px 12px; margin-bottom:6px; border-radius:12px; border:1px solid var(--line2); background:var(--card); color:var(--text); font:inherit; cursor:pointer; }
.wiz-dev > ha-icon { color:var(--muted); flex:none; }
.wiz-dev .grow { display:flex; flex-direction:column; gap:2px; min-width:0; }
.wiz-dev small { color:var(--muted); font-size:12px; overflow:hidden; text-overflow:ellipsis; }
.wiz-dev.on { border-color:color-mix(in srgb, #fb923c 50%, transparent); background:color-mix(in srgb, #fb923c 7%, var(--card)); }
.wiz-dev.on > ha-icon { color:#fb923c; }
.wiz-role { font-style:normal; font-size:12px; padding:4px 10px; border-radius:99px; border:1px solid var(--line2); background:var(--card2); white-space:nowrap; }
.wiz-role.on { background:#fb923c; color:#fff; border-color:#fb923c; }
.wiz-temp { display:flex; align-items:center; gap:10px; }
.wiz-temp b { min-width:64px; text-align:center; font-size:17px; }
.wiz-sum { display:flex; flex-direction:column; gap:2px; margin-bottom:12px; }
.wiz-sum .kv { display:flex; align-items:center; gap:10px; padding:9px 2px; border-bottom:1px solid var(--line2); }
.wiz-sum .kv ha-icon { color:#fb923c; }
.wiz-sum .kv span { flex:1; color:var(--muted); }
/* Entitätsauswahl */
.picker { position:relative; }
.chips { display:flex; flex-wrap:wrap; gap:6px; margin-bottom:8px; }
.echip { display:inline-flex; align-items:center; gap:7px; padding:5px 5px 5px 12px; border-radius:99px; background:color-mix(in srgb, var(--accent) 14%, var(--card2)); border:1px solid color-mix(in srgb, var(--accent) 30%, transparent); font-size:13px; font-weight:500; max-width:100%; }
.echip em { font-style:normal; color:var(--muted); font-size:12px; font-weight:400; }
.echip.missing { background:color-mix(in srgb, #f87171 15%, var(--card2)); border-color:color-mix(in srgb, #f87171 40%, transparent); }
.echip button { all:unset; cursor:pointer; width:22px; height:22px; border-radius:50%; display:grid; place-items:center; color:var(--muted); }
.echip button:hover { background:var(--line2); color:var(--text); }
.search { position:relative; }
.search ha-icon { position:absolute; left:12px; top:50%; transform:translateY(-50%); color:var(--muted); }
.search input { padding-left:38px; }
/* Entitätssuche: gewählte Karten, Vorschläge mit Trefferquote, nach Raum, Filter */
.picker { display:grid; grid-template-columns:minmax(0, 1fr); gap:8px; min-width:0; }
.pk-sel { display:flex; align-items:center; gap:6px; padding:3px 6px 3px 3px; border-radius:16px; border:2px solid color-mix(in srgb, var(--accent) 65%, transparent); background:color-mix(in srgb, var(--accent) 6%, var(--card)); }
.pk-sel.missing { border-color:color-mix(in srgb, #f87171 60%, transparent); }
.pk-sel-b { all:unset; cursor:pointer; flex:1; min-width:0; display:flex; flex-direction:column; gap:2px; padding:8px 10px; }
.pk-sel-b[disabled] { cursor:default; }
.pk-sel-b b { font-size:15px; font-weight:700; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.pk-sel-b small { font-size:12.5px; color:var(--muted); overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.pk-x { all:unset; cursor:pointer; width:36px; height:36px; flex:none; border-radius:10px; display:grid; place-items:center; color:var(--muted); }
.pk-x:hover { background:var(--card2); color:var(--text); }
.pk-add { all:unset; cursor:pointer; justify-self:start; display:inline-flex; align-items:center; gap:6px; color:var(--accent); font-weight:600; font-size:14px; padding:2px; }
.pk-box { display:grid; grid-template-columns:minmax(0, 1fr); min-width:0; gap:10px; padding:12px; border-radius:18px; border:1px solid var(--line2); background:var(--card); }
.pk-tabs { display:grid; grid-template-columns:repeat(3, 1fr); gap:2px; padding:3px; border-radius:14px; border:1px solid var(--line2); }
.pk-tabs button { all:unset; cursor:pointer; text-align:center; padding:9px 4px; border-radius:11px; font-weight:600; font-size:14px; color:var(--muted); }
.pk-tabs button.on { background:var(--accent); color:var(--ink); }
.pk-list { display:grid; gap:8px; }
.pk-card { display:grid; grid-template-columns:minmax(0, 1fr) auto; gap:3px 12px; padding:12px 14px; border-radius:14px; border:1px solid var(--line2); }
.pk-card.sel { border-color:var(--accent); background:color-mix(in srgb, var(--accent) 8%, var(--card)); }
.pk-card b { font-size:15px; overflow-wrap:anywhere; }
.pk-card .pk-v { font-weight:700; font-size:14px; white-space:nowrap; text-align:right; }
.pk-card small { grid-column:1 / -1; color:var(--muted); font-size:12.5px; overflow-wrap:anywhere; }
.pk-why { grid-column:1 / -1; display:flex; align-items:center; flex-wrap:wrap; gap:4px 8px; margin-top:2px; font-size:12.5px; color:var(--muted); }
.pk-why em { font-style:normal; font-weight:800; font-size:12px; padding:1px 8px; border-radius:99px; background:var(--card2); color:var(--text); }
.pk-why em.hi { background:#34d399; color:#04211d; }
.pk-pick { all:unset; cursor:pointer; grid-column:1 / -1; text-align:center; margin-top:8px; padding:9px; border-radius:12px; border:1px solid var(--line2); font-weight:700; font-size:15px; }
.pk-pick:hover { border-color:var(--accent); color:var(--accent); }
.pk-ok { grid-column:1 / -1; text-align:right; margin-top:6px; font-size:13px; color:var(--muted); }
.pk-foot { display:flex; flex-wrap:wrap; align-items:center; gap:6px; font-size:13.5px; color:var(--muted); }
.pk-foot .link { font-size:13.5px; }
.pk-scroll { max-height:340px; overflow:auto; margin-right:-6px; padding-right:6px; }
.pk-group { display:flex; justify-content:space-between; font-size:12px; font-weight:800; letter-spacing:.06em; text-transform:uppercase; color:var(--muted); padding:12px 2px 4px; }
.pk-group span { font-weight:600; letter-spacing:0; }
.pk-row { display:flex; align-items:center; gap:10px; padding:8px 2px; border-top:1px solid var(--line); }
.pk-row .grow { min-width:0; }
.pk-row b { display:block; font-size:14px; font-weight:600; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.pk-row small { display:block; font-size:12px; color:var(--muted); overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.pk-row .pk-v { font-size:13px; font-weight:600; white-space:nowrap; }
.pk-row.bad .pk-v { color:#f87171; }
.pk-mini { all:unset; cursor:pointer; flex:none; padding:6px 12px; border-radius:10px; border:1px solid var(--line2); font-weight:700; font-size:13px; }
.pk-mini:hover { border-color:var(--accent); color:var(--accent); }
.pk-mini.on { cursor:default; border-color:var(--accent); color:var(--accent); }
.pk-chips { display:flex; flex-wrap:wrap; gap:6px; }
.pk-chips button { all:unset; cursor:pointer; padding:6px 12px; border-radius:99px; border:1px solid var(--line2); font-size:13px; font-weight:600; color:var(--muted); }
.pk-chips button.on { color:var(--text); border-color:var(--accent); background:color-mix(in srgb, var(--accent) 14%, var(--card)); }
.pk-empty { padding:10px 2px; color:var(--muted); font-size:13.5px; }
.pk-close { justify-self:end; }
/* Anwesenheit */
.pstate { display:inline-flex; align-items:center; gap:7px; margin-bottom:12px; padding:7px 14px; border-radius:99px; font-weight:700; font-size:14px; color:var(--ct); background:color-mix(in srgb, var(--c) 14%, transparent); }
.pchips { display:flex; flex-wrap:wrap; gap:8px; justify-content:flex-end; }
.pchip { all:unset; cursor:pointer; display:inline-flex; align-items:center; gap:7px; padding:8px 14px; border-radius:99px; font-weight:700; font-size:14px; color:var(--muted); background:var(--card); border:1px dashed var(--line2); }
.pchip i { width:9px; height:9px; border-radius:50%; background:var(--line2); }
.pchip.on { color:var(--text); border:1px solid transparent; background:color-mix(in srgb, #f59e0b 14%, var(--card)); }
.pchip.on i { background:#f59e0b; }
.pchip.on.home { --c:#14b8a6; color:var(--ct); background:color-mix(in srgb, #14b8a6 16%, var(--card)); }
.pchip.on.home i { background:#14b8a6; }
.pchip[disabled] { cursor:default; }
.mstep { display:inline-flex; align-items:center; gap:4px; padding:4px; border-radius:99px; background:var(--card); border:1px solid var(--line); }
.mstep button { all:unset; cursor:pointer; width:38px; height:38px; border-radius:50%; display:grid; place-items:center; font-size:20px; font-weight:700; color:var(--accent); background:color-mix(in srgb, var(--accent) 12%, transparent); }
.mstep button[disabled] { cursor:default; opacity:.5; }
.mstep b { min-width:72px; text-align:center; font-size:16px; }
@media (max-width:600px) {
  .wxr.ctl .pchips { justify-content:flex-start; }
}
.pick-list { position:absolute; left:0; right:0; top:100%; margin-top:6px; max-height:270px; overflow:auto; z-index:10; background:var(--card2); border:1px solid var(--line2); border-radius:14px; box-shadow:0 16px 40px rgba(0,0,0,.5); padding:4px; }
.pick-item { all:unset; cursor:pointer; display:flex; flex-direction:column; padding:9px 12px; width:100%; box-sizing:border-box; border-radius:10px; }
.pick-item:hover { background:color-mix(in srgb, var(--accent) 14%, transparent); }
.pick-item small { color:var(--muted); font-size:11px; }
.pick-empty { padding:12px; color:var(--muted); }

/* Dialog */
.backdrop { position:fixed; inset:0; background:rgba(0,0,0,.6); backdrop-filter:blur(3px); z-index:20; }
.sheet { position:fixed; z-index:21; top:50%; left:50%; transform:translate(-50%,-50%); width:min(660px, calc(100vw - 24px)); max-height:calc(100vh - 40px);
  display:flex; flex-direction:column; background:var(--card); border:1px solid var(--line2); border-radius:24px; box-shadow:0 30px 80px rgba(0,0,0,.6); color:var(--text);
  font-family:Inter, "SF Pro Text", "Segoe UI", Roboto, system-ui, sans-serif; }
.sheet { height:min(780px, calc(100vh - 40px)); }
@supports (height:100dvh) { .sheet { max-height:calc(100dvh - 40px); height:min(780px, calc(100dvh - 40px)); } }
.sheet-head { display:flex; align-items:center; gap:14px; padding:20px 24px 12px; }
.sheet-head h2 { margin:0 0 2px; font-size:20px; }
.rr-ic.big { width:46px; height:46px; border-radius:14px; }
.rr-ic.big ha-icon { --mdc-icon-size:26px; }
.sheet-body { padding:16px 24px 8px; overflow:auto; flex:1; }
.dtabs { display:flex; gap:4px; padding:0 18px; border-bottom:1px solid var(--line); overflow-x:auto; scrollbar-width:none; flex:none; }
.dtab { all:unset; cursor:pointer; position:relative; flex:none; display:inline-flex; align-items:center; gap:7px; padding:11px 10px 12px; color:var(--muted); font-weight:600; font-size:13px; border-bottom:2px solid transparent; margin-bottom:-1px; }
.dtab:hover { color:var(--text); }
.dtab.on { color:var(--text); border-bottom-color:var(--accent); }
.dtab.on ha-icon { color:var(--accent); }
.dtab i { position:absolute; top:8px; left:24px; width:7px; height:7px; border-radius:50%; background:var(--accent); }
.icons { display:flex; flex-wrap:wrap; gap:6px; }
.ic-pick { all:unset; cursor:pointer; position:relative; width:42px; height:42px; display:grid; place-items:center; border-radius:12px; border:1px solid var(--line2); color:var(--muted); }
.ic-pick:hover { color:var(--text); border-color:var(--accent); }
.ic-pick.on { color:var(--accent); border-color:var(--accent); background:color-mix(in srgb, var(--accent) 14%, transparent); }
.ic-pick em { position:absolute; bottom:-7px; font-style:normal; font-size:9px; font-weight:700; background:var(--card); padding:0 3px; border-radius:4px; color:var(--accent); }
.check .ck-ic { --mdc-icon-size:22px; color:var(--muted); align-self:flex-start; margin-top:2px; }
.check > span:first-of-type { flex:1; }
.check:has(input:checked) .ck-ic { color:var(--accent); }
.sheet-foot { display:flex; gap:10px; padding:14px 24px 20px; border-top:1px solid var(--line); }
.sheet-foot .secondary, .sheet-foot .primary { flex:1; }
.types { display:grid; grid-template-columns:1fr 1fr; gap:10px; }
.type { all:unset; cursor:pointer; display:flex; flex-direction:column; gap:5px; padding:14px; border-radius:16px; border:1px solid var(--line2); }
.type ha-icon { --mdc-icon-size:28px; color:var(--muted); }
.type small { color:var(--muted); font-size:12px; line-height:1.4; }
.type.on { border-color:var(--accent); background:color-mix(in srgb, var(--accent) 12%, var(--card)); }
.type.on ha-icon { color:var(--accent); }
details { border-top:1px solid var(--line); padding-top:14px; margin-top:6px; }
summary { cursor:pointer; font-weight:600; margin-bottom:14px; }
/* Hinweise: Glocke, Zeile auf Start, Liste */
.bell { all:unset; cursor:pointer; position:relative; width:42px; height:42px; border-radius:14px; display:grid; place-items:center; color:var(--muted); background:var(--card); border:1px solid var(--line); }
.bell:hover { color:var(--text); border-color:var(--line2); }
.bell ha-icon { --mdc-icon-size:22px; }
.bell.warn { color:#f59e0b; }
.bell em { position:absolute; top:-5px; right:-5px; min-width:18px; height:18px; padding:0 5px; box-sizing:border-box; border-radius:99px; background:#f59e0b; color:#1f1300; font-style:normal; font-size:11px; font-weight:800; display:grid; place-items:center; }
.bell.on { color:var(--accent); border-color:var(--accent); background:color-mix(in srgb, var(--accent) 12%, var(--card)); }
.setintro { display:flex; align-items:center; flex-wrap:wrap; gap:4px; margin:0 2px 12px; }
.bell i { position:absolute; top:7px; right:8px; width:8px; height:8px; border-radius:50%; background:var(--accent); }
.hstrip { all:unset; cursor:pointer; box-sizing:border-box; width:100%; display:flex; align-items:center; gap:10px; padding:10px 14px; margin-bottom:14px; border-radius:14px; font-size:13.5px;
  background:color-mix(in srgb, #f59e0b 12%, var(--card)); border:1px solid color-mix(in srgb, #f59e0b 35%, transparent); }
.hstrip > ha-icon { color:#f59e0b; }
.hstrip .grow { min-width:0; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.hs-go { display:inline-flex; align-items:center; color:var(--accent); font-weight:600; white-space:nowrap; }
.hints { display:grid; gap:6px; }
.hint { all:unset; cursor:pointer; box-sizing:border-box; display:flex; align-items:center; gap:12px; padding:9px 10px; border-radius:14px; border:1px solid var(--line); }
.hint:hover { background:var(--card2); }
.hint[disabled] { cursor:default; }
.hint.warn .sr-ic { --c:#f59e0b; }
.hint.info .sr-ic { --c:#60a5fa; }
/* Startseite: Module und Widgets */
.modtiles { display:grid; grid-template-columns:repeat(auto-fill, minmax(220px, 1fr)); gap:10px; }
.modtile { all:unset; cursor:pointer; box-sizing:border-box; display:flex; align-items:center; gap:12px; padding:12px 14px; border-radius:16px; border:1px solid var(--line2); background:var(--card); min-width:0; }
.modtile:hover { border-color:var(--accent); }
.modtile .mico { width:44px; height:44px; border-radius:14px; display:grid; place-items:center; flex:none; background:color-mix(in srgb, var(--c) 18%, transparent); color:var(--ct); }
.modtile .mico ha-icon { --mdc-icon-size:24px; }
.mt-t { flex:1; min-width:0; display:flex; flex-direction:column; gap:2px; }
.mt-t b { font-size:16px; }
.mt-t small { color:var(--muted); font-size:12.5px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.mt-go { color:var(--muted); }
.modtile.soon { cursor:default; opacity:.45; border-style:dashed; --c:#94a3b8; }
.wgrid { display:grid; grid-template-columns:repeat(auto-fill, minmax(170px, 1fr)); gap:12px; grid-auto-flow:dense; }
.wdg.sz-s { grid-column:span 1; }
.wdg.sz-m { grid-column:span 2; }
.wdg.sz-l { grid-column:1 / -1; }
.wdg.sz-s { padding:12px 13px; }
.wdg.sz-s .wh { margin-bottom:8px; }
.wdg.sz-s .wh .link span { display:none; }
.wdg.sz-s.edit .wh b, .wdg.sz-s.edit .wic { display:none; }
.wline { display:flex; align-items:center; gap:6px; margin-top:6px; font-size:12.5px; font-weight:600; color:var(--ct); --c:var(--muted); min-width:0; }
.wline ha-icon { --mdc-icon-size:15px; flex:none; }
.wsplit { display:grid; grid-template-columns:minmax(0, 1fr) minmax(0, 1.3fr); gap:20px; align-items:start; }
.wrooms { display:grid; gap:2px; }
.wroom { display:flex; align-items:center; gap:8px; padding:6px 8px; border-radius:10px; font-size:13px; }
.wroom:nth-child(odd) { background:var(--card2); }
.wroom > ha-icon { --mdc-icon-size:17px; }
.wroom b { font-weight:600; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; min-width:0; }
.wroom span:not(.grow) { font-weight:700; }
.wroom small { color:var(--muted); }
.wroom .wm { color:var(--c); --mdc-icon-size:16px; }
.wroom .gf { color:#fb923c; --mdc-icon-size:15px; }
.wstate { font-size:18px; font-weight:700; margin-bottom:10px; }
.pqs { display:flex; gap:6px; }
.pq { all:unset; cursor:pointer; flex:1; display:grid; place-items:center; padding:9px 0; border-radius:12px; background:var(--card2); color:var(--muted); }
.pq.on { background:color-mix(in srgb, var(--accent) 18%, var(--card2)); color:var(--accent); }
.pq[disabled] { cursor:default; }
.ppl { display:grid; gap:4px; margin-top:12px; padding-top:10px; border-top:1px solid var(--line); }
.prow { display:flex; align-items:center; gap:10px; padding:5px 0; min-width:0; }
.prow b { display:block; font-size:14px; font-weight:600; }
.prow small { display:flex; align-items:center; gap:4px; color:var(--muted); font-size:12px; }
.prow small ha-icon { --mdc-icon-size:13px; }
.prow.home small { color:var(--ct); --c:#34d399; }
.prow em { font-style:normal; font-weight:700; font-size:14px; white-space:nowrap; }
.pav { position:relative; width:34px; height:34px; border-radius:50%; flex:none; display:grid; place-items:center; overflow:visible; background:var(--card2); border:2px solid var(--line2); font-weight:700; color:var(--muted); }
.pav img { width:100%; height:100%; border-radius:50%; object-fit:cover; }
.prow.home .pav, .pav.home { border-color:#34d399; }
.ppl-s { display:flex; gap:10px; flex-wrap:wrap; margin-top:10px; }
.ppl-s .pav { width:30px; height:30px; font-size:13px; }
.ppl-s .pav em { position:absolute; bottom:-8px; left:50%; transform:translateX(-50%); font-style:normal; font-size:9.5px; font-weight:700; white-space:nowrap; padding:0 4px; border-radius:6px; background:var(--card); color:var(--text); border:1px solid var(--line); }
.wdots { display:flex; flex-wrap:wrap; gap:5px; margin-top:10px; }
.wdots i { width:12px; height:12px; border-radius:4px; }
.gmini.two { grid-template-columns:repeat(2, 1fr); }
.wsc.s { grid-template-columns:repeat(auto-fill, minmax(44px, 1fr)); gap:6px; }
.wsc.s .sc { align-items:center; padding:10px 0; }
.wval b { display:block; font-size:24px; font-weight:800; letter-spacing:-.02em; line-height:1.1; word-break:break-word; }
.wval small { display:block; color:var(--muted); font-size:12px; margin-top:3px; }
.wlist.cols { grid-template-columns:repeat(auto-fill, minmax(240px, 1fr)); column-gap:24px; }
.wlist.cols .wrow:nth-child(-n+3) { border-top:none; }
.wrow.tall .dbar.mini { height:6px; margin-top:5px; }
.hbar { display:block; height:5px; border-radius:99px; background:var(--card2); margin-top:4px; overflow:hidden; }
.hbar i { display:block; height:100%; border-radius:99px; }
.rdot { width:9px; height:9px; border-radius:50%; flex:none; }
.wbar em { font-style:normal; font-size:10.5px; color:var(--muted); }
.fc.tight { grid-auto-columns:minmax(38px, 1fr); }
.fc.tight .fci { padding:5px 0; gap:2px; }
.fc.tight .fci > ha-icon { --mdc-icon-size:21px; }
.wdg { margin:0; padding:14px 16px; display:flex; flex-direction:column; min-width:0; }

.wdg.edit { outline:2px dashed color-mix(in srgb, var(--accent) 60%, transparent); outline-offset:-2px; }
.wh { display:flex; align-items:center; gap:9px; margin-bottom:12px; min-width:0; }
.wh b { font-size:15px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.wic { width:30px; height:30px; border-radius:10px; display:grid; place-items:center; flex:none; background:color-mix(in srgb, var(--c) 16%, transparent); color:var(--ct); }
.wic ha-icon { --mdc-icon-size:18px; }
.wtools { display:inline-flex; gap:2px; }
.wdrag { cursor:grab; touch-action:none; }
.dbar .dpre { background:repeating-linear-gradient(135deg, color-mix(in srgb, var(--pc) 85%, transparent) 0 3px, color-mix(in srgb, var(--pc) 30%, transparent) 3px 6px) !important; opacity:1; }
.xcard { display:flex; align-items:center; gap:12px; width:100%; margin:0 0 12px; padding:12px 14px; border-radius:14px; border:1px solid var(--line); background:var(--card); color:inherit; font:inherit; text-align:left; cursor:pointer; }
.xcard b { display:block; font-size:14px; }
.xcard small { display:block; color:var(--muted); font-size:12px; margin-top:2px; }
.xcard .xc-box { width:22px; height:22px; flex:none; border-radius:6px; border:2px solid var(--muted); display:grid; place-items:center; font-size:15px; font-weight:800; line-height:1; color:#fff; }
.xcard .xc-ic { --mdc-icon-size:20px; color:var(--muted); flex:none; }
.xcard.on { border-color:color-mix(in srgb, var(--accent) 55%, transparent); background:color-mix(in srgb, var(--accent) 8%, var(--card)); }
.xcard.on .xc-box { background:var(--accent); border-color:var(--accent); }
.xcard.on .xc-ic { color:var(--accent); }
.rs-legend { display:flex; flex-wrap:wrap; gap:4px 12px; margin-top:5px; }
.rs-pre, .rs-abs { display:flex; align-items:center; gap:6px; font-size:11.5px; color:var(--muted); }
.rs-abs i { width:14px; height:8px; border-radius:2px; flex:none; background:repeating-linear-gradient(135deg, #64748b 0 3px, color-mix(in srgb, #64748b 30%, transparent) 3px 6px); }
.dbar .dabs { background:repeating-linear-gradient(135deg, color-mix(in srgb, #64748b 92%, transparent) 0 3px, color-mix(in srgb, #94a3b8 45%, transparent) 3px 6px) !important; opacity:1; }
.rs-pre i { width:14px; height:8px; border-radius:2px; background:repeating-linear-gradient(135deg, #fb923c 0 3px, color-mix(in srgb, #fb923c 30%, transparent) 3px 6px); }
.gs-in { margin-bottom:12px; }
.pchips.left { justify-content:flex-start; }
.wiz-lead { margin:0 0 12px; }
.setup-card { display:flex; align-items:center; gap:12px; padding:14px 16px; }
.setup-card b { display:block; } .setup-card small { display:block; color:var(--muted); font-size:12.5px; }
.setup-prog { height:6px; border-radius:99px; background:var(--card2); margin-top:8px; overflow:hidden; }
.setup-prog i { display:block; height:100%; background:#2dd4bf; border-radius:99px; }
.setup-list { display:grid; gap:6px; margin:10px 0; }
.setup-list .srow { width:100%; }
.srow.static { cursor:default; }
.pchip.static { cursor:default; }
.setup-done { text-align:center; display:flex; flex-direction:column; align-items:center; gap:6px; margin:6px 0 10px; }
.setup-done > ha-icon { --mdc-icon-size:44px; color:#22c55e; }
.setup-done h2 { margin:0; } .setup-done p { margin:0; color:var(--muted); }
.gs-g { margin-bottom:10px; }
.gs-g .srow { width:100%; }
.gs-quick { display:flex; flex-wrap:wrap; gap:8px; margin-top:8px; }
.gs-quick .chip { all:unset; cursor:pointer; display:inline-flex; align-items:center; gap:6px; padding:7px 12px; border-radius:99px; border:1px solid var(--line); font-size:13px; font-weight:600; }
.gs-quick .chip:hover { border-color:var(--accent); }
.gs-quick .chip ha-icon { --mdc-icon-size:16px; color:var(--accent); }
kbd { font:600 11px/1 ui-monospace, monospace; padding:2px 6px; border-radius:5px; border:1px solid var(--line2); }
.wdg.dragging { opacity:.55; transform:scale(.98); box-shadow:0 12px 30px rgba(0,0,0,.25); z-index:2; }
.whint { display:flex; align-items:center; gap:6px; margin:-4px 0 10px; }
.whint ha-icon { --mdc-icon-size:16px; }
@media (pointer: coarse) { .wtools .wmv { display:none; } }
.wcat-i.on { border-color:var(--c); background:color-mix(in srgb, var(--c) 7%, var(--card2)); }
.wprev { display:grid; gap:10px; padding:10px 4px 14px; }
.wprev .segs { grid-template-columns:repeat(3, minmax(0, 1fr)); gap:6px; }
.wprev-g { pointer-events:none; }
.wprev-g .wdg { box-shadow:none; border:1px solid var(--line); }
.wprev > .primary { justify-self:stretch; justify-content:center; }
.wtools .icon[disabled] { opacity:.3; cursor:default; }
.danger-t { color:#f87171; }
.wb { flex:1; min-width:0; }
.wb .presence { margin:0; }
.wlink { all:unset; cursor:pointer; display:flex; align-items:center; gap:6px; margin-top:6px; font-size:12.5px; font-weight:600; color:var(--ct); }
.wmore { margin-top:8px; }
.wbtns { display:flex; gap:8px; margin-top:10px; flex-wrap:wrap; }
.wbtns button { flex:1; justify-content:center; }
.wverd { display:inline-flex; align-items:center; gap:4px; font-style:normal; font-size:12px; font-weight:700; color:var(--ct); white-space:nowrap; padding:3px 8px; border-radius:99px; background:color-mix(in srgb, var(--c) 14%, transparent); }
.wverd ha-icon { --mdc-icon-size:14px; }
.wtime { font-style:normal; font-weight:800; font-size:15px; min-width:48px; }
.wtl { margin-bottom:8px; }
.wtl small { display:block; color:var(--muted); font-size:11px; margin-bottom:2px; }
.wbig { display:flex; align-items:center; justify-content:space-between; gap:10px; flex-wrap:wrap; }
.wbig > span:first-child { font-size:38px; font-weight:800; letter-spacing:-.03em; line-height:1; }
.wbig small { font-size:15px; font-weight:500; color:var(--muted); margin-left:3px; }
.wverdict { display:inline-flex; align-items:center; gap:6px; padding:6px 11px; border-radius:99px; font-size:13px; font-weight:600; color:var(--ct); background:color-mix(in srgb, var(--c) 14%, transparent); }
.wminis { display:grid; grid-template-columns:repeat(3, 1fr); gap:8px; margin-top:12px; }
.wmini { display:flex; flex-direction:column; align-items:flex-start; gap:1px; padding:8px 10px; border-radius:12px; background:var(--card2); }
.wmini ha-icon { --mdc-icon-size:16px; color:var(--muted); }
.wmini b { font-size:17px; }
.wmini small { font-size:11.5px; color:var(--muted); }
.wwx { display:flex; align-items:center; gap:14px; }
.wwx > ha-icon { --mdc-icon-size:48px; color:#f59e0b; }
.wwx b { display:block; font-size:30px; font-weight:800; letter-spacing:-.02em; }
.wwx span { color:var(--muted); font-size:14px; }
.wsc { display:grid; grid-template-columns:repeat(auto-fill, minmax(110px, 1fr)); gap:8px; }
.sc { all:unset; cursor:pointer; box-sizing:border-box; display:flex; flex-direction:column; gap:4px; padding:10px 12px; border-radius:14px; background:var(--card2); border:1px solid transparent; min-width:0; }
.sc ha-icon { --mdc-icon-size:22px; color:var(--muted); }
.sc span { font-size:13px; font-weight:600; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.sc small { font-size:11px; color:var(--muted); }
.sc:hover { border-color:var(--line2); }
.sc.on { background:color-mix(in srgb, #f59e0b 16%, var(--card2)); }
.sc.on ha-icon { color:#f59e0b; }
.sc.missing { opacity:.5; }
.wok { display:flex; align-items:center; gap:8px; color:var(--muted); font-size:14px; }
.wok ha-icon { color:#34d399; }
.wok[style] ha-icon { color:var(--c); }
.wlist { display:grid; }
.wrow { display:flex; align-items:center; gap:10px; padding:7px 0; border-top:1px solid var(--line); min-width:0; }
.wrow:first-child { border-top:none; padding-top:0; }
.wrow > ha-icon { --mdc-icon-size:18px; color:var(--muted); }
.wrow b { display:block; font-size:13.5px; font-weight:600; }
.wrow small { display:block; font-size:11.5px; color:var(--muted); white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.wrow .grow { min-width:0; }
.wrow em { font-style:normal; font-size:12.5px; font-weight:600; white-space:nowrap; }
.wrow em.hot { color:var(--ct); --c:#f59e0b; }
.wbars { display:flex; align-items:flex-end; gap:8px; height:110px; }
.wbar { flex:1; height:100%; display:flex; flex-direction:column; justify-content:flex-end; align-items:center; gap:4px; }
.wbar i { width:100%; max-width:34px; border-radius:6px 6px 3px 3px; background:linear-gradient(180deg, #fb923c, color-mix(in srgb, #fb923c 45%, var(--card2))); }
.wbar small { font-size:11px; color:var(--muted); }
.wcat { display:grid; gap:6px; }
.fchints { display:flex; gap:8px; flex-wrap:wrap; margin-bottom:10px; }
.fchint { --c:#94a3b8; display:inline-flex; align-items:center; gap:6px; padding:5px 11px; border-radius:99px; font-size:12.5px; font-weight:600; color:var(--ct); background:color-mix(in srgb, var(--c) 14%, transparent); }
.fchint ha-icon { --mdc-icon-size:15px; }
.fc { display:grid; grid-auto-flow:column; grid-auto-columns:minmax(52px, 1fr); gap:4px; overflow-x:auto; scrollbar-width:thin; padding-bottom:4px; }
.fci { display:flex; flex-direction:column; align-items:center; gap:4px; padding:8px 2px; border-radius:12px; text-align:center; }
.fci:first-child { background:var(--card2); }
.fci > small { font-size:11.5px; color:var(--muted); white-space:nowrap; }
.fci > ha-icon { --mdc-icon-size:26px; color:#f59e0b; }
.fci b { font-size:15px; }
.fci em { font-style:normal; font-size:12.5px; color:var(--muted); }
.fcr { position:relative; width:6px; height:46px; border-radius:99px; background:var(--card2); }
.fci:first-child .fcr { background:var(--line2); }
.fcr i { position:absolute; left:0; right:0; border-radius:99px; background:linear-gradient(0deg, #60a5fa, #fb923c); }
.fcp { display:inline-flex; align-items:center; gap:1px; }
.fcp ha-icon { --mdc-icon-size:12px; }
.fcp.wet { color:#60a5fa !important; font-weight:600; }
.wcat-i { all:unset; cursor:pointer; box-sizing:border-box; display:flex; align-items:center; gap:12px; padding:10px; border-radius:14px; border:1px solid var(--line); }
.wcat-i:hover { border-color:var(--accent); background:var(--card2); }
.sr-t small.wrap { white-space:normal; }
@media (max-width:700px) {
  .wgrid { grid-template-columns:1fr 1fr; gap:10px; }
  .wdg.sz-m, .wdg.sz-l { grid-column:1 / -1; }
  .wsplit { grid-template-columns:1fr; }
  .modtiles { grid-template-columns:1fr 1fr; gap:8px; }
  .modtile { padding:10px; gap:9px; }
  .modtile .mico { width:36px; height:36px; border-radius:11px; }
  .modtile .mt-go { display:none; }
}
/* Banner der Raumübersicht */
.hero { flex-direction:column; align-items:stretch; gap:18px; }
.hero-row { display:flex; align-items:center; gap:22px; position:relative; z-index:1; }
.verdict { display:inline-flex; align-items:center; gap:8px; margin-top:12px; padding:8px 14px; border-radius:99px; font-size:14px; font-weight:600;
  background:color-mix(in srgb, var(--c) 26%, rgba(255,255,255,.08)); border:1px solid color-mix(in srgb, var(--c) 55%, transparent); }
.verdict ha-icon { color:var(--c); filter:brightness(1.3); }
.wx { display:flex; align-items:center; gap:12px; padding:12px 16px; border-radius:18px; background:rgba(255,255,255,.1); backdrop-filter:blur(6px); flex:none; }
.wx > ha-icon { --mdc-icon-size:40px; color:#fde68a; }
.wx b { display:block; font-size:22px; font-weight:700; }
.wx small { display:block; font-size:12px; color:rgba(255,255,255,.8); }
.hstats { display:grid; grid-template-columns:repeat(auto-fit, minmax(128px, 1fr)); gap:8px; position:relative; z-index:1; }
.hstat { display:flex; align-items:center; gap:10px; padding:10px 12px; border-radius:14px; background:rgba(255,255,255,.09); border:1px solid rgba(255,255,255,.1); min-width:0; }
.hstat > ha-icon { --mdc-icon-size:22px; color:var(--c, rgba(255,255,255,.85)); flex:none; }
.hstat span { display:flex; flex-direction:column; min-width:0; }
.hstat small { font-size:11px; color:rgba(255,255,255,.7); text-transform:uppercase; letter-spacing:.04em; }
.hstat b { font-size:16px; font-weight:700; white-space:nowrap; }
.hstat em { font-style:normal; font-size:11.5px; color:rgba(255,255,255,.72); white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
/* Ansicht der Raumkacheln */
.vtog { display:inline-flex; padding:3px; border-radius:12px; background:var(--card); border:1px solid var(--line); margin-right:6px; }
.vtog button { all:unset; cursor:pointer; display:inline-flex; align-items:center; gap:6px; padding:6px 10px; border-radius:9px; font-size:13px; font-weight:600; color:var(--muted); }
.vtog button.on { background:color-mix(in srgb, var(--accent) 16%, var(--card)); color:var(--text); }
.vtog button.on ha-icon { color:var(--accent); }
/* Zeitplan in der Raumkarte */
.rsched { margin:0 0 12px; padding:9px 11px 10px; border-radius:12px; background:var(--card2); }
.rs-top { display:flex; align-items:center; gap:7px; font-size:12.5px; margin-bottom:7px; min-width:0; }
.rs-top > ha-icon { --mdc-icon-size:15px; color:var(--muted); }
.rs-src { color:var(--muted); white-space:nowrap; overflow:hidden; text-overflow:ellipsis; min-width:0; }
.rs-top b { font-weight:600; white-space:nowrap; }
.rsched.on .rs-top b { color:var(--ct); --c:#f59e0b; }
.rsched .dbar.mini { height:8px; }
/* Kompakte Raumkacheln */
.rooms.compact { grid-template-columns:repeat(auto-fill, minmax(210px, 1fr)); gap:10px; }
.room.tap, .rmini.tap { cursor:pointer; }
.room.tap:active, .rmini.tap:active { transform:scale(.99); }
.rq-facts { display:flex; flex-wrap:wrap; gap:8px; margin-bottom:12px; }
.rq-facts span { display:inline-flex; align-items:center; gap:5px; padding:6px 10px; border-radius:99px; background:var(--card2); font-size:13px; font-weight:600; }
.rq-facts ha-icon { --mdc-icon-size:17px; color:var(--c); }
.rq-temp { display:grid; justify-items:center; gap:10px; padding:16px; border-radius:18px; background:var(--card2); margin-bottom:14px; }
.rq-temp > small { color:var(--muted); font-weight:600; }
.rq-temp .stepper { transform:scale(1.25); margin:8px 0; }
.rq-quick { display:flex; gap:8px; flex-wrap:wrap; justify-content:center; }
.segs.small.rq-dur { display:grid; grid-template-columns:repeat(5, minmax(0, 1fr)); gap:6px; }
.segs.small.rq-dur .seg { padding:10px 2px; font-size:12.5px; white-space:nowrap; }
.rw-sum-h { display:flex; align-items:flex-start; justify-content:space-between; gap:12px; flex-wrap:wrap; }
.rw-sum-h h2 { margin:2px 0 0; font-size:22px; }
.rw-all { display:flex; gap:8px; }
.kv2s { display:grid; grid-template-columns:repeat(auto-fit, minmax(150px, 1fr)); gap:8px; margin-top:14px; }
.kv2 { display:flex; align-items:center; gap:10px; background:var(--card2); border-radius:14px; padding:10px 12px; }
.kv2 > ha-icon { color:var(--c, var(--accent)); --mdc-icon-size:22px; }
.kv2 span { display:flex; flex-direction:column; }
.kv2 b { font-size:15px; }
.kv2 small { color:var(--muted); font-size:12px; }
.rw-area h3 { margin:18px 4px 8px; font-size:15px; color:var(--muted); font-weight:700; }
.rw-grid { display:grid; grid-template-columns:repeat(auto-fill, minmax(280px, 1fr)); gap:12px; }
.rw-c { padding:14px; display:flex; flex-direction:column; gap:10px; margin:0; }
.rw-c.bad { opacity:.6; }
.rw-top { display:flex; align-items:center; gap:12px; }
.rw-top .grow { display:flex; flex-direction:column; min-width:0; }
.rw-top b { font-size:15.5px; }
.rw-top small { color:var(--muted); font-size:12.5px; }
.rw-flags { display:flex; flex-wrap:wrap; gap:6px; }
.rw-flags span { display:inline-flex; align-items:center; gap:5px; font-size:12px; font-weight:600; padding:3px 9px; border-radius:99px; color:var(--c); background:color-mix(in srgb, var(--c) 14%, var(--card)); }
.rw-flags ha-icon { --mdc-icon-size:15px; }
.rw-ctl { display:flex; align-items:center; gap:8px; }
.rw-ctl .sbtn { width:40px; height:40px; flex:none; }
.rw-ctl .sbtn ha-icon { --mdc-icon-size:20px; }
.rw-c[data-action] { cursor:pointer; }
.rw-c[data-action]:hover { border-color:color-mix(in srgb, var(--accent) 45%, var(--line)); }
.rw-h { margin-left:auto; display:flex; align-items:center; gap:6px; font-size:13px; color:var(--muted); white-space:nowrap; min-width:0; }
.rw-c .rw-ctl { flex-wrap:wrap; row-gap:8px; }
.rw-h ha-icon { --mdc-icon-size:18px; }
.rw-h b { color:var(--text, inherit); font-size:15px; font-variant-numeric:tabular-nums; }
.rwpos { display:flex; gap:18px; align-items:stretch; margin:4px 0 14px; }
.rwwin { --v:50; position:relative; width:150px; height:220px; flex:none; border-radius:12px; border:6px solid color-mix(in srgb, var(--muted) 45%, var(--card)); background:color-mix(in srgb, var(--card) 70%, #bae6fd); overflow:hidden; cursor:ns-resize; touch-action:none; user-select:none; }
.rwwin.off { opacity:.5; cursor:not-allowed; }
.rwwin-glass { position:absolute; inset:0; background:linear-gradient(160deg, #e0f2fe, #bae6fd 55%, #7dd3fc); }
.rwwin-glass::before { content:""; position:absolute; left:50%; top:0; bottom:0; width:4px; margin-left:-2px; background:color-mix(in srgb, var(--muted) 45%, var(--card)); }
.rwwin-sh { position:absolute; left:0; right:0; top:0; height:calc((100 - var(--v)) * 1%); background:repeating-linear-gradient(180deg, #94a3b8 0 9px, #64748b 9px 11px); transition:height .15s; }
.rwwin-sh i { position:absolute; left:0; right:0; bottom:-8px; height:8px; background:#475569; border-radius:0 0 3px 3px; }
.rwwin-mark { position:absolute; right:0; width:12px; height:2px; top:calc((100 - var(--m)) * 1%); background:var(--accent); box-shadow:0 0 0 1px #fff; }
.rwwin-val { position:absolute; left:50%; bottom:10px; transform:translateX(-50%); padding:3px 9px; border-radius:999px; background:rgba(15,23,42,.72); color:#fff; font-weight:700; font-size:14px; }
.rwpos-side { display:flex; flex-direction:column; justify-content:space-between; gap:12px; min-width:0; }
.rwpos-now b { display:block; font-size:18px; }
.rwpos-now small { display:block; color:var(--muted); margin-top:4px; }
.rwpos-btns { display:flex; flex-direction:column; gap:8px; align-items:flex-start; }
.rwpre { display:grid; grid-template-columns:repeat(auto-fill, minmax(140px, 1fr)); gap:8px; margin-bottom:12px; }
.rwpre-b { display:flex; align-items:center; gap:8px; padding:10px 12px; border-radius:12px; border:1px solid var(--line); background:var(--card); color:inherit; font:inherit; cursor:pointer; text-align:left; }
.rwpre-b > span { flex:1; min-width:0; display:flex; flex-direction:column; }
.rwpre-n { overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.rwpre-b b { font-variant-numeric:tabular-nums; font-size:13px; color:var(--muted); }
.rwpre-b.on b { color:var(--accent); }
.rwpre-b ha-icon { --mdc-icon-size:20px; color:var(--muted); }
.rwpre-b.on { border-color:var(--accent); background:color-mix(in srgb, var(--accent) 10%, var(--card)); }
.rwpre-b.on ha-icon { color:var(--accent); }
.segs.small.rw-fac { display:grid; grid-template-columns:repeat(9, minmax(0, 1fr)); gap:4px; }
.segs.small.rw-fac .seg { padding:8px 0; font-size:12.5px; justify-content:center; }
.rwsug { padding:12px 14px; margin:4px 0 12px; border-radius:16px; background:color-mix(in srgb, #eab308 9%, var(--card)); border:1px solid color-mix(in srgb, #eab308 40%, transparent); }
.rwsug.ok { background:color-mix(in srgb, #22c55e 8%, var(--card)); border-color:color-mix(in srgb, #22c55e 40%, transparent); }
.rwsug-h { display:flex; align-items:center; gap:8px; }
.rwsug-h ha-icon { color:#ca8a04; }
.rwsug.ok .rwsug-h ha-icon { color:#16a34a; }
.rwsug p { margin:6px 0 8px; font-size:13px; line-height:1.45; color:var(--muted); }
.rwsug-v { display:flex; flex-wrap:wrap; gap:6px; margin-bottom:8px; }
.rwsug-v span { padding:3px 9px; border-radius:99px; background:var(--card2); font-size:12px; font-weight:600; }
.rwhint { display:inline-block; margin:0 4px; padding:0 7px; border-radius:99px; font-size:11px; line-height:1.6; color:#a16207; background:color-mix(in srgb, #eab308 15%, transparent); vertical-align:middle; }
.lg-logo { display:inline-flex; flex:none; width:18px; height:18px; }
.lg-logo .mlogo { width:18px; height:18px; border-radius:5px; filter:none; }
.lg-logo svg { width:18px; height:18px; }
.rwdel { padding:12px 14px; margin-bottom:12px; border-radius:14px; border:1px solid color-mix(in srgb, #ef4444 45%, transparent); background:color-mix(in srgb, #ef4444 8%, var(--card)); }
.rwdel > b { display:flex; align-items:center; gap:8px; color:#dc2626; margin-bottom:8px; }
.rwdel select { width:100%; padding:10px 12px; border-radius:12px; border:1px solid var(--line2); background:var(--card); color:var(--text); font:inherit; }
.rwdel-b { display:flex; gap:8px; justify-content:flex-end; margin-top:10px; }
.danger-bg { background:#dc2626 !important; border-color:#dc2626 !important; color:#fff !important; }
button.icon.danger ha-icon { color:#dc2626; }
.rwchecks { display:flex; flex-direction:column; gap:4px; margin:6px 0 10px; }
.rwck { display:flex; align-items:flex-start; gap:10px; text-align:left; padding:9px 10px; border-radius:12px; border:1px solid var(--line2); background:var(--card); color:var(--text); font:inherit; cursor:pointer; }
.rwck ha-icon { --mdc-icon-size:20px; color:var(--muted); flex:none; }
.rwck.on { border-color:color-mix(in srgb, var(--accent) 45%, transparent); background:color-mix(in srgb, var(--accent) 8%, var(--card)); }
.rwck.on ha-icon { color:var(--accent); }
.rwchips { margin:4px 0 8px; }
.rwchips .chip { display:inline-flex; align-items:center; gap:6px; padding:6px 12px; border-radius:99px; border:1px solid var(--line2); background:var(--card2); color:var(--text); font:inherit; font-size:13px; cursor:pointer; }
.rwchips .chip.on { background:color-mix(in srgb, var(--accent) 16%, var(--card2)); border-color:color-mix(in srgb, var(--accent) 45%, transparent); font-weight:600; }
.rwsecs { display:flex; gap:6px; overflow-x:auto; margin:0 -4px 14px; padding:2px 4px 6px; scrollbar-width:none; }
.rwsecs::-webkit-scrollbar { display:none; }
.rwsec { flex:none; display:inline-flex; align-items:center; gap:6px; padding:7px 12px; border-radius:99px; border:1px solid var(--line2); background:var(--card2); color:var(--text); font:inherit; font-size:13px; cursor:pointer; white-space:nowrap; }
.rwsec ha-icon { --mdc-icon-size:16px; color:var(--c); }
.rwsec.on { background:color-mix(in srgb, var(--c) 18%, var(--card2)); border-color:color-mix(in srgb, var(--c) 50%, transparent); font-weight:600; }
.rwsec.off { opacity:.55; }
select.rwsel { width:100%; padding:10px 12px; border-radius:12px; border:1px solid var(--line2); background:var(--card); color:var(--text); font:inherit; }
button.danger { color:#ef4444; }
select[data-rwc] { width:100%; padding:10px 12px; border-radius:12px; border:1px solid var(--line2); background:var(--card); color:var(--text); font:inherit; }
@media (max-width:600px) { .rw-grid { grid-template-columns:1fr; } .segs.small.rw-fac { grid-template-columns:repeat(5, minmax(0, 1fr)); } }
.mlogo { display:inline-flex; width:24px; height:24px; flex:none; border-radius:7px; filter:drop-shadow(0 1px 2px rgba(0,0,0,.18)); }
.mlogo svg { width:100%; height:100%; display:block; }
/* Kraftwerk */
.rwname { margin-bottom:10px; }
.hw-fail { text-align:center; display:flex; flex-direction:column; align-items:center; gap:8px; padding:24px 18px; }
.hw-fail > ha-icon { --mdc-icon-size:40px; color:#ef4444; }
.hw-fail h2 { margin:0; }
.hw-fail p { margin:0; max-width:520px; }
.hw-fail code { display:block; max-width:100%; overflow-wrap:anywhere; padding:8px 12px; border-radius:10px; background:color-mix(in srgb, #ef4444 10%, var(--card2)); font-size:12.5px; }
.hw-fail-b { display:flex; flex-wrap:wrap; gap:8px; justify-content:center; margin:6px 0; }
.hw-fail.small { flex-direction:row; text-align:left; padding:6px 0; gap:10px; }
.hw-fail.small > ha-icon { --mdc-icon-size:22px; }
.hw-fail.small b { display:block; font-size:13px; } .hw-fail.small small { display:block; color:var(--muted); font-size:11.5px; overflow-wrap:anywhere; }
.hw-errtext { width:100%; box-sizing:border-box; font:12px/1.4 ui-monospace, monospace; }
.cwiz-name { margin:4px 0 10px 36px; }
.mlogo.big { width:56px; height:56px; border-radius:16px; margin-bottom:6px; }
.kwd { position:relative; width:100%; max-width:440px; margin:4px auto 8px; aspect-ratio:300 / 252; }
.kwd svg { position:absolute; inset:0; width:100%; height:100%; overflow:visible; }
.kwd .kl-base { fill:none; stroke:var(--line2); stroke-width:2; }
.kwd .kl { fill:none; stroke:var(--c); stroke-width:3.2; stroke-linecap:round; stroke-dasharray:0.1 14; opacity:0; }
.kwd .kl.on { opacity:1; animation:kwrun var(--d, 3s) linear infinite; }
@keyframes kwrun { from { stroke-dashoffset:28.2; } to { stroke-dashoffset:0; } }
@media (prefers-reduced-motion: reduce) { .kwd .kl.on { animation:none; stroke-dasharray:none; opacity:.7; } }
.kn { position:absolute; transform:translate(-50%, -50%); display:flex; flex-direction:column; align-items:center; gap:3px; text-align:center; }
.kn-c { width:86px; height:86px; border-radius:50%; display:flex; flex-direction:column; align-items:center; justify-content:center; gap:1px; background:var(--card);
  border:3px solid color-mix(in srgb, var(--c) 70%, transparent); box-shadow:0 0 0 6px color-mix(in srgb, var(--c) 10%, transparent); }
.kn-c ha-icon { --mdc-icon-size:24px; color:var(--c); }
.kn-c b { font-size:14px; font-weight:800; letter-spacing:-.01em; white-space:nowrap; }
.kn small { font-size:11.5px; color:var(--muted); white-space:nowrap; font-weight:600; }
.kn-grid.exp { --c:#10b981 !important; }
.kn-home .kn-c { width:96px; height:96px; }
.kwd.small .kn-c { width:62px; height:62px; border-width:2px; box-shadow:none; }
.kwd.small .kn-home .kn-c { width:68px; height:68px; }
.kwd.small .kn-c ha-icon { --mdc-icon-size:18px; }
.kwd.small .kn-c b { font-size:11.5px; }
.kwd.small .kn small { font-size:10px; }
.kw-live { display:inline-flex; align-items:center; gap:6px; font-size:12px; font-weight:700; color:#10b981; }
.kw-live i { width:7px; height:7px; border-radius:50%; background:#10b981; animation:kwpulse 1.6s ease-in-out infinite; }
@keyframes kwpulse { 50% { opacity:.3; } }
.kc { display:grid; gap:10px; }
.kc-row { display:flex; align-items:center; gap:12px; }
.kc-row b { display:block; font-size:13.5px; }
.kc-ic { width:34px; height:34px; border-radius:11px; flex:none; display:grid; place-items:center; background:color-mix(in srgb, #0ea5e9 13%, transparent); color:#0ea5e9; }
.kc-ic ha-icon { --mdc-icon-size:19px; }
.kc-row.rest .kc-ic { background:var(--card2); color:var(--muted); }
.kwnames { display:grid; gap:8px; margin:6px 0 8px; }
.kwname { display:flex; align-items:center; gap:10px; }
.kwname input { width:100%; box-sizing:border-box; }
.kwname small { display:block; color:var(--muted); font-size:11px; margin-top:3px; overflow-wrap:anywhere; }
.kc-bar { display:block; height:7px; border-radius:99px; background:var(--card2); margin-top:4px; overflow:hidden; }
.kc-bar i { display:block; height:100%; border-radius:99px; background:#0ea5e9; }
.kc-row.rest .kc-bar i { background:var(--muted); opacity:.5; }
.kc-row em { font-style:normal; font-weight:800; font-size:14px; white-space:nowrap; text-align:right; }
.kc-row em small { display:block; font-weight:600; font-size:11px; color:var(--muted); }
.kks { display:grid; grid-template-columns:repeat(auto-fill, minmax(132px, 1fr)); gap:8px; }
.kk { display:flex; flex-direction:column; gap:1px; padding:10px 12px; border-radius:14px; background:color-mix(in srgb, var(--c) 9%, var(--card2)); }
.kk ha-icon { --mdc-icon-size:20px; color:var(--c); margin-bottom:2px; }
.kk b { font-size:17px; font-weight:800; letter-spacing:-.01em; }
.kk small { font-size:11.5px; color:var(--muted); }
.kk em { font-style:normal; font-size:11.5px; font-weight:700; color:var(--ct); margin-top:3px; }
.kw-range { margin:0 0 12px; display:flex; flex-wrap:nowrap; }
.kw-range .seg { flex:1; padding-left:4px; padding-right:4px; white-space:nowrap; }
.kbars { display:flex; align-items:stretch; gap:3px; height:190px; padding-top:6px; }
.kb { flex:1; min-width:0; display:flex; flex-direction:column; align-items:stretch; }
.kb-up { flex:3; display:flex; flex-direction:column-reverse; justify-content:flex-start; border-bottom:1px solid var(--line2); }
.kb-down { flex:1; display:flex; flex-direction:column; }
.kb i { display:block; border-radius:3px; min-height:1px; }
.kb-up i + i { margin-bottom:1px; }
.kb small { font-size:9.5px; color:var(--muted); text-align:center; margin-top:3px; white-space:nowrap; overflow:hidden; }
.kbars.thin .kb:not(:nth-child(5n+1)) small { visibility:hidden; }
.kb i.s, .klegend i.s { background:#f59e0b; }
.kb i.b, .klegend i.b { background:#ec4899; }
.kb i.g, .klegend i.g { background:#8b5cf6; }
.kb i.e, .klegend i.e { background:#10b981; }
.klegend { display:flex; flex-wrap:wrap; gap:12px; margin:10px 0 4px; font-size:12px; color:var(--muted); }
.klegend span { display:inline-flex; align-items:center; gap:5px; }
.klegend i { width:10px; height:10px; border-radius:3px; }
.kw-hint { display:flex; gap:12px; align-items:flex-start; }
.kw-hint > ha-icon { --mdc-icon-size:26px; color:#10b981; flex:none; }
.kw-hint b { display:block; } .kw-hint small { display:block; color:var(--muted); margin:3px 0 6px; }
.kwsugs { display:grid; gap:8px; margin:12px 0; }
.kwsug { display:flex; align-items:center; gap:10px; padding:10px; border-radius:14px; border:1px solid var(--line); }
.kwsug .sr-ic { --c:inherit; }
.kwsug b { display:block; } .kwsug small { display:block; color:var(--muted); font-size:12px; overflow-wrap:anywhere; }
.kwsug.none { opacity:.6; }
.wminis.four { grid-template-columns:repeat(auto-fit, minmax(70px, 1fr)); }
.mtab .mlogo { width:22px; height:22px; }
.mtab.active .mlogo { filter:drop-shadow(0 1px 3px rgba(0,0,0,.28)); }
.sr-ic.logo { background:none !important; box-shadow:none; }
.sr-ic.logo .mlogo { width:100%; height:100%; border-radius:12px; }
.vh { display:flex; flex-direction:column; gap:6px; margin-top:4px; }
.vh-row { display:grid; grid-template-columns:110px minmax(0, 1fr); gap:10px; align-items:center; }
.vh-name { font-size:13px; font-weight:600; display:flex; flex-direction:column; min-width:0; overflow-wrap:break-word; line-height:1.2; }
.vh-name .rdot { display:none; }
.vh-name small { color:var(--muted); font-weight:500; font-size:11.5px; }
.vh-cells { display:grid; grid-template-columns:repeat(24, minmax(0, 1fr)); gap:2px; }
.vh-cells i { height:22px; border-radius:4px; }
.vh-axis b { font-size:10.5px; color:var(--muted); font-weight:600; }
@media (max-width:600px) { .vh-row { grid-template-columns:78px minmax(0, 1fr); } .vh-cells i { height:18px; border-radius:3px; } }
.roles { display:flex; flex-direction:column; gap:8px; }
.role { background:var(--card2); border-radius:14px; padding:10px 12px; display:flex; flex-direction:column; gap:8px; }
.role-h { display:flex; align-items:center; gap:10px; }
.role-h > ha-icon { --mdc-icon-size:22px; color:var(--accent); }
.role-h .grow { display:flex; flex-direction:column; min-width:0; }
.role-h b { font-size:14.5px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.role-h small { color:var(--muted); font-size:12.5px; }
.role-main { font-style:normal; font-size:12px; font-weight:700; padding:3px 9px; border-radius:99px; background:color-mix(in srgb, var(--accent) 16%, var(--card)); color:var(--accent); white-space:nowrap; }
.role .segs.small { display:grid; grid-template-columns:repeat(3, minmax(0, 1fr)); gap:6px; margin:0; }
.role .segs.small.n2 { grid-template-columns:repeat(2, minmax(0, 1fr)); }
.role .segs.small .seg { padding:8px 4px; font-size:12.5px; white-space:nowrap; justify-content:center; gap:5px; }
.role .segs.small .seg ha-icon { --mdc-icon-size:16px; }
.role-help { margin-top:8px; font-size:13px; color:var(--muted); }
.role-help summary { cursor:pointer; display:inline-flex; align-items:center; gap:6px; color:var(--accent); font-weight:600; list-style:none; }
.role-help summary::-webkit-details-marker { display:none; }
.role-help p { margin:8px 0 0; line-height:1.4; }
.rq-more { display:flex; flex-wrap:wrap; gap:8px; margin-top:16px; }
.rq-more .qbtn { all:unset; cursor:pointer; display:inline-flex; align-items:center; gap:6px; padding:10px 14px; border-radius:12px; background:var(--card2); font-size:13.5px; font-weight:600; color:var(--text); }
.rq-more .qbtn ha-icon { --mdc-icon-size:18px; color:var(--accent); }
.rq-more .qbtn.hot ha-icon { color:#fb923c; }
.rm-dev { display:inline-flex; align-items:center; gap:2px; font-size:11px; font-weight:700; color:var(--muted); }
.rm-dev ha-icon { --mdc-icon-size:16px; }
.rm-dev.on { color:#f97316; }
.rmini { position:relative; overflow:hidden; display:flex; flex-direction:column; gap:8px; padding:12px 12px 12px 15px; border-radius:16px; background:var(--card); border:1px solid var(--line); }
.rmini::before { content:""; position:absolute; left:0; top:0; bottom:0; width:4px; background:var(--rc); }
.rmini.off { opacity:.62; }
.rm-head { display:flex; align-items:center; gap:8px; min-width:0; }
.rm-ic { width:28px; height:28px; border-radius:9px; display:grid; place-items:center; flex:none; background:color-mix(in srgb, var(--rc) 18%, transparent); color:var(--rct); }
.rm-ic ha-icon { --mdc-icon-size:17px; }
.rm-name { flex:1; min-width:0; font-size:15px; line-height:1.25; text-align:left; white-space:normal; overflow-wrap:break-word; hyphens:manual; }
.rm-ind { display:flex; align-items:center; flex-wrap:wrap; gap:8px; min-height:0; }
.rm-ind:empty { display:none; }
.rm-fire { color:#fb923c; --mdc-icon-size:16px; }
.rm-win { color:#22d3ee; --mdc-icon-size:16px; }
.icon.tiny { width:28px; height:28px; }
.icon.tiny ha-icon { --mdc-icon-size:16px; }
.rm-body { display:flex; align-items:flex-end; justify-content:space-between; gap:6px; }
.rm-tgt { display:flex; flex-direction:column; align-items:flex-end; line-height:1.15; }
.rm-tgt small { font-size:11px; color:var(--muted); }
.rm-tgt b { font-size:16px; }
.rm-temp { font-size:28px; font-weight:800; letter-spacing:-.02em; line-height:1; }
.rm-temp small { font-size:13px; font-weight:500; color:var(--muted); margin-left:2px; }
.rm-mode { display:flex; align-items:center; gap:6px; font-size:12px; font-weight:600; color:var(--ct); min-width:0; }
.rm-mode ha-icon { --mdc-icon-size:14px; }
.rm-mode small { color:var(--muted); font-weight:500; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.rmini .dbar.mini { height:6px; }
.link.back { margin:0 0 10px; }
@media (max-width:600px) {
  .hero-row { flex-wrap:wrap; }
  .hero .gauge { display:none; }
  .wx { flex:1 1 100%; }
  .hstats { grid-template-columns:1fr 1fr; }
  .vtog span { display:none; }
  .rooms.compact { grid-template-columns:1fr 1fr; }
  .rm-mode small { display:none; }

}
/* Einstellungen: flache Liste, Details im Pop-up */
.setsearch { margin-bottom:14px; }
.setsearch input { width:100%; }
.sgroup { padding:8px 10px; }
.sg-h { display:flex; align-items:center; gap:8px; padding:8px 10px 6px; font-size:12px; font-weight:800; letter-spacing:.08em; text-transform:uppercase; color:var(--muted); }
.srow { all:unset; cursor:pointer; box-sizing:border-box; width:100%; display:flex; align-items:center; gap:12px; padding:10px; border-radius:14px; }
.srow + .srow { border-top:1px solid var(--line); border-radius:0 0 14px 14px; }
.srow:hover { background:var(--card2); border-radius:14px; }
.srow[disabled] { cursor:default; }
.srow.off { opacity:.6; }
.sr-ic { width:38px; height:38px; border-radius:12px; display:grid; place-items:center; flex:none; background:color-mix(in srgb, var(--c) 16%, transparent); color:var(--ct); }
.sr-ic ha-icon { --mdc-icon-size:21px; }
.sr-ic.big { width:46px; height:46px; border-radius:14px; }
.sr-ic.big ha-icon { --mdc-icon-size:26px; }
.sr-t { flex:1; min-width:0; display:flex; flex-direction:column; gap:2px; }
.sr-t b { font-size:15px; font-weight:600; display:flex; align-items:center; gap:8px; flex-wrap:wrap; }
.sr-t small { color:var(--muted); font-size:12.5px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.srow.warn .sr-t small { color:var(--ct); --c:#f59e0b; }
.sr-go { color:var(--muted); }
.sheet.pop { height:auto; width:min(580px, calc(100vw - 24px)); z-index:23; }
#pop .backdrop { z-index:22; }
.note.warn { --c:#f59e0b; border-radius:12px; display:flex; margin:4px 0 12px; }
.note.ok { --c:#16a34a; border-radius:12px; display:flex; margin:4px 0 12px; }
pre.code { margin:6px 0 10px; padding:10px 14px; border-radius:10px; background:var(--card2, rgba(127,127,127,.12)); font:13px/1.5 ui-monospace, SFMono-Regular, Menlo, monospace; user-select:all; white-space:pre; overflow:auto; }
.evlist { display:grid; gap:6px; margin-bottom:12px; }
.ev { display:flex; align-items:center; gap:10px; padding:9px 12px; border-radius:12px; background:var(--card2); }
.ev > ha-icon { color:var(--muted); }
.ev.live > ha-icon { color:#34d399; }
.ev b { display:block; font-size:14px; font-weight:600; }
.ev small { color:var(--muted); font-size:12px; }
.wide { width:100%; display:flex; align-items:center; justify-content:center; gap:8px; }
/* Heizpläne */
.plangroups { padding:14px 16px 4px; }
.pg { display:flex; align-items:baseline; gap:12px; flex-wrap:wrap; }
.pg + .pg { border-top:1px solid var(--line); padding-top:12px; }
.pg-l { display:inline-flex; align-items:center; gap:6px; min-width:150px; font-size:12px; font-weight:700; letter-spacing:.04em; text-transform:uppercase; color:var(--muted); }
.pg .pills { flex:1; margin-bottom:10px; }
.pill em { font-style:normal; font-size:11px; font-weight:700; padding:0 7px; border-radius:99px; background:var(--card2); color:var(--muted); }
.pill .pi { --mdc-icon-size:14px; color:var(--muted); }
.pill.add { border-style:dashed; color:var(--accent); }
.plan-name { font-size:20px; font-weight:700; width:100%; max-width:420px; margin-bottom:6px; }
.uchip { display:inline-flex; align-items:center; gap:5px; padding:2px 9px; border-radius:99px; background:var(--card2); margin:2px 2px 0 0; }
.uchip i { width:7px; height:7px; border-radius:50%; background:var(--rc); }
.row-btns { display:flex; gap:10px; flex-wrap:wrap; align-items:flex-end; justify-content:center; margin-top:8px; }
.plan-head + p, .plan-head + .row-btns { margin-top:-6px; margin-bottom:14px; }
.card:not(.empty) .row-btns { justify-content:flex-start; }
.inline-sel { margin:0; min-width:240px; text-align:left; }
.empty .inline-sel { max-width:320px; margin:8px auto 0; }
@media (max-width:600px) {
  .pg-l { min-width:0; width:100%; }
  .row-btns > * { flex:1 1 100%; }
}
/* Plakativer Hintergrund je Bereich: Heizen = Glut und aufsteigende Wärme, Start = Zuhause */
:host { background-color:var(--bg); background-image:var(--deco, none); background-attachment:fixed; background-repeat:no-repeat; }
:host([view="heat"]) {
  --deco:radial-gradient(110% 55% at 50% 118%, rgba(249,115,22,.30), transparent 70%),
         radial-gradient(50% 45% at 102% -5%, rgba(239,68,68,.20), transparent 70%),
         radial-gradient(40% 40% at -5% 40%, rgba(251,191,36,.12), transparent 70%),
         url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='160' height='160' viewBox='0 0 160 160'%3E%3Cg fill='none' stroke='%23fb923c' stroke-opacity='0.13' stroke-width='3' stroke-linecap='round'%3E%3Cpath d='M30 150c-14-16 14-28 0-44s14-28 0-44'/%3E%3Cpath d='M80 118c-14-16 14-28 0-44s14-28 0-44'/%3E%3Cpath d='M130 158c-14-16 14-28 0-44s14-28 0-44'/%3E%3C/g%3E%3C/svg%3E");
  background-size:100% 100%, 100% 100%, 100% 100%, 160px 160px; background-repeat:no-repeat, no-repeat, no-repeat, repeat; }
:host([dark][view="heat"]) {
  --deco:radial-gradient(110% 55% at 50% 118%, rgba(249,115,22,.28), transparent 70%),
         radial-gradient(50% 45% at 102% -5%, rgba(239,68,68,.22), transparent 70%),
         radial-gradient(40% 40% at -5% 40%, rgba(251,191,36,.08), transparent 70%),
         url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='160' height='160' viewBox='0 0 160 160'%3E%3Cg fill='none' stroke='%23fb923c' stroke-opacity='0.08' stroke-width='3' stroke-linecap='round'%3E%3Cpath d='M30 150c-14-16 14-28 0-44s14-28 0-44'/%3E%3Cpath d='M80 118c-14-16 14-28 0-44s14-28 0-44'/%3E%3Cpath d='M130 158c-14-16 14-28 0-44s14-28 0-44'/%3E%3C/g%3E%3C/svg%3E"); }
:host([view="start"]) {
  --deco:radial-gradient(60% 50% at 0% 0%, rgba(45,212,191,.22), transparent 70%),
         radial-gradient(55% 50% at 100% 100%, rgba(251,146,60,.18), transparent 70%),
         radial-gradient(rgba(45,212,191,.16) 1.2px, transparent 1.6px);
  background-size:100% 100%, 100% 100%, 22px 22px; background-repeat:no-repeat, no-repeat, repeat; }
:host([dark][view="start"]) {
  --deco:radial-gradient(60% 50% at 0% 0%, rgba(45,212,191,.20), transparent 70%),
         radial-gradient(55% 50% at 100% 100%, rgba(251,146,60,.14), transparent 70%),
         radial-gradient(rgba(45,212,191,.12) 1.2px, transparent 1.6px); }
/* Heizen-Banner: schmal und dezent */
.hero { color:var(--text); padding:14px 18px; gap:12px; border-radius:var(--r); border:1px solid var(--line); box-shadow:none;
  background:linear-gradient(100deg, color-mix(in srgb, #fb923c 10%, var(--card)) 0%, var(--card) 55%); }
.hero::after { display:none; }
.hero .hero-label { color:var(--muted); font-size:12.5px; }
.hero-line { display:flex; align-items:center; gap:14px; flex-wrap:wrap; margin-top:2px; }
.hero .hero-big { font-size:38px; margin-top:0; }
.hero .hero-big span { font-size:16px; color:var(--muted); }
.hero .verdict { margin-top:0; padding:5px 12px; font-size:13px; color:var(--ct); background:color-mix(in srgb, var(--c) 13%, transparent); border-color:color-mix(in srgb, var(--c) 35%, transparent); }
.hero .verdict ha-icon { filter:none; }
.hero .wx { background:var(--card2); padding:8px 12px; border-radius:14px; backdrop-filter:none; }
.hero .wx > ha-icon { --mdc-icon-size:30px; color:#f59e0b; }
.hero .wx b { font-size:17px; }
.hero .wx small { color:var(--muted); }
.hero .hstats { grid-template-columns:repeat(auto-fit, minmax(118px, 1fr)); gap:6px; }
.hero .hstat { background:var(--card2); border:none; padding:7px 10px; border-radius:12px; }
.hero .hstat > ha-icon { --mdc-icon-size:18px; color:var(--ct); --c:var(--muted); }
.hero .hstat[style] > ha-icon { color:var(--ct); }
.hero .hstat small { color:var(--muted); font-size:10.5px; }
.hero .hstat b { font-size:14.5px; }
.hero .hstat em { color:var(--muted); font-size:11px; }
@media (max-width:600px) {
  .hero { padding:12px 14px; }
  .hero .hero-big { font-size:32px; }
}
/* Untere Navigationsleiste (nur Handy) */
.bnav { display:none; }
@media (max-width:600px) {
  .bnav { display:flex; position:fixed; left:0; right:0; bottom:0; z-index:8; padding:6px 8px calc(6px + env(safe-area-inset-bottom)); gap:4px;
    background:color-mix(in srgb, var(--card) 92%, transparent); backdrop-filter:blur(12px); border-top:1px solid var(--line); }
  .bn { all:unset; cursor:pointer; flex:1; display:flex; flex-direction:column; align-items:center; gap:2px; padding:5px 0; border-radius:12px; font-size:11px; font-weight:600; color:var(--muted); }
  .bn .bi { position:relative; display:grid; place-items:center; width:54px; height:28px; border-radius:99px; }
  .bn ha-icon { --mdc-icon-size:22px; }
  .bn .mlogo { width:26px; height:26px; }
  .bn.on { color:var(--text); }
  .bn.on .bi { background:color-mix(in srgb, var(--accent) 18%, transparent); color:var(--accent); }
  .bn em { position:absolute; top:-3px; right:6px; min-width:16px; height:16px; padding:0 4px; box-sizing:border-box; border-radius:99px; font-style:normal; font-size:10px; font-weight:800; display:grid; place-items:center; background:#fb923c; color:#1f1300; }
  .bn em.warn { background:#22d3ee; color:#001b20; }
  .app { padding-bottom:calc(84px + env(safe-area-inset-bottom)); }
  /* Speicherleisten über der unteren Navigationsleiste halten */
  .savebar { bottom:calc(78px + env(safe-area-inset-bottom)); z-index:9; }
  .mtabs { display:none !important; }
  .heatnav { margin-bottom:12px; }
  .hnav { padding:9px 10px; font-size:13px; }
  .top { padding-bottom:6px; }
  :host .top.slim .bar { display:flex; min-height:44px; }
  :host .top.slim .ttl { display:flex; order:2; flex:1; }
  :host .top.slim .ttl b { font-size:15px; }
  :host .top.slim .ttl small { display:none; }
}
/* Raum-Detailseite */
.rlink { all:unset; cursor:pointer; display:block; max-width:100%; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.rlink:hover { color:var(--accent); text-decoration:underline; text-underline-offset:3px; }
.rm-name.rlink, .room-t .rlink { white-space:normal; overflow:visible; text-overflow:clip; overflow-wrap:break-word; hyphens:manual; }
.rpage .room { margin-bottom:14px; }
.rp-grid { display:grid; grid-template-columns:repeat(auto-fit, minmax(300px, 1fr)); gap:14px; }
.rp-grid .card { margin:0; }
.kvs { display:grid; }
.kv { display:flex; justify-content:space-between; gap:12px; padding:8px 0; border-top:1px solid var(--line); font-size:13.5px; }
.kv:first-child { border-top:none; }
.kv span { color:var(--muted); }
.kv b { font-weight:600; text-align:right; }
.wrow em.bad { color:#f87171; }
.wminis.four { grid-template-columns:repeat(2, 1fr); }
.rlegend { display:inline-flex; gap:12px; flex-wrap:wrap; font-size:12px; color:var(--muted); }
.rlegend span { display:inline-flex; align-items:center; gap:5px; }
.rlegend i { display:inline-block; width:14px; height:3px; border-radius:2px; }
.rlegend .lt { background:var(--accent); }
.rlegend .ls { background:repeating-linear-gradient(90deg, #fb923c 0 4px, transparent 4px 7px); }
.rlegend .lh { background:#fb923c; opacity:.55; height:8px; }
.rlegend .lw { background:#22d3ee; opacity:.55; height:8px; }
.chart.hist { height:240px; }
.hwrap { position:relative; }
.hy { position:absolute; left:0; top:0; height:240px; width:6.5%; pointer-events:none; }
.hy span { position:absolute; right:4px; transform:translateY(-50%); font-size:11px; color:var(--muted); }
.hx { display:flex; justify-content:space-between; margin:-18px 0 0 7%; font-size:11px; color:var(--muted); }
@media (max-width:600px) { .chart.hist, .hy { height:190px; } .rlegend { gap:8px; } }
.chart.hist .pt { fill:none; stroke:var(--accent); stroke-width:2.5; vector-effect:non-scaling-stroke; stroke-linejoin:round; }
.chart.hist .ps { fill:none; stroke:#fb923c; stroke-width:2; stroke-dasharray:6 5; vector-effect:non-scaling-stroke; }
.chart.hist .bh { fill:#fb923c; opacity:.45; }
.chart.hist .bw { fill:#22d3ee; opacity:.45; }
/* Kopfzeile beim Scrollen: eine Zeile mit Logo, Reitern und Glocke */
:host { position:relative; }
#sentinel { position:absolute; top:0; left:0; width:1px; height:48px; pointer-events:none; }
.top.slim { display:flex; align-items:center; gap:10px; padding-top:6px; padding-bottom:6px; }
.top.slim .bar { display:contents; }
.top.slim .ttl { display:none; }
.top.slim .menu { order:0; width:34px; height:34px; }
.top.slim .brand { order:1; }
.top.slim .brand svg { width:32px; height:32px; }
.top.slim .mtabs { order:2; flex:1; min-width:0; padding:0; gap:6px; }
.top.slim .mtab { padding:6px 12px; }
.top.slim .mtab > ha-icon { --mdc-icon-size:18px; }
.top.slim .mtab .mlogo { width:18px; height:18px; border-radius:5px; }
.top.slim .mtab .mt b { font-size:14px; }
.top.slim .hacts { order:3; }
.top.slim .bell { width:36px; height:36px; border-radius:12px; }
/* Räume ohne Thermostat */
.room.setup, .rmini.setup { background:transparent; border-style:dashed; box-shadow:none; }
.room.setup::before, .rmini.setup::before { background:var(--line2); }
.room.setup .room-ic, .rmini.setup .rm-ic { opacity:.6; }
.room.setup .room-t small { color:var(--muted); }
.setup-b { display:flex; flex-direction:column; align-items:flex-start; gap:10px; margin-top:14px; }
.setup-b p { display:flex; align-items:center; gap:8px; margin:0; color:var(--muted); font-size:13.5px; }
.setup-b p ha-icon { --mdc-icon-size:20px; }
.setup-b .secondary { display:inline-flex; align-items:center; gap:7px; }
.rmini .setup-b { margin-top:6px; }
.rmini .setup-b .secondary { padding:7px 11px; font-size:13px; }
.wroom.setup { opacity:.6; }
.wroom.setup small { font-style:italic; }
/* Gleichmäßiges Widget-Raster: klein und mittel gleich hoch, groß nach Inhalt */
.wdg.sz-s, .wdg.sz-m { height:236px; }
.wdg .wb { min-height:0; overflow-y:auto; overflow-x:hidden; scrollbar-width:thin; margin-right:-6px; padding-right:6px; }
.wdg.sz-s .wb, .wdg.sz-m .wb { padding-bottom:16px; mask-image:linear-gradient(180deg, #000 calc(100% - 14px), transparent); -webkit-mask-image:linear-gradient(180deg, #000 calc(100% - 14px), transparent); }
@media (max-width:700px) {
  .wdg.sz-s { height:176px; }
  .wdg.sz-m { height:auto; max-height:340px; }
}
/* Experten-Schalter im Raum-Dialog */
.xtog { all:unset; cursor:pointer; flex:none; display:inline-flex; align-items:center; gap:6px; margin:6px 0; padding:5px 10px; border-radius:99px; font-size:12.5px; font-weight:600; color:var(--muted); border:1px solid var(--line2); }
.xtog ha-icon { --mdc-icon-size:16px; }
.xtog i { width:26px; height:14px; border-radius:99px; background:var(--track); position:relative; }
.xtog i::after { content:""; position:absolute; top:2px; left:2px; width:10px; height:10px; border-radius:50%; background:#fff; transition:left .15s; }
.xtog.on { color:var(--accent); border-color:var(--accent); }
.xtog.on i { background:var(--accent); }
.xtog.on i::after { left:14px; }
.xhint { all:unset; cursor:pointer; box-sizing:border-box; width:100%; display:flex; align-items:center; gap:8px; margin-top:18px; padding:10px 12px; border-radius:12px; border:1px dashed var(--line2); color:var(--muted); font-size:13px; }
.xhint:hover { border-color:var(--accent); color:var(--text); }
.xhint > span:not(.grow) { color:var(--text); font-weight:600; }
@media (max-width:600px) { .xtog span { display:none; } }
/* Ruhigere Farben: Raumfarbe nur als Streifen, Symbole einheitlich */
.room-ic, .rm-ic { background:var(--card2) !important; color:var(--text) !important; }
.wic, .sr-ic { --c:var(--accent) !important; }
.hint.warn .sr-ic { --c:#f59e0b !important; }
.hint.info .sr-ic { --c:#60a5fa !important; }
.room-head { gap:8px; }
.room-head .icon { width:34px; height:34px; flex:none; }
.room-t small { flex-wrap:wrap; }
.room-t .sis { display:inline-flex; gap:7px; margin-left:8px; }
.rmenu { border:none !important; padding:0 !important; margin:0 !important; }
.room-head .icon { width:30px; height:30px; }
.room-head .rmenu summary { width:30px; height:30px; }
.room-head .mode { padding:4px 9px; font-size:12px; }
.room-head .mode ha-icon { --mdc-icon-size:14px; }
.room-t .si { display:inline-flex; align-items:center; gap:3px; color:var(--ct); font-size:12px; padding:0; background:none; }
.room-t .si ha-icon { --mdc-icon-size:14px; }
.rmenu { position:relative; flex:none; }
.rmenu summary { list-style:none; display:grid; place-items:center; width:34px; height:34px; border-radius:11px; cursor:pointer; color:var(--muted); }
.rmenu summary::-webkit-details-marker { display:none; }
.rmenu summary:hover, .rmenu[open] summary { background:var(--card2); color:var(--text); }
.rm-pop { position:absolute; right:0; top:calc(100% + 6px); z-index:6; min-width:210px; padding:6px; border-radius:14px; background:var(--card); border:1px solid var(--line2); box-shadow:var(--shadow); display:grid; }
.rm-pop button { all:unset; cursor:pointer; display:flex; align-items:center; gap:10px; padding:9px 10px; border-radius:10px; font-size:14px; }
.rm-pop button:hover { background:var(--card2); }
.rm-pop ha-icon { --mdc-icon-size:18px; color:var(--muted); }
.room .room-note:last-child { margin-bottom:0; }
.room .rsched:last-child { margin-bottom:0; }
@media (max-width:600px) {
  .room-head .mode { max-width:120px; }
}
/* Einheitliche Schrift: Wert groß, Titel, Nebeninfo */
:host { --fs-val:34px; --fs-title:15px; --fs-sub:12.5px; }
.room-temp, .wbig > span:first-child, .wval b, .wwx b, .hero .hero-big, .kpi-v, .rm-temp { font-size:var(--fs-val) !important; letter-spacing:-.02em; }
.rm-temp, .wdg.sz-s .wbig > span:first-child, .wdg.sz-s .wval b, .wdg.sz-s .wwx b { font-size:28px !important; }
.room-t h4, .wh b, .sr-t b, .stit b, .shead h3, .rm-name, .prow b, .wrow b, .mt-t b, .ev b { font-size:var(--fs-title) !important; }
.room-t small, .sr-t small, .wrow small, .prow small, .wmini small, .ev small, .kv, .rs-top, .room-note, .muted.small, .trend, .gm .gl, .rm-mode { font-size:var(--fs-sub) !important; }
.room-temp span, .wbig small, .hero .hero-big span, .rm-temp small { font-size:14px !important; }
/* Darstellung: Himmel nach Tageszeit, schlichter Hintergrund, Größe, Uhrzeit und Wetter oben rechts */
:host {
  --sky-night:radial-gradient(1.5px 1.5px at 12% 30%, #fff, transparent), radial-gradient(1px 1px at 32% 62%, #fffc, transparent),
    radial-gradient(1.5px 1.5px at 58% 22%, #fff, transparent), radial-gradient(1px 1px at 76% 52%, #fffb, transparent),
    radial-gradient(1px 1px at 90% 18%, #fffc, transparent), linear-gradient(165deg, #0b1026 0%, #1b2557 60%, #34386f 100%);
  --sky-dawn:radial-gradient(60% 120% at 80% 120%, rgba(253,186,116,.9), transparent 70%), linear-gradient(165deg, #3b2c5f 0%, #a8507a 60%, #f39b62 100%);
  --sky-day:radial-gradient(18% 60% at 88% 20%, rgba(255,247,200,.95), transparent 70%), linear-gradient(165deg, #3b82f6 0%, #7cb7fb 55%, #cfe6ff 100%);
  --sky-dusk:radial-gradient(60% 120% at 20% 120%, rgba(251,146,60,.9), transparent 70%), linear-gradient(165deg, #251b48 0%, #873c69 60%, #ef8547 100%);
}
:host([sky]) .top { border-bottom-color:transparent; color:var(--text); }
:host([sky="night"]) .top { background:var(--sky-night); }
:host([sky="dawn"]) .top { background:var(--sky-dawn); }
:host([sky="day"]) .top { background:var(--sky-day); }
:host([sky="dusk"]) .top { background:var(--sky-dusk); }
:host([sky="night"]) .top, :host([sky="dawn"]) .top, :host([sky="dusk"]) .top {
  --text:#fff; --muted:rgba(255,255,255,.78); --card:rgba(255,255,255,.13); --line:rgba(255,255,255,.2); --line2:rgba(255,255,255,.35); }
:host([sky="day"]) .top { --text:#0b2545; --muted:rgba(11,37,69,.72); --card:rgba(255,255,255,.6); --line:rgba(255,255,255,.7); --line2:rgba(255,255,255,.9); }
:host([sky]) .top .ttl small { color:var(--text); opacity:.85; }
:host([sky]) .top .mtab, :host([sky]) .top .bell, :host([sky]) .top .hinfo { backdrop-filter:blur(8px); }
:host([bg="plain"]) { background-image:none !important; }
:host([size="s"]) .top, :host([size="s"]) .app, :host([size="s"]) .bnav, :host([size="s"]) .sheet, :host([size="s"]) .toast { zoom:.9; }
:host([size="l"]) .top, :host([size="l"]) .app, :host([size="l"]) .bnav, :host([size="l"]) .sheet, :host([size="l"]) .toast { zoom:1.15; }
.hinfo { display:flex; align-items:center; gap:10px; padding:0 12px; height:42px; box-sizing:border-box; border-radius:14px; background:var(--card); border:1px solid var(--line); font-weight:700; font-size:15px; white-space:nowrap; }
.hwx { display:inline-flex; align-items:center; gap:5px; }
.hwx ha-icon { --mdc-icon-size:20px; color:#f59e0b; }
.hclock { font-variant-numeric:tabular-nums; }
.hclock + .hwx { padding-left:10px; border-left:1px solid var(--line2); }
.top.slim .hinfo { height:36px; border-radius:12px; font-size:13.5px; }
.bell.gear ha-icon { --mdc-icon-size:21px; }
.swatches { display:flex; flex-wrap:wrap; gap:10px; align-items:center; margin-bottom:6px; }
.sw { all:unset; cursor:pointer; position:relative; width:38px; height:38px; border-radius:50%; background:var(--c); box-shadow:inset 0 0 0 1px rgba(0,0,0,.12); display:grid; place-items:center; }
.sw.on { box-shadow:0 0 0 3px var(--card), 0 0 0 5px var(--c); }
.sw.on::after { content:""; width:12px; height:12px; border-radius:50%; background:#fff; box-shadow:0 0 0 2px rgba(0,0,0,.25); }
.sw.custom { background:conic-gradient(#ef4444, #f59e0b, #84cc16, #0ea5e9, #8b5cf6, #ec4899, #ef4444); }
.sw.custom input { position:absolute; inset:0; width:100%; height:100%; opacity:0; cursor:pointer; padding:0; border:none; }
.sw[disabled] { cursor:default; opacity:.6; }
.skies { display:grid; grid-template-columns:repeat(4, 1fr); gap:8px; margin:4px 0 8px; }
.skyc { display:flex; flex-direction:column; gap:4px; min-width:0; }
.skyc small { font-size:12px; font-weight:600; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.sky { position:relative; height:58px; border-radius:12px; border:2px solid transparent; }
.sky.on { border-color:var(--accent); }
.sky em { position:absolute; left:6px; top:5px; font-style:normal; font-size:10px; font-weight:800; padding:1px 7px; border-radius:99px; background:var(--accent); color:var(--ink); }
@media (max-width:600px) {
  .hclock { display:none; }
  .hclock + .hwx { border:none; padding:0; }
  .hinfo { padding:0 9px; height:38px; font-size:14px; }
  .skies { grid-template-columns:repeat(2, 1fr); }
}
/* Wetter: Zeilen mit Wert rechts und Erklärung per „?“ */
.wxrows { display:grid; gap:2px; margin-bottom:6px; }
.wxr { display:flex; align-items:center; gap:14px; padding:12px 14px; border-radius:14px; }
.wxr:nth-child(odd) { background:var(--card2); }
.wxr-l { flex:1; min-width:0; }
.wxr-l b { display:flex; align-items:center; gap:8px; font-size:15px; font-weight:600; }
.wxr-l small { display:block; color:var(--muted); font-size:12.5px; margin-top:2px; line-height:1.35; }
.wxr-h { margin:8px 0 0 !important; font-size:12.5px; line-height:1.45; color:var(--text) !important; padding:8px 10px; border-radius:10px; background:color-mix(in srgb, var(--accent) 10%, var(--card)); }
.wxr-v { flex:none; max-width:55%; text-align:right; font-weight:700; font-size:15px; }
.wxr-v select { max-width:260px; font-weight:600; }
.wxsrcs { display:grid; gap:8px; margin-bottom:6px; }
.wxsrc { background:var(--card2); border-radius:14px; }
.wxr-pk { padding:0 14px 12px; }
.newp { display:flex; gap:8px; align-items:center; margin-top:8px; flex-wrap:wrap; }
.newp input { flex:1; min-width:160px; }
.wxsrc .segs { margin-top:2px; }
.wxsrc .segs.small.n4 { grid-template-columns:repeat(4, minmax(0, 1fr)); gap:6px; }
.wxsrc .segs.small.n4 .seg { padding:9px 4px; font-size:12.5px; gap:4px; }
@media (max-width:420px) { .wxsrc .segs.small.n4 .seg ha-icon { display:none; } }
.nrow { display:flex; align-items:center; gap:10px; justify-content:flex-end; }
.nrow .unit input { width:76px; }
.nrow input[type=time] { width:auto; }
.pk-none { padding:4px 2px; }
.wxr-v .unit { justify-content:flex-end; }
.wxr-v .unit input { width:96px; text-align:right; font-weight:700; }
.wxr-v .link { font-size:15px; }
.qm { all:unset; cursor:pointer; width:22px; height:22px; flex:none; border-radius:50%; border:1.5px solid var(--line2); display:grid; place-items:center; font-size:12px; font-weight:700; color:var(--muted); }
.qm:hover, .qm.on { border-color:var(--accent); color:var(--accent); }
@media (max-width:600px) {
  .wxr { flex-wrap:wrap; gap:8px 12px; }
  .wxr.ctl .wxr-v { width:100%; max-width:none; }
  .wxr.ctl .wxr-v select { max-width:none; width:100%; }
}
/* Protokoll */
.card.lg { padding:20px 22px; }
.lg-head { display:flex; align-items:flex-start; gap:12px; margin-bottom:16px; }
.lg-ic { width:44px; height:44px; flex:none; border-radius:14px; display:grid; place-items:center; background:var(--card2); color:var(--muted); }
.lg-ic ha-icon { --mdc-icon-size:24px; }
.lg-head h2 { margin:0 0 2px; font-size:20px; }
.lg-head small { color:var(--muted); font-size:13px; }
.lg-live { display:inline-flex; align-items:center; gap:6px; font-size:13px; font-weight:600; color:var(--muted); white-space:nowrap; padding-top:4px; font-variant-numeric:tabular-nums; }
.lg-live i { width:10px; height:10px; border-radius:50%; background:var(--line2); }
.lg-live.on i { background:#22c55e; box-shadow:0 0 0 3px color-mix(in srgb, #22c55e 25%, transparent); }
.lg-chips { display:flex; flex-wrap:wrap; gap:8px; margin-bottom:12px; }
.lg-room, .lg-cat { all:unset; cursor:pointer; display:inline-flex; align-items:center; gap:7px; padding:8px 14px; border-radius:99px; font-size:14px; font-weight:600;
  color:var(--muted); background:color-mix(in srgb, var(--c) 7%, var(--card)); border:1px solid color-mix(in srgb, var(--c) 16%, transparent); opacity:.62; }
.lg-room i { width:8px; height:8px; border-radius:50%; background:var(--c); }
.lg-cat ha-icon { --mdc-icon-size:17px; color:var(--ct); }
.lg-room.on, .lg-cat.on { opacity:1; color:var(--text); background:color-mix(in srgb, var(--c) 15%, var(--card)); border-color:color-mix(in srgb, var(--c) 38%, transparent); }
.lg-search { margin:4px 0 6px; }
.lg-day { font-size:12px; font-weight:800; letter-spacing:.08em; text-transform:uppercase; color:var(--muted); padding:18px 0 8px; border-bottom:1px solid var(--line); }
.lg-row { display:grid; grid-template-columns:48px 40px minmax(0, 1fr); gap:12px; padding:12px 0; border-bottom:1px solid var(--line); align-items:start; }
.lg-row time { font-size:13.5px; font-weight:600; color:var(--muted); padding-top:10px; font-variant-numeric:tabular-nums; }
.lg-i { width:40px; height:40px; border-radius:12px; display:grid; place-items:center; background:color-mix(in srgb, var(--c) 15%, transparent); color:var(--ct); }
.lg-i ha-icon { --mdc-icon-size:21px; }
.lg-t { display:flex; flex-wrap:wrap; align-items:center; gap:4px 8px; padding-top:2px; }
.lg-t b { font-size:15px; font-weight:700; }
.lg-badge { font-size:12px; font-weight:600; padding:2px 9px; border-radius:99px; color:var(--ct); background:color-mix(in srgb, var(--c) 14%, transparent); }
.lg-b p { margin:4px 0 0; font-size:13.5px; color:var(--muted); line-height:1.45; overflow-wrap:anywhere; }
.lg-b p b { color:var(--text); font-weight:600; }
.lg-more { margin-top:14px; box-sizing:border-box; }
@media (max-width:600px) {
  .card.lg { padding:14px; }
  .lg-row { grid-template-columns:40px 34px minmax(0, 1fr); gap:10px; }
  .lg-i { width:34px; height:34px; border-radius:10px; }
  .lg-row time { padding-top:7px; font-size:12.5px; }
  .lg-room, .lg-cat { padding:7px 11px; font-size:13px; }
}
.toast { position:fixed; bottom:24px; left:50%; transform:translateX(-50%); background:var(--text); color:var(--bg); padding:11px 20px; border-radius:12px; z-index:30; font-size:14px; font-weight:600; box-shadow:0 10px 30px rgba(0,0,0,.4); }

@media (max-width:820px) {
  .kpis { grid-template-columns:1fr 1fr; }
  .gauge { width:130px; }
  .hero-big { font-size:52px; }
}
@media (max-width:600px) {
  /* unten Platz für die Navigationsleiste lassen, sonst verdeckt sie das Ende der letzten Kachel */
  .app { padding:10px 12px calc(96px + env(safe-area-inset-bottom)); }
  .hmodes { grid-template-columns:1fr; }
  .top { padding:6px 10px 0; }
  .bar { gap:8px; }
  .brand svg { width:36px; height:36px; }
  .ttl b { font-size:16px; }
  .ttl span { display:none; }
  .abtn span { display:none; }
  .abtn { padding:9px; }
  .mtab { padding:8px 12px; gap:8px; }
  .mtiles { grid-template-columns:repeat(2, 1fr); gap:8px; }
  .mtile { padding:12px 8px; gap:4px; }
  .mico { width:38px; height:38px; border-radius:12px; }
  .gmini { grid-template-columns:1fr 1fr; }
  .hl { font-size:22px; }
  .hero { flex-direction:column; align-items:stretch; padding:20px; }
  .gauge { position:absolute; right:10px; top:10px; width:96px; opacity:.95; }
  .hero-big { font-size:46px; }
  .row2, .row3, .types { grid-template-columns:1fr; }
  .rooms { grid-template-columns:1fr; }
  .card { padding:16px; }
  .chart { height:180px; }
  .dp { width:38px; }
  .block-temp { justify-content:flex-start; flex-basis:calc(100% - 60px); }
  .block .daypills { display:grid; grid-template-columns:repeat(7, 1fr); gap:5px; }
  .block .dp { width:auto; }
  .plan-tools .addbtn { flex-basis:100%; }
  .plan-tools .ghost { padding:12px 18px; justify-content:center; flex:1; }
  .sheet { top:auto; bottom:0; left:0; transform:none; width:100vw; height:92vh; max-height:92vh; border-radius:24px 24px 0 0; }
  /* sichtbare Höhe statt 100vh (in der App und im Browser liegen sonst Leisten über dem Fuß) */
  @supports (height:100dvh) { .sheet { height:92dvh; max-height:92dvh; } .sheet.pop { height:auto; } }
  .sheet-foot { padding-bottom:calc(16px + env(safe-area-inset-bottom)); }
  .dtabs { padding:0 10px; justify-content:space-between; }
  .dtab:not(.on) span { display:none; }
  .dtab { padding:11px 8px 12px; }
  .pseg span { font-size:13px; }
  .ptoggles { width:100%; }
  .ptoggle { flex:1; justify-content:center; }
  .snav:not(.on) span { display:none; }
  .si .t { display:none; }
  .si { padding:0 6px; }
}
/* ---------- Tabletmodus ---------- */
:host([tablet]) { height:100vh; height:100dvh; min-height:0; display:flex; flex-direction:column; overflow:hidden; }
/* als Dashboard (Strategie custom:hauswerk): unter der Kopfleiste von Home Assistant */
:host([embedded]) { min-height:calc(100vh - var(--header-height, 56px)); }
:host([embedded][tablet]) { height:calc(100vh - var(--header-height, 56px)); height:calc(100dvh - var(--header-height, 56px)); }
:host([tablet]) .top { position:relative; flex:none; padding-left:20px; padding-right:20px; }
:host([tablet]) .mtabs { display:flex !important; }
:host([tablet]) .top .ttl span { display:none; }
:host([tablet]) .app { flex:1; min-height:0; width:100%; max-width:none; margin:0; padding:10px 20px 0; display:flex; flex-direction:column; }
:host([tablet]) #main { order:1; flex:1; min-height:0; overflow:hidden; position:relative; }
:host([tablet]) #tdots { order:2; }
:host([tablet]) #chips { order:3; flex:none; }
:host([tablet]) .tpages { height:100%; overflow:hidden; touch-action:pan-y pinch-zoom; }
:host([tablet]) .tin { column-fill:auto; }
:host([tablet]) .tpages.tflip { animation:tflip .18s ease-out; }
@keyframes tflip { from { opacity:.35; } to { opacity:1; } }
:host([tablet]) .tpages article, :host([tablet]) .tpages .wdg, :host([tablet]) .tpages .srow, :host([tablet]) .tpages .hero,
:host([tablet]) .tpages .card:not(.sgroup) { break-inside:avoid; }
:host([tablet]) .tpages .sg-h { break-after:avoid; }
:host([tablet]) .tpages .rw-area { display:inline-block; vertical-align:top; margin:0 14px 0 0; max-width:100%; }
:host([tablet]) .tpages .rw-area .rw-grid { display:flex; flex-wrap:wrap; gap:12px; }
:host([tablet]) .tpages .rw-area .rw-c { width:300px; }
:host([tablet]) .tpages h3, :host([tablet]) .tpages .shead, :host([tablet]) .tpages .sub-h { break-after:avoid; }
.tdots { display:none; }
:host([tablet]) .tdots { display:flex; justify-content:center; gap:4px; min-height:22px; padding:8px 0 0; }
.tdots button { all:unset; cursor:pointer; width:12px; height:12px; border-radius:99px; background:var(--track); background-clip:content-box; padding:12px 10px; margin:-12px 0; transition:width .15s; }
.tdots button.on { width:30px; background:var(--accent); background-clip:content-box; }
:host([tablet]) .bnav { display:none !important; }
/* Unterleiste unten: groß zum Antippen */
:host([tablet]) #chips nav { margin:8px 0 calc(10px + env(safe-area-inset-bottom)); padding:6px; gap:6px; }
:host([tablet]) #chips nav button { padding:14px 12px; font-size:16px; }
:host([tablet]) #chips nav button ha-icon { --mdc-icon-size:22px; }
:host([tablet]) .app { padding-bottom:0; }
:host([tablet]) .savebar { position:sticky; bottom:0; }
.saver { position:fixed; inset:0; z-index:50; background:#000; color:#e5e7eb; display:grid; place-items:center; cursor:pointer; user-select:none; }
.saver[hidden] { display:none; }
.saver .sv-in { display:flex; flex-direction:column; align-items:center; gap:min(1.6vh, 14px); max-height:94vh; text-align:center; opacity:.62; transition:transform 2s ease; max-width:92vw; }
.saver.night .sv-in { opacity:.32; }
.sv-time { font-size:min(18vw, 24vh); line-height:.95; font-weight:200; letter-spacing:-.02em; font-variant-numeric:tabular-nums; }
.sv-date { font-size:min(3.4vw, 5vh); font-weight:500; text-transform:capitalize; color:#cbd5e1; }
.sv-wx { display:flex; align-items:center; gap:12px; font-size:min(2.8vw, 4vh); color:#cbd5e1; }
.sv-wx ha-icon { --mdc-icon-size:min(5vw, 7vh); }
.sv-wx b { font-size:min(4.2vw, 6vh); font-weight:500; color:#e5e7eb; }
.sv-mods { display:flex; flex-wrap:wrap; justify-content:center; gap:10px 28px; margin-bottom:min(2.4vh, 22px); }
.sv-mod { display:flex; align-items:center; gap:12px; font-size:min(1.9vw, 2.7vh); color:#cbd5e1; }
.sv-logo { display:inline-flex; width:min(2.6vw, 3.6vh); height:min(2.6vw, 3.6vh); }
.sv-logo .mlogo, .sv-logo svg { width:100%; height:100%; border-radius:22%; filter:saturate(.7); }
.sv-i { display:inline-flex; align-items:center; gap:5px; }
.sv-i ha-icon { --mdc-icon-size:min(2vw, 2.8vh); color:#94a3b8; }
.sv-i b { font-weight:600; font-variant-numeric:tabular-nums; }
.sv-next ha-icon:nth-of-type(2) { margin-left:4px; }
.sv-facts { display:flex; flex-wrap:wrap; justify-content:center; gap:10px 26px; font-size:min(2.2vw, 3.2vh); color:#94a3b8; }
.sv-facts span { display:flex; align-items:center; gap:8px; }
.sv-facts ha-icon { --mdc-icon-size:min(2.8vw, 4vh); }
.sv-hints { display:flex; flex-direction:column; gap:8px; margin-top:6px; min-width:min(60vw, 720px); }
.sv-h { display:flex; align-items:center; gap:12px; padding:min(1vh, 10px) 16px; border-radius:14px; background:rgba(255,255,255,.06); text-align:left; font-size:min(1.6vw, 2.3vh); }
.sv-h ha-icon { --mdc-icon-size:min(2.2vw, 3vh); color:#94a3b8; }
.sv-h.warn ha-icon { color:#fbbf24; }
.sv-h b { display:block; font-weight:600; }
.sv-h small { display:block; color:#94a3b8; font-size:.8em; }
.sv-h.new { background:rgba(251,191,36,.16); box-shadow:0 0 0 2px rgba(251,191,36,.55); animation:svpulse 2s ease-in-out infinite; }
@keyframes svpulse { 50% { box-shadow:0 0 0 6px rgba(251,191,36,.15); } }
.saver .sv-more { color:#64748b; }
.sv-tap { margin-top:8px; font-size:13px; color:#475569; }
.sv-time.small { font-size:min(9vw, 12vh); font-weight:300; }
.saver.black .sv-in { opacity:.3; }
.saver.alert .sv-in { opacity:.92; }
.sv-fc { display:flex; gap:14px; margin-left:18px; padding-left:18px; border-left:1px solid rgba(255,255,255,.15); }
.sv-fc span { display:flex; flex-direction:column; align-items:center; gap:2px; font-size:min(1.8vw, 2.6vh); }
.sv-fc small { color:#64748b; font-size:.8em; }
.sv-fc ha-icon { --mdc-icon-size:min(2.6vw, 3.6vh); color:#94a3b8; }
.sv-fc b { font-size:1em !important; }
.sv-urgent { display:flex; flex-direction:column; gap:8px; min-width:min(70vw, 820px); }
.sv-u { display:flex; align-items:center; gap:12px; padding:min(1vh, 10px) 16px; border-radius:14px; background:rgba(251,146,60,.16); border:1px solid rgba(251,146,60,.45); text-align:left; font-size:min(1.7vw, 2.4vh); color:#fed7aa; }
.sv-u ha-icon { --mdc-icon-size:min(2.6vw, 3.6vh); color:#fb923c; }
.sv-u b { display:block; }
.sv-u small { display:block; color:#fdba74; font-size:.8em; }
.sv-u.new { animation:svpulse 2s ease-in-out infinite; box-shadow:0 0 0 2px rgba(251,146,60,.7); }
.sv-side { display:grid; grid-template-columns:repeat(2, minmax(0, 1fr)); gap:8px 26px; min-width:min(70vw, 820px); }
.sv-row { display:flex; align-items:center; gap:10px; text-align:left; font-size:min(1.5vw, 2.1vh); color:#cbd5e1; }
.sv-row ha-icon { --mdc-icon-size:min(2vw, 2.8vh); color:#64748b; }
.sv-row b { display:block; font-weight:600; }
.sv-row small { display:block; color:#94a3b8; font-size:.85em; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.warnline, .okline { display:flex; gap:8px; align-items:flex-start; }
.warnline ha-icon { color:#f59e0b; --mdc-icon-size:18px; flex:none; }
.okline ha-icon { color:#22c55e; --mdc-icon-size:18px; flex:none; }
.tstart { display:flex; align-items:center; gap:12px; padding:12px 14px; margin:0 0 10px; border-radius:14px; border:1px dashed color-mix(in srgb, var(--accent) 50%, var(--line)); background:color-mix(in srgb, var(--accent) 6%, var(--card)); }
.tstart b { display:block; }
.tstart small { display:block; color:var(--muted); }

/* ---------- Lage-Kachel (Kopf der Module) ---------- */
/* Tabletmodus: alle Kopfleisten gleich schmal (Höhe wie Kraftwerk) */
:host([tablet]) .brief { height:66px; box-sizing:border-box; overflow:hidden; display:flex; flex-direction:column; justify-content:center; }
:host([tablet]) .brief .br-head { position:absolute; right:14px; top:50%; transform:translateY(-50%); min-height:0; z-index:2; }
:host([tablet]) .brief .br-line { min-height:0; margin-top:0; padding-right:220px; }
:host([tablet]) .brief .br-lines { flex:none; padding-right:220px; }
:host([tablet]) .brief.card { padding:8px 14px !important; }
:host([tablet]) .brief .br-l { margin:0; }
:host([tablet]) .brief .br-line { flex-wrap:nowrap; min-width:0; gap:10px; }
:host([tablet]) .brief .br-h { white-space:nowrap; overflow:hidden; text-overflow:ellipsis; min-width:0; }
:host([tablet]) .brief .br-h span { overflow:hidden; text-overflow:ellipsis; }
:host([tablet]) .brief .br-big { font-size:19px !important; line-height:1.1; }
:host([tablet]) .brief .br-big span { font-size:11px !important; }
:host([tablet]) .brief .br-top { min-height:0; }
:host([tablet]) .brief .wx b { font-size:15px; }
:host([tablet]) .brief .wx ha-icon { --mdc-icon-size:20px !important; }
:host([tablet]) .brief.hero { padding-top:8px !important; padding-bottom:8px !important; }
:host([tablet]) .brief .br-lines { flex-wrap:nowrap !important; overflow:hidden; margin-top:4px !important; }
:host([tablet]) .brief .br-l { white-space:nowrap; flex:none; }
:host([tablet]) .brief .wx { padding:0 !important; }
:host([tablet]) .brief .wx div { display:flex; align-items:baseline; gap:6px; }
:host([tablet]) .brief .wx small { display:none; }
:host([tablet]) .brief .wx small:first-of-type { display:inline; }
:host([tablet]) .brief .rw-all .secondary { padding:5px 10px !important; font-size:13px; }
/* Tabletmodus: Kachel-Raster mit 2 Reihen je Seite – Räume und Rollläden gleich proportioniert */
:host([tablet]) .tgrid { display:grid !important; gap:12px; }
:host([tablet]) .tgrid > * { height:100%; box-sizing:border-box; overflow:hidden; width:auto !important; margin:0; }
.rw-al { display:block; font-size:11px; text-transform:uppercase; letter-spacing:.06em; color:var(--muted); }
/* Tabletmodus: dezent – eine Zeile mit Stand, Hinweise als kleine Zeile, ohne Hintergrundbild */
:host([tablet]) .brief { padding:10px 14px !important; margin-bottom:10px; border-left-width:3px !important; background:var(--card) !important; color:var(--text) !important; box-shadow:none !important; border-radius:14px; }
:host([tablet]) .brief.hero::before, :host([tablet]) .brief.hero::after { display:none !important; }
:host([tablet]) .brief .br-top { align-items:center; gap:12px; }
:host([tablet]) .brief .br-label { display:none; }
:host([tablet]) .brief .br-big { font-size:26px; }
:host([tablet]) .brief .br-big span { font-size:12px; }
:host([tablet]) .brief .br-h { font-size:15px; font-weight:600; }
:host([tablet]) .brief .br-h ha-icon { --mdc-icon-size:19px; }
:host([tablet]) .brief .br-lines { flex-direction:row; flex-wrap:wrap; gap:4px 16px; margin-top:6px; }
:host([tablet]) .brief .br-l { padding:2px 0; font-size:12.5px; color:var(--muted); }
:host([tablet]) .brief .br-l:nth-child(n+3) { display:none; }
:host([tablet]) .brief .br-l .br-go { display:none; }
:host([tablet]) .brief .br-l > ha-icon:first-child { --mdc-icon-size:15px; }
:host([tablet]) .brief .br-chips { display:none; }
:host([tablet]) .brief .wx { padding:6px 10px; background:none; }
:host([tablet]) .brief .wx ha-icon { --mdc-icon-size:22px; }
:host([tablet]) .brief .wx small:last-child { display:none; }
:host([tablet]) .brief .rw-all .secondary { padding:6px 10px; }
.brief { position:relative; margin-bottom:14px; border-left:4px solid var(--tone) !important; }
/* Modulthema: Farbe wie das Modul-Logo (Heizwerk orange, Rollwerk blau, Kraftwerk gelb) */
.brief.br-mod-heat { --mc:#ea580c; --mc2:#fdba74; }
.brief.br-mod-rw { --mc:#0284c7; --mc2:#7dd3fc; }
.brief.br-mod-kw { --mc:#d97706; --mc2:#fde047; }
.brief.br-mod-lw { --mc:#4f46e5; --mc2:#a5b4fc; }
:host([dark]) .brief.br-mod-heat { --mc:#fb923c; }
:host([dark]) .brief.br-mod-rw { --mc:#38bdf8; }
:host([dark]) .brief.br-mod-kw { --mc:#fbbf24; }
:host([dark]) .brief.br-mod-lw { --mc:#a5b4fc; }
.brief[class*="br-mod-"] { background:
    radial-gradient(120% 140% at 100% 0%, color-mix(in srgb, var(--mc2) 26%, transparent), transparent 60%),
    linear-gradient(135deg, color-mix(in srgb, var(--mc) 9%, var(--card)), var(--card) 70%) !important;
  border-color:color-mix(in srgb, var(--mc) 28%, var(--line)); }
.brief[class*="br-mod-"] .br-label, .brief[class*="br-mod-"] .br-label ha-icon { color:var(--mc); font-weight:600; }
.brief[class*="br-mod-"] .br-big { color:var(--mc); }
.brief[class*="br-mod-"] .br-c { background:color-mix(in srgb, var(--mc) 10%, transparent); }
:host([tablet]) .brief[class*="br-mod-"] { background:linear-gradient(90deg, color-mix(in srgb, var(--mc) 14%, var(--card)), var(--card) 65%) !important; }
/* gleiche Größe in allen Modulen */
.brief.card { padding:14px 18px; height:204px; box-sizing:border-box; display:flex; flex-direction:column; overflow:hidden; }
.br-head { display:flex; align-items:center; gap:10px; min-height:30px; }
.br-label { display:flex; align-items:center; gap:6px; font-size:12.5px; color:var(--muted); }
.br-label ha-icon { --mdc-icon-size:16px; }
.br-line { display:flex; align-items:center; gap:14px; min-height:52px; min-width:0; margin-top:2px; }
.br-big { font-size:40px; font-weight:700; line-height:1; letter-spacing:-.02em; white-space:nowrap; flex:none; }
.br-big span { font-size:15px; font-weight:500; margin-left:4px; color:var(--muted); letter-spacing:0; }
.br-h { all:unset; display:flex; align-items:center; gap:10px; min-width:0; font-size:17px; font-weight:700; line-height:1.3; }
.br-h span { display:-webkit-box; -webkit-line-clamp:2; -webkit-box-orient:vertical; overflow:hidden; }
button.br-h { cursor:pointer; }
.br-h ha-icon { --mdc-icon-size:24px; color:var(--tone); flex:none; }
.br-lines { flex:1; min-height:0; display:flex; flex-direction:column; gap:0; margin-top:6px; overflow:hidden; }
.br-l { all:unset; box-sizing:border-box; display:flex; align-items:center; gap:10px; padding:4px 8px; margin:0 -8px; border-radius:10px; font-size:13.5px; line-height:1.35; min-width:0; }
.br-l .grow { overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
button.br-l { cursor:pointer; }
button.br-l:hover { background:color-mix(in srgb, var(--text) 6%, transparent); }
.br-l > ha-icon:first-child { --mdc-icon-size:18px; color:var(--c); flex:none; }
.br-l .br-go { --mdc-icon-size:18px; opacity:.45; flex:none; }
.br-chips { display:flex; flex-wrap:nowrap; gap:8px; margin-top:8px; overflow:hidden; flex:none; }
.br-c { display:inline-flex; align-items:baseline; gap:6px; padding:6px 11px; border-radius:12px; background:color-mix(in srgb, var(--text) 6%, transparent); font-size:13px; flex:none; white-space:nowrap; }
.br-c ha-icon { --mdc-icon-size:16px; align-self:center; color:var(--c, var(--muted)); }
.br-c b { font-size:14.5px; }
.br-c small { color:var(--muted); }
.br-wx { display:inline-flex; align-items:center; gap:6px; font-size:13px; }
.br-wx ha-icon { --mdc-icon-size:22px; color:#f59e0b; }
.br-wx small { color:var(--muted); }
.br-acts { display:inline-flex; gap:6px; }
.br-act { all:unset; cursor:pointer; display:inline-flex; align-items:center; gap:4px; height:30px; padding:0 10px; border-radius:9px; border:1px solid var(--line); background:var(--card2, transparent); font-size:12.5px; font-weight:600; }
.br-act ha-icon { --mdc-icon-size:17px; }
.br-act:hover { border-color:var(--accent); }
@media (max-width:600px) {
  .brief.card { height:232px; padding:12px 14px; }
  .br-big { font-size:32px; }
  .br-h { font-size:15.5px; }
  .br-line { gap:10px; }
  .br-wx small { display:none; }
  .br-chips { -webkit-mask-image:linear-gradient(90deg, #000 85%, transparent); mask-image:linear-gradient(90deg, #000 85%, transparent); }
}

/* ---------- Rollläden kompakt ---------- */
.rw-grid.compact { display:grid; grid-template-columns:repeat(auto-fill, minmax(170px, 1fr)); gap:10px; }
.rw-m { padding:12px 12px 10px; cursor:pointer; display:flex; flex-direction:column; gap:8px; }
.rw-m.bad { opacity:.6; }
.rwm-top { display:flex; align-items:center; gap:6px; }
.rwm-top b { flex:1; min-width:0; font-size:14px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.rwm-top ha-icon { --mdc-icon-size:18px; flex:none; }
.rwm-pos { display:flex; align-items:center; gap:10px; }
.rwm-pos b { font-size:20px; font-variant-numeric:tabular-nums; white-space:nowrap; }
.rwm-win { --v:50; position:relative; width:26px; height:32px; flex:none; border-radius:5px; border:2px solid color-mix(in srgb, var(--muted) 50%, transparent); background:linear-gradient(160deg, #e0f2fe, #7dd3fc); overflow:hidden; }
.rwm-win i { position:absolute; left:0; right:0; top:0; height:calc((100 - var(--v)) * 1%); background:repeating-linear-gradient(180deg, #94a3b8 0 4px, #64748b 4px 5px); }
.rwm-win em { position:absolute; left:-2px; right:-2px; top:calc((100 - var(--t)) * 1%); height:0; border-top:2px dashed #f97316; }
.rwm-win.big { width:34px; height:42px; border-radius:7px; }
.rwm-nx { margin-left:auto; display:inline-flex; align-items:center; gap:3px; font-size:12px; color:var(--muted); white-space:nowrap; font-variant-numeric:tabular-nums; }
.rwm-nx ha-icon { --mdc-icon-size:13px; }
.nk-tabs { display:flex; margin-bottom:14px; }
.nk-tabs .seg { flex:1; }
.nk-badge { font-style:normal; background:#ef4444; color:#fff; border-radius:9px; padding:0 6px; font-size:11px; margin-left:4px; }
.nk-tpl { display:flex; flex-wrap:wrap; gap:6px; align-items:center; margin-bottom:12px; }
.nk-tpl small { color:var(--muted); font-weight:600; font-size:12px; margin-right:4px; }
.nk-view { margin-bottom:10px; }
.nk-g { margin-bottom:14px; }
.nk-gh { display:flex; align-items:center; gap:8px; font-size:12px; font-weight:800; letter-spacing:.06em; text-transform:uppercase; color:var(--c); margin:0 0 6px; }
.nk-k { border:1px solid var(--line); border-left:3px solid var(--c); border-radius:12px; margin-bottom:6px; background:var(--card); }
.nk-k.off { opacity:.62; }
.nk-h { display:flex; align-items:center; gap:8px; padding-right:10px; }
.nk-sum { all:unset; cursor:pointer; flex:1; min-width:0; display:flex; align-items:center; gap:10px; padding:10px 12px; }
.nk-sum b { display:block; font-size:14px; }
.nk-sum small { display:block; color:var(--muted); font-size:12px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.nk-k.open .nk-sum small { white-space:normal; }
.nk-imp { --mdc-icon-size:14px; color:#ef4444; vertical-align:-2px; }
.nk-chev { color:var(--muted); --mdc-icon-size:20px; }
.nk-body { padding:0 12px 12px; display:flex; flex-direction:column; gap:8px; }
.nk-prev { display:flex; flex-direction:column; gap:6px; }
.nk-phone { display:flex; align-items:center; gap:10px; padding:10px 12px; border-radius:16px; background:var(--card2); box-shadow:0 1px 3px rgba(0,0,0,.12); max-width:420px; }
.nk-phone > ha-icon { --mdc-icon-size:22px; color:#18bcf2; }
.nk-phone b { display:block; font-size:13.5px; }
.nk-phone small { display:block; font-size:12.5px; color:var(--muted); }
.nk-phone em { font-style:normal; font-size:11px; color:var(--muted); align-self:flex-start; }
.nk-pa { display:flex; gap:6px; flex-wrap:wrap; }
.nk-tbl-w { overflow-x:auto; margin-bottom:6px; }
.nk-tbl { border-collapse:collapse; width:100%; font-size:13px; }
.nk-tbl th { font-size:11.5px; font-weight:700; color:var(--muted); text-align:center; padding:6px 4px; white-space:nowrap; }
.nk-tbl th:first-child, .nk-tbl td:first-child { text-align:left; }
.nk-tbl td { border-top:1px solid var(--line); padding:4px; text-align:center; white-space:nowrap; }
.nk-tbl td:first-child ha-icon { --mdc-icon-size:17px; margin-right:6px; vertical-align:-3px; }
.nk-tbl select { font-size:12px; padding:2px 4px; }
.nk-tg td { font-size:11px; font-weight:800; letter-spacing:.06em; text-transform:uppercase; color:var(--muted); padding-top:10px; border-top:none; }
.nk-cell { width:30px; height:30px; border-radius:8px; border:1px solid var(--line2); background:none; color:transparent; cursor:pointer; display:inline-grid; place-items:center; }
.nk-cell ha-icon { --mdc-icon-size:18px; }
.nk-cell.on { background:#0ea5e9; border-color:#0ea5e9; color:#fff; }
.nk-dot { display:inline-block; width:8px; height:8px; border-radius:50%; background:var(--line2); margin-right:5px; vertical-align:1px; }
.nk-dot.ok { background:#22c55e; } .nk-dot.bad { background:#ef4444; }
.nk-cards { display:grid; grid-template-columns:repeat(auto-fill,minmax(280px,1fr)); gap:10px; margin-bottom:12px; }
.nk-card { border:1px solid var(--line); border-radius:14px; padding:12px; display:flex; flex-direction:column; gap:8px; background:var(--card); }
.nk-card.bad { border-color:#ef4444; }
.nk-card.paused { opacity:.72; border-style:dashed; }
.nk-card.paused .nk-kinds, .nk-card.paused .nk-opts { filter:grayscale(1); }
.nk-card .nk-hs { display:flex; align-items:center; gap:6px; margin-top:-4px; }
.nk-card .nk-hs ha-icon { --mdc-icon-size:16px; }
.nk-whohead { display:flex; align-items:center; gap:8px; margin-bottom:10px; }
.nk-addsec { border:1px solid var(--line); border-radius:14px; padding:4px 12px; margin-top:8px; scroll-margin-top:8px; }
.nk-addsec.open { padding-bottom:12px; border-color:#0ea5e9; }
.nk-addh { all:unset; cursor:pointer; display:flex; align-items:center; gap:8px; width:100%; padding:8px 0; font-weight:700; font-size:14px; color:#0ea5e9; }
.nk-tbl th.paused { opacity:.55; text-decoration:line-through; }
.nk-ch { display:flex; align-items:center; gap:10px; }
.nk-ch > ha-icon { --mdc-icon-size:22px; color:#0ea5e9; }
.nk-ch b { display:block; font-size:14px; } .nk-ch small { display:block; color:var(--muted); font-size:11.5px; }
.nk-hs { font-size:11.5px; color:var(--muted); white-space:nowrap; }
.nk-err { margin:0; font-size:12px; color:#ef4444; display:flex; gap:6px; align-items:center; }
.nk-kinds { justify-content:flex-start; }
.nk-kinds .pchip { font-size:12px; }
.nk-o .segs { display:inline-flex; flex-direction:row; width:auto; flex:none; }
.nk-o .segs .seg { flex:none; width:auto; padding:0 12px; }
.nk-o .nrow { display:flex; align-items:center; gap:6px; }
.pchip.ro { cursor:default; opacity:.8; }
.nk-opts { display:flex; flex-direction:column; gap:6px; }
.nk-o { display:flex; align-items:center; gap:8px; flex-wrap:wrap; font-size:13px; }
.nk-o > span:first-child { min-width:60px; color:var(--muted); }
.nk-o small { display:block; font-size:11px; color:var(--muted); }
.nk-ca { display:flex; justify-content:space-between; align-items:center; }
.nk-stats { display:grid; grid-template-columns:repeat(4,1fr); gap:6px; margin-bottom:12px; }
.nk-stats span { border-radius:12px; padding:8px; background:color-mix(in srgb, var(--c) 12%, transparent); text-align:center; }
.nk-stats b { display:block; font-size:20px; color:var(--c); }
.nk-stats small { font-size:11px; color:var(--muted); }
.nk-hist { display:flex; flex-direction:column; gap:6px; margin-bottom:8px; }
.nk-hr { display:flex; gap:10px; align-items:flex-start; }
.nk-hr b { display:block; font-size:13px; } .nk-hr small { display:block; font-size:12px; }
.nk-hr em { font-style:normal; font-size:12px; color:var(--muted); }
@media (max-width:560px) { .nk-stats { grid-template-columns:repeat(2,1fr); } .nk-tabs .seg { font-size:12px; padding:0 6px; } }
.block .blk-no { font-size:11px; font-weight:800; letter-spacing:.06em; text-transform:uppercase; color:var(--muted); margin-bottom:6px; }
.block.conflict { box-shadow:0 0 0 2px #ef4444 inset; }
.block.ecoblk { background:color-mix(in srgb, #60a5fa 8%, var(--card)); }
.blk-kind-row { display:flex; align-items:center; gap:10px; flex-wrap:wrap; margin:8px 0 2px; }
.blk-kind { display:inline-flex; flex-direction:row; width:auto; flex:none; }
.blk-kind .seg { flex:none; width:auto; padding:0 12px; }
.blk-eco { color:#60a5fa; font-size:20px; }
.blk-conf { display:flex; gap:8px; align-items:center; flex-wrap:wrap; margin:8px 0 2px; padding:8px 10px; border-radius:10px; background:color-mix(in srgb, #ef4444 12%, transparent); color:#ef4444; font-size:12.5px; font-weight:600; }
.plan-conf small { display:block; margin-top:3px; }
.plan-rules { margin-top:10px; }
.dseg.ecow { background-image:repeating-linear-gradient(135deg, rgba(255,255,255,.35) 0 3px, transparent 3px 7px) !important; }
.ecow-i { background:#93c5fd repeating-linear-gradient(135deg, rgba(255,255,255,.5) 0 2px, transparent 2px 5px); }
.rs-why { display:flex; gap:6px; align-items:center; font-size:12px; color:var(--muted); margin-top:4px; }
.rs-why ha-icon { --mdc-icon-size:15px; flex:none; }
.rq-why { display:flex; gap:10px; align-items:flex-start; padding:10px 12px; border-radius:12px; background:var(--card2); margin:8px 0; }
.rq-why b { display:block; font-size:13px; } .rq-why small { display:block; font-size:12.5px; }
.lw-c.on { box-shadow:inset 0 0 0 1px color-mix(in srgb, var(--lc) 45%, transparent); }
.lw-bulb { width:46px; height:46px; flex:none; border-radius:14px; border:none; display:grid; place-items:center; cursor:pointer; background:var(--card2); color:var(--muted); }
.lw-bulb ha-icon { --mdc-icon-size:26px; }
.lw-bulb { position:relative; }
.lwsc-list { display:flex; flex-direction:column; gap:8px; margin:8px 0; }
.lwsc { display:grid; grid-template-columns:118px minmax(70px,1fr) 104px 124px 14px 36px; grid-template-areas:"t n b k d x"; gap:6px; align-items:center; padding:8px; border-radius:12px; background:var(--card2, transparent); }
.lwsc > :nth-child(1) { grid-area:t; } .lwsc > :nth-child(2) { grid-area:n; } .lwsc > :nth-child(3) { grid-area:b; }
.lwsc > :nth-child(4) { grid-area:k; } .lwsc > :nth-child(5) { grid-area:d; } .lwsc > :nth-child(6) { grid-area:x; }
.lwsc input { min-width:0; width:100%; box-sizing:border-box; }
.lwsc .unit { min-width:0; }
.lwsc-dot { width:14px; height:14px; border-radius:50%; box-shadow:0 0 0 1px var(--line); }
@media (max-width:560px) { .lwsc { grid-template-columns:minmax(0,1fr) minmax(0,1fr) 14px 36px; grid-template-areas:"t n d x" "b k k k"; } }
.lw-room .lwr-list { display:flex; flex-direction:column; gap:2px; margin-top:8px; }
.lw-room .lwr { display:flex; align-items:center; gap:8px; padding:6px 4px; border-top:1px solid var(--line); }
.lw-room .lwr:first-child { border-top:none; }
.lw-room .lwr > ha-icon { --mdc-icon-size:20px; flex:none; }
.lw-room .lwr .lwr-n { all:unset; cursor:pointer; flex:1; min-width:0; display:flex; flex-direction:column; }
.lw-room .lwr .lwr-n b { font-weight:600; font-size:14px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.lw-room .lwr .lwr-n small { color:var(--muted); font-size:12px; }
.lw-room .lwr .lwr-f { display:inline-flex; gap:4px; align-items:center; color:var(--muted); font-size:12px; font-variant-numeric:tabular-nums; }
.lw-room .lwr .lwr-f ha-icon { --mdc-icon-size:15px; }
.lwrep { display:flex; flex-direction:column; }
.lwrep-r { display:flex; align-items:center; gap:12px; padding:8px 0; border-top:1px solid var(--line); }
.lwrep-r:first-child { border-top:none; }
.lwrep-n { all:unset; cursor:pointer; flex:1; min-width:0; display:flex; flex-direction:column; }
.lwrep-n b { font-weight:600; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.lwrep-n small { color:var(--muted); font-size:12px; }
.lwrep-b { display:flex; gap:3px; height:40px; align-items:stretch; flex:none; }
.lwrep-b span { width:14px; display:flex; flex-direction:column; justify-content:flex-end; align-items:center; gap:2px; }
.lwrep-b i { width:100%; background:#6366f1; border-radius:3px 3px 1px 1px; }
.lwrep-b small { font-size:9px; color:var(--muted); line-height:1; }
.lw-offm { margin-left:auto; font-variant-numeric:tabular-nums; color:#22c55e; font-weight:600; }
.lw-mot { position:absolute; right:-5px; bottom:-5px; width:20px; height:20px; border-radius:50%; display:grid; place-items:center; background:var(--card); border:1.5px solid var(--line, var(--card2)); color:#22c55e; }
.lw-mot ha-icon { --mdc-icon-size:13px !important; }
.lw-bulb.on { background:color-mix(in srgb, var(--lc) 26%, var(--card2)); color:var(--lc); box-shadow:0 0 18px color-mix(in srgb, var(--lc) 45%, transparent); }
.lw-name { all:unset; cursor:pointer; min-width:0; display:block; }
.lw-name b { display:block; font-size:15px; } .lw-name small { display:block; color:var(--muted); font-size:12.5px; }
.lw-dim { display:flex; align-items:center; gap:8px; margin-top:6px; }
.lw-dim > ha-icon { color:var(--muted); --mdc-icon-size:18px; }
.lw-dim b { font-size:13px; min-width:44px; text-align:right; }
.lw-meter { flex:1; height:8px; border-radius:6px; background:var(--card2); overflow:hidden; }
.lw-meter i { display:block; height:100%; border-radius:6px; background:linear-gradient(90deg, color-mix(in srgb, var(--lc) 50%, transparent), var(--lc)); }
.lw-m .lw-mi { --mdc-icon-size:26px; color:var(--lc); }
.lwbar { position:relative; height:12px; border-radius:7px; overflow:hidden; margin:4px 0 2px; }
.lwbar.small { height:10px; }
.lwtrack { position:absolute; inset:0; background:color-mix(in srgb, #6366f1 10%, var(--card2)); }
.lwseg { position:absolute; top:0; bottom:0; background:linear-gradient(180deg, #fde047, #facc15); }
.lwseg.night { background:repeating-linear-gradient(135deg, rgba(99,102,241,.55) 0 3px, rgba(99,102,241,.25) 3px 7px); }
.lwbar .now { position:absolute; top:-2px; bottom:-2px; width:2px; background:var(--text); border-radius:1px; }
.lw-slider { display:flex; align-items:center; gap:12px; margin:10px 0; }
.lw-slider input { flex:1; accent-color:#6366f1; height:32px; }
.lw-slider b { font-size:18px; min-width:56px; text-align:right; }
.lw-pre { flex-wrap:wrap; }
.lw-presets { display:grid; grid-template-columns:repeat(auto-fill,minmax(210px,1fr)); gap:8px; margin:6px 0 10px; }
.lw-presets.small { grid-template-columns:repeat(auto-fill,minmax(150px,1fr)); }
.lw-preset { display:flex; gap:10px; align-items:center; text-align:left; padding:10px 12px; border-radius:12px; border:1px solid var(--line); background:var(--card); cursor:pointer; color:inherit; font:inherit; }
.lw-preset.on { border-color:#6366f1; box-shadow:0 0 0 1px #6366f1 inset; }
.lw-preset ha-icon { color:#6366f1; --mdc-icon-size:22px; flex:none; }
.lw-preset b { display:block; font-size:13.5px; } .lw-preset small { display:block; color:var(--muted); font-size:12px; }
.lwsum { margin:-4px 0 8px; }
.wnext { display:block; margin:-4px 0 6px; }
.hl-list { display:flex; flex-direction:column; gap:10px; }
.hl-room { border:1px solid var(--line); border-radius:12px; padding:10px 12px; display:flex; flex-direction:column; gap:6px; }
.hl-room > b { font-size:14px; }
.hl-w { display:flex; align-items:flex-start; gap:8px; flex-wrap:wrap; margin:4px 0; }
.hl-wn { display:inline-flex; align-items:center; gap:6px; font-weight:600; font-size:13px; }
.hl-wn ha-icon, .hl-p ha-icon { --mdc-icon-size:16px; }
.hl-arrow { --mdc-icon-size:16px; color:var(--muted); margin-top:2px; }
.hl-ps { display:flex; flex-wrap:wrap; gap:6px; flex:1; min-width:0; }
.hl-p { display:inline-flex; align-items:center; gap:5px; padding:3px 9px; border-radius:9px; font-size:12.5px; background:color-mix(in srgb, #0ea5e9 12%, transparent); }
.hl-p.out { background:var(--card2); color:var(--muted); }
.hl-none { font-style:normal; color:#f97316; font-size:12.5px; font-weight:600; }
@media (max-width:560px) { .hl-arrow { display:none; } .hl-ps { flex-basis:100%; padding-left:22px; } }
.lw-hl .hl-ps { padding-left:0 !important; }
.lg-colors { display:grid; grid-template-columns:repeat(auto-fill,minmax(150px,1fr)); gap:6px 12px; margin:4px 0 12px; }
.lg-c { display:grid; grid-template-columns:14px 1fr; column-gap:8px; align-items:center; align-content:start; font-size:13px; }
.lg-c b { font-size:13px; }
.lg-c i { width:12px; height:12px; border-radius:50%; background:var(--c); grid-row:span 2; box-shadow:0 0 0 3px color-mix(in srgb, var(--c) 22%, transparent); }
.lg-c small { color:var(--muted); font-size:11.5px; line-height:1.25; }
.lg-q { width:100%; box-sizing:border-box; margin:2px 0 6px; }
.lg-list { display:flex; flex-direction:column; gap:6px; margin-bottom:8px; }
.lg-r { display:flex; align-items:center; gap:10px; }
.lg-r b { display:block; font-size:13.5px; }
.lg-r small { display:block; color:var(--muted); font-size:12px; line-height:1.3; }
.lg-s { min-width:34px; justify-content:center; flex:none; }
.chpick { display:flex; flex-direction:column; gap:10px; margin:6px 0 12px; }
.chpick .pchips { justify-content:flex-start; }
.chg small { display:block; font-size:11.5px; color:var(--muted); font-weight:600; margin-bottom:4px; text-transform:uppercase; letter-spacing:.04em; }
.ch-tts { display:flex; gap:8px; flex-wrap:wrap; align-items:center; }
.ch-tts select { min-width:0; flex:1 1 140px; }
.ch-route summary { font-size:12.5px; }
.ch-own { display:flex; align-items:center; gap:8px; font-size:13px; margin:6px 0; }
.ap-c { padding:14px 16px; display:flex; flex-direction:column; gap:10px; margin:0; }
.ap-run { display:flex; flex-direction:column; gap:4px; }
.ap-run small { color:var(--muted); font-size:12.5px; }
.ap-run.ending .vt-bar i { background:#f59e0b; }
.ap-run.running .vt-bar i { background:#0ea5e9; }
.ap-run.done b { color:#16a34a; }
.ap-w { display:flex; align-items:center; gap:6px; font-size:12.5px; color:var(--muted); }
.ap-w ha-icon { --mdc-icon-size:15px; }
.ap-w .warn { color:#f59e0b; font-weight:600; }
.ap-acts { display:flex; flex-wrap:wrap; gap:8px; }
.ap-acts button { padding:8px 12px; min-height:0; font-size:13px; }
.ap-hist { display:flex; flex-direction:column; gap:3px; font-size:12px; color:var(--muted); }
.ap-hist b { color:var(--text); font-weight:600; margin-right:6px; }
.vt-grid { display:grid; grid-template-columns:repeat(auto-fill, minmax(300px, 1fr)); gap:14px; }
.vt-c { padding:14px 16px; display:flex; flex-direction:column; gap:10px; margin:0; cursor:pointer; }
.vt-h { display:flex; align-items:center; gap:8px; }
.vt-h b { flex:1; font-size:15.5px; min-width:0; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.vt-chip { display:inline-flex; align-items:center; gap:4px; font-size:12px; font-weight:700; color:var(--c); padding:3px 9px; border-radius:99px; background:color-mix(in srgb, var(--c) 14%, var(--card)); white-space:nowrap; }
.vt-chip ha-icon { --mdc-icon-size:14px; }
.vt-need, .vt-ok { display:flex; align-items:center; gap:10px; }
.vt-need ha-icon { --mdc-icon-size:26px; color:#0891b2; }
.vt-need span, .vt-run { display:flex; flex-direction:column; }
.vt-need small, .vt-run small { color:var(--muted); font-size:12.5px; }
.vt-ok { color:var(--muted); font-size:13px; }
.vt-ok ha-icon { color:#22c55e; }
.vt-run { gap:4px; }
.vt-bar { height:8px; border-radius:99px; background:var(--card2); overflow:hidden; }
.vt-bar i { display:block; height:100%; border-radius:inherit; background:#22c55e; transition:width .5s; }
.vt-run.done .vt-bar i { background:#ef4444; }
.vt-run.done b { color:#ef4444; }
.vt-f { display:flex; flex-wrap:wrap; gap:8px 16px; }
.vt-f span { display:flex; flex-direction:column; min-width:0; }
.vt-f b { font-size:15px; font-variant-numeric:tabular-nums; }
.vt-f span.on b { color:var(--c); }
.vt-f small { font-size:11.5px; color:var(--muted); }
.rw-info { display:flex; flex-wrap:wrap; gap:4px 12px; font-size:12px; color:var(--muted); }
.rw-info span { display:inline-flex; align-items:center; gap:4px; white-space:nowrap; min-width:0; }
.rw-info span.on { color:var(--c); font-weight:600; }
.rw-info ha-icon { --mdc-icon-size:14px; flex:none; }
.rw-info.in-ctl { margin-left:6px; flex:1; min-width:0; flex-wrap:nowrap; overflow:hidden; gap:10px; -webkit-mask-image:linear-gradient(90deg, #000 85%, transparent); mask-image:linear-gradient(90deg, #000 85%, transparent); }
.rw-info.in-ctl span { flex:none; }
.rwm-ctl { display:flex; gap:6px; }
.rwm-ctl .sbtn { flex:1; }
:host([tablet]) .tpages .rw-area.compact .rw-grid { display:flex; flex-wrap:wrap; }
:host([tablet]) .tpages .rw-area.compact .rw-m { width:190px; }

/* ---------- Anwesenheit kompakt (Widget) ---------- */
.pc-row { display:flex; gap:8px; flex-wrap:wrap; }
.pc-seg, .pc-tg { display:flex; gap:4px; padding:3px; border-radius:12px; background:color-mix(in srgb, var(--text) 5%, transparent); }
.pc-seg { flex:3 1 220px; }
.pc-tg { flex:2 1 150px; }
.pc-seg button, .pc-tg label { all:unset; box-sizing:border-box; flex:1; min-width:0; display:flex; flex-direction:column; align-items:center; gap:1px; padding:6px 4px; border-radius:9px; cursor:pointer; color:var(--muted); font-size:11px; font-weight:600; text-align:center; }
.pc-seg button span, .pc-tg label span { max-width:100%; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.pc-seg ha-icon, .pc-tg ha-icon { --mdc-icon-size:20px; }
.pc-tg input { position:absolute; opacity:0; pointer-events:none; }
.pc-seg button.on { background:var(--card); color:var(--text); box-shadow:0 1px 3px rgba(0,0,0,.12); }
.pc-seg button.on ha-icon { color:var(--wacc, var(--accent)); }
.pc-tg label.on { background:color-mix(in srgb, var(--accent) 16%, var(--card)); color:var(--text); }
.pc-tg label.on ha-icon { color:var(--accent); }
.pc-seg button[disabled], .pc-tg label:has(input[disabled]) { cursor:default; }
.pc-st { display:flex; align-items:center; gap:6px; margin:8px 2px 0; font-size:12px; color:var(--muted); }
.pc-st ha-icon { --mdc-icon-size:15px; flex:none; }
.pc-st span { overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.pc-ppl { display:flex; flex-wrap:wrap; gap:6px; margin-top:10px; }
.pc-p { display:inline-flex; align-items:center; gap:6px; padding:3px 10px 3px 3px; border-radius:99px; background:color-mix(in srgb, var(--text) 5%, transparent); font-size:13px; }
.pc-p .pav { width:26px; height:26px; flex:none; border-radius:99px; overflow:hidden; display:grid; place-items:center; background:var(--card2, #e2e8f0); font-size:12px; font-weight:700; box-shadow:0 0 0 2px var(--line); }
.pc-p.home .pav { box-shadow:0 0 0 2px #22c55e; }
.pc-p .pav img { width:100%; height:100%; object-fit:cover; }
.pc-p small { color:var(--muted); font-size:12px; display:inline-flex; }
.pc-p.home small { color:#16a34a; }
.pc-p small ha-icon { --mdc-icon-size:14px; }

/* ---------- Widgets: Lage, Ereignisse, Termine, Vorschläge ---------- */
.wlage { display:flex; flex-direction:column; gap:6px; }
.wl { all:unset; box-sizing:border-box; display:flex; align-items:center; gap:10px; padding:8px 10px; border-radius:12px; cursor:pointer; border-left:3px solid var(--c); background:color-mix(in srgb, var(--c) 7%, transparent); }
.wl b { display:block; font-size:13.5px; line-height:1.3; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.wl small { display:block; font-size:12px; color:var(--muted); overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.wlage.s .wl b { font-size:12.5px; }
.wl-logo { display:inline-flex; width:26px; height:26px; flex:none; }
.wl-logo .mlogo, .wl-logo svg { width:100%; height:100%; border-radius:7px; }
.wl-go { --mdc-icon-size:18px; opacity:.4; flex:none; }
.wev { display:flex; flex-direction:column; gap:2px; }
.we { all:unset; box-sizing:border-box; display:flex; align-items:center; gap:10px; padding:6px 4px; border-radius:10px; }
button.we { cursor:pointer; }
button.we:hover { background:color-mix(in srgb, var(--text) 5%, transparent); }
.we-t { width:66px; flex:none; font-size:13px; font-weight:700; font-variant-numeric:tabular-nums; color:var(--muted); }
.we ha-icon { --mdc-icon-size:18px; flex:none; }
.we b { display:block; font-size:13.5px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.we small { display:block; font-size:12px; color:var(--muted); overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.wcal { display:flex; flex-direction:column; gap:4px; }
.wc-d { font-size:11.5px; font-weight:700; text-transform:uppercase; letter-spacing:.06em; color:var(--muted); margin-top:4px; }
.wc-d:first-child { margin-top:0; }
.wc-e { display:flex; align-items:center; gap:10px; }
.wc-e b { flex:1; min-width:0; font-size:14px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.wc-e small { color:var(--muted); font-size:12px; }
.wc-i { width:30px; height:30px; border-radius:9px; display:grid; place-items:center; flex:none; background:color-mix(in srgb, var(--c) 16%, transparent); color:var(--c); }
.wc-i ha-icon { --mdc-icon-size:18px; }
.wsetup { display:flex; flex-direction:column; align-items:flex-start; gap:8px; }
.wsetup p { margin:0; }
.wsetup-b { display:flex; flex-wrap:wrap; gap:6px; }
.wsetup-b button { padding:6px 12px; font-size:13px; }
.wsug { display:flex; flex-wrap:wrap; gap:6px; }
.wsug span { display:inline-flex; align-items:center; gap:5px; padding:4px 9px; border-radius:99px; background:color-mix(in srgb, var(--text) 6%, transparent); font-size:12.5px; }
.wsug ha-icon { --mdc-icon-size:15px; color:var(--muted); }
.wlage-t span { overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.wl-sub { color:var(--muted); font-size:12.5px; }
.wl-sub span { overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.wshr { display:flex; flex-wrap:wrap; gap:8px 16px; margin-top:8px; }
.wsha > span { display:block; font-size:11px; color:var(--muted); margin-bottom:3px; }
.wsha > div { display:flex; gap:6px; }
.wsh { all:unset; cursor:pointer; display:flex; flex-direction:column; align-items:center; gap:2px; }
.wsh .rwm-win { width:22px; height:28px; }
.wsh[style*="--f"] .rwm-win { border-color:var(--f); }
.wsh small { font-size:11px; color:var(--muted); font-variant-numeric:tabular-nums; }
.wflow { display:flex; align-items:center; justify-content:space-between; gap:4px; margin:4px 0 8px; }
.wfn { display:flex; flex-direction:column; align-items:center; gap:1px; min-width:0; }
.wfn ha-icon { --mdc-icon-size:22px; color:var(--c); }
.wfn b { font-size:14px; white-space:nowrap; }
.wfn small { font-size:11px; color:var(--muted); }
.wfa { font-size:18px; color:var(--line); font-weight:700; }
.wfa.on { color:var(--accent); animation:wfa 1.6s ease-in-out infinite; }
@keyframes wfa { 50% { opacity:.4; } }

`;

customElements.get("hauswerk-panel") || customElements.define("hauswerk-panel", HauswerkPanel);
